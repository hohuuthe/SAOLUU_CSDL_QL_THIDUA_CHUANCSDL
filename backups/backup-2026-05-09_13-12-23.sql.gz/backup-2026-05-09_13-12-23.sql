--
-- PostgreSQL database dump
--

\restrict 3HCfSdS47hFWP9u2XTqb4d4QZwG9WMRG5FW0tpzpkwEkfjYrn2nybTlMO9MfLj4

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Enable read access for all users" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phancong";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."namhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."doanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Authenticated users can insert activity logs" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Admins can view all activity logs" ON "public"."activity_logs";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_chidoan";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_key";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_namhoc";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_namhoc";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_taikhoan_chidoan";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thoigian_context";
DROP INDEX IF EXISTS "public"."idx_chamdiem_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_12" DROP CONSTRAINT IF EXISTS "messages_2026_05_12_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_11" DROP CONSTRAINT IF EXISTS "messages_2026_05_11_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_10" DROP CONSTRAINT IF EXISTS "messages_2026_05_10_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_09" DROP CONSTRAINT IF EXISTS "messages_2026_05_09_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_08" DROP CONSTRAINT IF EXISTS "messages_2026_05_08_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_07" DROP CONSTRAINT IF EXISTS "messages_2026_05_07_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_06" DROP CONSTRAINT IF EXISTS "messages_2026_05_06_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_12";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_11";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_10";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_09";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_08";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_07";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_06";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "chidoan1111" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid"
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT * FROM taikhoan WHERE username = p_username OR username = lower(p_username) LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_
        -- Filter by action early - only get subscriptions interested in this action
        -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
        and (subs.action_filter = '*' or subs.action_filter = action::text);

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL AND ppt.tablename NOT LIKE '% %'),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  -- Count raw slot entries before apply_rls/subscription filter
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  -- Apply RLS and filter as before
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  -- Real rows with slot count attached
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  -- Sentinel row: always returned when no real rows exist so Elixir can
  -- always read slot_changes_count. Identified by wal IS NULL.
  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid"
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "hocky" "text",
    "diachi" "text",
    "chidoan_id" "uuid"
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text"
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "quyen_chi_doan_phu_trach" boolean DEFAULT false,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "quyen_xem_tat_ca_chi_doan" boolean DEFAULT false
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: COLUMN "phanquyen"."quyen_chi_doan_phu_trach"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."quyen_chi_doan_phu_trach" IS 'Giới hạn phạm vi dữ liệu chỉ trong chi đoàn của user';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid"
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid"
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text"
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_05_06; Type: TABLE; Schema: realtime; Owner: postgres
--

CREATE TABLE "realtime"."messages_2026_05_06" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_06" OWNER TO "postgres";

--
-- Name: messages_2026_05_07; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_07" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_07" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_08; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_08" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_08" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_09; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_09" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_09" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_10; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_10" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_10" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_11; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_11" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_11" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_12; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_12" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_12" OWNER TO "supabase_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_05_06; Type: TABLE ATTACH; Schema: realtime; Owner: postgres
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_06" FOR VALUES FROM ('2026-05-06 00:00:00') TO ('2026-05-07 00:00:00');


--
-- Name: messages_2026_05_07; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_07" FOR VALUES FROM ('2026-05-07 00:00:00') TO ('2026-05-08 00:00:00');


--
-- Name: messages_2026_05_08; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_08" FOR VALUES FROM ('2026-05-08 00:00:00') TO ('2026-05-09 00:00:00');


--
-- Name: messages_2026_05_09; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_09" FOR VALUES FROM ('2026-05-09 00:00:00') TO ('2026-05-10 00:00:00');


--
-- Name: messages_2026_05_10; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_10" FOR VALUES FROM ('2026-05-10 00:00:00') TO ('2026-05-11 00:00:00');


--
-- Name: messages_2026_05_11; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_11" FOR VALUES FROM ('2026-05-11 00:00:00') TO ('2026-05-12 00:00:00');


--
-- Name: messages_2026_05_12; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_12" FOR VALUES FROM ('2026-05-12 00:00:00') TO ('2026-05-13 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	{"sub": "c8c61706-f5fc-4032-8c18-e97fa2c9a8cf", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": false, "phone_verified": false}	email	2026-05-03 21:59:40.913289+00	2026-05-03 21:59:40.91334+00	2026-05-03 21:59:40.91334+00	c3bec671-43bc-4b8f-b749-dbd00cb9ee43
b94273ee-bc95-4b0d-987f-b2b3655199f8	b94273ee-bc95-4b0d-987f-b2b3655199f8	{"sub": "b94273ee-bc95-4b0d-987f-b2b3655199f8", "email": "hs0001@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-04 04:05:54.174721+00	2026-05-04 04:05:54.174772+00	2026-05-04 04:05:54.174772+00	e033e3d5-eecf-4773-8a76-0da333de45f6
9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	{"sub": "9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc", "email": "bithu@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-04 04:21:34.362341+00	2026-05-04 04:21:34.362729+00	2026-05-04 04:21:34.362729+00	40946340-849e-4531-b533-293c8056e024
993e879a-890f-4ed0-8b66-9d6961212f0e	993e879a-890f-4ed0-8b66-9d6961212f0e	{"sub": "993e879a-890f-4ed0-8b66-9d6961212f0e", "email": "bithu@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": false, "phone_verified": false}	email	2026-05-04 07:34:16.173352+00	2026-05-04 07:34:16.173402+00	2026-05-04 07:34:16.173402+00	7cda7096-65a2-493b-bbaf-b2af3ab992a7
351d73d3-961d-4f8e-9f6d-d1c06092384a	351d73d3-961d-4f8e-9f6d-d1c06092384a	{"sub": "351d73d3-961d-4f8e-9f6d-d1c06092384a", "email": "bithu_10a2@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-07 11:30:48.424825+00	2026-05-07 11:30:48.426047+00	2026-05-07 11:30:48.426047+00	c4601588-8f9f-4a2c-a07a-02c55d9ed9aa
f1442181-b297-4857-a22a-63ce695149ec	f1442181-b297-4857-a22a-63ce695149ec	{"sub": "f1442181-b297-4857-a22a-63ce695149ec", "email": "vothile1@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-09 01:29:43.768617+00	2026-05-09 01:29:43.768674+00	2026-05-09 01:29:43.768674+00	a3ac956a-afde-4561-8328-839e32f0c001
abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd	abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd	{"sub": "abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd", "email": "huynhhuuthua@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-09 08:58:50.787873+00	2026-05-09 08:58:50.787924+00	2026-05-09 08:58:50.787924+00	329ddf57-a318-44a5-a826-6612b8856226
1e4c7fef-312b-4cc1-85ce-465a4bc313bf	1e4c7fef-312b-4cc1-85ce-465a4bc313bf	{"sub": "1e4c7fef-312b-4cc1-85ce-465a4bc313bf", "email": "hohuuthe@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-09 09:08:33.121227+00	2026-05-09 09:08:33.121673+00	2026-05-09 09:08:33.121673+00	01cb921c-76f9-4f92-a5fc-87dc49f97aa3
9d05e348-d145-44a9-be0e-6021aa2e4efe	9d05e348-d145-44a9-be0e-6021aa2e4efe	{"sub": "9d05e348-d145-44a9-be0e-6021aa2e4efe", "email": "gvcn_11c8@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-09 09:25:43.197162+00	2026-05-09 09:25:43.199048+00	2026-05-09 09:25:43.199048+00	b2b977bd-852d-4c1d-94c4-e8aee6f93f86
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
c9bd9518-36c0-4bd4-b287-c4190cf31174	2026-05-03 11:24:24.662015+00	2026-05-03 11:24:24.662015+00	password	4efd528c-207c-4e64-b7b2-1593a9e703aa
877e603a-e33e-4174-ae45-c7ac680ec478	2026-05-03 11:25:27.047016+00	2026-05-03 11:25:27.047016+00	password	d344ce94-cf45-4321-b7ae-fce9017294a9
6dc6675e-1cba-4b8f-8b8d-bee264b5e143	2026-05-03 13:11:29.647918+00	2026-05-03 13:11:29.647918+00	password	6063c210-b928-456c-989c-ed9032157780
eaf7495a-26f9-41fe-8389-4123eb7ea505	2026-05-03 14:17:39.102121+00	2026-05-03 14:17:39.102121+00	password	92a86657-3d11-4cf0-a64b-11d2e9c5c0cc
58a4a49f-3b69-4132-9d05-5f735f096f88	2026-05-03 14:24:39.200394+00	2026-05-03 14:24:39.200394+00	password	3189fee7-42c6-4289-9f65-8099e1ec2cef
a9f71761-0c48-4f61-92aa-cfafec4854f7	2026-05-03 14:35:52.341041+00	2026-05-03 14:35:52.341041+00	password	80829dc5-0cd1-4d80-99fa-77d63601e291
8640120a-6292-43b0-8f93-ef41687a520f	2026-05-03 21:59:40.986672+00	2026-05-03 21:59:40.986672+00	password	2653661c-6592-4486-9005-af0226c045c8
4bc16c81-b338-47e3-a393-8d7def5ae6da	2026-05-03 22:56:30.505317+00	2026-05-03 22:56:30.505317+00	password	50ff8a96-9166-4f32-b36c-af743b2be6a6
0f9530a7-f3ef-4981-aa6b-c118d24d7962	2026-05-03 23:00:04.087649+00	2026-05-03 23:00:04.087649+00	password	fd48a62f-fb0d-4ed0-8b07-ad2914560e4c
93c745be-708f-494a-9b2a-af0010658877	2026-05-03 23:00:47.49235+00	2026-05-03 23:00:47.49235+00	password	5e7c61be-f3f4-4bee-880d-a78c2ab918fc
2ee8f239-f4d4-4d4b-8bee-3887d74e1df0	2026-05-03 23:05:47.915662+00	2026-05-03 23:05:47.915662+00	password	108308f6-731c-4cf7-aba4-37978af57ab8
1aec8fd1-a225-4424-aa52-bf474b5b60fb	2026-05-03 23:28:32.249168+00	2026-05-03 23:28:32.249168+00	password	27d240e0-15ce-423c-87c8-a72b7b86cb67
435a59ac-6009-4552-b2d4-387fa2b26002	2026-05-03 23:28:34.222732+00	2026-05-03 23:28:34.222732+00	password	104218d5-19d6-4456-99f6-d4caa00d88f0
f686e532-34f1-492f-a3a4-08197c6cf178	2026-05-03 23:36:38.53328+00	2026-05-03 23:36:38.53328+00	password	6a83688a-8cb0-42e9-bb69-de1fad0a0d5b
ea5a8b32-117a-4b45-9ae4-f677623e00d0	2026-05-03 23:36:54.438186+00	2026-05-03 23:36:54.438186+00	password	aec14e8f-929a-44b8-98df-e6baa052e1f7
2b39e69c-be95-45ab-9fb1-d847de0f629e	2026-05-04 00:00:54.919647+00	2026-05-04 00:00:54.919647+00	password	e40392a5-e68e-4065-a613-ace20c0ac657
52e5cd6f-9d31-48a7-8385-33bf30439cc7	2026-05-04 00:03:37.203291+00	2026-05-04 00:03:37.203291+00	password	e3fef64a-5308-44c1-8fdf-6383650cdab4
67b87980-8dad-43f9-8ba1-50f7e1b128ee	2026-05-04 00:06:47.178665+00	2026-05-04 00:06:47.178665+00	password	b4ff1154-8636-4cf5-a38f-d6af62336e59
776bcc42-d8de-46a4-9101-cc01271e77ad	2026-05-04 00:09:24.759169+00	2026-05-04 00:09:24.759169+00	password	66453030-8214-413e-8045-21c460d35ba9
8e159c62-2baf-41ac-bdf4-e3f2ad45d9c3	2026-05-04 01:25:44.094998+00	2026-05-04 01:25:44.094998+00	password	44bdfdb4-1618-4d44-8d13-d5ab13d687e6
aa29775f-4e6e-4ec7-bedc-40f6b875cf9d	2026-05-04 01:29:05.639429+00	2026-05-04 01:29:05.639429+00	password	8ad40919-fbcc-49e2-acc2-582eb51239ba
4e7b2003-93f8-41fc-b20a-f8d387b9de22	2026-05-04 01:30:33.647286+00	2026-05-04 01:30:33.647286+00	password	d0f465db-e957-427d-b266-bffdad041724
4d43293a-a4f1-4857-aa29-e3a5606e0145	2026-05-04 03:20:08.505305+00	2026-05-04 03:20:08.505305+00	password	2a25c0b3-6797-41b7-a9a1-20f050d97c59
2aee4c89-ea00-47d8-b37a-0439105cb524	2026-05-04 03:44:36.883745+00	2026-05-04 03:44:36.883745+00	password	b7b84ff9-46bd-4f6f-95e7-a2d92dcd1113
689e8ae8-4aec-416e-9fb0-908cd9db8eeb	2026-05-04 03:54:01.847259+00	2026-05-04 03:54:01.847259+00	password	e40db58e-677c-4be0-9692-e74d808ba06f
9b1a1093-4da1-4f9a-9056-b66025ebff5d	2026-05-04 04:02:20.456614+00	2026-05-04 04:02:20.456614+00	password	a762e7a1-3379-4d14-a05d-93ff730ebcd3
fccf43d9-76e5-4550-bd87-33c238f0ff9c	2026-05-04 04:05:54.256323+00	2026-05-04 04:05:54.256323+00	password	0621c26f-190a-4632-940b-967f087115cd
9a728368-7d9d-4730-b225-afe2e770f316	2026-05-04 04:07:31.100903+00	2026-05-04 04:07:31.100903+00	password	98c12635-2ed3-46cb-bbb5-da236b39e3aa
13d28c14-dcf4-422b-975a-36a5f88d424c	2026-05-04 04:16:42.07663+00	2026-05-04 04:16:42.07663+00	password	617ece93-f783-4c45-9cde-ac88db9a3287
fba42d59-e128-495d-aaf4-2fae1478c053	2026-05-04 04:21:34.446882+00	2026-05-04 04:21:34.446882+00	password	99ba62cb-3ac6-4d0c-97ca-1e471ba77cc1
ab559789-09c6-4c81-bbd4-8bd745d03861	2026-05-04 04:28:23.709208+00	2026-05-04 04:28:23.709208+00	password	6d2da892-4d68-4dd1-a3b4-f316a900be84
6e449404-35c9-4bf9-9e1f-f871d9d400e3	2026-05-04 05:00:00.224183+00	2026-05-04 05:00:00.224183+00	password	f2b8657e-06fb-4ad9-9970-6d1330a254d7
72c04168-ac8a-402d-8a42-38f79db1c7c7	2026-05-04 05:02:00.982991+00	2026-05-04 05:02:00.982991+00	password	c33f7fcd-7d9b-47b7-aecc-126d688bcb18
479ce70e-ded0-4693-9892-e922265e34a8	2026-05-04 05:18:28.856281+00	2026-05-04 05:18:28.856281+00	password	012be709-0b6a-48cd-874f-625805e27861
105b9db6-a192-43a4-84f4-48ed803cd2dd	2026-05-04 06:21:33.625537+00	2026-05-04 06:21:33.625537+00	password	262f7566-76a3-4e8a-ab61-8caffc8e615b
81837a5a-c412-4872-8e68-43af2753baf0	2026-05-04 06:24:11.784947+00	2026-05-04 06:24:11.784947+00	password	af157f0c-4c29-4c5d-bf48-3dae074bd7e7
d5fd71e8-b40d-42ec-9696-4344dcdaa86c	2026-05-04 06:30:18.619329+00	2026-05-04 06:30:18.619329+00	password	b996312b-76fe-4158-b5e3-ca50d38a6220
6ba6c376-d068-4dbf-946c-bfd996016c45	2026-05-04 06:32:08.376128+00	2026-05-04 06:32:08.376128+00	password	fc91c7d2-c841-4adf-9187-9c1a36943442
4c522d28-af26-400f-9a32-3616b132f712	2026-05-04 06:33:17.869054+00	2026-05-04 06:33:17.869054+00	password	21af702a-c298-422a-9468-ef58d8ad59ea
0e2dabc6-76e5-4ea6-917a-38ece58afb32	2026-05-04 06:46:33.566506+00	2026-05-04 06:46:33.566506+00	password	e61ab2cd-c4e8-4789-bec1-554340af23a4
bb476353-4cdc-41c3-b8bf-8a119b902897	2026-05-04 06:49:46.328048+00	2026-05-04 06:49:46.328048+00	password	3a626335-ff53-458a-bfc7-b6b62d39148d
e74c3e19-ab98-4088-b3b0-287cbef92279	2026-05-04 06:50:59.085536+00	2026-05-04 06:50:59.085536+00	password	7062ffe2-433d-4515-8256-5b35eba76381
6537b654-95c8-4a72-aed2-0da557fa19a1	2026-05-04 06:51:06.456529+00	2026-05-04 06:51:06.456529+00	password	ff367ea1-57c2-4e28-823e-7afce1e0b50f
1109195b-712e-4ded-be25-be64f6311386	2026-05-04 07:31:50.502834+00	2026-05-04 07:31:50.502834+00	password	f4b2e655-2fde-4f99-a172-2bacadaafdd9
f801e33b-57f7-410c-bb84-018a21da37ca	2026-05-04 07:34:16.250229+00	2026-05-04 07:34:16.250229+00	password	456c0e18-3e46-4563-aac8-ec701df38ee4
9906e777-7f70-4c91-9294-7bfd48bd401b	2026-05-04 07:38:59.322671+00	2026-05-04 07:38:59.322671+00	password	a3a6df67-bdb1-4d3a-b494-13c48b40ae46
fd542575-21cd-4444-b481-1bfdfdfdc35a	2026-05-04 10:10:28.609293+00	2026-05-04 10:10:28.609293+00	password	6847e542-9568-431b-8236-449bcf6adad7
1186854e-c047-46cb-9fba-aafc05fd7236	2026-05-04 13:25:59.322605+00	2026-05-04 13:25:59.322605+00	password	c9d01e7e-6dfb-4e3e-89b5-cd62baec6866
8747aaf6-8e09-45af-a5cb-aa38424b7e93	2026-05-04 13:26:21.932962+00	2026-05-04 13:26:21.932962+00	password	ca63b6bc-f927-4411-abcb-755197e5ebbe
287a47c4-ae75-4fa2-be80-bf0bc7214d4b	2026-05-04 23:30:59.722596+00	2026-05-04 23:30:59.722596+00	password	658a62a8-7dc7-4e2c-b175-eafa8476b5e2
a484cd4b-f987-4141-9980-eeb9a151d019	2026-05-04 23:37:58.118196+00	2026-05-04 23:37:58.118196+00	password	cd41c1f4-5512-4481-8a93-282e3a66f6a9
a432c393-4960-4b05-b95e-46c563d5c93c	2026-05-04 23:42:29.499069+00	2026-05-04 23:42:29.499069+00	password	1dc5f2b3-76ab-4e94-b63f-b024f9d4ad41
b66597a0-6bbf-4032-bf7d-b40531fa0e06	2026-05-05 00:47:42.320166+00	2026-05-05 00:47:42.320166+00	password	cf8c09d9-9517-420e-ad84-1b610b66c944
7c36d6ac-d284-470a-918e-0cbfc1f064dd	2026-05-05 00:55:16.483491+00	2026-05-05 00:55:16.483491+00	password	4c0d69e0-969d-45cd-a5fd-188ba5129a17
5db8b234-c7d0-4314-ba81-43722e99f3a8	2026-05-05 01:13:46.254623+00	2026-05-05 01:13:46.254623+00	password	7dcc4099-26c7-4e5b-b4c6-2cf866e1ff4c
47fbc13d-b1f2-42ae-a04c-3480e13b2257	2026-05-05 08:56:37.632046+00	2026-05-05 08:56:37.632046+00	password	e9a75c0f-67fd-43c8-8547-72c6a4c9cc4a
d1a1a69e-2173-47e7-96b6-c3c17a779008	2026-05-05 14:23:00.983044+00	2026-05-05 14:23:00.983044+00	password	d03e969c-a86d-4ee9-b2f3-840864108931
a01ee6af-55aa-4fa9-9c3b-34089c6eae33	2026-05-05 23:23:32.204193+00	2026-05-05 23:23:32.204193+00	password	448e8e7a-f436-4d20-b614-2c84be4ebd1f
c1ba37d0-85c4-413a-aefd-220f1c26f666	2026-05-06 00:51:14.191074+00	2026-05-06 00:51:14.191074+00	password	324f8328-44df-41e0-95ec-b9d8df5e83c1
66b67ee4-ee8e-45cf-bc11-b7755cdb840b	2026-05-06 01:58:03.017809+00	2026-05-06 01:58:03.017809+00	password	c0c81094-ccd5-4e9b-a090-c6c219174047
7c075f35-311f-48b9-94e5-c0a2e479d3bd	2026-05-06 13:54:06.480767+00	2026-05-06 13:54:06.480767+00	password	18508f98-edd8-4d37-bc69-576d9bf3d11d
7d6e885b-8181-4cd6-901b-0b2b7b6bceeb	2026-05-06 23:31:39.102365+00	2026-05-06 23:31:39.102365+00	password	eacf9c87-9465-441d-9f99-36567eaed1d2
67754bfe-4e12-4ed5-bdc4-d5e2253adf00	2026-05-07 01:02:30.48895+00	2026-05-07 01:02:30.48895+00	password	4af6a736-ba9f-479c-828b-f782407a5323
4aefc905-8d8c-4f2d-8f05-02470d9fedcb	2026-05-07 01:30:46.645596+00	2026-05-07 01:30:46.645596+00	password	1cd02119-38b5-445a-956b-82edca5673e5
01d89993-b9fd-4d47-a5c2-7d9bc771fc1e	2026-05-07 02:24:49.269439+00	2026-05-07 02:24:49.269439+00	password	0502958c-03d4-4a29-b34d-a91bfbe96792
bd75f381-9c47-461b-aa9e-892cc5b3970e	2026-05-07 02:51:17.79878+00	2026-05-07 02:51:17.79878+00	password	11f59365-7405-44d6-acea-bbde1f0e1d49
c94fe185-0fd3-4bf7-ab19-724ef8e0b1e1	2026-05-07 02:55:52.283972+00	2026-05-07 02:55:52.283972+00	password	e261756d-c68a-4351-a98e-bf159014f64c
c276b750-185e-4769-a8d4-3b1626210244	2026-05-07 03:09:13.146107+00	2026-05-07 03:09:13.146107+00	password	6ed9a1e6-dbd0-44d7-ba82-648cb12d6136
9de8cd36-bc6c-44f3-8746-5cc7980a0490	2026-05-07 03:32:34.324027+00	2026-05-07 03:32:34.324027+00	password	0d4ab2d9-7a7c-4e32-88bf-6488acf10c11
00e47898-4ccf-4c9a-9039-0873aaa612ef	2026-05-07 04:51:01.963767+00	2026-05-07 04:51:01.963767+00	password	8c2d0834-38d4-45bc-90e0-1c5505d11108
ac8a7395-e2a7-49d5-a7c4-73e06609eaae	2026-05-07 04:52:49.932373+00	2026-05-07 04:52:49.932373+00	password	cf8e9750-d38c-40b3-8a75-1a781f9fb37c
5fcd6ec2-39dd-46bd-b68b-40ae490d285b	2026-05-07 04:55:28.588416+00	2026-05-07 04:55:28.588416+00	password	7fb0a2cf-ccd5-4f3c-a020-6e542cbef948
c1ca134f-6898-4815-b3c3-699c7a6822ab	2026-05-07 06:23:13.962675+00	2026-05-07 06:23:13.962675+00	password	eb0a4867-1255-45a7-9372-8f8833a90432
9e3fd50f-75aa-4b51-9ffe-f2b96c0526d8	2026-05-07 11:25:22.855962+00	2026-05-07 11:25:22.855962+00	password	abbae104-583d-455f-9591-2e2952508a04
1cd2b3c0-541f-442b-ad56-0d661d3c28e6	2026-05-07 11:30:48.682877+00	2026-05-07 11:30:48.682877+00	password	3be9cc72-1001-4cc9-8f30-2af8aca2fdd7
6203fbb8-1f89-483e-9dad-ef6a376bfcea	2026-05-07 12:01:31.429753+00	2026-05-07 12:01:31.429753+00	password	5451b4fb-fd48-4759-81ca-a6d97b2f3142
b463e1d7-bac1-4130-b429-93273f9c93f7	2026-05-07 12:43:29.513977+00	2026-05-07 12:43:29.513977+00	password	3a099528-961c-4cfb-8c35-985e722e39bc
af7f313a-b929-41d3-97c7-78c3ebd1be43	2026-05-07 15:02:28.710956+00	2026-05-07 15:02:28.710956+00	password	65df7047-6a11-47a6-bd17-12aef0e232f7
f2776b53-2c93-4168-a2a2-87c289a0a11a	2026-05-08 08:34:44.399723+00	2026-05-08 08:34:44.399723+00	password	939f1c42-da52-4e57-ac50-24783f4b282a
bee5d7e8-ba9c-4f3e-8d80-f58843ac48cf	2026-05-08 12:10:04.024945+00	2026-05-08 12:10:04.024945+00	password	1507a0fc-d345-4956-b86a-94bfddddde90
8e947ba9-daa9-4497-af71-b6cd6bbd6afe	2026-05-08 16:07:43.883316+00	2026-05-08 16:07:43.883316+00	password	69544823-6460-454c-955e-31af7746c698
0aec02ab-e144-4b5e-ad79-9c9d8027f9ac	2026-05-08 16:14:32.321027+00	2026-05-08 16:14:32.321027+00	password	99459ac2-c306-4f03-906f-a01997ae0da3
39c3d606-1a9a-48e6-bfe8-af1a2501ce8d	2026-05-08 16:19:01.169876+00	2026-05-08 16:19:01.169876+00	password	923696b4-5fe0-4d84-9594-5429de377df4
67dc673e-5447-4add-a5d6-536ce16fbdd9	2026-05-08 16:24:50.450962+00	2026-05-08 16:24:50.450962+00	password	743d1b5c-3eef-48b4-b9ab-4e634079f734
0b7c351f-310f-423c-b735-d18a6ff75f8c	2026-05-08 23:10:34.455619+00	2026-05-08 23:10:34.455619+00	password	389c1e21-9faf-4daf-acca-228104872627
9898c482-9921-47c7-95a5-8e39fd3d4d20	2026-05-09 00:46:20.634069+00	2026-05-09 00:46:20.634069+00	password	7569473a-4b06-4c9e-ba2b-33d63c37cdf8
e5ee7612-d3f3-44fa-b49d-64f9921a33ba	2026-05-09 01:09:42.490198+00	2026-05-09 01:09:42.490198+00	password	c9aedba9-777e-4483-a893-e77577d1cfb6
a33c0d84-12c9-4d07-b4b9-233c00e893f0	2026-05-09 01:29:43.848055+00	2026-05-09 01:29:43.848055+00	password	6b4adfb8-4f97-4f6b-b9b3-a22ec3cfeb58
1a3b6e33-b917-4944-8d22-3fb0c55978e1	2026-05-09 01:30:28.141798+00	2026-05-09 01:30:28.141798+00	password	9a800784-534c-44c1-85d6-78b58a575433
fbded906-5140-44d9-8c14-9aa24ee82914	2026-05-09 01:31:13.577656+00	2026-05-09 01:31:13.577656+00	password	f6e9a889-a2a9-45b5-96e0-b3d678182563
3dadfa6e-d096-4ea5-a367-3752d682b7ab	2026-05-09 01:32:25.549678+00	2026-05-09 01:32:25.549678+00	password	a7fc0f03-a643-42af-bfb1-e47e042eb77d
d8fb695f-15e9-499d-a2ef-e6be0dbd42bc	2026-05-09 01:33:24.938236+00	2026-05-09 01:33:24.938236+00	password	ab45a4d5-82c4-4fb9-b624-cc9ef9b0fa77
5f14627a-e13b-442b-82a2-967887c7903a	2026-05-09 02:29:15.731026+00	2026-05-09 02:29:15.731026+00	password	3c69825a-b9ce-4e3a-8a10-0d4f8ee4c906
46dc5e32-7326-4a92-a6d4-6314f0e32bee	2026-05-09 03:27:29.957633+00	2026-05-09 03:27:29.957633+00	password	0a88f6a5-9532-461e-a5ea-acc3533447ac
f110b544-1a0e-40be-b5ab-df89e72ac2a6	2026-05-09 03:28:00.61153+00	2026-05-09 03:28:00.61153+00	password	7ad34596-e034-4e75-b615-0305867a4581
c90e4c4c-780e-4cf6-b6ca-09a5f9d808e4	2026-05-09 03:51:56.035111+00	2026-05-09 03:51:56.035111+00	password	bbf19ed3-eba1-4e30-95a8-74c9adc1209c
50fc30f6-0d98-44cf-b0ce-faac730d55a3	2026-05-09 03:55:56.55591+00	2026-05-09 03:55:56.55591+00	password	b292efa1-d7a3-4011-987e-f023dddc1832
cf6f6ae7-5fb6-40c4-81c7-cb16de297381	2026-05-09 07:05:34.632918+00	2026-05-09 07:05:34.632918+00	password	038094ce-74a6-4265-88e1-d51f5e80e85c
0f3a9007-aff0-4062-9959-09225ebfd97c	2026-05-09 08:55:37.028028+00	2026-05-09 08:55:37.028028+00	password	8f63bc39-553b-41fe-a483-baa4550cf13a
0feeed9a-363b-43b0-8fdd-2a6a317a4aa7	2026-05-09 08:57:00.818312+00	2026-05-09 08:57:00.818312+00	password	f9d61298-db92-4129-8442-1a63a7918e81
774615e7-b83a-428a-ba7e-b5d01ae415e0	2026-05-09 08:58:50.874292+00	2026-05-09 08:58:50.874292+00	password	0a62c1ec-27d7-4ab8-bd02-43f00a29b110
9237627f-9577-4a49-a7e9-2b79807fdd27	2026-05-09 09:08:33.471442+00	2026-05-09 09:08:33.471442+00	password	fdd39650-8bc0-4364-9e5e-9f2391eac0e6
8c80946a-6ee5-4fea-b2b4-040477ccd705	2026-05-09 09:25:43.397324+00	2026-05-09 09:25:43.397324+00	password	46289e15-7f68-41ae-bba7-2adfeb5a3377
57549814-3673-4faa-b7ab-c407b9043653	2026-05-09 09:28:19.604217+00	2026-05-09 09:28:19.604217+00	password	498f17a9-fe13-40db-8b9f-097963b10068
a2b80c3f-1573-48a6-a5a5-5a9c73bfabf4	2026-05-09 09:52:50.184091+00	2026-05-09 09:52:50.184091+00	password	6ea8c4ff-cc2d-4eaf-9133-8d1ece5cd8ed
1a636561-6f17-45df-adaf-ce5f70f740e6	2026-05-09 12:06:53.83287+00	2026-05-09 12:06:53.83287+00	password	fd268c03-d5b7-4dba-9ef7-af7cac9153f7
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	111	5ycuczcp2hwj	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 11:24:24.651198+00	2026-05-03 11:24:24.651198+00	\N	c9bd9518-36c0-4bd4-b287-c4190cf31174
00000000-0000-0000-0000-000000000000	264	ojxrwxi7dfsl	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 16:07:43.854242+00	2026-05-08 16:07:43.854242+00	\N	8e947ba9-daa9-4497-af71-b6cd6bbd6afe
00000000-0000-0000-0000-000000000000	112	naolpn76kf7k	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 11:25:27.031642+00	2026-05-03 12:24:18.297001+00	\N	877e603a-e33e-4174-ae45-c7ac680ec478
00000000-0000-0000-0000-000000000000	113	2xpps2r7x6v4	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 12:24:18.495994+00	2026-05-03 12:24:18.495994+00	naolpn76kf7k	877e603a-e33e-4174-ae45-c7ac680ec478
00000000-0000-0000-0000-000000000000	267	kif6mb63hq52	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 16:24:09.261485+00	2026-05-08 16:24:09.261485+00	mchkkiljrl4l	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	114	yahzauamfeto	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 13:11:29.636593+00	2026-05-03 14:10:11.727607+00	\N	6dc6675e-1cba-4b8f-8b8d-bee264b5e143
00000000-0000-0000-0000-000000000000	115	agn5s5nj7mep	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 14:10:11.736402+00	2026-05-03 14:10:11.736402+00	yahzauamfeto	6dc6675e-1cba-4b8f-8b8d-bee264b5e143
00000000-0000-0000-0000-000000000000	117	inbjqiblneus	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 14:24:39.167468+00	2026-05-03 14:24:39.167468+00	\N	58a4a49f-3b69-4132-9d05-5f735f096f88
00000000-0000-0000-0000-000000000000	116	iroq56ngldwj	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 14:17:39.092197+00	2026-05-03 20:57:11.289003+00	\N	eaf7495a-26f9-41fe-8389-4123eb7ea505
00000000-0000-0000-0000-000000000000	118	pgn525kznglz	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 14:35:52.323682+00	2026-05-03 20:57:11.288839+00	\N	a9f71761-0c48-4f61-92aa-cfafec4854f7
00000000-0000-0000-0000-000000000000	119	n7guxmamfb2w	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 20:57:11.317455+00	2026-05-03 21:56:04.904551+00	pgn525kznglz	a9f71761-0c48-4f61-92aa-cfafec4854f7
00000000-0000-0000-0000-000000000000	120	4q4lzbybmw5o	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 20:57:11.317454+00	2026-05-03 21:57:21.453356+00	iroq56ngldwj	eaf7495a-26f9-41fe-8389-4123eb7ea505
00000000-0000-0000-0000-000000000000	124	zyckiayggow3	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-03 22:56:30.487338+00	2026-05-03 22:56:30.487338+00	\N	4bc16c81-b338-47e3-a393-8d7def5ae6da
00000000-0000-0000-0000-000000000000	127	p6ld5ixsopuv	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 23:05:47.893026+00	2026-05-03 23:05:47.893026+00	\N	2ee8f239-f4d4-4d4b-8bee-3887d74e1df0
00000000-0000-0000-0000-000000000000	128	twhj6v2mw7th	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 23:28:32.226417+00	2026-05-03 23:28:32.226417+00	\N	1aec8fd1-a225-4424-aa52-bf474b5b60fb
00000000-0000-0000-0000-000000000000	129	frhnpm4an2np	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 23:28:34.201408+00	2026-05-03 23:28:34.201408+00	\N	435a59ac-6009-4552-b2d4-387fa2b26002
00000000-0000-0000-0000-000000000000	130	q5mopcmjegcs	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-03 23:36:38.518295+00	2026-05-03 23:36:38.518295+00	\N	f686e532-34f1-492f-a3a4-08197c6cf178
00000000-0000-0000-0000-000000000000	126	ggj6l55mbvlc	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-03 23:00:47.478438+00	2026-05-04 00:00:01.076273+00	\N	93c745be-708f-494a-9b2a-af0010658877
00000000-0000-0000-0000-000000000000	132	7qxdyja25hr7	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 00:00:01.095666+00	2026-05-04 00:00:01.095666+00	ggj6l55mbvlc	93c745be-708f-494a-9b2a-af0010658877
00000000-0000-0000-0000-000000000000	133	c2tnpzzo5ekj	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 00:00:54.918028+00	2026-05-04 00:00:54.918028+00	\N	2b39e69c-be95-45ab-9fb1-d847de0f629e
00000000-0000-0000-0000-000000000000	134	bzsxggwgbn72	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 00:03:37.17153+00	2026-05-04 00:03:37.17153+00	\N	52e5cd6f-9d31-48a7-8385-33bf30439cc7
00000000-0000-0000-0000-000000000000	135	g5f46ohqgn6d	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 00:06:47.156975+00	2026-05-04 00:06:47.156975+00	\N	67b87980-8dad-43f9-8ba1-50f7e1b128ee
00000000-0000-0000-0000-000000000000	131	bm32yv2qrzfn	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 23:36:54.411216+00	2026-05-04 00:35:16.184204+00	\N	ea5a8b32-117a-4b45-9ae4-f677623e00d0
00000000-0000-0000-0000-000000000000	123	rt6nmzts43vr	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-03 21:59:40.969015+00	2026-05-04 00:52:14.391956+00	\N	8640120a-6292-43b0-8f93-ef41687a520f
00000000-0000-0000-0000-000000000000	121	kmowr72wkane	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 21:56:04.921152+00	2026-05-04 00:52:14.393124+00	n7guxmamfb2w	a9f71761-0c48-4f61-92aa-cfafec4854f7
00000000-0000-0000-0000-000000000000	139	3vcql3y65mpt	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 00:52:14.424027+00	2026-05-04 00:52:14.424027+00	rt6nmzts43vr	8640120a-6292-43b0-8f93-ef41687a520f
00000000-0000-0000-0000-000000000000	122	nn3mizanjfyn	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-03 21:57:21.455892+00	2026-05-04 01:14:33.021215+00	4q4lzbybmw5o	eaf7495a-26f9-41fe-8389-4123eb7ea505
00000000-0000-0000-0000-000000000000	140	dpiqxaz5hmae	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 01:14:33.035909+00	2026-05-04 01:14:33.035909+00	nn3mizanjfyn	eaf7495a-26f9-41fe-8389-4123eb7ea505
00000000-0000-0000-0000-000000000000	141	apbk6anjm4gk	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 01:25:44.071326+00	2026-05-04 01:25:44.071326+00	\N	8e159c62-2baf-41ac-bdf4-e3f2ad45d9c3
00000000-0000-0000-0000-000000000000	142	ugzqilmxayjl	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 01:29:05.614008+00	2026-05-04 01:29:05.614008+00	\N	aa29775f-4e6e-4ec7-bedc-40f6b875cf9d
00000000-0000-0000-0000-000000000000	138	j3shefjecjln	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 00:52:14.424028+00	2026-05-04 01:52:24.354009+00	kmowr72wkane	a9f71761-0c48-4f61-92aa-cfafec4854f7
00000000-0000-0000-0000-000000000000	143	4u6crpoycqmm	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-04 01:30:33.633349+00	2026-05-04 02:30:42.936462+00	\N	4e7b2003-93f8-41fc-b20a-f8d387b9de22
00000000-0000-0000-0000-000000000000	144	f4nhj43f5wuy	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 01:52:24.36699+00	2026-05-04 02:50:45.102034+00	j3shefjecjln	a9f71761-0c48-4f61-92aa-cfafec4854f7
00000000-0000-0000-0000-000000000000	146	ohx6amvg3pmy	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 02:50:45.11143+00	2026-05-04 02:50:45.11143+00	f4nhj43f5wuy	a9f71761-0c48-4f61-92aa-cfafec4854f7
00000000-0000-0000-0000-000000000000	147	ukoj4ctixtbz	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 03:20:08.469163+00	2026-05-04 03:20:08.469163+00	\N	4d43293a-a4f1-4857-aa29-e3a5606e0145
00000000-0000-0000-0000-000000000000	145	yejvyglbh2hr	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-04 02:30:42.947477+00	2026-05-04 03:30:52.554908+00	4u6crpoycqmm	4e7b2003-93f8-41fc-b20a-f8d387b9de22
00000000-0000-0000-0000-000000000000	149	pwvvie3t5sxi	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 03:44:36.856673+00	2026-05-04 03:44:36.856673+00	\N	2aee4c89-ea00-47d8-b37a-0439105cb524
00000000-0000-0000-0000-000000000000	150	mpucwk7ztnvl	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 03:54:01.805849+00	2026-05-04 03:54:01.805849+00	\N	689e8ae8-4aec-416e-9fb0-908cd9db8eeb
00000000-0000-0000-0000-000000000000	152	p36knlhld4ep	b94273ee-bc95-4b0d-987f-b2b3655199f8	f	2026-05-04 04:05:54.241954+00	2026-05-04 04:05:54.241954+00	\N	fccf43d9-76e5-4550-bd87-33c238f0ff9c
00000000-0000-0000-0000-000000000000	153	5ktulsyh4sww	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 04:07:31.083772+00	2026-05-04 04:07:31.083772+00	\N	9a728368-7d9d-4730-b225-afe2e770f316
00000000-0000-0000-0000-000000000000	154	danwqtfhuk4s	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 04:16:42.059467+00	2026-05-04 04:16:42.059467+00	\N	13d28c14-dcf4-422b-975a-36a5f88d424c
00000000-0000-0000-0000-000000000000	155	awsun2f7uhax	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	f	2026-05-04 04:21:34.429959+00	2026-05-04 04:21:34.429959+00	\N	fba42d59-e128-495d-aaf4-2fae1478c053
00000000-0000-0000-0000-000000000000	137	dlrvhh32jqt7	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 00:35:16.206981+00	2026-05-04 04:58:57.593219+00	bm32yv2qrzfn	ea5a8b32-117a-4b45-9ae4-f677623e00d0
00000000-0000-0000-0000-000000000000	157	frcfdajfgpae	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 04:58:57.613115+00	2026-05-04 04:58:57.613115+00	dlrvhh32jqt7	ea5a8b32-117a-4b45-9ae4-f677623e00d0
00000000-0000-0000-0000-000000000000	158	6iphkokwfaaw	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 05:00:00.21401+00	2026-05-04 05:00:00.21401+00	\N	6e449404-35c9-4bf9-9e1f-f871d9d400e3
00000000-0000-0000-0000-000000000000	159	vtlwpxfhskpp	b94273ee-bc95-4b0d-987f-b2b3655199f8	f	2026-05-04 05:02:00.892308+00	2026-05-04 05:02:00.892308+00	\N	72c04168-ac8a-402d-8a42-38f79db1c7c7
00000000-0000-0000-0000-000000000000	160	idbmncy7dbny	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 05:18:28.833395+00	2026-05-04 06:17:00.233779+00	\N	479ce70e-ded0-4693-9892-e922265e34a8
00000000-0000-0000-0000-000000000000	161	spjouvzbhdmu	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 06:17:00.251536+00	2026-05-04 06:17:00.251536+00	idbmncy7dbny	479ce70e-ded0-4693-9892-e922265e34a8
00000000-0000-0000-0000-000000000000	162	gduow2wxljq6	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	f	2026-05-04 06:21:33.610977+00	2026-05-04 06:21:33.610977+00	\N	105b9db6-a192-43a4-84f4-48ed803cd2dd
00000000-0000-0000-0000-000000000000	151	a5o4djcmbgof	f8652643-0aac-4cee-803f-e689419fe979	t	2026-05-04 04:02:20.429379+00	2026-05-04 06:52:46.270832+00	\N	9b1a1093-4da1-4f9a-9056-b66025ebff5d
00000000-0000-0000-0000-000000000000	148	sw7eteslwnek	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-04 03:30:52.571847+00	2026-05-04 07:02:21.221012+00	yejvyglbh2hr	4e7b2003-93f8-41fc-b20a-f8d387b9de22
00000000-0000-0000-0000-000000000000	136	hwmbidgyk3oh	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-04 00:09:24.74198+00	2026-05-05 11:16:52.54703+00	\N	776bcc42-d8de-46a4-9101-cc01271e77ad
00000000-0000-0000-0000-000000000000	125	ikmvxuzsgamf	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-03 23:00:04.075077+00	2026-05-06 13:53:51.210733+00	\N	0f9530a7-f3ef-4981-aa6b-c118d24d7962
00000000-0000-0000-0000-000000000000	163	zgzfjmgfftwv	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 06:24:11.7615+00	2026-05-04 06:24:11.7615+00	\N	81837a5a-c412-4872-8e68-43af2753baf0
00000000-0000-0000-0000-000000000000	164	v2clkzrk3vma	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	f	2026-05-04 06:30:18.598738+00	2026-05-04 06:30:18.598738+00	\N	d5fd71e8-b40d-42ec-9696-4344dcdaa86c
00000000-0000-0000-0000-000000000000	165	hqc222wyqdo5	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	f	2026-05-04 06:32:08.364031+00	2026-05-04 06:32:08.364031+00	\N	6ba6c376-d068-4dbf-946c-bfd996016c45
00000000-0000-0000-0000-000000000000	166	bq7d2e7dl3vd	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 06:33:17.851989+00	2026-05-04 06:33:17.851989+00	\N	4c522d28-af26-400f-9a32-3616b132f712
00000000-0000-0000-0000-000000000000	167	wkdkdbmtrv6s	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	f	2026-05-04 06:46:33.545272+00	2026-05-04 06:46:33.545272+00	\N	0e2dabc6-76e5-4ea6-917a-38ece58afb32
00000000-0000-0000-0000-000000000000	168	ouvrmiv4ryrs	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 06:49:46.312776+00	2026-05-04 06:49:46.312776+00	\N	bb476353-4cdc-41c3-b8bf-8a119b902897
00000000-0000-0000-0000-000000000000	169	dmqcbysor6d5	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 06:50:57.70587+00	2026-05-04 06:50:57.70587+00	\N	e74c3e19-ab98-4088-b3b0-287cbef92279
00000000-0000-0000-0000-000000000000	265	hzprndfsnpes	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 16:14:32.295712+00	2026-05-08 16:14:32.295712+00	\N	0aec02ab-e144-4b5e-ad79-9c9d8027f9ac
00000000-0000-0000-0000-000000000000	156	xny25wz52fi2	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 04:28:23.686868+00	2026-05-04 06:52:46.27142+00	\N	ab559789-09c6-4c81-bbd4-8bd745d03861
00000000-0000-0000-0000-000000000000	171	gpmkyyfwbsdb	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 06:52:46.284264+00	2026-05-04 06:52:46.284264+00	xny25wz52fi2	ab559789-09c6-4c81-bbd4-8bd745d03861
00000000-0000-0000-0000-000000000000	173	kaj2z265qn46	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 07:02:21.236659+00	2026-05-04 07:02:21.236659+00	sw7eteslwnek	4e7b2003-93f8-41fc-b20a-f8d387b9de22
00000000-0000-0000-0000-000000000000	174	6sxgj42px7qd	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-04 07:31:50.471966+00	2026-05-04 07:31:50.471966+00	\N	1109195b-712e-4ded-be25-be64f6311386
00000000-0000-0000-0000-000000000000	172	omxof7onsba7	f8652643-0aac-4cee-803f-e689419fe979	t	2026-05-04 06:52:46.284648+00	2026-05-04 07:53:00.158815+00	a5o4djcmbgof	9b1a1093-4da1-4f9a-9056-b66025ebff5d
00000000-0000-0000-0000-000000000000	175	urkbwvia5zkm	993e879a-890f-4ed0-8b66-9d6961212f0e	t	2026-05-04 07:34:16.229399+00	2026-05-04 08:33:22.311296+00	\N	f801e33b-57f7-410c-bb84-018a21da37ca
00000000-0000-0000-0000-000000000000	176	fur5b2fkyvw5	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 07:38:59.301978+00	2026-05-04 08:37:21.33151+00	\N	9906e777-7f70-4c91-9294-7bfd48bd401b
00000000-0000-0000-0000-000000000000	177	tusyqe2cnm62	f8652643-0aac-4cee-803f-e689419fe979	t	2026-05-04 07:53:00.253129+00	2026-05-04 09:28:53.511331+00	omxof7onsba7	9b1a1093-4da1-4f9a-9056-b66025ebff5d
00000000-0000-0000-0000-000000000000	180	cxskzv6feccd	f8652643-0aac-4cee-803f-e689419fe979	f	2026-05-04 09:28:53.526236+00	2026-05-04 09:28:53.526236+00	tusyqe2cnm62	9b1a1093-4da1-4f9a-9056-b66025ebff5d
00000000-0000-0000-0000-000000000000	178	eezgdw3kptfs	993e879a-890f-4ed0-8b66-9d6961212f0e	t	2026-05-04 08:33:22.442107+00	2026-05-04 09:33:33.82969+00	urkbwvia5zkm	f801e33b-57f7-410c-bb84-018a21da37ca
00000000-0000-0000-0000-000000000000	181	uon7yr6mbwcd	993e879a-890f-4ed0-8b66-9d6961212f0e	f	2026-05-04 09:33:33.851523+00	2026-05-04 09:33:33.851523+00	eezgdw3kptfs	f801e33b-57f7-410c-bb84-018a21da37ca
00000000-0000-0000-0000-000000000000	179	p3guvm3frvm5	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 08:37:21.352548+00	2026-05-04 09:36:00.251583+00	fur5b2fkyvw5	9906e777-7f70-4c91-9294-7bfd48bd401b
00000000-0000-0000-0000-000000000000	170	mvyk27o3mjec	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	t	2026-05-04 06:51:06.224429+00	2026-05-04 10:10:03.732269+00	\N	6537b654-95c8-4a72-aed2-0da557fa19a1
00000000-0000-0000-0000-000000000000	183	4vajn2dw4gd3	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	f	2026-05-04 10:10:03.764251+00	2026-05-04 10:10:03.764251+00	mvyk27o3mjec	6537b654-95c8-4a72-aed2-0da557fa19a1
00000000-0000-0000-0000-000000000000	182	tcywvlm3xik4	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 09:36:00.260659+00	2026-05-04 13:25:27.501617+00	p3guvm3frvm5	9906e777-7f70-4c91-9294-7bfd48bd401b
00000000-0000-0000-0000-000000000000	185	ktoyg6t66vxb	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 13:25:27.519897+00	2026-05-04 13:25:27.519897+00	tcywvlm3xik4	9906e777-7f70-4c91-9294-7bfd48bd401b
00000000-0000-0000-0000-000000000000	186	eezewbnufoah	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 13:25:59.31328+00	2026-05-04 13:25:59.31328+00	\N	1186854e-c047-46cb-9fba-aafc05fd7236
00000000-0000-0000-0000-000000000000	187	kiratzvokhj4	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 13:26:21.906177+00	2026-05-04 14:25:14.15951+00	\N	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	184	d2fiqa6bu324	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 10:10:28.596688+00	2026-05-04 23:30:56.161425+00	\N	fd542575-21cd-4444-b481-1bfdfdfdc35a
00000000-0000-0000-0000-000000000000	189	yly4h4raodoy	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 23:30:56.183952+00	2026-05-04 23:30:56.183952+00	d2fiqa6bu324	fd542575-21cd-4444-b481-1bfdfdfdc35a
00000000-0000-0000-0000-000000000000	190	3ic73dg574ue	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 23:30:59.636893+00	2026-05-04 23:30:59.636893+00	\N	287a47c4-ae75-4fa2-be80-bf0bc7214d4b
00000000-0000-0000-0000-000000000000	191	q2z5cdpzjrlj	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-04 23:37:58.092909+00	2026-05-04 23:37:58.092909+00	\N	a484cd4b-f987-4141-9980-eeb9a151d019
00000000-0000-0000-0000-000000000000	192	bi3rjcdds3g3	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 23:42:29.479752+00	2026-05-05 00:40:58.431116+00	\N	a432c393-4960-4b05-b95e-46c563d5c93c
00000000-0000-0000-0000-000000000000	193	24fwj3xblk5m	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-05 00:40:58.444199+00	2026-05-05 00:40:58.444199+00	bi3rjcdds3g3	a432c393-4960-4b05-b95e-46c563d5c93c
00000000-0000-0000-0000-000000000000	194	4djk6d5iyqwj	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-05 00:47:42.300279+00	2026-05-05 00:47:42.300279+00	\N	b66597a0-6bbf-4032-bf7d-b40531fa0e06
00000000-0000-0000-0000-000000000000	196	4l7ukwdd46wg	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-05 01:13:46.234214+00	2026-05-05 01:13:46.234214+00	\N	5db8b234-c7d0-4314-ba81-43722e99f3a8
00000000-0000-0000-0000-000000000000	188	gwdm4yzumoot	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-04 14:25:14.18241+00	2026-05-05 07:33:20.935774+00	kiratzvokhj4	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	197	e5e6mjnienij	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-05 07:33:20.961886+00	2026-05-05 08:45:36.316323+00	gwdm4yzumoot	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	198	n5wdil4n6nb4	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-05 08:45:36.329963+00	2026-05-05 13:23:57.55872+00	e5e6mjnienij	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	199	urowpcww5ebo	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-05 08:56:37.609794+00	2026-05-05 13:23:57.557923+00	\N	47fbc13d-b1f2-42ae-a04c-3480e13b2257
00000000-0000-0000-0000-000000000000	200	pqwsuiy3ikvx	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-05 11:16:52.562067+00	2026-05-05 14:22:55.369193+00	hwmbidgyk3oh	776bcc42-d8de-46a4-9101-cc01271e77ad
00000000-0000-0000-0000-000000000000	203	fmy25sr65s2a	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-05 14:22:55.400775+00	2026-05-05 14:22:55.400775+00	pqwsuiy3ikvx	776bcc42-d8de-46a4-9101-cc01271e77ad
00000000-0000-0000-0000-000000000000	202	egk3f7alkn6i	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-05 13:23:57.57551+00	2026-05-05 14:24:06.802856+00	n5wdil4n6nb4	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	201	m2hjnqzripjf	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-05 13:23:57.575516+00	2026-05-05 14:24:06.80396+00	urowpcww5ebo	47fbc13d-b1f2-42ae-a04c-3480e13b2257
00000000-0000-0000-0000-000000000000	205	mhrklslb4rc5	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-05 14:24:06.826106+00	2026-05-05 14:24:06.826106+00	m2hjnqzripjf	47fbc13d-b1f2-42ae-a04c-3480e13b2257
00000000-0000-0000-0000-000000000000	195	qggafvkjv3fm	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-05 00:55:16.456804+00	2026-05-05 23:23:21.72893+00	\N	7c36d6ac-d284-470a-918e-0cbfc1f064dd
00000000-0000-0000-0000-000000000000	207	3sblheaziro3	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-05 23:23:21.75553+00	2026-05-05 23:23:21.75553+00	qggafvkjv3fm	7c36d6ac-d284-470a-918e-0cbfc1f064dd
00000000-0000-0000-0000-000000000000	208	hg7bxwnrxirf	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-05 23:23:32.19479+00	2026-05-06 00:30:25.184825+00	\N	a01ee6af-55aa-4fa9-9c3b-34089c6eae33
00000000-0000-0000-0000-000000000000	209	gqsdf2wm7luh	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-06 00:30:25.243024+00	2026-05-06 00:30:25.243024+00	hg7bxwnrxirf	a01ee6af-55aa-4fa9-9c3b-34089c6eae33
00000000-0000-0000-0000-000000000000	206	h7khytgg7y5p	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-05 14:24:06.827842+00	2026-05-06 01:57:48.215989+00	egk3f7alkn6i	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	211	buebamme3vov	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-06 01:57:48.236609+00	2026-05-06 01:57:48.236609+00	h7khytgg7y5p	8747aaf6-8e09-45af-a5cb-aa38424b7e93
00000000-0000-0000-0000-000000000000	212	jzk4yu55bdrt	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 01:58:02.988527+00	2026-05-06 02:58:14.058835+00	\N	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	213	xdhsbpe2zmx7	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 02:58:14.076564+00	2026-05-06 08:56:12.354627+00	jzk4yu55bdrt	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	210	54pkhtgcsmnj	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 00:51:14.175133+00	2026-05-06 23:31:18.846463+00	\N	c1ba37d0-85c4-413a-aefd-220f1c26f666
00000000-0000-0000-0000-000000000000	204	6oi5dtqxhyx3	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-05 14:23:00.973115+00	2026-05-07 01:30:44.787347+00	\N	d1a1a69e-2173-47e7-96b6-c3c17a779008
00000000-0000-0000-0000-000000000000	266	cnkexp3dupah	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 16:19:01.133657+00	2026-05-08 16:19:01.133657+00	\N	39c3d606-1a9a-48e6-bfe8-af1a2501ce8d
00000000-0000-0000-0000-000000000000	214	3g3z7oubacnx	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 08:56:12.373721+00	2026-05-06 09:55:21.093693+00	xdhsbpe2zmx7	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	263	mchkkiljrl4l	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 15:23:59.119985+00	2026-05-08 16:24:09.237064+00	lunapdlshasp	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	215	zcwmh6x6ffo2	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 09:55:21.105453+00	2026-05-06 12:55:21.879462+00	3g3z7oubacnx	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	260	if2fiopoawjc	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 13:16:04.913653+00	2026-05-08 16:40:40.072285+00	fk4vvungeuhm	bee5d7e8-ba9c-4f3e-8d80-f58843ac48cf
00000000-0000-0000-0000-000000000000	217	cspqkwrhiooa	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-06 13:53:51.232233+00	2026-05-06 13:53:51.232233+00	ikmvxuzsgamf	0f9530a7-f3ef-4981-aa6b-c118d24d7962
00000000-0000-0000-0000-000000000000	216	fmer5z2zojgu	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 12:55:21.895657+00	2026-05-06 13:55:05.4125+00	zcwmh6x6ffo2	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	219	lfev56bmigos	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 13:55:05.4309+00	2026-05-06 20:19:50.733723+00	fmer5z2zojgu	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	220	7eytcjt5ss6q	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 20:19:50.753194+00	2026-05-06 21:18:20.035303+00	lfev56bmigos	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	221	or4xgp2fnnxm	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 21:18:20.045806+00	2026-05-06 22:20:26.87206+00	7eytcjt5ss6q	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	223	ganfqbu2sbru	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-06 23:31:18.86734+00	2026-05-06 23:31:18.86734+00	54pkhtgcsmnj	c1ba37d0-85c4-413a-aefd-220f1c26f666
00000000-0000-0000-0000-000000000000	224	em6tsri2wkyg	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 23:31:39.090284+00	2026-05-07 00:29:59.546828+00	\N	7d6e885b-8181-4cd6-901b-0b2b7b6bceeb
00000000-0000-0000-0000-000000000000	225	3j336fkfymvx	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 00:29:59.58563+00	2026-05-07 00:29:59.58563+00	em6tsri2wkyg	7d6e885b-8181-4cd6-901b-0b2b7b6bceeb
00000000-0000-0000-0000-000000000000	222	sv7ozxu2uonp	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-06 22:20:26.882595+00	2026-05-07 01:17:59.972868+00	or4xgp2fnnxm	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	228	bbynved3dmh7	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 01:30:44.806078+00	2026-05-07 01:30:44.806078+00	6oi5dtqxhyx3	d1a1a69e-2173-47e7-96b6-c3c17a779008
00000000-0000-0000-0000-000000000000	226	xlm7quzmypsw	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 01:02:30.46231+00	2026-05-07 02:24:46.80524+00	\N	67754bfe-4e12-4ed5-bdc4-d5e2253adf00
00000000-0000-0000-0000-000000000000	230	nxmfo5ohfbqm	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 02:24:46.826963+00	2026-05-07 02:24:46.826963+00	xlm7quzmypsw	67754bfe-4e12-4ed5-bdc4-d5e2253adf00
00000000-0000-0000-0000-000000000000	231	ctapf5gxirhe	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 02:24:49.267031+00	2026-05-07 02:24:49.267031+00	\N	01d89993-b9fd-4d47-a5c2-7d9bc771fc1e
00000000-0000-0000-0000-000000000000	232	4lmqpnvinxan	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 02:51:17.771226+00	2026-05-07 02:51:17.771226+00	\N	bd75f381-9c47-461b-aa9e-892cc5b3970e
00000000-0000-0000-0000-000000000000	233	zadsygn5rbnv	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 02:55:52.267882+00	2026-05-07 02:55:52.267882+00	\N	c94fe185-0fd3-4bf7-ab19-724ef8e0b1e1
00000000-0000-0000-0000-000000000000	234	if4mni5qvhis	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 03:09:13.129244+00	2026-05-07 03:09:13.129244+00	\N	c276b750-185e-4769-a8d4-3b1626210244
00000000-0000-0000-0000-000000000000	218	di4un3zkh7zo	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-06 13:54:06.439076+00	2026-05-07 03:32:14.902267+00	\N	7c075f35-311f-48b9-94e5-c0a2e479d3bd
00000000-0000-0000-0000-000000000000	235	rh3l7e7fpp6b	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 03:32:14.914381+00	2026-05-07 03:32:14.914381+00	di4un3zkh7zo	7c075f35-311f-48b9-94e5-c0a2e479d3bd
00000000-0000-0000-0000-000000000000	236	qqcappoysogh	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 03:32:34.254474+00	2026-05-07 03:32:34.254474+00	\N	9de8cd36-bc6c-44f3-8746-5cc7980a0490
00000000-0000-0000-0000-000000000000	229	t45ejgoyelu2	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-07 01:30:46.627197+00	2026-05-07 04:50:56.681761+00	\N	4aefc905-8d8c-4f2d-8f05-02470d9fedcb
00000000-0000-0000-0000-000000000000	237	f56w75v32czu	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 04:50:56.702875+00	2026-05-07 04:50:56.702875+00	t45ejgoyelu2	4aefc905-8d8c-4f2d-8f05-02470d9fedcb
00000000-0000-0000-0000-000000000000	238	giwx3l4osnxp	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 04:51:01.946045+00	2026-05-07 04:51:01.946045+00	\N	00e47898-4ccf-4c9a-9039-0873aaa612ef
00000000-0000-0000-0000-000000000000	239	hhcvptzgjsa6	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 04:52:49.904271+00	2026-05-07 04:52:49.904271+00	\N	ac8a7395-e2a7-49d5-a7c4-73e06609eaae
00000000-0000-0000-0000-000000000000	227	ye552ceowdvn	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 01:17:59.997607+00	2026-05-07 06:15:31.41604+00	sv7ozxu2uonp	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	241	t46cu55tatmo	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 06:15:31.439446+00	2026-05-07 06:15:31.439446+00	ye552ceowdvn	66b67ee4-ee8e-45cf-bc11-b7755cdb840b
00000000-0000-0000-0000-000000000000	242	hrwghnngfcif	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 06:23:13.949972+00	2026-05-07 07:23:28.782028+00	\N	c1ca134f-6898-4815-b3c3-699c7a6822ab
00000000-0000-0000-0000-000000000000	243	hrkw2afvkii6	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 07:23:29.020508+00	2026-05-07 07:23:29.020508+00	hrwghnngfcif	c1ca134f-6898-4815-b3c3-699c7a6822ab
00000000-0000-0000-0000-000000000000	240	uydcfiqyd6ex	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-07 04:55:28.570981+00	2026-05-07 07:52:11.845248+00	\N	5fcd6ec2-39dd-46bd-b68b-40ae490d285b
00000000-0000-0000-0000-000000000000	244	pklouuqynmsn	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-07 07:52:11.869157+00	2026-05-07 07:52:11.869157+00	uydcfiqyd6ex	5fcd6ec2-39dd-46bd-b68b-40ae490d285b
00000000-0000-0000-0000-000000000000	245	blmv7paprkmh	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 11:25:22.829833+00	2026-05-07 11:25:22.829833+00	\N	9e3fd50f-75aa-4b51-9ffe-f2b96c0526d8
00000000-0000-0000-0000-000000000000	246	msnc5tkkiymt	351d73d3-961d-4f8e-9f6d-d1c06092384a	f	2026-05-07 11:30:48.652258+00	2026-05-07 11:30:48.652258+00	\N	1cd2b3c0-541f-442b-ad56-0d661d3c28e6
00000000-0000-0000-0000-000000000000	248	vxfboz7q4eew	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 12:43:29.487733+00	2026-05-07 13:43:39.630012+00	\N	b463e1d7-bac1-4130-b429-93273f9c93f7
00000000-0000-0000-0000-000000000000	247	lh4ni3q4urgo	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 12:01:31.410436+00	2026-05-07 15:02:19.812637+00	\N	6203fbb8-1f89-483e-9dad-ef6a376bfcea
00000000-0000-0000-0000-000000000000	250	6lerrjqda77d	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-07 15:02:19.837151+00	2026-05-07 15:02:19.837151+00	lh4ni3q4urgo	6203fbb8-1f89-483e-9dad-ef6a376bfcea
00000000-0000-0000-0000-000000000000	249	rp4h4slvgge6	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 13:43:39.649279+00	2026-05-08 08:34:41.570769+00	vxfboz7q4eew	b463e1d7-bac1-4130-b429-93273f9c93f7
00000000-0000-0000-0000-000000000000	252	vkl6tziorcss	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 08:34:41.590099+00	2026-05-08 08:34:41.590099+00	rp4h4slvgge6	b463e1d7-bac1-4130-b429-93273f9c93f7
00000000-0000-0000-0000-000000000000	253	oqvvn26l2z4y	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 08:34:44.376656+00	2026-05-08 09:33:03.195091+00	\N	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	254	xk6msau6nbc6	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 09:33:03.21346+00	2026-05-08 10:31:34.268363+00	oqvvn26l2z4y	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	255	4ev4ja654cf2	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 10:31:34.352921+00	2026-05-08 11:29:59.662446+00	xk6msau6nbc6	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	251	e6ph3mbrhzb2	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-07 15:02:28.705507+00	2026-05-08 12:10:00.821349+00	\N	af7f313a-b929-41d3-97c7-78c3ebd1be43
00000000-0000-0000-0000-000000000000	257	ikblf6kh2pxh	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 12:10:00.830404+00	2026-05-08 12:10:00.830404+00	e6ph3mbrhzb2	af7f313a-b929-41d3-97c7-78c3ebd1be43
00000000-0000-0000-0000-000000000000	256	lmbymdpa4fno	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 11:29:59.685221+00	2026-05-08 12:28:29.108633+00	4ev4ja654cf2	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	258	fk4vvungeuhm	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 12:10:04.009131+00	2026-05-08 13:16:04.896482+00	\N	bee5d7e8-ba9c-4f3e-8d80-f58843ac48cf
00000000-0000-0000-0000-000000000000	259	v5jjlbmermg7	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 12:28:29.121286+00	2026-05-08 13:26:47.66225+00	lmbymdpa4fno	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	261	l4an2uj4ui5z	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 13:26:47.678964+00	2026-05-08 14:25:17.247469+00	v5jjlbmermg7	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	262	lunapdlshasp	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 14:25:17.267671+00	2026-05-08 15:23:59.095015+00	l4an2uj4ui5z	f2776b53-2c93-4168-a2a2-87c289a0a11a
00000000-0000-0000-0000-000000000000	269	hyzkqirhflsz	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 16:40:40.096355+00	2026-05-08 16:40:40.096355+00	if2fiopoawjc	bee5d7e8-ba9c-4f3e-8d80-f58843ac48cf
00000000-0000-0000-0000-000000000000	268	np64nna7hk3g	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 16:24:50.407078+00	2026-05-08 23:10:31.896124+00	\N	67dc673e-5447-4add-a5d6-536ce16fbdd9
00000000-0000-0000-0000-000000000000	270	apwyr7p3d6br	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-08 23:10:31.913651+00	2026-05-08 23:10:31.913651+00	np64nna7hk3g	67dc673e-5447-4add-a5d6-536ce16fbdd9
00000000-0000-0000-0000-000000000000	271	ruulzf6wjliz	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-08 23:10:34.433536+00	2026-05-09 00:09:22.874698+00	\N	0b7c351f-310f-423c-b735-d18a6ff75f8c
00000000-0000-0000-0000-000000000000	272	lbthppwaxosr	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 00:09:22.891917+00	2026-05-09 01:09:31.965546+00	ruulzf6wjliz	0b7c351f-310f-423c-b735-d18a6ff75f8c
00000000-0000-0000-0000-000000000000	274	dhgpxooxms7r	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 01:09:31.985257+00	2026-05-09 01:09:31.985257+00	lbthppwaxosr	0b7c351f-310f-423c-b735-d18a6ff75f8c
00000000-0000-0000-0000-000000000000	275	uf4hwlxk3ufk	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 01:09:42.472781+00	2026-05-09 01:09:42.472781+00	\N	e5ee7612-d3f3-44fa-b49d-64f9921a33ba
00000000-0000-0000-0000-000000000000	276	mboxqzbqnfac	f1442181-b297-4857-a22a-63ce695149ec	f	2026-05-09 01:29:43.822948+00	2026-05-09 01:29:43.822948+00	\N	a33c0d84-12c9-4d07-b4b9-233c00e893f0
00000000-0000-0000-0000-000000000000	277	meqbfsvnq5nh	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 01:30:28.116729+00	2026-05-09 01:30:28.116729+00	\N	1a3b6e33-b917-4944-8d22-3fb0c55978e1
00000000-0000-0000-0000-000000000000	278	kc2uglktndko	f1442181-b297-4857-a22a-63ce695149ec	f	2026-05-09 01:31:13.553373+00	2026-05-09 01:31:13.553373+00	\N	fbded906-5140-44d9-8c14-9aa24ee82914
00000000-0000-0000-0000-000000000000	279	var5rgir3tpo	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 01:32:25.528505+00	2026-05-09 01:32:25.528505+00	\N	3dadfa6e-d096-4ea5-a367-3752d682b7ab
00000000-0000-0000-0000-000000000000	280	c6oz4qam2xxn	f1442181-b297-4857-a22a-63ce695149ec	f	2026-05-09 01:33:24.91796+00	2026-05-09 01:33:24.91796+00	\N	d8fb695f-15e9-499d-a2ef-e6be0dbd42bc
00000000-0000-0000-0000-000000000000	282	2dpyl62wh56f	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 03:27:29.939319+00	2026-05-09 03:27:29.939319+00	\N	46dc5e32-7326-4a92-a6d4-6314f0e32bee
00000000-0000-0000-0000-000000000000	281	o6n2cz4ohwtf	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 02:29:15.713636+00	2026-05-09 03:28:00.548979+00	\N	5f14627a-e13b-442b-82a2-967887c7903a
00000000-0000-0000-0000-000000000000	283	grs6x3gb5f5t	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 03:28:00.559771+00	2026-05-09 03:28:00.559771+00	o6n2cz4ohwtf	5f14627a-e13b-442b-82a2-967887c7903a
00000000-0000-0000-0000-000000000000	285	3hfnnhwjdmic	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-09 03:51:56.011001+00	2026-05-09 03:51:56.011001+00	\N	c90e4c4c-780e-4cf6-b6ca-09a5f9d808e4
00000000-0000-0000-0000-000000000000	286	qn3nj3ejchje	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-09 03:55:56.531907+00	2026-05-09 03:55:56.531907+00	\N	50fc30f6-0d98-44cf-b0ce-faac730d55a3
00000000-0000-0000-0000-000000000000	284	hdnxi3zptgxh	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 03:28:00.609875+00	2026-05-09 07:05:25.145327+00	\N	f110b544-1a0e-40be-b5ab-df89e72ac2a6
00000000-0000-0000-0000-000000000000	287	aqufkpv2p5iw	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 07:05:25.165038+00	2026-05-09 07:05:25.165038+00	hdnxi3zptgxh	f110b544-1a0e-40be-b5ab-df89e72ac2a6
00000000-0000-0000-0000-000000000000	288	ljnjm3qhumuz	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 07:05:34.618589+00	2026-05-09 08:04:02.305527+00	\N	cf6f6ae7-5fb6-40c4-81c7-cb16de297381
00000000-0000-0000-0000-000000000000	289	l2rft5thqqc2	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 08:04:02.319954+00	2026-05-09 08:04:02.319954+00	ljnjm3qhumuz	cf6f6ae7-5fb6-40c4-81c7-cb16de297381
00000000-0000-0000-0000-000000000000	290	6sdd6is3bqzq	f1442181-b297-4857-a22a-63ce695149ec	f	2026-05-09 08:55:37.006469+00	2026-05-09 08:55:37.006469+00	\N	0f3a9007-aff0-4062-9959-09225ebfd97c
00000000-0000-0000-0000-000000000000	292	kaaylynxcprq	abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd	f	2026-05-09 08:58:50.861438+00	2026-05-09 08:58:50.861438+00	\N	774615e7-b83a-428a-ba7e-b5d01ae415e0
00000000-0000-0000-0000-000000000000	293	7u6v2h6hyefv	1e4c7fef-312b-4cc1-85ce-465a4bc313bf	f	2026-05-09 09:08:33.344216+00	2026-05-09 09:08:33.344216+00	\N	9237627f-9577-4a49-a7e9-2b79807fdd27
00000000-0000-0000-0000-000000000000	294	zpcmrijmmttw	9d05e348-d145-44a9-be0e-6021aa2e4efe	f	2026-05-09 09:25:43.354066+00	2026-05-09 09:25:43.354066+00	\N	8c80946a-6ee5-4fea-b2b4-040477ccd705
00000000-0000-0000-0000-000000000000	295	p22z7czpknla	1e4c7fef-312b-4cc1-85ce-465a4bc313bf	f	2026-05-09 09:28:19.587438+00	2026-05-09 09:28:19.587438+00	\N	57549814-3673-4faa-b7ab-c407b9043653
00000000-0000-0000-0000-000000000000	291	d5ekwzeniri4	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-09 08:57:00.801077+00	2026-05-09 09:57:09.677252+00	\N	0feeed9a-363b-43b0-8fdd-2a6a317a4aa7
00000000-0000-0000-0000-000000000000	296	ec42q3rvm7re	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 09:52:50.165993+00	2026-05-09 10:51:38.793808+00	\N	a2b80c3f-1573-48a6-a5a5-5a9c73bfabf4
00000000-0000-0000-0000-000000000000	298	me5e4lliezqq	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 10:51:38.817947+00	2026-05-09 10:51:38.817947+00	ec42q3rvm7re	a2b80c3f-1573-48a6-a5a5-5a9c73bfabf4
00000000-0000-0000-0000-000000000000	297	qoxs57my7jnz	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	t	2026-05-09 09:57:09.695722+00	2026-05-09 10:56:22.69793+00	d5ekwzeniri4	0feeed9a-363b-43b0-8fdd-2a6a317a4aa7
00000000-0000-0000-0000-000000000000	299	sedds3vn5eed	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	f	2026-05-09 10:56:22.707448+00	2026-05-09 10:56:22.707448+00	qoxs57my7jnz	0feeed9a-363b-43b0-8fdd-2a6a317a4aa7
00000000-0000-0000-0000-000000000000	273	kdansb2hlnfc	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 00:46:20.608197+00	2026-05-09 12:06:48.405329+00	\N	9898c482-9921-47c7-95a5-8e39fd3d4d20
00000000-0000-0000-0000-000000000000	300	y6aipntfl26b	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 12:06:48.428807+00	2026-05-09 12:06:48.428807+00	kdansb2hlnfc	9898c482-9921-47c7-95a5-8e39fd3d4d20
00000000-0000-0000-0000-000000000000	301	6gquj54r43uq	53baabfc-21bb-43e2-85fb-fdfa56351b26	t	2026-05-09 12:06:53.82451+00	2026-05-09 13:09:07.710785+00	\N	1a636561-6f17-45df-adaf-ce5f70f740e6
00000000-0000-0000-0000-000000000000	302	t57k5jwjtzmi	53baabfc-21bb-43e2-85fb-fdfa56351b26	f	2026-05-09 13:09:07.725344+00	2026-05-09 13:09:07.725344+00	6gquj54r43uq	1a636561-6f17-45df-adaf-ce5f70f740e6
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
c9bd9518-36c0-4bd4-b287-c4190cf31174	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 11:24:24.616646+00	2026-05-03 11:24:24.616646+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
877e603a-e33e-4174-ae45-c7ac680ec478	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 11:25:27.013622+00	2026-05-03 12:24:18.683733+00	\N	aal1	\N	2026-05-03 12:24:18.673646	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6dc6675e-1cba-4b8f-8b8d-bee264b5e143	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 13:11:29.61263+00	2026-05-03 14:10:11.756195+00	\N	aal1	\N	2026-05-03 14:10:11.755717	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
58a4a49f-3b69-4132-9d05-5f735f096f88	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 14:24:39.147431+00	2026-05-03 14:24:39.147431+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
ea5a8b32-117a-4b45-9ae4-f677623e00d0	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 23:36:54.379509+00	2026-05-04 04:58:57.626793+00	\N	aal1	\N	2026-05-04 04:58:57.626327	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
a9f71761-0c48-4f61-92aa-cfafec4854f7	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 14:35:52.288117+00	2026-05-04 02:50:45.129219+00	\N	aal1	\N	2026-05-04 02:50:45.128831	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
4d43293a-a4f1-4857-aa29-e3a5606e0145	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 03:20:08.425154+00	2026-05-04 03:20:08.425154+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
0f9530a7-f3ef-4981-aa6b-c118d24d7962	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-03 23:00:04.049342+00	2026-05-06 13:53:51.251604+00	\N	aal1	\N	2026-05-06 13:53:51.25133	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.173.81	\N	\N	\N	\N	\N
4bc16c81-b338-47e3-a393-8d7def5ae6da	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-03 22:56:30.460436+00	2026-05-03 22:56:30.460436+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.130.116	\N	\N	\N	\N	\N
2ee8f239-f4d4-4d4b-8bee-3887d74e1df0	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 23:05:47.870131+00	2026-05-03 23:05:47.870131+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
1aec8fd1-a225-4424-aa52-bf474b5b60fb	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 23:28:32.197541+00	2026-05-03 23:28:32.197541+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
435a59ac-6009-4552-b2d4-387fa2b26002	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 23:28:34.178577+00	2026-05-03 23:28:34.178577+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
f686e532-34f1-492f-a3a4-08197c6cf178	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 23:36:38.489331+00	2026-05-03 23:36:38.489331+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
93c745be-708f-494a-9b2a-af0010658877	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-03 23:00:47.44811+00	2026-05-04 00:00:01.112433+00	\N	aal1	\N	2026-05-04 00:00:01.112335	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
2b39e69c-be95-45ab-9fb1-d847de0f629e	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 00:00:54.904708+00	2026-05-04 00:00:54.904708+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
52e5cd6f-9d31-48a7-8385-33bf30439cc7	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 00:03:37.135379+00	2026-05-04 00:03:37.135379+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
67b87980-8dad-43f9-8ba1-50f7e1b128ee	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 00:06:47.123113+00	2026-05-04 00:06:47.123113+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.130.116	\N	\N	\N	\N	\N
2aee4c89-ea00-47d8-b37a-0439105cb524	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 03:44:36.832042+00	2026-05-04 03:44:36.832042+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
8640120a-6292-43b0-8f93-ef41687a520f	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-03 21:59:40.952391+00	2026-05-04 00:52:14.443818+00	\N	aal1	\N	2026-05-04 00:52:14.443487	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
eaf7495a-26f9-41fe-8389-4123eb7ea505	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-03 14:17:39.071884+00	2026-05-04 01:14:33.05126+00	\N	aal1	\N	2026-05-04 01:14:33.050251	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
8e159c62-2baf-41ac-bdf4-e3f2ad45d9c3	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 01:25:44.04061+00	2026-05-04 01:25:44.04061+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
aa29775f-4e6e-4ec7-bedc-40f6b875cf9d	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 01:29:05.586369+00	2026-05-04 01:29:05.586369+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
6e449404-35c9-4bf9-9e1f-f871d9d400e3	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 05:00:00.173806+00	2026-05-04 05:00:00.173806+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
689e8ae8-4aec-416e-9fb0-908cd9db8eeb	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 03:54:01.766434+00	2026-05-04 03:54:01.766434+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
fccf43d9-76e5-4550-bd87-33c238f0ff9c	b94273ee-bc95-4b0d-987f-b2b3655199f8	2026-05-04 04:05:54.224601+00	2026-05-04 04:05:54.224601+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
9a728368-7d9d-4730-b225-afe2e770f316	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 04:07:31.059045+00	2026-05-04 04:07:31.059045+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
13d28c14-dcf4-422b-975a-36a5f88d424c	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 04:16:42.030772+00	2026-05-04 04:16:42.030772+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
fba42d59-e128-495d-aaf4-2fae1478c053	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	2026-05-04 04:21:34.410499+00	2026-05-04 04:21:34.410499+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
72c04168-ac8a-402d-8a42-38f79db1c7c7	b94273ee-bc95-4b0d-987f-b2b3655199f8	2026-05-04 05:02:00.668742+00	2026-05-04 05:02:00.668742+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
479ce70e-ded0-4693-9892-e922265e34a8	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 05:18:28.805016+00	2026-05-04 06:17:00.275354+00	\N	aal1	\N	2026-05-04 06:17:00.274255	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
105b9db6-a192-43a4-84f4-48ed803cd2dd	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	2026-05-04 06:21:33.564389+00	2026-05-04 06:21:33.564389+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
81837a5a-c412-4872-8e68-43af2753baf0	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 06:24:11.725901+00	2026-05-04 06:24:11.725901+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
d5fd71e8-b40d-42ec-9696-4344dcdaa86c	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	2026-05-04 06:30:18.570569+00	2026-05-04 06:30:18.570569+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
4e7b2003-93f8-41fc-b20a-f8d387b9de22	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 01:30:33.613271+00	2026-05-04 07:02:21.257319+00	\N	aal1	\N	2026-05-04 07:02:21.257203	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
776bcc42-d8de-46a4-9101-cc01271e77ad	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 00:09:24.712603+00	2026-05-05 14:22:55.425545+00	\N	aal1	\N	2026-05-05 14:22:55.425443	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.123.65	\N	\N	\N	\N	\N
6ba6c376-d068-4dbf-946c-bfd996016c45	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	2026-05-04 06:32:08.335612+00	2026-05-04 06:32:08.335612+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
4c522d28-af26-400f-9a32-3616b132f712	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 06:33:17.819941+00	2026-05-04 06:33:17.819941+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
0e2dabc6-76e5-4ea6-917a-38ece58afb32	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	2026-05-04 06:46:33.517244+00	2026-05-04 06:46:33.517244+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
bb476353-4cdc-41c3-b8bf-8a119b902897	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 06:49:46.28891+00	2026-05-04 06:49:46.28891+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
e74c3e19-ab98-4088-b3b0-287cbef92279	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 06:50:57.151714+00	2026-05-04 06:50:57.151714+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
ab559789-09c6-4c81-bbd4-8bd745d03861	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 04:28:23.659716+00	2026-05-04 06:52:46.298907+00	\N	aal1	\N	2026-05-04 06:52:46.298786	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1109195b-712e-4ded-be25-be64f6311386	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-04 07:31:50.422655+00	2026-05-04 07:31:50.422655+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
7d6e885b-8181-4cd6-901b-0b2b7b6bceeb	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-06 23:31:39.057288+00	2026-05-07 00:29:59.646125+00	\N	aal1	\N	2026-05-07 00:29:59.643748	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.122.75	\N	\N	\N	\N	\N
9b1a1093-4da1-4f9a-9056-b66025ebff5d	f8652643-0aac-4cee-803f-e689419fe979	2026-05-04 04:02:20.401269+00	2026-05-04 09:28:53.539038+00	\N	aal1	\N	2026-05-04 09:28:53.538155	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
f801e33b-57f7-410c-bb84-018a21da37ca	993e879a-890f-4ed0-8b66-9d6961212f0e	2026-05-04 07:34:16.21551+00	2026-05-04 09:33:33.89433+00	\N	aal1	\N	2026-05-04 09:33:33.891424	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6537b654-95c8-4a72-aed2-0da557fa19a1	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	2026-05-04 06:51:05.921539+00	2026-05-04 10:10:03.783656+00	\N	aal1	\N	2026-05-04 10:10:03.783557	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.169.95	\N	\N	\N	\N	\N
9906e777-7f70-4c91-9294-7bfd48bd401b	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 07:38:59.270165+00	2026-05-04 13:25:27.536246+00	\N	aal1	\N	2026-05-04 13:25:27.536149	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1186854e-c047-46cb-9fba-aafc05fd7236	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 13:25:59.294192+00	2026-05-04 13:25:59.294192+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
47fbc13d-b1f2-42ae-a04c-3480e13b2257	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-05 08:56:37.581714+00	2026-05-05 14:24:06.842199+00	\N	aal1	\N	2026-05-05 14:24:06.841728	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
fd542575-21cd-4444-b481-1bfdfdfdc35a	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 10:10:28.560266+00	2026-05-04 23:30:56.20057+00	\N	aal1	\N	2026-05-04 23:30:56.200472	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	27.67.73.143	\N	\N	\N	\N	\N
287a47c4-ae75-4fa2-be80-bf0bc7214d4b	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 23:30:59.47475+00	2026-05-04 23:30:59.47475+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	27.67.73.143	\N	\N	\N	\N	\N
a484cd4b-f987-4141-9980-eeb9a151d019	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 23:37:58.061393+00	2026-05-04 23:37:58.061393+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	27.67.73.143	\N	\N	\N	\N	\N
a432c393-4960-4b05-b95e-46c563d5c93c	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 23:42:29.450076+00	2026-05-05 00:40:58.460404+00	\N	aal1	\N	2026-05-05 00:40:58.459777	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	27.67.73.143	\N	\N	\N	\N	\N
b66597a0-6bbf-4032-bf7d-b40531fa0e06	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-05 00:47:42.27837+00	2026-05-05 00:47:42.27837+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-A556E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.111 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	123.19.71.119	\N	\N	\N	\N	\N
5db8b234-c7d0-4314-ba81-43722e99f3a8	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-05 01:13:46.208012+00	2026-05-05 01:13:46.208012+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	117.3.142.59	\N	\N	\N	\N	\N
7c36d6ac-d284-470a-918e-0cbfc1f064dd	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-05 00:55:16.43174+00	2026-05-05 23:23:21.770578+00	\N	aal1	\N	2026-05-05 23:23:21.77027	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.123.65	\N	\N	\N	\N	\N
a01ee6af-55aa-4fa9-9c3b-34089c6eae33	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-05 23:23:32.176283+00	2026-05-06 00:30:25.315781+00	\N	aal1	\N	2026-05-06 00:30:25.313605	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.123.65	\N	\N	\N	\N	\N
8747aaf6-8e09-45af-a5cb-aa38424b7e93	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-04 13:26:21.879351+00	2026-05-06 01:57:48.25427+00	\N	aal1	\N	2026-05-06 01:57:48.254166	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.176.126	\N	\N	\N	\N	\N
d1a1a69e-2173-47e7-96b6-c3c17a779008	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-05 14:23:00.938832+00	2026-05-07 01:30:44.826873+00	\N	aal1	\N	2026-05-07 01:30:44.826014	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.122.75	\N	\N	\N	\N	\N
67754bfe-4e12-4ed5-bdc4-d5e2253adf00	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 01:02:30.425134+00	2026-05-07 02:24:46.844496+00	\N	aal1	\N	2026-05-07 02:24:46.844224	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
bd75f381-9c47-461b-aa9e-892cc5b3970e	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 02:51:17.730044+00	2026-05-07 02:51:17.730044+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
c1ba37d0-85c4-413a-aefd-220f1c26f666	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-06 00:51:14.154291+00	2026-05-06 23:31:18.889907+00	\N	aal1	\N	2026-05-06 23:31:18.889372	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	117.3.122.75	\N	\N	\N	\N	\N
01d89993-b9fd-4d47-a5c2-7d9bc771fc1e	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 02:24:49.259472+00	2026-05-07 02:24:49.259472+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
c94fe185-0fd3-4bf7-ab19-724ef8e0b1e1	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 02:55:52.243427+00	2026-05-07 02:55:52.243427+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
c276b750-185e-4769-a8d4-3b1626210244	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 03:09:13.100197+00	2026-05-07 03:09:13.100197+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
7c075f35-311f-48b9-94e5-c0a2e479d3bd	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-06 13:54:06.388219+00	2026-05-07 03:32:14.936688+00	\N	aal1	\N	2026-05-07 03:32:14.936577	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.137 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.184.187	\N	\N	\N	\N	\N
9de8cd36-bc6c-44f3-8746-5cc7980a0490	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-07 03:32:34.133687+00	2026-05-07 03:32:34.133687+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/147.0.7727.137 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.254.184.187	\N	\N	\N	\N	\N
4aefc905-8d8c-4f2d-8f05-02470d9fedcb	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-07 01:30:46.596318+00	2026-05-07 04:50:56.726898+00	\N	aal1	\N	2026-05-07 04:50:56.726796	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
00e47898-4ccf-4c9a-9039-0873aaa612ef	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-07 04:51:01.905134+00	2026-05-07 04:51:01.905134+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
ac8a7395-e2a7-49d5-a7c4-73e06609eaae	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-07 04:52:49.883018+00	2026-05-07 04:52:49.883018+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
66b67ee4-ee8e-45cf-bc11-b7755cdb840b	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-06 01:58:02.94607+00	2026-05-07 06:15:31.457997+00	\N	aal1	\N	2026-05-07 06:15:31.457899	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
c1ca134f-6898-4815-b3c3-699c7a6822ab	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 06:23:13.917907+00	2026-05-07 07:23:29.15093+00	\N	aal1	\N	2026-05-07 07:23:29.145056	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
5fcd6ec2-39dd-46bd-b68b-40ae490d285b	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-07 04:55:28.54935+00	2026-05-07 07:52:11.884365+00	\N	aal1	\N	2026-05-07 07:52:11.884265	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
9e3fd50f-75aa-4b51-9ffe-f2b96c0526d8	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 11:25:22.801945+00	2026-05-07 11:25:22.801945+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
1cd2b3c0-541f-442b-ad56-0d661d3c28e6	351d73d3-961d-4f8e-9f6d-d1c06092384a	2026-05-07 11:30:48.570741+00	2026-05-07 11:30:48.570741+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.184.187	\N	\N	\N	\N	\N
0b7c351f-310f-423c-b735-d18a6ff75f8c	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 23:10:34.409872+00	2026-05-09 01:09:32.009321+00	\N	aal1	\N	2026-05-09 01:09:32.007773	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6203fbb8-1f89-483e-9dad-ef6a376bfcea	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 12:01:31.381366+00	2026-05-07 15:02:19.865259+00	\N	aal1	\N	2026-05-07 15:02:19.86513	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.170.4	\N	\N	\N	\N	\N
b463e1d7-bac1-4130-b429-93273f9c93f7	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 12:43:29.462516+00	2026-05-08 08:34:41.605699+00	\N	aal1	\N	2026-05-08 08:34:41.605604	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e5ee7612-d3f3-44fa-b49d-64f9921a33ba	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 01:09:42.455678+00	2026-05-09 01:09:42.455678+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
a33c0d84-12c9-4d07-b4b9-233c00e893f0	f1442181-b297-4857-a22a-63ce695149ec	2026-05-09 01:29:43.801918+00	2026-05-09 01:29:43.801918+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1a3b6e33-b917-4944-8d22-3fb0c55978e1	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 01:30:28.076817+00	2026-05-09 01:30:28.076817+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
af7f313a-b929-41d3-97c7-78c3ebd1be43	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-07 15:02:28.684466+00	2026-05-08 12:10:00.843775+00	\N	aal1	\N	2026-05-08 12:10:00.843681	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.138.55	\N	\N	\N	\N	\N
fbded906-5140-44d9-8c14-9aa24ee82914	f1442181-b297-4857-a22a-63ce695149ec	2026-05-09 01:31:13.51656+00	2026-05-09 01:31:13.51656+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
3dadfa6e-d096-4ea5-a367-3752d682b7ab	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 01:32:25.496696+00	2026-05-09 01:32:25.496696+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
d8fb695f-15e9-499d-a2ef-e6be0dbd42bc	f1442181-b297-4857-a22a-63ce695149ec	2026-05-09 01:33:24.902169+00	2026-05-09 01:33:24.902169+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
46dc5e32-7326-4a92-a6d4-6314f0e32bee	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 03:27:29.917207+00	2026-05-09 03:27:29.917207+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
8e947ba9-daa9-4497-af71-b6cd6bbd6afe	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 16:07:43.820195+00	2026-05-08 16:07:43.820195+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
0aec02ab-e144-4b5e-ad79-9c9d8027f9ac	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 16:14:32.26655+00	2026-05-08 16:14:32.26655+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
39c3d606-1a9a-48e6-bfe8-af1a2501ce8d	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 16:19:01.103363+00	2026-05-08 16:19:01.103363+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
f2776b53-2c93-4168-a2a2-87c289a0a11a	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 08:34:44.349307+00	2026-05-08 16:24:09.278659+00	\N	aal1	\N	2026-05-08 16:24:09.278554	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
bee5d7e8-ba9c-4f3e-8d80-f58843ac48cf	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 12:10:03.992092+00	2026-05-08 16:40:40.116305+00	\N	aal1	\N	2026-05-08 16:40:40.115976	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Mobile Safari/537.36	171.254.138.55	\N	\N	\N	\N	\N
67dc673e-5447-4add-a5d6-536ce16fbdd9	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-08 16:24:50.356563+00	2026-05-08 23:10:31.92839+00	\N	aal1	\N	2026-05-08 23:10:31.928285	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
774615e7-b83a-428a-ba7e-b5d01ae415e0	abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd	2026-05-09 08:58:50.844352+00	2026-05-09 08:58:50.844352+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
5f14627a-e13b-442b-82a2-967887c7903a	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 02:29:15.691661+00	2026-05-09 03:28:00.574071+00	\N	aal1	\N	2026-05-09 03:28:00.57336	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
c90e4c4c-780e-4cf6-b6ca-09a5f9d808e4	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-09 03:51:55.981071+00	2026-05-09 03:51:55.981071+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
50fc30f6-0d98-44cf-b0ce-faac730d55a3	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-09 03:55:56.501321+00	2026-05-09 03:55:56.501321+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 16; SM-S908E Build/BP2A.250605.031.A3;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/148.0.7778.120 Mobile Safari/537.36 Zalo android/26041894 ZaloTheme/light ZaloLanguage/vi	171.226.24.154	\N	\N	\N	\N	\N
f110b544-1a0e-40be-b5ab-df89e72ac2a6	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 03:28:00.606426+00	2026-05-09 07:05:25.178742+00	\N	aal1	\N	2026-05-09 07:05:25.178643	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
cf6f6ae7-5fb6-40c4-81c7-cb16de297381	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 07:05:34.586741+00	2026-05-09 08:04:02.34513+00	\N	aal1	\N	2026-05-09 08:04:02.341495	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
0f3a9007-aff0-4062-9959-09225ebfd97c	f1442181-b297-4857-a22a-63ce695149ec	2026-05-09 08:55:36.983254+00	2026-05-09 08:55:36.983254+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
9237627f-9577-4a49-a7e9-2b79807fdd27	1e4c7fef-312b-4cc1-85ce-465a4bc313bf	2026-05-09 09:08:33.293332+00	2026-05-09 09:08:33.293332+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
8c80946a-6ee5-4fea-b2b4-040477ccd705	9d05e348-d145-44a9-be0e-6021aa2e4efe	2026-05-09 09:25:43.303509+00	2026-05-09 09:25:43.303509+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
57549814-3673-4faa-b7ab-c407b9043653	1e4c7fef-312b-4cc1-85ce-465a4bc313bf	2026-05-09 09:28:19.551609+00	2026-05-09 09:28:19.551609+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
1a636561-6f17-45df-adaf-ce5f70f740e6	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 12:06:53.799504+00	2026-05-09 13:09:07.744602+00	\N	aal1	\N	2026-05-09 13:09:07.744511	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.254.179.189	\N	\N	\N	\N	\N
a2b80c3f-1573-48a6-a5a5-5a9c73bfabf4	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 09:52:50.146467+00	2026-05-09 10:51:38.853113+00	\N	aal1	\N	2026-05-09 10:51:38.851812	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
0feeed9a-363b-43b0-8fdd-2a6a317a4aa7	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	2026-05-09 08:57:00.77911+00	2026-05-09 10:56:22.728541+00	\N	aal1	\N	2026-05-09 10:56:22.727736	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
9898c482-9921-47c7-95a5-8e39fd3d4d20	53baabfc-21bb-43e2-85fb-fdfa56351b26	2026-05-09 00:46:20.562998+00	2026-05-09 12:06:48.922446+00	\N	aal1	\N	2026-05-09 12:06:48.922346	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.226.24.154	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	3f89aa8f-4801-409d-be20-390eceaee9ff	authenticated	authenticated	bithu@85247c6c-a1ff-4b86-bda4-417193ee1de8.com	$2a$10$u0SdaiHnQP5rs.GgUzS0eOzHQUuCrTQ0n8Dfl97WEiy4.limrZng6	2026-05-02 02:44:22.578529+00	\N		\N		\N			\N	2026-05-02 08:56:20.828879+00	{"provider": "email", "providers": ["email"]}	{"sub": "3f89aa8f-4801-409d-be20-390eceaee9ff", "email": "bithu@85247c6c-a1ff-4b86-bda4-417193ee1de8.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 02:44:22.505465+00	2026-05-02 15:16:15.120491+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	55b04869-9d7b-4c06-8245-6110fc2966e9	authenticated	authenticated	taotranbaongoc@gioithieu.com	$2a$10$k0A9KUFymQmFjqeW24pXge2oxVNyK45HY8SVYAfB4Thdd6SyEGySW	2026-05-02 22:54:16.760161+00	\N		\N		\N			\N	2026-05-02 22:54:16.884704+00	{"provider": "email", "providers": ["email"]}	{"sub": "55b04869-9d7b-4c06-8245-6110fc2966e9", "email": "taotranbaongoc@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 22:54:16.476798+00	2026-05-02 22:54:17.158659+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	93728c0a-a5e9-4009-9e7c-145231c1bf4e	authenticated	authenticated	admin@0b25ed79-509c-4144-9376-f861f7e17647.com	$2a$10$aCPnZ.LIz7faICMvmXSD8.11NpwhYbebfTZm6ijQONBJFM8KIgsGa	2026-05-02 02:33:27.045951+00	\N		\N		\N			\N	2026-05-02 02:39:36.557261+00	{"provider": "email", "providers": ["email"]}	{"sub": "93728c0a-a5e9-4009-9e7c-145231c1bf4e", "email": "admin@0b25ed79-509c-4144-9376-f861f7e17647.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 02:33:26.981752+00	2026-05-02 06:21:25.985342+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1f222835-fcc8-4ef3-856c-e3e82b2a75dd	authenticated	authenticated	bithu_10a10@85247c6c-a1ff-4b86-bda4-417193ee1de8.com	$2a$10$oTTKTOFMqSzQCOdAmFLhDe0ofa.5ml0A0JHKgW2wmJbDjGG/l/MXW	2026-05-03 08:00:42.609433+00	\N		\N		\N			\N	2026-05-03 08:00:45.087887+00	{"provider": "email", "providers": ["email"]}	{"sub": "1f222835-fcc8-4ef3-856c-e3e82b2a75dd", "email": "bithu_10a10@85247c6c-a1ff-4b86-bda4-417193ee1de8.com", "email_verified": true, "phone_verified": false}	\N	2026-05-03 08:00:42.500619+00	2026-05-03 08:00:45.135933+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c90e7aa2-810a-4180-807c-8ad3ae97fae4	authenticated	authenticated	bithu_11c7@85247c6c-a1ff-4b86-bda4-417193ee1de8.com	$2a$10$Vdq6WFxnSBYSSajhDOnFHeed/eJiMIDn6rzOnr7aZ.BoTywDzJHlq	2026-05-02 12:23:52.494098+00	\N		\N		\N			\N	2026-05-02 12:23:53.169509+00	{"provider": "email", "providers": ["email"]}	{"sub": "c90e7aa2-810a-4180-807c-8ad3ae97fae4", "email": "bithu_11c7@85247c6c-a1ff-4b86-bda4-417193ee1de8.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 12:23:52.400202+00	2026-05-02 12:23:53.18388+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	eac3c144-436c-4bd2-8aac-e78d96f19e52	authenticated	authenticated	admin@de8a298d-ae5b-4a68-9139-01ed2955cd3a.com	$2a$10$uuEJ0KkO8c2kCz7bu6y8cOiXOK.DfjJ3sFVjnaYmAnUNo8stlF8AW	2026-05-02 03:27:47.588814+00	\N		\N		\N			\N	2026-05-02 05:53:55.662717+00	{"provider": "email", "providers": ["email"]}	{"sub": "eac3c144-436c-4bd2-8aac-e78d96f19e52", "email": "admin@de8a298d-ae5b-4a68-9139-01ed2955cd3a.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 03:27:47.518813+00	2026-05-02 05:53:55.758111+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	4276ca70-28b5-47fc-8069-791858383367	authenticated	authenticated	bithu2@gioithieu.com	$2a$10$hrEvRMt6XZ/qIsauXu4Us.Ih4HUuyGHJV1Gg0GA6UtU7D6n6N0olq	2026-05-03 04:34:09.710837+00	\N		\N		\N			\N	2026-05-03 04:34:09.751936+00	{"provider": "email", "providers": ["email"]}	{"sub": "4276ca70-28b5-47fc-8069-791858383367", "email": "bithu2@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-03 04:34:09.623624+00	2026-05-03 04:34:09.801574+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	ecc34848-57cf-459d-862c-065de30363da	authenticated	authenticated	admin@85247c6c-a1ff-4b86-bda4-417193ee1de8.com	$2a$10$BTWDQHfCmX50mGNJxpz9i.qpDZlLIn5MgOJHOVf4pUK9Yp6jLDbxS	2026-05-02 02:38:10.141593+00	\N		\N		\N			\N	2026-05-03 10:27:17.641376+00	{"provider": "email", "providers": ["email"]}	{"sub": "ecc34848-57cf-459d-862c-065de30363da", "email": "admin@85247c6c-a1ff-4b86-bda4-417193ee1de8.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 02:38:10.072939+00	2026-05-03 10:27:24.299379+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	59ba10a7-3faa-4331-941f-7436721f0b23	authenticated	authenticated	gvcn_151@gioithieu.com	$2a$10$ZhnGK4OWjKzmqPauDdQ12elnzS.WGuFPMJyMbFzFLZtMoARQlgtkm	2026-05-03 08:28:12.446682+00	\N		\N		\N			\N	2026-05-03 08:28:12.523219+00	{"provider": "email", "providers": ["email"]}	{"sub": "59ba10a7-3faa-4331-941f-7436721f0b23", "email": "gvcn_151@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-03 08:28:11.647339+00	2026-05-03 08:28:12.669127+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	53baabfc-21bb-43e2-85fb-fdfa56351b26	authenticated	authenticated	admin@gioithieu.com	$2a$10$w037J9APvyDDsyHqmeRmKutlhlv0qndD58bGNT12LsM7aPQBSBjVq	2026-05-02 03:41:17.299149+00	\N		\N		\N			\N	2026-05-09 12:06:53.797298+00	{"provider": "email", "providers": ["email"]}	{"sub": "53baabfc-21bb-43e2-85fb-fdfa56351b26", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-02 03:41:17.243249+00	2026-05-09 13:09:07.737507+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	b94273ee-bc95-4b0d-987f-b2b3655199f8	authenticated	authenticated	hs0001@gioithieu.com	$2a$10$U6MIF.iROLaASJMZaSCdZObyEE3OMpY9.2SWFKzUSbdfRPC8RwoCS	2026-05-04 04:05:54.203169+00	\N		\N		\N			\N	2026-05-04 05:02:00.60809+00	{"provider": "email", "providers": ["email"]}	{"sub": "b94273ee-bc95-4b0d-987f-b2b3655199f8", "email": "hs0001@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-04 04:05:54.135985+00	2026-05-04 05:02:00.975585+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f8652643-0aac-4cee-803f-e689419fe979	authenticated	authenticated	bithu1@gioithieu.com	$2a$10$RrIfVDKPDh19zNAfL/eMXOAHGaOQ2cxc/EQyUxySmcBBRJjE378RS	2026-05-03 02:19:38.89927+00	\N		\N		\N			\N	2026-05-04 04:02:20.401164+00	{"provider": "email", "providers": ["email"]}	{"sub": "f8652643-0aac-4cee-803f-e689419fe979", "email": "bithu1@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-03 02:19:38.857+00	2026-05-04 09:28:53.534071+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c8c61706-f5fc-4032-8c18-e97fa2c9a8cf	authenticated	authenticated	admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com	$2a$10$4JI4mtEqCR/IuoiRmZGSf.gjxUpuZM0iQcUmBSeXiXguF.ghiubLC	2026-05-03 21:59:40.936999+00	\N		\N		\N			\N	2026-05-09 08:57:00.778628+00	{"provider": "email", "providers": ["email"]}	{"sub": "c8c61706-f5fc-4032-8c18-e97fa2c9a8cf", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}	\N	2026-05-03 21:59:40.888009+00	2026-05-09 10:56:22.714654+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	351d73d3-961d-4f8e-9f6d-d1c06092384a	authenticated	authenticated	bithu_10a2@gioithieu.com	$2a$10$qqZkmjKnUqnUP.ynGKYM6uOUOWtVMjC3e9fMTZ26KulgfvdEtWlpC	2026-05-07 11:30:48.505714+00	\N		\N		\N			\N	2026-05-07 11:30:48.55137+00	{"provider": "email", "providers": ["email"]}	{"sub": "351d73d3-961d-4f8e-9f6d-d1c06092384a", "email": "bithu_10a2@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-07 11:30:48.335058+00	2026-05-07 11:30:48.682181+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd	authenticated	authenticated	huynhhuuthua@gioithieu.com	$2a$10$9AJ9xjVG0q1VMusjrnVPnO/A5IuxbSaeHctl1mBaxJdSzoLy8Mt0m	2026-05-09 08:58:50.821817+00	\N		\N		\N			\N	2026-05-09 08:58:50.843079+00	{"provider": "email", "providers": ["email"]}	{"sub": "abdd16a9-02cc-4bf7-9ac5-6ca74d9e82cd", "email": "huynhhuuthua@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-09 08:58:50.73386+00	2026-05-09 08:58:50.873718+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9d05e348-d145-44a9-be0e-6021aa2e4efe	authenticated	authenticated	gvcn_11c8@gioithieu.com	$2a$10$/MrwPm77C.zxag.93oeWMuojLg0nfem8crfqTQyVRzSj0jym0C4BW	2026-05-09 09:25:43.263458+00	\N		\N		\N			\N	2026-05-09 09:25:43.299844+00	{"provider": "email", "providers": ["email"]}	{"sub": "9d05e348-d145-44a9-be0e-6021aa2e4efe", "email": "gvcn_11c8@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-09 09:25:42.877037+00	2026-05-09 09:25:43.396625+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1e4c7fef-312b-4cc1-85ce-465a4bc313bf	authenticated	authenticated	hohuuthe@gioithieu.com	$2a$10$8/YaMpLuZTePWORbY0ZWKuXN5ppop1YaYUYhOfcpxSKHbwIAeu0Oy	2026-05-09 09:08:33.193255+00	\N		\N		\N			\N	2026-05-09 09:28:19.549622+00	{"provider": "email", "providers": ["email"]}	{"sub": "1e4c7fef-312b-4cc1-85ce-465a4bc313bf", "email": "hohuuthe@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-09 09:08:33.016934+00	2026-05-09 09:28:19.602647+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	993e879a-890f-4ed0-8b66-9d6961212f0e	authenticated	authenticated	bithu@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com	$2a$10$nIJxWMzZ8s7fOueoC6m/suelFcd4pjp.beQ5gcAqlvNC9RWyRy91W	2026-05-04 07:34:16.200082+00	\N		\N		\N			\N	2026-05-04 07:34:16.215415+00	{"provider": "email", "providers": ["email"]}	{"sub": "993e879a-890f-4ed0-8b66-9d6961212f0e", "email": "bithu@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}	\N	2026-05-04 07:34:16.143393+00	2026-05-04 09:33:33.879016+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc	authenticated	authenticated	bithu@gioithieu.com	$2a$10$bt4/szYv/6fzrNAcp1vC6OoOnMKcRnCDo.ivdaESP1nLty0kzIRV2	2026-05-04 04:21:34.389626+00	\N		\N		\N			\N	2026-05-04 06:51:05.894361+00	{"provider": "email", "providers": ["email"]}	{"sub": "9c09d0e6-a1d2-4a09-b7c0-0d12ca54dccc", "email": "bithu@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-04 04:21:34.327972+00	2026-05-04 10:10:03.775434+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	f1442181-b297-4857-a22a-63ce695149ec	authenticated	authenticated	vothile1@gioithieu.com	$2a$10$cNhrhYv6B.NOl0odVJ02r.d0qqf10pTlNRpHd33ip28cFbtMNfw5G	2026-05-09 01:29:43.789013+00	\N		\N		\N			\N	2026-05-09 08:55:36.981671+00	{"provider": "email", "providers": ["email"]}	{"sub": "f1442181-b297-4857-a22a-63ce695149ec", "email": "vothile1@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-09 01:29:43.748584+00	2026-05-09 08:55:37.026587+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id") FROM stdin;
194bf509-c7b3-4a47-9cdd-7ea89a7a30a3	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	0f7c0fa5-7ba2-4f4a-ac47-38dc43384f4d	Rơ Mah Điềm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5ef21e40-6b45-40d8-a24d-6bee8c1f432c	2026-05-08 14:08:19.711+00	\N
ed7822b0-00f7-4abf-92b4-042be8dea14a	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	0a4e59dc-cf48-41c9-9554-c7ed639e2539	Đặng Thùy Linh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5ef21e40-6b45-40d8-a24d-6bee8c1f432c	2026-05-08 14:08:19.711+00	\N
2658ecff-60dc-4adb-b7e9-9ff5adabc2be	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	f9c48044-beb9-4ca0-ae76-13586115e60a	Kpuih Trí	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5ef21e40-6b45-40d8-a24d-6bee8c1f432c	2026-05-08 14:08:19.711+00	\N
14fa5680-d26b-42bf-b087-acb7adcbd9c3	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	539248e4-4825-42e2-b5e1-52dd70ae3fba	33250f94-6931-47dd-ac2f-bb4e8a5535b1	03337fd9-bcc7-45bc-9b67-840253859c76	Nguyễn Thị Ngọc Phượng	TC01	Đi học muộn	Vi phạm	2	0	Sổ cổng sáng thứ 3	539248e4-4825-42e2-b5e1-52dd70ae3fba	2026-05-08 14:08:19.711+00	\N
772565c3-0535-49eb-a3d3-ab81f905b44a	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	141be337-7bb7-4d92-bd8e-21330ef7702f	02180031-0a4d-4aa7-b43b-0d3549779653	599b49cc-1992-4526-ae52-5bf7d940e264	Phan Thị Thu Hằng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		141be337-7bb7-4d92-bd8e-21330ef7702f	2026-05-08 14:08:19.711+00	\N
6dfa49d8-52e9-4a37-a7c3-2daf957ee2b1	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	846cdc56-d3b7-494e-b805-6e584dcd9392	141be337-7bb7-4d92-bd8e-21330ef7702f	c5300675-c6cc-473a-b29d-444bb840c78b	Trần Văn Khánh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		846cdc56-d3b7-494e-b805-6e584dcd9392	2026-05-08 14:08:19.712+00	\N
d3e33e21-a539-4951-8e6e-b8d926da419b	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	93ed547c-5b97-49e5-be05-b64ade9a6586	73fd5eb9-d6a9-47be-b1aa-5392d2466618	Trần Thị Mỹ Tâm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	2026-05-08 14:08:19.712+00	\N
79e6b7c4-1b78-437e-be10-2ec2ca29cdc4	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	93ed547c-5b97-49e5-be05-b64ade9a6586	bf8ff2b8-31d1-4e45-88e4-2c5a5b64956e	Trần Minh Thư	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	2026-05-08 14:08:19.712+00	\N
551bbd80-c286-4b46-9c07-98e757ef648a	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	93ed547c-5b97-49e5-be05-b64ade9a6586	4513cbe1-3f68-47c2-accc-350504325682	Nguyễn Khắc Hùng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	2026-05-08 14:08:19.712+00	\N
7b673b07-513d-4cd4-819d-0e3063aada2c	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	93ed547c-5b97-49e5-be05-b64ade9a6586	8cdbe5ad-9a05-4f45-ab11-fa6f756d0674	Lý Trâm Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	2026-05-08 14:08:19.712+00	\N
00a07a24-0c4a-4d5f-b4b0-050681b85a1e	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	76691235-4889-43c5-912f-22ec7dbfb5f3	Chu Thị Quỳnh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.712+00	\N
71d6d4b1-797f-46c4-ae65-e5c8408eaa35	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	3e631f27-48da-4a5f-8f0b-adacdccd5f99	Nguyễn Văn Tuấn	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.712+00	\N
23c15f51-953d-462b-980f-decbbb8ecd14	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	bf28accd-a226-49f7-8715-c05bf8857353	Đậu Quang Thỏa Hiệp	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.712+00	\N
6d551a8e-fef3-4a1e-a334-c11af138c2a2	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	82a6c205-d925-48d9-9f98-f0559b639f9a	Nguyễn Văn Mạnh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.712+00	\N
33cd76b4-0ddf-4ebf-af28-40cf5ecc4b38	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	2f26724f-0e53-4b43-82f9-ca2d6f87f06d	Đoàn Ngô Vũ Luân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.713+00	\N
ef59cccc-faff-4424-9d55-6b9543941f0f	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	02180031-0a4d-4aa7-b43b-0d3549779653	5d2969a5-0d68-4845-bcab-407f002e89b1	753fe8e5-5cbc-4e9c-9264-5b6f65ab1f3e	Rơ Lan Kim A	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		02180031-0a4d-4aa7-b43b-0d3549779653	2026-05-08 14:08:19.713+00	\N
eee85325-ea1b-4038-9a37-bfc3e35cc110	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	02180031-0a4d-4aa7-b43b-0d3549779653	5d2969a5-0d68-4845-bcab-407f002e89b1	cdafe818-3f41-48b3-b8fc-38924c6c70e7	Kpuih Lan Văn	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		02180031-0a4d-4aa7-b43b-0d3549779653	2026-05-08 14:08:19.713+00	\N
698df0e5-6395-4cd0-bc47-9767c9190c06	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	02180031-0a4d-4aa7-b43b-0d3549779653	5d2969a5-0d68-4845-bcab-407f002e89b1	7b879a48-c03d-4b4d-b1ca-9bc25488a544	Khuất Anh Khoa	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		02180031-0a4d-4aa7-b43b-0d3549779653	2026-05-08 14:08:19.713+00	\N
06779451-7ac4-4ab2-8d5c-7b1e91788e51	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	6538c9ab-9f9c-42f5-afd3-c52c75ade10f	Kpuih Kiệt	TC01	Đi học muộn	Vi phạm	2	0		Trần Thị Thủy Tâm - Phó BT ĐT	2026-05-08 14:08:19.713+00	\N
2dcb1081-98de-4afa-9fcb-d6775550ee22	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	71767878-bb5f-43d2-a409-17a95f26ff39	Nguyễn Văn Sang	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.713+00	\N
8c5c65aa-3305-4497-b04d-b91b09fcf0f7	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	50517434-db92-4415-86fe-330f5067431d	Nguyễn Trọng Tâm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.713+00	\N
7c66ada7-b82a-4214-9fdd-83cc32ebde51	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	7b3b945b-4956-4eba-af49-d6af3cfce237	Dương Hữu Lộc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.714+00	\N
22883131-6ab0-4114-9ec5-1227cff42cde	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	fa45f554-b9fe-4224-b289-8c6e847ab4a0	Hà Như Ngọc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.669+00	\N
01eb7bc2-602a-4b62-938a-645a9d4a7aac	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	f1e5773a-d263-4bea-a200-c5066720380c	Nguyễn Duy Khánh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.669+00	\N
1e59c27f-a118-4a27-91ef-2f978ed4b845	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	600a84d8-4f96-44e1-80a5-29f9d808ba03	Rơ Châm Vũ Bảo Trang	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.669+00	\N
79d49fa0-7a12-40da-afb6-309c8d220a22	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	2b9cbf01-35f2-48a4-b7a2-06afed784206	Nguyễn Thị Thanh Ngọc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.669+00	\N
22b36287-31a5-45f1-90db-e282303cec98	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	0a5bb4bd-c7f5-466e-a6dd-1514c591ab6e	Lương Thị Hà Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.669+00	\N
5abeda31-f5e9-4a05-9e84-7c787fa495fc	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	2eb12ec5-33c1-46f5-91a0-d27f32f3c5dd	Lê Thị Mai Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.67+00	\N
3f007b77-2672-44fc-a948-bdc9e7dc5697	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 2	2026-04-27	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	d5b7810b-6a0e-44ef-96d3-db6d170ae520	Lê Minh Hoàng	TC29	Mang quà vặt lên lớp	Vi phạm	10	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.67+00	\N
c46596bd-3da4-4777-ae16-22bde02b3faf	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	c1a121e9-d6aa-4dff-9736-56bf57296aeb	Ngô Sỹ Thêm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.67+00	\N
5cafaaf1-6f59-4903-b3e1-296c854fb1be	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	4e1d3528-0282-41f6-a17c-b04f7a5bb22d	Bùi Lê Trung Nguyên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.67+00	\N
2118f600-daa2-4c2c-8c43-cb148001e398	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	9f6d8ea1-ea7a-4470-88fe-012bd8189b07	Phạm Khánh Duy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.67+00	\N
80b5cbe1-b165-4a33-827a-39742b07d571	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	ea020c65-cdad-4926-8071-673f30c2789e	Rơ Mah Bom	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.67+00	\N
c19394df-9426-4844-b696-66da9d0a6e31	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	522e7e6c-82c8-4dd3-9c0f-bbd2bbb7c1ae	Nguyễn Văn Cường	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.67+00	\N
1c299622-fd41-48a0-bd53-d31b68f3c779	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	5609c740-ff28-4573-9637-39ea8d9a1733	Trần Gia Hưng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.671+00	\N
ddb91ee1-f33d-450b-bea5-4ff97afdfede	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	\N	Tập thể 12B9	TC26	Vệ sinh muộn	Vi phạm	5	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.673+00	539248e4-4825-42e2-b5e1-52dd70ae3fba
977f8e9a-1678-4c5b-9633-822e36c6b4ab	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	6ee012f0-a2c0-4515-877a-288e91ba25b7	Lê Văn Phụng	TC10	Không quai dép	Vi phạm	5	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.673+00	\N
ceec5355-3846-44ab-898b-b5c1e4913d38	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	5b727795-d975-41cc-8854-ee5a186cac6e	Hồ Văn An	TC10	Không quai dép	Vi phạm	5	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.673+00	\N
7431672f-57a1-4a98-b525-59f8876d7651	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	7eb62d3c-f9cb-4386-9df9-6cd71c4b6391	Đinh Thị Ngọc Anh	TC29	Mang quà vặt lên lớp	Vi phạm	10	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
6d1b1a59-5c1c-41af-8253-defa8df051f6	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	9f6d8ea1-ea7a-4470-88fe-012bd8189b07	Phạm Khánh Duy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
fd97be70-caf3-4385-b5e4-11c73b7b0817	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	522e7e6c-82c8-4dd3-9c0f-bbd2bbb7c1ae	Nguyễn Văn Cường	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
7991d83a-8563-4ee2-b8fd-e93e4aa62bc7	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	5609c740-ff28-4573-9637-39ea8d9a1733	Trần Gia Hưng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
cab963d4-e74f-417b-bac5-4ec0b2e0d370	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	d6ae2d2d-c066-4623-862e-85e65eb8a809	Lương Thị Thủy Tiên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
6608d046-a1c3-4350-b42f-89d79a0cd168	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	a109f481-e19a-4375-a321-897acf8974c7	Rơ Mah Luy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
75732630-d024-4c53-b6f9-bd3eb18239cd	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	7994dab9-614a-4f9d-ae27-c76996ac0a34	Rơ Mah Dấu	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
3db5e0dd-3b40-4217-87cd-b79a806ea843	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	ea020c65-cdad-4926-8071-673f30c2789e	Rơ Mah Bom	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
33fc2b4b-6c28-49da-b37d-446bf6079c24	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	1d712008-dda7-4791-8b18-a2078c091830	539248e4-4825-42e2-b5e1-52dd70ae3fba	911a0b92-86be-4c39-834c-5aa4a0b8dbd6	Lê Thị Hiền	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		1d712008-dda7-4791-8b18-a2078c091830	2026-05-08 14:08:19.674+00	\N
ab467196-d2ef-4c28-872b-255a9dab5afa	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 2	2026-04-27	65560ab5-035b-496a-9133-a50d9bf0a0d0	846cdc56-d3b7-494e-b805-6e584dcd9392	0ad7d3ae-d26b-4190-a891-00c70a22cf75	Nguyễn Thị Thanh Ngân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		65560ab5-035b-496a-9133-a50d9bf0a0d0	2026-05-08 14:08:19.677+00	\N
a59f389b-2e90-4834-b4c9-9e60d869277c	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	44722561-7fa7-44ef-9a26-cdfeb098934f	84ee092b-3b6d-48aa-8324-f4eafda5b546	c286c4bc-ce2b-4176-9a80-7ca0a3c9223b	Thái Hoàng Mỹ Uyên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		44722561-7fa7-44ef-9a26-cdfeb098934f	2026-05-08 14:08:19.677+00	\N
6f13cd6e-dc17-43d6-8b01-e735d69b38b9	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	44722561-7fa7-44ef-9a26-cdfeb098934f	84ee092b-3b6d-48aa-8324-f4eafda5b546	4279c481-4639-4c4c-83d0-73e077471151	Nguyễn Hà Thảo My	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		44722561-7fa7-44ef-9a26-cdfeb098934f	2026-05-08 14:08:19.677+00	\N
793521e8-1f52-42fc-9ac9-b34bc4ba0517	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	44722561-7fa7-44ef-9a26-cdfeb098934f	84ee092b-3b6d-48aa-8324-f4eafda5b546	d7d3766f-b453-44ff-af8d-0da223e683e2	Trương Thị Thu Na	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		44722561-7fa7-44ef-9a26-cdfeb098934f	2026-05-08 14:08:19.677+00	\N
bf2842b5-b297-4385-ae19-6e8079fafd96	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	61a554f0-87f5-4dbd-a152-22cebed82925	0c673b7d-6199-4fbd-b3ce-5a11324113b6	3107d2be-c342-40a7-9664-dfd7cc38d186	Rơ Mah H' Lang	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		61a554f0-87f5-4dbd-a152-22cebed82925	2026-05-08 14:08:19.677+00	\N
223ffe2c-e0d9-41fb-8da4-259a2a472917	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	61a554f0-87f5-4dbd-a152-22cebed82925	0c673b7d-6199-4fbd-b3ce-5a11324113b6	bcd71496-703b-4147-afd9-4da246e1c4ec	Hồ Hữu Đại	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		61a554f0-87f5-4dbd-a152-22cebed82925	2026-05-08 14:08:19.678+00	\N
952dbbeb-5321-438f-9453-127f810500c5	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	61a554f0-87f5-4dbd-a152-22cebed82925	0c673b7d-6199-4fbd-b3ce-5a11324113b6	2ed5d5f2-7e4c-4278-a557-79afd0fb8bcb	Lê Trần Gia Bảo	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		61a554f0-87f5-4dbd-a152-22cebed82925	2026-05-08 14:08:19.678+00	\N
08cb781a-ea28-459a-bb1f-e9a5c81c021a	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 5	2026-04-30	fce39a4b-0928-4944-b3bf-d8efe09ddaf3	c9981426-89cd-4565-8c8e-5f1119f30018	\N	Tập thể 12B2	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Vi phạm	0	0	không vi phạm	fce39a4b-0928-4944-b3bf-d8efe09ddaf3	2026-05-08 14:08:19.68+00	c9981426-89cd-4565-8c8e-5f1119f30018
aaf571a9-bde6-4e96-ad58-d48490334bcd	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 5	2026-04-30	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	d9ba578d-620d-440e-a811-ae60582078e9	Phan Quốc Vương	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5d2969a5-0d68-4845-bcab-407f002e89b1	2026-05-08 14:08:19.68+00	\N
4effc562-0266-4694-9e49-7619c1dc65a6	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 5	2026-04-30	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	85247163-36df-412e-9bb2-4fc9e7e549f2	Hà Thanh Lâm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5d2969a5-0d68-4845-bcab-407f002e89b1	2026-05-08 14:08:19.681+00	\N
da75a7f6-4fe9-43d1-a550-cff20de1df68	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	c0071337-e27c-405a-a40d-7c8a2ede3f52	Nguyễn Hồng An	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5d2969a5-0d68-4845-bcab-407f002e89b1	2026-05-08 14:08:19.681+00	\N
5df46dce-df9d-442c-823f-19fe171f446e	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	905ccb7f-b98f-459d-b287-6e1cebd633f0	Rơ Châm Thảo My	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5d2969a5-0d68-4845-bcab-407f002e89b1	2026-05-08 14:08:19.681+00	\N
39008b79-4a2b-47b4-9637-8df258bbe833	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	b3e79ebf-d3d9-42f9-a0d4-ae6e3ba1eddd	Siu H' Beo	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5d2969a5-0d68-4845-bcab-407f002e89b1	2026-05-08 14:08:19.681+00	\N
649aec6a-d650-4d08-a6f2-1cb5ee9dc563	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	702a03a5-1641-41ba-821f-7c0c4eb6e46b	Ngô Trí Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		5d2969a5-0d68-4845-bcab-407f002e89b1	2026-05-08 14:08:19.681+00	\N
4a3e0f65-f665-4ae4-bd92-bff4d64ad792	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 5	2026-04-30	b7b2f041-de5d-49db-8186-5dd8db250052	25d78477-f93d-401d-85b3-3a39ba2e83e7	\N	Tập thể 11C5	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Vi phạm	0	0		b7b2f041-de5d-49db-8186-5dd8db250052	2026-05-08 14:08:19.684+00	25d78477-f93d-401d-85b3-3a39ba2e83e7
5d2fd465-dcab-4a6e-b3f5-370f3f6ab7b7	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	84ee092b-3b6d-48aa-8324-f4eafda5b546	1c86cf6e-19bd-42ea-8cb0-8137cb63988a	987dac80-3d3a-493c-9316-f7cf064d5363	ĐẶNG THỊ YẾN NHI	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		84ee092b-3b6d-48aa-8324-f4eafda5b546	2026-05-08 14:08:19.684+00	\N
aa499d39-88c8-43da-af14-8c84da863c05	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	93ed547c-5b97-49e5-be05-b64ade9a6586	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	b2fea11b-52ad-49b5-ad74-91721c6254a3	Nguyễn Hương Thảo	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		93ed547c-5b97-49e5-be05-b64ade9a6586	2026-05-08 14:08:19.684+00	\N
e46ad7b3-2bc9-4912-89a8-aaaebb964ab8	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	33250f94-6931-47dd-ac2f-bb4e8a5535b1	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	074fd61a-7962-468b-8fba-c9a953675059	Hồ Thị Tình	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		33250f94-6931-47dd-ac2f-bb4e8a5535b1	2026-05-08 14:08:19.684+00	\N
20a16718-39b7-4ec0-acf9-dc2bd393800f	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	33250f94-6931-47dd-ac2f-bb4e8a5535b1	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	df3d058a-ae56-4685-aa21-e1eb8e89a388	Trần Thị Thanh Nhàn	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		33250f94-6931-47dd-ac2f-bb4e8a5535b1	2026-05-08 14:08:19.685+00	\N
e9575024-0fc5-43be-b748-75343aa33e06	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	fdc18dde-9e98-4ceb-831f-2944f68998d4	b7b2f041-de5d-49db-8186-5dd8db250052	\N	Tập thể 11C4	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Vi phạm	0	0		fdc18dde-9e98-4ceb-831f-2944f68998d4	2026-05-08 14:08:19.69+00	b7b2f041-de5d-49db-8186-5dd8db250052
ea7399ee-b3dd-43a3-91c1-bc3fb7d31420	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	09d8ade5-bb92-46ab-98e7-3ab869d59f75	65560ab5-035b-496a-9133-a50d9bf0a0d0	fe271c35-24f8-4766-8c07-46d49790226b	Hoàng Thị Thu Hoài	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		09d8ade5-bb92-46ab-98e7-3ab869d59f75	2026-05-08 14:08:19.69+00	\N
198318f7-ab94-4080-ad95-4a04ded88901	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	09d8ade5-bb92-46ab-98e7-3ab869d59f75	65560ab5-035b-496a-9133-a50d9bf0a0d0	3725c6a7-045e-448b-aa38-3e662a06c170	Trần Văn Thái	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		09d8ade5-bb92-46ab-98e7-3ab869d59f75	2026-05-08 14:08:19.69+00	\N
751f8e6f-194b-4f10-a7dc-a48e88cd4078	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	09d8ade5-bb92-46ab-98e7-3ab869d59f75	65560ab5-035b-496a-9133-a50d9bf0a0d0	73d5fb36-6389-4f4e-a6ce-fa44d7acfbf8	Bùi Thị Khánh Linh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		09d8ade5-bb92-46ab-98e7-3ab869d59f75	2026-05-08 14:08:19.69+00	\N
9bea1bd2-d8fc-4f92-ac00-ce88f9172cbc	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Chủ nhật	2026-05-03	1c86cf6e-19bd-42ea-8cb0-8137cb63988a	fce39a4b-0928-4944-b3bf-d8efe09ddaf3	\N	Tập thể 12B4	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Vi phạm	0	0		1c86cf6e-19bd-42ea-8cb0-8137cb63988a	2026-05-08 14:08:19.693+00	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
3419425e-649f-43ef-aa86-b8779b974e28	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	3e631f27-48da-4a5f-8f0b-adacdccd5f99	Nguyễn Văn Tuấn	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.693+00	\N
8abdcd8c-3dd5-45a0-93e3-ae2958374a13	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	bf28accd-a226-49f7-8715-c05bf8857353	Đậu Quang Thỏa Hiệp	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.693+00	\N
9f7b788f-0b8c-47ed-9a05-7da421156d9d	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	a3b4c2d8-b70b-464a-8282-c77ad9e70605	Kpuih H' Ngát	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.693+00	\N
3db333aa-73dd-4541-994a-bd36173e4ed4	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	2f26724f-0e53-4b43-82f9-ca2d6f87f06d	Đoàn Ngô Vũ Luân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	2026-05-08 14:08:19.693+00	\N
417763fb-def7-4e92-85e4-2ca75568e666	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	f7501580-cc9c-41c9-a00d-0f8c54c13bcb	325ddee6-e5ad-47d5-8351-b12c1eb67acc	\N	Tập thể 11C2	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Vi phạm	0	0		f7501580-cc9c-41c9-a00d-0f8c54c13bcb	2026-05-08 14:08:19.696+00	325ddee6-e5ad-47d5-8351-b12c1eb67acc
0662aefc-fc0c-44d9-81d3-5da157836d1f	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	\N	Tập thể 10A10	TC53	Trực cầu thang bẩn	Vi phạm	5	0		Lê Minh Phương BTV	2026-05-08 14:08:19.698+00	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
ff9fc8ff-afc8-4a8b-be9c-740cc311289a	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	5d2969a5-0d68-4845-bcab-407f002e89b1	b43602fc-3d2e-48a1-b281-4fa1b7aabef9	\N	Tập thể 10A10	TC53	Trực cầu thang bẩn	Vi phạm	5	0		Lê Minh Phương BTV	2026-05-08 14:08:19.701+00	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
be45356d-d456-4bad-b847-ea3194a0c445	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	93ed547c-5b97-49e5-be05-b64ade9a6586	\N	Tập thể 12B3	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Vi phạm	0	0		642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	2026-05-08 14:08:19.703+00	93ed547c-5b97-49e5-be05-b64ade9a6586
1ac1c60f-1d4d-4538-857a-d036d634ac2f	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	02180031-0a4d-4aa7-b43b-0d3549779653	5d2969a5-0d68-4845-bcab-407f002e89b1	c1cea216-5cbd-435d-9e7a-21ffe1cb040b	Lương Hữu Phương	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		02180031-0a4d-4aa7-b43b-0d3549779653	2026-05-08 14:08:19.703+00	\N
0dd1f890-19e7-4df3-a6ee-c2f2660f84b1	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	02180031-0a4d-4aa7-b43b-0d3549779653	5d2969a5-0d68-4845-bcab-407f002e89b1	58186ebc-f6db-4a3b-9086-a13e781e8d5a	Đặng Hồ Phương Linh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		02180031-0a4d-4aa7-b43b-0d3549779653	2026-05-08 14:08:19.703+00	\N
149c4dc7-6d99-4b5d-952f-c3aa5e33811f	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	02180031-0a4d-4aa7-b43b-0d3549779653	5d2969a5-0d68-4845-bcab-407f002e89b1	753fe8e5-5cbc-4e9c-9264-5b6f65ab1f3e	Rơ Lan Kim A	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		02180031-0a4d-4aa7-b43b-0d3549779653	2026-05-08 14:08:19.703+00	\N
50d863af-73ac-4a24-8aee-4af544a14bdb	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	1d712008-dda7-4791-8b18-a2078c091830	\N	Tập thể 11C6	TC26	Vệ sinh muộn	Vi phạm	5	0		6d3e0c06-4ed8-460c-8ebc-67ade36f0276	2026-05-08 14:08:19.709+00	1d712008-dda7-4791-8b18-a2078c091830
5c1e719b-c03a-4310-abb0-b8e8fe7ff2c3	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	1d712008-dda7-4791-8b18-a2078c091830	81214e59-b082-44ab-b5ff-cb5ee6a43417	Nguyễn Thị Quỳnh Nhi	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		6d3e0c06-4ed8-460c-8ebc-67ade36f0276	2026-05-08 14:08:19.709+00	\N
59fa1dc8-6949-45bd-b648-affc86a7bca2	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	1d712008-dda7-4791-8b18-a2078c091830	41114c2f-e5c0-4a65-92ba-7b27adc49544	Cao Chấn Đông	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		6d3e0c06-4ed8-460c-8ebc-67ade36f0276	2026-05-08 14:08:19.709+00	\N
369e49bb-ccf3-43fb-99cb-09b3bf8642b9	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	1d712008-dda7-4791-8b18-a2078c091830	4e29f357-4997-44c7-a64b-275378cbf2aa	Rơ Mah Liêm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		6d3e0c06-4ed8-460c-8ebc-67ade36f0276	2026-05-08 14:08:19.709+00	\N
ccdc5657-a317-4677-bdea-a2fe3a447939	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	6d3e0c06-4ed8-460c-8ebc-67ade36f0276	1d712008-dda7-4791-8b18-a2078c091830	41114c2f-e5c0-4a65-92ba-7b27adc49544	Cao Chấn Đông	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		6d3e0c06-4ed8-460c-8ebc-67ade36f0276	2026-05-08 14:08:19.709+00	\N
5ac3e1bd-1862-43a4-ada0-5551cdf7c8f3	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	146fdb02-0c4c-49b2-b32f-efb174b3f886	Bùi Lương Hải Đăng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.709+00	\N
4d48a4b1-5ba5-47d3-b209-ef2129e62dca	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	8cdd1e55-2614-4e9a-ab36-09099d1b97e2	Nguyễn Tiến Vinh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
03b7d153-b2a7-4ccd-852d-4c95f13ba2f6	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
8476f28b-d56f-4148-b8fd-c76020446db4	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	440b60d2-0be6-401a-9ca6-03787396db35	Nguyễn Văn Tài	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
6de3a7ea-35fe-44c6-997b-2854da395ccf	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	cf35b19c-6a66-4cf1-a3ae-ff2ec40481f6	Phùng Chí Long	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
80d41a7b-aa7a-4f07-ab4c-f024be7e34b8	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	b6385120-f9f0-4c28-964e-6594b2aaabd5	Mai Hoàng Phi	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
9b0a8b9a-e324-45de-8bc9-d95c38671de5	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
e38216da-3461-4168-ad69-76d34d77979e	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	04eccc7d-8439-421e-aee8-ab07b4dec31b	Vũ Quốc Huy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
abf7bc47-cf7b-413e-8ee2-9a9c8088f594	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	faffb8ff-2084-4fc2-a189-0a15a0e0c058	Đoàn Trần Anh Thư	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.71+00	\N
7d75e302-7ba6-48a0-880b-827e331deffd	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 4	2026-04-29	44722561-7fa7-44ef-9a26-cdfeb098934f	84ee092b-3b6d-48aa-8324-f4eafda5b546	7e6d804b-4bb7-4790-becd-6146d8d46a07	Lê Đại Đồng	TC02	Cúp tiết	Vi phạm	5	0	Tiết Địa 4,5	Ksor H Quet	2026-05-08 14:08:19.71+00	\N
c590d54c-cf9c-4272-ae35-8b07595eb62d	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	61a554f0-87f5-4dbd-a152-22cebed82925	0c673b7d-6199-4fbd-b3ce-5a11324113b6	ccaa6f72-343e-44b5-bd9d-d30c468203e0	Lê Nguyễn Trà My	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		61a554f0-87f5-4dbd-a152-22cebed82925	2026-05-08 14:08:19.711+00	\N
f1a7fead-1141-402a-8e46-907ad408dacb	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	61a554f0-87f5-4dbd-a152-22cebed82925	0c673b7d-6199-4fbd-b3ce-5a11324113b6	f999cb05-84a5-49b6-9e99-061b00bd01b3	Đỗ Hà Lan	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		61a554f0-87f5-4dbd-a152-22cebed82925	2026-05-08 14:08:19.711+00	\N
06cbd2df-2d74-45e6-99a7-409fe928822e	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	d7253c52-2efb-4b00-acb4-51edd46b02d4	Phạm Ngọc Khánh Băng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.714+00	\N
2f0ad5b0-21c3-434e-bd68-57d1004a8061	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	c15ea371-e3c3-4007-9206-2f88c7d56b2f	Hoàng Nguyễn Bảo Long	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.714+00	\N
07de727c-0c47-4e37-abc8-ea7e6455eb72	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.714+00	\N
6dd88225-a029-4a1b-9d71-235cdde72ab8	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	450ff56c-ab21-4927-a712-9e9e155646b7	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		450ff56c-ab21-4927-a712-9e9e155646b7	2026-05-08 14:08:19.714+00	\N
f7654e2e-6fa9-4229-a7d3-f16f30f9f6de	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	44722561-7fa7-44ef-9a26-cdfeb098934f	84ee092b-3b6d-48aa-8324-f4eafda5b546	0d12676f-06e1-41a6-8496-55d4f5a1d418	Nguyễn Thu Hiền	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		44722561-7fa7-44ef-9a26-cdfeb098934f	2026-05-08 14:08:19.714+00	\N
ea2e00c6-86d4-4cab-9a16-aa138ef7c45b	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	c9981426-89cd-4565-8c8e-5f1119f30018	450ff56c-ab21-4927-a712-9e9e155646b7	77afc10e-f33f-4e28-8dad-3566bc4b63f6	Kpuih Trần	TC01	Đi học muộn	Vi phạm	2	0		c9981426-89cd-4565-8c8e-5f1119f30018	2026-05-08 14:08:19.714+00	\N
a15619d6-f650-4669-bdd6-7f0f4dff73f0	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	c9981426-89cd-4565-8c8e-5f1119f30018	450ff56c-ab21-4927-a712-9e9e155646b7	71d89426-a1a2-49f4-881f-5c9898718bf9	Nguyễn Hoàng Gia Huy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		c9981426-89cd-4565-8c8e-5f1119f30018	2026-05-08 14:08:19.714+00	\N
d8cda404-0193-49c0-ab57-e153600cd91a	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	Thứ 3	2026-04-28	c9981426-89cd-4565-8c8e-5f1119f30018	450ff56c-ab21-4927-a712-9e9e155646b7	13f76236-96ab-41d0-ac24-8bf2d814bbba	Đoàn Ngọc Nam Phương	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		c9981426-89cd-4565-8c8e-5f1119f30018	2026-05-08 14:08:19.715+00	\N
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "hocky", "diachi", "chidoan_id") FROM stdin;
720f92d6-550d-4085-95e0-210bfbce23f2	Ksor H’ Lê A	23/08/2010	Nữ	Gia-rai		f	10A7	\N	00	không	2026-05-03 13:24:59.744+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung le kắt, xã Ia Dớt , Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
17d6aa72-10d1-4cc6-b413-bce3de96cc01	Mai Đức Hiếu	27/02/2009	Nam	Kinh		t	11C9				2026-03-28 10:47:22.605+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 4 - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
bd4e72c9-25b0-433c-8c03-2c065a60430c	Lê Đình Lâm	03/02/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.884+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
88d463c9-fde1-4ed1-8f30-96dc5dfe1e65	ĐÀO THỊ THANH THẢO	01/11/2008	Nữ	Kinh		t	12B6				2026-03-26 02:05:01.444+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		TDP 9 - Chư Ty - Đức Cơ - Gia lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
7afbc2dc-bd6a-4fcc-b48e-7a87f28b1dec	Đinh Thị Trúc Linh	11/09/2008	Nữ	Kinh		t	12B9				2026-03-26 02:05:03.847+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP3, xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
e571d368-76ac-43ec-9c65-ea2bce2d34ce	Nguyễn Thị Như Quỳnh	2010-02-14	Nữ	Kinh		t	10A4	2025-04-20			2026-03-27 14:13:39.054+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
59345d98-8db8-49db-8715-ffad9ad15fc6	Hà Tiến Đạt	07/04/2010	Nam	Kinh		t	10A4				2026-04-27 14:33:51.183+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
9d2172ca-0a0f-449f-a804-4e25c1ac53d2	Quách Thùy Linh	2010-02-21	Nữ	Kinh		t	10A4	2025-04-25			2026-03-27 14:11:25.1+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
fc8c0354-cd5f-4355-a755-2d0e86420c62	Đào Gia Đức	01/10/2010	Nam	Kinh		t	10A4				2026-04-25 00:39:56.769+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Khóp, xã Ia Krel tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
8ccb7764-027b-4dd9-a6c5-afb4fe633e4c	Đỗ Viết Đạt	16/11/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.447+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
e37d84d3-2c81-4ac6-88c4-6bc96a1408c6	Võ Lê Thanh Thảo	05/02/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:24.668+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
abf18cb0-4618-4ddd-8481-68a23aa25d87	Võ Hoàng Ngọc Thiên	03/07/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:24.806+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ấp chợ, Xã Thống Nhất, Tỉnh Đồng Nai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
633de0c5-a190-4999-bf71-2d31a735f04d	Hồ Diên Thiện	30/08/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:24.952+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, xã Iakrel, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
b09cd342-6338-4093-b09f-38d738914c21	Trần Trọng Tiến	09/11/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:25.279+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
911cf14c-aa32-46af-819e-66bef517ec66	Nguyễn Thị Thảo Trang	22/01/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:25.6+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
9d3933ae-a49e-4e06-8826-b22993b27254	Nguyễn Bảo Ngọc	11/03/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:23.141+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
d31c986b-f027-429b-894c-f9cd50a58549	Bùi Nữ Vy Oanh	16/10/2009	Nữ	Kinh		t	11C1				2026-03-25 14:49:24.681+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ DP4-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
281a1c3f-9c02-42ed-9cac-67597edecdac	Bạch Thị Ngọc Hà	05/08/2010	Nữ	Kinh		t	10A4				2026-04-25 00:40:00.836+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
c0011a25-8d65-4fcd-8a40-ab05437d8cbd	Trần Văn Trọng	08/09/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:26.159+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
bc56e160-4833-426f-a473-8d6eb2a531d6	Trần Đỗ Uy Vũ	23/03/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:26.426+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
c1bbd11a-8ec6-4c27-9e85-b3410306e99e	Mã Quỳnh Anh	29/05/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:26.555+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
7af30e53-b4e2-4078-b78e-a96c991800ed	Nguyễn Thị Mai Anh	24/05/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:26.673+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
034f3566-f2c2-48a2-ab7a-b3f62cc48ec0	Nguyễn Ngọc Bảo Châu	03/10/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:26.814+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
2dfa3208-1704-4826-b43d-0c8db1de46cf	Rơ Lan Chun	31/10/2010	Nam	Gia-rai		f	10A5				2026-03-23 13:55:26.941+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung le Kắt, xã Ia Dơk, tỉnh Gia La	65560ab5-035b-496a-9133-a50d9bf0a0d0
7af1fbde-8e57-4fa2-bbdf-0bcbe99a3c94	Kpuih H' Han	11/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:27.066+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
8e122d44-9380-4d31-a84e-9b7c903137ac	Võ Xuân Hiền	12/09/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:27.499+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
fe271c35-24f8-4766-8c07-46d49790226b	Hoàng Thị Thu Hoài	02/02/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:27.642+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
517da195-7676-4682-8d99-58045e893918	Lê Đình Huy	24/10/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:27.774+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
93e5d59a-78e0-47e1-8e86-d259c45c4109	Lưu Thị Phương Khanh	22/02/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.029+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
c5eea9f0-a1cc-42c4-a0c6-241f42f0fe9e	Phạm Ngọc Cao Kiệt	20/07/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:28.154+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lâm Tôk, xã IaDơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
ce963ebe-989f-4412-b4cb-05e3d4eefb19	Kpuih H' Lăk	01/10/2009	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:28.303+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, xã IaDơk, tỉnh GIa Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
8ff162e9-e162-43dd-87d7-17e5b691d173	Rơ Mah H' Liên	05/07/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:28.426+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pong, xã IaDơk, tỉnh GIa Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
df00e483-5d57-4ef6-98de-9b73e2c2d9ed	Nguyễn Tấn Lợi	08/10/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:12.115+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
1d3a2ecc-1252-4061-a547-3c70a1e3152c	Hồ Ngọc Trâm Anh	22/09/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:20.64+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
95826f84-a0e6-40ac-85b4-170cad68fdfa	Nguyễn Thị Mai Ly	25/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:29.025+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Tang, Xã Ia Dơk, Tỉnh gia lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
b580585d-7a6e-4fd9-9778-60431fda6f4f	Võ Trần Bảo Ngọc	2010-10-03	Nữ	Kinh		t	10A4	2025-09-07			2026-03-27 14:12:35.995+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
1465c63c-1e0a-4e99-9ffb-a85bceb97b9e	Hồ Ngọc Hải	29/09/2010	Nam	Kinh		t	10A4				2026-04-25 00:40:04.176+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
73d5fb36-6389-4f4e-a6ce-fa44d7acfbf8	Bùi Thị Khánh Linh	05/09/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.545+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
ba9bbf15-6cb1-4feb-bbb5-a6546135e489	Đào Thị Thùy Linh	20/06/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.698+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
aeacc36d-49d3-49c4-b2ea-fd0dbf8751a3	Nguyễn Thị Tố Nga	04/01/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.347+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Grôn,  xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
587c35c2-af99-4659-a932-3afaf148e79d	Phan Văn Trọng	2010-04-28	Nam	Kinh		t	10A4	2025-04-25			2026-03-27 14:11:13.423+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
ef37eda6-8f8d-471b-9f0e-0b5eca5abc04	Nguyễn Thị Minh Hằng	01/01/2010	Nữ	Kinh		t	10A5				2026-03-31 16:12:51.803+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
8e4174b8-5675-4363-9157-65b538490ca1	Phạm Công Hậu	01/02/2010	Nam	Kinh		t	10A5				2026-03-31 16:15:56.447+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo. xã Ia Krêl, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
dd59b2e4-fbfb-43ba-ac01-5782da31b7a4	Lê Hoàng Kiều My	02/07/2010	Nữ	Kinh		t	10A5				2026-03-31 16:16:32.586+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
520b03c9-3846-4a10-be0c-405f6ce627c8	Hồ Thị Mỹ Linh	03/07/2010	Nữ	Kinh		t	10A5				2026-03-31 16:17:36.26+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
79861eb9-1241-4584-a656-13de4216083b	Trần Thị Khánh Huyền	12/07/2010	Nữ	Kinh		t	10A5				2026-03-31 16:17:49.749+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
533a3d0d-8928-4e5f-bc47-2ac613cf80c9	Dương Thị Hồng Quyên	29/09/2010	Nữ	Kinh		t	10A4				2026-04-25 00:40:44.973+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
6dfbbb0d-3ccf-454a-9143-ea8168bffc0f	Hồ Văn Tài	22/02/2010	Nam	Kinh		t	10A4				2026-04-25 00:40:49.281+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
3db167b5-b445-4b1c-bc6f-d822b469efa9	Võ Huỳnh Thiên Thư	02/04/2010	Nữ	Kinh		t	10A4				2026-04-25 00:41:16.254+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
ccc4ec59-ccdd-490e-9f6a-2d34cd9ebf2e	Nguyễn Đăng Hoàng	12/10/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.088+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
ea7fe20f-f7aa-4509-a14f-49e1d2e551a4	Nguyễn Thị Quỳnh Nhi	10/04/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:49.665+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Hrang- Xã Đức Cơ - Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
9eef5557-b6b6-41b4-8677-0a2839dfed77	Phạm Hà Anh	2010-01-23	Nữ	Kinh		t	10A4	2025-04-25	0901910680		2026-03-27 14:11:36.496+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
0de094dd-08c5-41ca-a4e8-397792be2146	Trần Đức Nguyên	2010-02-25	Nam	Kinh		t	10A4	2025-09-07			2026-03-27 14:15:24.839+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
d0a4a7c3-fd26-4238-b682-8250b456ec44	Võ Văn Tiến	01/01/2010	Nam	Kinh		t	10A4				2026-04-25 00:41:22.02+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
35221125-27d2-4995-9505-f106f0796480	Nguyễn Thị Thùy Trang	17/01/2010	Nữ	Kinh		t	10A4				2026-04-25 00:41:27.773+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
1cb8daea-2018-42a2-b902-a10df5c5fdd3	Nguyễn Huỳnh Như Trúc	27/02/2010	Nữ	Kinh		t	10A4				2026-04-25 00:41:33.309+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
fca46968-183d-4bd3-901d-f6808854d653	Trần Đăng Khoa	28/12/2010	Nam	Kinh		t	10A4				2026-04-27 14:34:30.205+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
78e8b072-41a3-42a5-bc32-e16b9249d0c3	Rơ Mah H' Hạ	18/10/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:46.773+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
fa5b96f6-1ba3-4529-9e39-d7ed1ace3fb9	Trần Doãn Kiên	20/06/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:48.256+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
20cf3766-167c-44af-ac0d-1f6e6d15bbc7	Đỗ Bảo Nhi	13/10/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:49.765+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
5b7de434-c274-4b3b-a93b-d2a584da8fc2	Phan Thị Phương Thảo	21/09/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:51.247+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
f94b2d91-a32f-4111-8bdb-58acf4b46ee7	Dương Bình An	08/02/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:52.722+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TỔ dân phố 7, xã Đức Cơ, Tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
11e416e8-414f-47b0-bf87-b56a91e0c952	Võ Hữu Hoàng	28/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.247+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
acfddfbd-1b1b-4993-9abe-7eac7c4bebba	Trần Văn Mạnh	06/10/2009	Nam	Kinh		f	10A9				2026-03-23 13:55:55.829+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
1616271d-9962-4feb-b356-91b7e879855e	Kpuih Khuyên	10/07/2009	Nam	Gia-rai		f	11C6				2026-03-23 13:58:24.836+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
4df0a3a6-0766-4078-8b43-9ddc6b2c17c5	Vũ Thị Hà Anh	17/10/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:20.924+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
06f90b36-5d96-4bda-b6f1-f1af4165b58c	Nguyễn Tuấn Anh	2008-08-13	Nam	Kinh		t	12B1	2024-01-14	0984802579		2026-03-26 02:25:42.195+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Đoàn Kết - Xã Ia Dơk- Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
98e8b3ec-e44c-41c5-95d2-7ff55b733aab	Nguyễn Đăng Huy	2010-10-12	Nam	Kinh		t	10A4	2025-09-07			2026-03-27 14:14:19.953+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
aa2880ce-9399-44f8-baec-4f268d9b5f8e	Hoàng Mai Nhi	2010-09-19	Nữ	Kinh		t	10A4	2025-09-07			2026-03-27 14:16:11.858+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
47754fdb-ced0-4541-aa77-4795419a9e61	Rơ Mah H' Sarina	25/05/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:57.308+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung le -Iakla- Đức cơ - Tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
97b33d21-a1d4-408d-903e-7ccd9355240c	Nguyễn Thị Cẩm Tú	10/03/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:58.848+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
e21bf7b6-2fb6-4af6-bcc7-eaacf5877502	Cầm Trung Hiệp	14/11/2010	Nam	Thái		f	10A10				2026-03-23 13:56:00.358+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
3b816258-ea65-42e9-a577-a3a9b89005f8	Vi Thị Phương Linh	17/11/2010	Nữ	Thái		f	10A10				2026-03-23 13:56:01.983+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaTang - IaKla - Đức Cơ - Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
225ff706-1178-49eb-b8f8-b3e2f537066e	Nguyễn Thị Diễm Phương	07/09/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:03.496+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 5,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
8b29ea93-06af-4f1f-b80b-7e9b6013aa96	Lương Quốc Trọng	16/11/2010	Nam	Tày		f	10A10				2026-03-23 13:56:05.068+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, IaKriêng, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
2a4eaedb-db81-4e0f-8647-bca8afd73444	Cao Trần Gia Bảo	21/09/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:06.476+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
281424bc-c299-4c4e-8179-6e190ef1712a	Hồ Huy Hoàng	30/09/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:08.03+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
a80f88a9-a190-4ab9-aa62-24ebb9a38e52	Siu Phương Linh	31/12/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:09.542+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
5599cb8d-fb94-4661-b1df-586ac2a16e5b	Hồ Viết Sỹ	02/01/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.059+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
49f081a1-ab76-4e7a-81ae-b231b07258ab	Nguyễn Đình Gia Bảo	10/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.534+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ialâm - Iakrêl - Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
2d173741-0f7e-45d5-9b45-a5cffe149bf4	Nguyễn Văn Huy	29/06/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.38+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
1e83d23f-392d-4fd7-8e82-a78e68e5a837	Bùi Thùy Dương	2023-01-04	Nữ	Kinh		t	12B1	2023-03-26	 0346923157		2026-03-26 04:58:25.875+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 1 - xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
722083d2-e4c8-4b94-8f2d-ffd599eda079	Lê Thị Khánh Băng	16/01/2010	Nữ	Kinh		t	10A4				2026-04-25 00:39:33.909+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
380cc84a-98c3-4e1c-a6c3-a23bc527ffc3	Hồ Thị Yến Nhi	20/02/2010	Nữ	Kinh		t	10A4				2026-04-25 00:40:27.582+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng ấp, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
496c7624-b8b2-4b61-a09c-2f8073354ca9	Lê Khánh Hằng	03/09/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.106+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
2837e1b3-0b3d-4fec-95ab-f2b4c51e3da2	Hàn Quốc Hải	13/02/2010	Nam	Kinh		t	10A7				2026-03-26 02:29:48.349+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
ac731f7e-fcc0-4dc2-bf6c-55250be6e668	Lê Thị Thùy Linh	03/04/2010	Nữ	Kinh		t	10A7				2026-03-26 02:30:34.609+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
00b874e6-94b9-46d9-a3e0-6c37acba92f1	Trần Thị Tuệ Tâm	2010-05-03	Nữ	Kinh		t	10A4	2024-03-26			2026-03-27 14:07:20.702+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai.	09d8ade5-bb92-46ab-98e7-3ab869d59f75
3725c6a7-045e-448b-aa38-3e662a06c170	Trần Văn Thái	25/08/2010	Nam	Kinh		t	10A5				2026-03-31 16:16:12.727+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
3dc0af5f-c895-4875-a0a7-832f607356c8	Lê Thị Hạ Vy	04/11/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:39.446+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Hợp Nhất - Ia Hrung - Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
330637d3-a201-4e5d-aaa2-18103c027e09	Rơ Mah H' Jin	26/02/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:48.416+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
bc500fd0-3b26-4ed5-87e8-8e2f75bf92f7	Ksor Hà Nhi	01/01/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:49.923+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
806645fe-43a6-4b84-8444-811c5a441f97	Hồ Hữu Thắng	16/01/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:51.394+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
e9b4b1a7-3183-414b-8ed7-8136589b472a	Lê Hoàng Anh	21/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:52.873+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
8e925e67-2d7d-4f06-a279-021264e559d6	Phan Lê Quốc Huy	06/03/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.398+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
38713c13-ce9a-4839-ae44-a86d7c5f58dc	PHẠM TRỌNG BẢO NAM	06/11/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.999+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Đội 15, Xã IA Púch, huyện Chư Prông	5d2969a5-0d68-4845-bcab-407f002e89b1
04e8f5ec-60dc-4a3e-bf56-fff17a704d14	Hà Ngọc Thành	13/08/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:57.454+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
9a559309-ee32-4ce3-a520-37eae6cf4ffb	Nguyễn Quang Thành Công	2008-09-04	Nam	Kinh		t	12B1	2025-11-30	0349995067		2026-03-26 13:09:12.324+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Tân- Xã Ia Krêl- Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
1c024700-02ac-4848-9dc6-4f4f6a9619ea	Hồ Anh Dũng	17/07/2010	Nam	Kinh		t	10A4				2026-04-25 00:39:46.352+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
3f286083-cab9-437d-bf2e-a03f8037a771	Võ Đình Huy	17/05/2010	Nam	Kinh		t	10A4				2026-04-25 00:40:10.024+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	tổ dân phố 7, xác Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
6591fe0f-abf3-45c5-a517-67d4ce0e8ca9	Hoàng Lâm Phú	05/10/2010	Nam	Kinh		f	10A4	\N			2026-04-25 00:40:38.44+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Bi, xã Ia Dom, huyện Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
ce7b2908-1bb8-47d1-84ae-8d094b7f950c	Phan Đình Tùng	21/10/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:58.994+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, Chư Ty, Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
bb25bc9d-8436-454d-8258-c55afeb98b01	Phạm Sỹ Hoàng Long	12/08/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:02.148+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
702a03a5-1641-41ba-821f-7c0c4eb6e46b	Ngô Trí Quân	13/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:03.644+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Kom Ngó, Ia Chía, Ia Grai, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
c714c574-cb27-4cc8-ac81-f2da791c3816	Kpuih Trực	15/11/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:05.203+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung Tung - Ia kla - Đức Cơ -Gia La	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
eabf8f7d-1ae6-4fb1-b265-4388962e6855	Hà Phạm Gia Bảo	28/10/2010	Nam	Thái		f	10A11				2026-03-23 13:56:06.641+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
484c4026-0ae9-4cd1-a431-3e2bd3b52574	Lương Hoàng Huy	18/11/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:08.171+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
3c1120e0-4081-4a2f-a9ed-ce296b052ad4	Nguyễn Hoàng Minh	10/11/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:09.687+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
6ad01ada-5069-49d6-a871-bcb3dad3bb23	Phạm Ngọc Chính	14/01/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.708+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung kép - Ia Dơk- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
3a05ebde-5b29-430d-b6f9-d3445b9418d9	Diêu Gia Hân	05/01/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.272+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP9-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
5e0bb03a-1728-4bcd-b72f-4cca3ebf71be	Dương Bảo Hân	09/12/2010	Nữ	Kinh		t	10A7				2026-03-26 02:29:13.341+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
620bbc2a-94c9-419d-a8d7-2382be78ee42	Hoàng Bá Thiên	21/06/2010	Nam	Kinh		t	10A7				2026-03-26 02:29:54.565+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krêl- xã Krêl, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
a6b6c24c-77c9-438a-8d7e-04db8ef9129e	Lê Thị Phương Uyên	05/04/2010	Nữ	Kinh		t	10A7				2026-03-26 02:30:12.741+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
8e9998ba-172e-4fa4-b27c-34997c86eabc	Nguyễn Ngọc Quỳnh Trân	2010-08-25	Nữ	Kinh		t	10A4	2025-09-07			2026-03-27 14:04:18.173+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
bbb65f3f-7e4c-46b8-9689-ae63b0c642d2	Lê Quang Dũng	24/08/2010	Nam	Kinh		t	10A4				2026-04-25 00:39:51.225+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
c34e4f5c-bd0d-45e0-b593-8a8ccb24fd70	Nguyễn Phùng Tuấn Hưng	08/09/2010	Nam	Kinh		t	10A4				2026-04-25 00:40:13.255+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Đội 12, xã Ia Chía, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
a266e837-1b3a-459c-aea5-579a1bca14d0	Lại Minh Quang	12/12/2010	Nam	Kinh		t	10A4				2026-04-25 00:40:41.887+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	09d8ade5-bb92-46ab-98e7-3ab869d59f75
751f1c0c-404e-4f68-a602-416a9eb9332d	Nguyễn Thị Thùy Linh	28/11/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:38.675+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
63aa427d-0d01-4be0-b195-6df7993dfc5d	Nguyễn Dương Thanh Hằng	24/08/2010	Nữ	Kinh		t	10A8				2026-04-01 02:25:24.072+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
340c7f3c-b4ab-4a86-abc6-6de0aa99025f	Nguyễn Khánh Hoà	10/08/2010	Nữ	Kinh		t	10A10				2026-04-27 07:42:56.195+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm Tốk, xã Ia Krêl, huyện Đức cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
0e2c7021-8766-4858-a3fa-09eb82929180	Rơ Lan H' Khuyên	30/09/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:48.722+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
e82bd0e6-4828-441c-9285-150405ae12e0	Lường Thị Kiều Oanh	03/03/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:50.204+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
7d0f9a2f-a165-40d4-97ea-c49abf025882	Rơ Mah Phạm Thị Thương	21/05/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:51.691+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
7d1efe29-8015-410a-adae-dd9745b4a204	Nguyễn Xuân Anh	21/01/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:53.143+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
7b879a48-c03d-4b4d-b1ca-9bc25488a544	Khuất Anh Khoa	07/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.701+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
22eb3de1-f12b-4cc2-b037-cdf54f66da58	Rơ Mah H' Ngiêt	17/03/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:56.281+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp, xã Ia krêl, Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
e48eacfc-c1dd-46a9-8ff7-968d8b061b69	Vũ Thu Thảo	28/10/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:57.747+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
c0071337-e27c-405a-a40d-7c8a2ede3f52	Nguyễn Hồng An	20/02/2010	Nam	Kinh		f	10A10				2026-03-23 13:55:59.32+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ I, IaKLa, Đức Cơ, Gia lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
01f805eb-3449-4126-bcae-bfdf9f47e615	Nguyễn Hà Thảo My	03/02/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.083+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
0135e0b3-c41c-4c70-b644-6ba204fcd6c0	Rơ Mah H' Trinh	19/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:31.871+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
0a5bb4bd-c7f5-466e-a6dd-1514c591ab6e	Lương Thị Hà Anh	25/12/2010	Nữ	Thái		f	10A6				2026-03-23 13:55:33.437+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
05c832b5-d3af-4f7f-9ec9-7c5f9c5bbc06	Lê Đình Khánh	30/07/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:34.893+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
fa45f554-b9fe-4224-b289-8c6e847ab4a0	Hà Như Ngọc	01/12/2010	Nữ	Mường		f	10A6				2026-03-23 13:55:36.35+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Đội 8, xã Ia Púch,tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
652cccb3-c7fa-4fd8-8291-6fff01d86fb0	Lục Phương Thảo	18/01/2010	Nữ	Sán Dìu		f	10A6				2026-03-23 13:55:37.821+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, Iadơk, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
6c786001-0a08-482b-8edb-2620f7fc358e	Vũ Hoàng Minh Tuấn	16/12/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:39.264+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim, Ia Dơk, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
24ce332c-5cfe-4fe1-ae54-8b44bbfea345	Bùi Thị Thảo	05/12/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:43.821+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 , Đức Cơ, Gia lai	141be337-7bb7-4d92-bd8e-21330ef7702f
5ae36145-cbaf-410d-a420-e8374322777f	Rơ Mah H' Ury	10/01/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:45.279+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung Kắt - Ia Dơk -Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
2b7cb785-206f-4139-837b-b85e48d5c05e	Rơ Mah H’ An ne	09/12/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:29.221+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung le Tung, Xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
607c43b9-b919-4745-b012-34d35f90a31d	Hồ Thu Thảo	04/12/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:30.591+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
9fdcdc43-e228-4cf5-9f5b-fd0feab06445	Nguyễn Ngọc Trung	21/10/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:32.01+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
f7ec447c-444b-4d34-a18f-45ccda9dbab5	Nguyễn Hoàng Hân Di	22/12/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:33.574+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7,Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
f1e5773a-d263-4bea-a200-c5066720380c	Nguyễn Duy Khánh	09/06/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:35.03+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl, IaKrêl, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
2b9cbf01-35f2-48a4-b7a2-06afed784206	Nguyễn Thị Thanh Ngọc	28/04/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.494+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân, IaKrêl, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
89f2e86a-684f-4a9c-80d7-0a4b85dc5655	Đậu Thị Anh Thư	01/02/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:37.971+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm, Ia Krêl, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
53d800b8-60af-4182-803f-7c1df4727525	Bùi Sinh Thái	08/01/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.205+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn 9, Xã Chư Prông, Tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
5460c122-86f9-4911-bf06-7a6d115f3ada	Rơ Mah H' Thủy	26/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:30.871+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kắt, Xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
42209264-0932-4c06-b343-465180e61494	Kpuih H' Yên	08/06/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:32.316+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
d5b7810b-6a0e-44ef-96d3-db6d170ae520	Lê Minh Hoàng	18/08/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:33.883+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
ad304002-5d95-44c0-97ca-b6cc43b04c11	Nguyễn Văn Quốc Kiệt	10/10/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:35.325+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
7eeec437-5229-4e15-b124-1039f3bc28c8	Kpuih H' Nhanh	24/07/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:36.785+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk - Đức Cơ - Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
3786ad9f-9d14-4599-ab64-3d74e0b26799	Rơ Lan H' Thư	17/05/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.248+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
a7d48afa-ce1e-477b-af29-483b78df746c	Trần Thị Ngọc Huyền	11/04/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:41.263+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
0bb83554-85ff-49cc-a4af-ba7018051b5b	Rơ Châm Zaka	11/04/2009	Nam	Gia-rai		f	10A7				2026-03-23 13:55:45.722+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
25e5014b-fbcd-4048-a014-dca960c95cda	Dương Thị Như Nguyệt	14/11/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.601+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
3a2e075b-3a93-42ca-a0ea-261f0abac7dd	Lê Bảo Nam	01/10/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:02.458+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, Iadơk, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
5988f370-49b7-4e81-877a-da653534429e	Trần Đức Quân	19/04/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:03.973+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N		b43602fc-3d2e-48a1-b281-4fa1b7aabef9
cdaf652c-09f1-4085-8a32-c336b3c357c1	Lê Văn Tuấn Tú	19/03/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:05.471+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iakăm, xã Ia Krêl, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
0a09fa25-7832-4a1d-840a-c72e33c006d9	Nhữ Thị Kim Dung	27/03/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:06.982+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
ce6b3764-acc6-4ce5-be3c-0d07348043d3	Lê Thị Lưu Huyền	28/06/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:08.49+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
d19db5f1-d49c-4dfb-bc37-0204f352cf69	Nguyễn Văn Bảo Nam	24/11/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:10.005+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
6de24c68-5bfc-4de1-a3c6-faacb7d8b734	Kpă Tiếu	05/08/2009	Nam	Gia-rai		f	10A11				2026-03-23 13:56:11.493+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
d5796adb-c619-45a5-a17b-2421cec8f5b2	Đào Tuấn Duy	29/06/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
325281bf-30ea-42c9-a403-10b78c097fd3	Lê Phạm Công Hiếu	10/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:14.612+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
c1425aff-8437-42a1-8e40-96f4e974ed3e	Trần Thị Bảo Yến	27/12/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:32.541+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
6d58bd2e-43b3-405c-b79d-78c548e24243	Nguyễn Việt Hoàng	18/08/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:34.05+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
eaf87147-67a0-479e-94fe-6303294ea8fe	Bùi Thị Mỹ Linh	11/05/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:35.459+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
4d471811-0f1b-48d6-85ba-5f1661e1a20d	Rơ Măh Thương	02/11/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:31.186+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
09715ed6-1cc0-4b81-acbb-2a662311e84a	Đoàn Thị Ngọc An	02/05/2010	Nữ	Kinh		t	10A7				2026-03-26 02:29:40.036+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Ia Tang, Ia Kla, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
a34d6ef6-c720-46c2-8fe1-55b71db8eb5a	Lê Thị Trà My	21/09/2010	Nữ	Kinh		t	10A7				2026-03-26 02:30:42.286+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
6297eb0b-b110-4015-a2dc-504b9469fa58	Nguyễn Lê Bảo Thư	26/10/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:09.199+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Kép, xã Ia Dơk, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
f6ece7c2-5d91-4617-b820-a31ad8f60fb8	Hàn Thị Hồng Nguyên	15/10/2010	Nữ	Kinh		t	10A5				2026-03-31 16:17:13.222+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
a07d5e49-9d17-4b87-9873-e38e601f7184	Nguyễn Nữ Bảo Hân	15/06/2010	Nữ	Kinh		t	10A8				2026-04-01 02:25:39.996+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
a5cb860e-7aa8-4aac-bbd6-64f63e2407ef	Nguyễn Ngọc Bảo Như	04/11/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.93+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
21ffd761-624b-42d8-bacb-af6c8d43495d	Trần Anh Thư	24/10/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:38.391+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, Đức Cơ, tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
88504133-610c-4051-8b97-1d0cf3b3ab59	Lê Thị Thu Hương	24/01/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:41.408+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl - xã Iakrêl - Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
facf8dd1-963a-417b-b0de-e5b54f3c3798	Nguyễn Ngọc Anh Thư	29/01/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:44.406+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
03af4e5f-43fe-4ef4-a4cf-0e4fcf1b7209	Nguyễn Thị Hồng	21/09/2009	Nữ	Kinh		f	10A6				2026-03-23 13:55:34.197+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
ceeb18db-609b-417b-befc-135d9c318197	Rơ Mah Thị Thanh Mai	14/08/2009	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:35.599+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, Xã Ia Dơk , Tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
2410031d-4e67-4e33-9616-e0b05711c51a	Ksor H' Za Ni	21/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:29.9+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, xã Ia Dơk tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
ca10d869-943a-4d54-a0a4-3df254ea6db6	Đinh Thị Thùy Trang	24/10/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:31.335+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
70a98b39-a6bd-435e-ab45-c866831726ac	Lê Hồ Lan Anh	22/02/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:32.846+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - xã Iakrêl - Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
bc027983-4c3d-4fae-99aa-4a47e44d4f53	Vũ Ngọc Bảo Anh	11/09/2009	Nữ	Kinh		f	10A8				2026-03-23 13:55:45.869+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
a7477a2a-d6b0-48e9-b823-19debca63f3d	Nguyễn Đình Hiếu	08/09/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:47.358+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
981e130a-3ab5-4493-a4ec-ef9d54a0b0ad	Ngô Thị Kim Luân	10/08/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:48.881+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
e63bd1f8-fdbc-4e22-a40f-2ecd024d37f9	Rơ Lan H’ Rubin	07/08/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.365+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
0271c9a4-ab62-4151-8b75-2ed7e6e7a7d6	Nguyễn Duy Tiến	25/07/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:51.831+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
e497a6c5-6938-4807-9d2e-d9dc0690da97	Hồ Viết Tường Huy	18/10/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:34.334+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaMang, xã IaDơk, tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
363aa6a3-5fc3-4342-af41-46bdf215e459	Rơ Châm H' Mẫn	20/09/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:35.744+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pong, IaDơk, GIa Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
e84e5bf8-1c66-48b5-9965-42f5062c9a13	Nguyễn Thị Như Quỳnh	22/05/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:37.22+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iamang, IaDơk, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
600a84d8-4f96-44e1-80a5-29f9d808ba03	Rơ Châm Vũ Bảo Trang	17/11/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.675+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ngo Le 1 - Ia Krêl - Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
c5300675-c6cc-473a-b29d-444bb840c78b	Trần Văn Khánh	29/06/2010	Nam	Kinh		f	10A7				2026-03-23 13:55:41.704+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
88172d2b-aad4-4851-8143-7e5292096469	Rơ Lan Anh	04/04/2009	Nam	Gia-rai		f	10A9				2026-03-23 13:55:53.306+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, Ia Kiêng, Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
393b79bc-53a7-47bd-b9c4-849109a54fc1	Nguyễn Trọng Khoa	01/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.926+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
35e49996-cbdf-48eb-bec7-2c198cc3e92f	Kpuih Nguyên	19/01/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:56.421+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Trolđeng, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
963dddec-f485-4c50-9bd5-5727ef315649	Bùi Sỹ Thắng	04/05/2008	Nam	Kinh		f	10A9				2026-03-23 13:55:57.924+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
00134d7c-aabf-44c6-bc27-353ce5bcc464	Rơ Lan H' Hường	27/04/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:00.974+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Tung, xã IaKla, huyện Đức Cơ, Tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
b945aae9-3222-4b9e-9263-8ff0e0d07eae	Phạm Quang Nam	02/01/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:02.6+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
b4d26962-fb8a-4d54-b718-f51b6909c227	Kpuih H' Quế	28/11/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:04.106+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Trol Đeng, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
6d8b28de-318f-4c20-b323-1bb23a261524	Rơ Mah H' Viên	06/02/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:05.603+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pong, Ia Dơk, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
2167f676-0c33-487c-bfa2-5b83891393b4	Phạm Thị Oanh	18/10/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:30.044+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
c644dc1a-321f-4b1e-be34-06b59e3e41eb	Hồ Thị Huyền Trang	26/03/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:31.472+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
2eb12ec5-33c1-46f5-91a0-d27f32f3c5dd	Lê Thị Mai Anh	03/08/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:33.022+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl,tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
b2d8bc5d-1bd5-4ffa-8461-dad6b9397750	Nguyễn Hoài Diễm My	24/09/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:35.895+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, Đức Cơ , Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
8d8f6a71-1666-4a3d-befa-af9af1d1912d	Kpuih H' Dương	18/08/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:07.138+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
d7c94e81-ebeb-478a-b7a6-9707e4468be5	Rơ Lan Khàng	11/02/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:08.646+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
d52fbbbe-e6c4-449e-97e2-7f30a28bc43a	Rơ Mah Nguyên	17/12/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:10.154+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia lai	87881984-264c-4c97-b336-69ef0999dd67
eb5a9e9c-8963-43cb-84c7-2320b5d5d2e1	Nguyễn Vĩnh Triều	04/12/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.654+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
fc500ba6-ee21-4836-8b5c-4bef5884d606	Nguyễn Nhật Duy	02/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.169+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
e11a1aa2-b221-4dcc-bb4e-baa788094843	Lê Thị Ánh Hồng	03/08/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.758+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
0ecb07cf-4366-4c57-a15d-de80da19eb1c	Bùi Gia Bảo	17/09/2010	Nam	Kinh		t	10A7				2026-03-26 02:29:01.263+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
aee77de4-b1e8-48dd-98d2-93d72ebb17ff	Rơ Lan Anh	02/12/2009	Nam	Gia-rai		f	10A6				2026-03-23 13:55:33.17+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè- IaDơk,Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
d9b6734e-e516-4789-a818-a45b9d0d15ca	Rơ Châm H' Huyền	19/03/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:34.613+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang, Ia Dơk, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
988fa30a-9865-479a-a7a7-322cebf490f1	Nguyễn Phan Trà My	11/06/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.028+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố , Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
2844d861-9243-4feb-abf9-868cfbc33237	Rơ Lan H’ Sương	20/12/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:37.508+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Le 2, Ia Dơk, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
3456e14e-cc90-418b-b3cc-71a302e09af0	Kpuih H' Trâm	22/06/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.968+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
af86bd09-34ed-414a-b3e8-c4ed1f8ea066	Kpuih H' Lin	01/02/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:42.007+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, Ia Dơk, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
38bfddd0-f935-46f8-af19-1d4516871268	Nguyễn Minh Nguyệt	14/11/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:18.598+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
75ee1dc8-6fe0-4a85-bac5-94e61d7523ad	Trần Vũ Anh Thư	16/06/2010	Nữ	Kinh		t	10A5				2026-03-31 16:17:28.244+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
2577d390-a4d5-4cb0-8b24-dbad6f96f707	Đinh Nhương	26/11/2010	Nữ	Ba na		f	10A6				2026-03-23 13:55:37.079+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, xã Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
482853b8-16e1-4058-85ad-0fa6c01c634d	Rơ Lan H' Thương	27/10/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.539+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung Le - Ia Dơk, GIa Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
611ecdac-8c20-446a-bd82-709803d23ce7	Siu H' Xim Bi	13/03/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:40.037+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung kép , Xã Ia Dơk, Gia lai	141be337-7bb7-4d92-bd8e-21330ef7702f
b08c1dba-7943-4041-a3de-dee86a86687d	Lê Hữu Khang	13/07/2010	Nam	Kinh		f	10A7				2026-03-23 13:55:41.554+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
c00eacf3-4684-457c-82ac-50555ebcb978	Kpuih H' Nhuy	04/11/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:43.07+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
bf0acbcb-0831-4ded-b1ad-9a2f34b60a6f	Trần Thị Thu Thủy	27/10/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:44.554+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim , xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
609124df-b7e1-4c07-a60a-94b814993c40	Nguyễn Sỹ Thế Bảo	17/10/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:46.03+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
61561ed7-3041-4a72-ab63-691bb6bdc351	Trương Văn Hiếu	06/05/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:47.512+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
3a068f6d-f9a7-49ce-8568-53e195e91f16	Nguyễn Hiền Thu	05/10/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:22.301+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Xã Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
71090bf5-4da7-40e3-9615-2903bce8496f	Nguyễn Thị Ly Ly	02/12/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:49.019+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
93fed5e4-85fd-4fb1-a163-b266c79d38ed	Rơ Lan A Sở	02/05/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:30.328+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
4f9f4998-4db6-4f5d-8167-15dced091674	Kpuih H' Trinh	26/08/2009	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:31.745+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Đo, xã Ia Dơk, tỉnh Gia Laỉ	65560ab5-035b-496a-9133-a50d9bf0a0d0
d4c38d8b-8c8c-41e5-9511-549fafe44210	Rơ Lan H' Bích	20/07/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:33.31+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le, Xã Ia Dơk, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
93140630-880e-4c64-8577-437319c7a2c1	Rơ Lan H' Thiết	27/01/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:30.743+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Đo, xã Ia Dơk , tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
ee8dec8c-1e45-446e-88a6-4c53feff60ae	Hàn Quốc Tuấn	09/11/2009	Nam	Kinh		f	10A5				2026-03-23 13:55:32.16+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ , xã Ia Dơk, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
ce6e5faf-0dd4-4212-b4a8-de0d4e7038d1	Kpuih Sái	09/11/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.505+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
1c25e82c-dbb5-45a7-b735-64effe1346fc	Đặng Thị Huyền Trang	17/04/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:51.985+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
272370da-8369-404a-b8d8-c60da9269abc	Lương Thị Ngọc Ánh	07/09/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:53.458+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
502a342f-9384-4302-9978-f230df716068	Bùi Hữu Kiên	19/01/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.07+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
9c2040f6-0dd0-4d32-b694-fba05587f50f	Hồ Trọng Nhật	18/05/2009	Nam	Kinh		f	10A9				2026-03-23 13:55:56.564+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
d48bcd7f-4adc-409c-a0d4-054cdf29788f	Rơ Lan H' Thư	12/10/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:58.073+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
b3e79ebf-d3d9-42f9-a0d4-ae6e3ba1eddd	Siu H' Beo	19/02/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:55:59.618+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, Iakriêng, Đức Cơ	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
6231ecca-15a1-440b-bf1e-43763213fde8	Võ Trần Gia Khánh	31/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:01.127+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
d0364fbd-f5f0-4ee1-b259-db4b795707ad	Nguyễn Hoàng Bảo Ngọc	17/07/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:02.761+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
53b06f76-6f6d-4bcf-b19f-3ff7bd8890dc	Lê Đình Tài	23/11/2009	Nam	Kinh		f	10A10				2026-03-23 13:56:04.252+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 1 Chư Ty , Đức Cơ , Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
d9ba578d-620d-440e-a811-ae60582078e9	Phan Quốc Vương	08/03/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:05.728+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
ba70cbec-b12f-446e-b874-59f019865db9	Rơ Lan Điệp	14/06/2009	Nam	Gia-rai		f	10A11				2026-03-23 13:56:07.278+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
8b711101-381f-4ab5-82a1-f136830840c4	Rơ Lan A Khiển	11/07/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:08.796+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
42be00ab-855f-486f-9366-672190e46405	Võ Phước Nguyên	20/07/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.293+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
1177883b-bf16-41fc-97f8-3c05a483c3a9	Hồ Sỹ Tuấn	07/06/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.8+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
47e0d6fb-4a01-48e2-99c4-5429de21489b	Bùi Thị Thùy Duyên	01/01/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:13.317+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP6-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
6b4f82da-2380-4c71-bcb8-390bf4ced282	Lê Quang Khải	25/02/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:14.906+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 6, Đức Cơ, Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
9b522a06-2aa3-4f33-b6ca-dfa21cd25c79	Trương Thị Hồng Yến	27/08/2010	Nữ	Kinh		t	10A5				2026-03-31 16:14:57.241+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
07b7aab4-2f5a-498d-9a3c-c1f5e54ca211	Nguyễn Hoàng Bảo Trâm	05/03/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.621+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
80e3b0bf-5a11-4d9f-8fec-35de7afacfef	Hồ Ngọc Diễn	17/11/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.318+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 7 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
29e29e25-4086-4d0f-b33a-6c4b30f21f16	Trần Thiên Khánh	16/12/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.893+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 9 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
169526a1-b152-46c4-9ac1-ed340b7a7ee4	Nguyễn Yến Nhi	06/03/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.523+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
7de07f3b-d7ec-4664-a987-0110f00955a8	Nguyễn Thị Quỳnh Như	2010-06-11	Nữ	Mường		t	10A5				2026-03-31 16:15:27.923+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
b964e3a3-692b-47a9-bc19-80c4ad5f2a34	Nguyễn Thị Diệu	22/02/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:46.177+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
91853786-4884-4a5e-af28-46253012dc9d	Phạm Gia Minh	23/07/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:49.168+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
0e19d0ff-492c-46f5-8431-80583c879093	Kpuih H' Sen	28/04/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.646+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
f9b78ac9-aa13-41ac-b895-39fd64eef05f	Mai Giang Tuyết	02/11/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:52.118+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
2833fa4c-c043-4259-9ff2-ed20f4853874	Mai Thị Anh Đào	14/03/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:53.636+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
87a4a611-8036-416e-82e5-df585f7337a1	Nguyễn Tuấn Kiệt	06/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.21+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
26a78d3d-69d3-47e3-8812-ab57d45cf66e	Mai Võ Yến Nhi	23/08/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:56.695+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
805a2617-0b7d-4756-b5ff-509ba9914bdb	Đào Nguyễn Lâm Tiên	29/12/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:58.223+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
378b06c1-76c4-4249-a2fc-7a7a54dac4e8	Nguyễn Vũ Tuấn Kiểm	06/01/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:01.278+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
e9ec14d0-c297-4bc9-8c0f-cfc7ca120a70	Rơ Mah Xâm	28/09/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:05.871+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung kép 1 - Iakla -Đức cơ -Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
dae1df7d-722f-4ab8-b094-0b166d3e6d01	Ksor Đinh Đức	24/08/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:07.428+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 8, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
1e5628b0-5f33-4f9f-8f39-1267747e100a	Kpuih Khruin	20/11/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:08.945+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
811f25f1-4531-41af-8d56-90e3998e1445	Ngô Quang Nhật	01/09/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:10.444+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
c26e5e5d-18df-4300-8883-40e40a0b0bbf	Tống Minh Tùng	20/05/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.934+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
99ba8b45-b1cb-4254-92a8-319e8bdabe80	Nguyễn Tấn Đạt	26/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.466+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP4-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
9c614028-1d47-43fd-8c4b-6adcc0f9ed84	Nguyễn Đức Nhật Khánh	01/09/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:15.061+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP6- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
bd97ecf7-d4f7-4e32-97df-b360216508ea	Võ Hồ Yến Vi	25/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.812+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
881ede24-9751-444a-aa92-8ad9dde7f409	Hồ Nghĩa Dũng	09/12/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.48+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 9 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
2aaa6039-08b8-46ba-9713-5e06920e3026	Nguyễn Anh Kỳ	28/02/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.046+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - xã Ia Dơk - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
e12104b2-5404-4f27-94af-3e8abbd90696	Ngô Thị Tuyết Nhung	06/06/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.672+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
0192ba81-a254-4fac-85f4-930c6a1bdd1b	Võ Hoài Bảo Trâm	03/01/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:01.1+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 1 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
b313feb5-d496-496f-b6ff-fc319033872d	Hoàng Gia Bình	15/09/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.041+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
c3b4cc69-b422-4f54-99b5-dfc70fa0d875	Châu Ngọc Như Ý	18/06/2008	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.985+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
9208ea3b-7eca-421c-80d3-20a8adf4fbd3	Nguyễn Thị Bích Ngọc	08/09/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:32.856+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Xã Ia Kla, Huyện Đức Cơ, Tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
4f0e3907-85bb-47ef-828e-a64c36d16ac2	Nguyễn Thị Hồng Thắm	07/08/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:41.743+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Xã ia chía, Huyện Ia grai,Tỉnh gia lai.	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
14190fb8-bfa9-4aee-b881-d1e7f8b24017	Kpuih Y Lan Tina	05/02/2010	Nữ	Gia-rai		t	10A7				2026-03-26 02:30:05.379+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ghè, Ia Dơk, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
d684d7d6-a3e5-493d-bc9a-2ff67a1b152f	Phạm Khánh Chi	19/05/2010	Nữ	Kinh		t	10A7				2026-03-26 02:32:25.744+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
3055501c-c63a-44ba-82c7-06a94c85531d	Siu En Ny	28/02/2010	Nam	Gia-rai		t	10A7				2026-03-26 02:32:53.47+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Lung Prông, xã Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
c5208b0f-3302-4323-9f99-e4b566bda949	Trần Đức Hoàng	06/08/2010	Nam	Kinh		t	10A8				2026-04-01 02:25:50.557+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
cc6c26cb-603c-4360-9ff5-9489e8f7e092	Hoàng Thị Thanh Thanh Huyền	24/03/2010	Nữ	Mường		f	10A6				2026-03-23 13:55:34.461+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Đức Cơ, tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
18147bfc-4b50-4603-bd51-82f472b8b89e	Rơ Mah Y H’ RiLa	28/04/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:37.362+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung le - Ia Dơk- Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
edbb473d-8a68-4d71-841a-bed34215f321	Ksor Nguyễn Tráng	29/04/2010	Nam	Gia-rai		f	10A6				2026-03-23 13:55:38.828+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Mới, Xã Ia Dơk , Tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
65f8c316-e7d9-40b3-a21d-ae7f9e984cae	Ksor H' Giang	23/11/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:40.315+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, Xã Đức Cơ, GIa lai	141be337-7bb7-4d92-bd8e-21330ef7702f
606bf350-60cb-4191-a732-3d01732c4b79	Mã Văn Kiệt	11/12/2010	Nam	Tày		f	10A7				2026-03-23 13:55:41.859+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Grôn, xã Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
7769404a-0af8-40f3-a5ba-ee9c819e3e3d	Rơ Mah H' Đa	15/09/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:46.323+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
516b8cfa-f3b3-4783-899d-04640f486b9c	Đoàn Văn Nam	22/03/2009	Nam	Kinh		f	10A8				2026-03-23 13:55:49.332+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
a23ccfd6-a018-4fdb-b28e-f22020c8b4d0	Rơ Lan H' Siu	13/09/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.791+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
6889527e-19fa-4bfd-a062-4bf22e4dd559	Kpuih H' Uyên	29/06/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:52.263+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
dbc07e68-5e68-41e9-a16c-eed1bf066a53	Kpuih Hải	02/04/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:53.778+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, Iakriêng, Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
58186ebc-f6db-4a3b-9086-a13e781e8d5a	Đặng Hồ Phương Linh	30/07/2009	Nữ	Kinh		f	10A9				2026-03-23 13:55:55.363+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
825fbf1f-dd8d-4da5-9f00-cccd03693f77	Nguyễn Thị Hồng Duyên	21/06/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:56.627+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
2803dd6b-beae-4f97-85d4-3f70d3fcaf0d	Phan Ngọc Lâm	11/03/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.202+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 1 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
e643ae7e-94fe-4154-80e7-f37a2cc14840	Trần Gia Như	01/03/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.797+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 4 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
25a8b8c0-0949-4533-a342-12feac3c29ca	Nguyễn Phan Bảo Trân	25/10/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:01.243+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân  - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
4e5c248d-3ad9-4562-9af2-fdb65705b2a1	Nguyễn Đình Phong	15/10/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:56.857+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
cec84b70-24ae-43a7-b5de-a091b4f2bd5c	Nguyễn Song Toàn	07/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:58.382+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
84240a86-2f2a-42a9-af81-19b48208a478	Nguyễn Đinh Ngọc Duy	26/10/2010	Nam	Kinh		f	10A10				2026-03-23 13:55:59.905+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Păng tul - Ia Dơk - Đức Cơ Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
6538c9ab-9f9c-42f5-afd3-c52c75ade10f	Kpuih Kiệt	26/02/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:01.438+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Grôn, IaKriêng, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
20003609-c70d-43c3-9ed7-9c61d26c0f75	Nguyễn Xuân Thắng	03/06/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:04.593+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
5f14efd2-4b32-43ed-90a7-edbe2f2a8382	Lê Thị Mai Anh	19/12/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:06.031+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
e7cf006a-25fc-44f5-abcf-3ea659785d13	Nguyễn Thị Khánh Hà	02/09/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:07.58+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
9ed00fda-679e-440e-b5bf-9fc7886528d2	Cao Thục Khuê	14/07/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:09.099+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
47303f97-6e00-41da-bc9f-e31767d56a99	Hồ Hữu Minh Phong	04/05/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.6+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
642ec80c-f1dd-4bc3-bb7d-d5a3c171b6ee	Hồ Thị Lan Anh	29/11/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:12.085+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP6- Đức Cơ- Gia Lai.	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
d16094e7-0513-4943-94c1-46dbdd154297	Nguyễn Hải Đăng	29/07/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.624+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
d0813061-cd90-44a6-8d18-72e1f8cfbbfd	Nguyễn Phạm Phương Linh	06/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:15.21+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
129dcd98-2afa-4224-afc3-153982a9e9a9	Lê Viết Tình	24/01/2010	Nam	Kinh		t	10A7				2026-03-26 02:30:53.953+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krêl, xã Ia Krêl, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
818e187b-dbc1-4a49-b4a2-8057d1677415	Rơ Mah H' Quỳnh	22/04/2010	Nữ	Gia-rai		t	10A7				2026-03-26 02:32:47.175+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Hrang, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
9dfab549-5dab-499a-8f02-eeec88e0dfbc	Nguyễn Lê Thu Huyền	13/11/2010	Nữ	Kinh		t	10A8				2026-04-02 09:51:33.292+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
6f06a0f9-d009-4090-8049-dc32c3f3a07c	Phạm Thị Như Ngọc	07/09/2010	Nữ	Kinh		t	10A10				2026-04-27 07:43:12.558+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
dbf0d81a-6454-44cd-b1ff-6720b90b3ad2	Kpuih Sữa	05/06/2010	Nam	Gia-rai		f	10A7				2026-03-23 13:55:43.514+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, IaKriêng, Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
cfff97af-ca0f-430d-91ae-c2a044f50d6d	Nguyễn Ngọc Như Ý	28/10/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:55.141+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
d112a9b1-b9a9-44d9-962a-4e2725df2fdc	Nguyễn Quang Dương	24/12/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.778+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Ia Dơk- Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
94a1781e-5855-4959-98d0-19f249fd540b	Thủy Ngọc Lĩnh	14/06/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.377+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
5aa3ab25-0f70-4c89-9341-675517f58439	Nguyễn Thị Kim Oanh	15/05/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.945+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - xã Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
c3825d27-cd8a-4248-a9b3-71002f487360	Nguyễn Phạm Đức Trí	01/04/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.392+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Ia Dơk - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
775576e2-b3ae-40cf-b2d1-aa5a4bebeac5	Ksor H' Đuin	23/01/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:46.468+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
658c8665-9a38-409a-a8b7-19946738f131	Trần Văn Bảo Nam	22/02/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:49.471+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
64a057ed-56ce-405f-8d55-2e44b340ae11	Rơ Mah H’ Sôri	06/12/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.96+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
282e7a0e-4921-49c9-b581-97bf653a0697	Nguyễn Thị Hải Yến	24/01/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:52.416+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
48d37194-6cd5-44b6-97da-5cd226260755	Đinh Thị Hằng	26/09/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:53.928+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
20e53e7c-1e8e-4202-9df9-41adbb9e8e10	Nguyễn Thành Long	12/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.515+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
c1cea216-5cbd-435d-9e7a-21ffe1cb040b	Lương Hữu Phương	13/04/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:57.013+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iatang, Ia Dơk tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
d8ff06c9-dc90-4b99-a26b-d101c3cff02d	Võ Thị Kiều Trinh	25/11/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:58.528+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
e5b57e59-0507-465e-84b6-01313157d8eb	Rơ Mah Kiệt	12/09/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:01.645+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
302e5178-058e-4df0-a570-0bd051efbdbe	Hồ Thanh Nguyên	15/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:03.208+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
1d80f7c0-2ea2-4c0b-9d1f-69040602433c	Hồ Thị Nguyệt Ánh	30/10/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:06.172+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
0a6763b9-a1f3-434a-b7cb-36811d73ac6f	Nguyễn Diệp Hân	13/03/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:07.731+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
732d693b-6496-4b45-a2ef-3a2829bf1961	Hoàng Tùng Lâm	11/12/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:09.235+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
f6a96036-128c-4010-9fcd-2ceb406e77c7	Hoàng Minh Quân	18/10/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.748+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
853dbe68-63b8-4ff9-8ff5-58bd659f4126	Nguyễn Mai Công Anh	22/06/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.235+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2- Ia Dơk- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
b614c228-e053-4871-ad05-fae722a1bcbb	Vũ Minh Đức	09/02/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.792+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung kép - Ia Dơk- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
ffff29a4-941c-47f4-a14a-4307f8f4ba97	Bùi Văn Lộc	27/07/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:15.358+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Kăm - Ia Krêl  - Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
fae31961-3ea6-4f8c-9889-99836f82663c	Phan Thị Yến	20/07/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:55.33+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
bbe75490-d8b9-466b-9dd4-3c02ed8c3fd5	Nguyễn Việt Đức	27/10/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.951+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
4d4977e6-06f0-4143-9938-a563a8615eb1	Phan Minh Bảo Long	08/07/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.537+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	681 Quang Trung - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
a6c87c09-4491-4694-8fc1-5d40824e661b	Trần Gia Phát	26/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:00.08+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 1 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
a6315b45-1031-46e8-a944-24973ed9798b	Nguyễn Bảo Trân	07/04/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:00.017+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
360acaf7-a85e-47b9-ac8d-a4e88b2117ed	Nguyễn Thị Trà Giang	13/03/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:45.748+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
5b2dc503-d8ce-4fda-8da8-01ae238322dc	Hồ Thị Ngọc Trang	20/03/2010	Nữ	Kinh		t	10A5				2026-03-31 16:16:22.966+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
46fd5316-a304-4dfa-bac6-f28977556841	Mai Tiến Quân	19/04/2010	Nam	Kinh		t	10A5				2026-03-31 16:17:58.793+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krai,xã Đức Cơ, tỉnh Gia Lai	65560ab5-035b-496a-9133-a50d9bf0a0d0
17d5b0e2-be37-4618-a3f9-3088f4dc608a	Trần Ngọc Huyền	06/02/2010	Nữ	Kinh		t	10A8				2026-04-02 09:51:50.099+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
b48f48fb-748f-49c7-89bd-746ac26097ec	Đoàn Hà Giang	16/11/2010	Nữ	Kinh		t	10A10				2026-04-27 07:42:41.011+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
9a6de8b6-b095-449e-816c-285ca3a678ec	Hoàng Thị Cúc Hương	06/08/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:34.753+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
0ad7d3ae-d26b-4190-a891-00c70a22cf75	Nguyễn Thị Thanh Ngân	31/01/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.196+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ngole, xã Ia Krêl, Tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
cfbd79a3-17e8-44f6-938b-58c572cd485a	Nguyễn Phùng Thành	18/08/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:37.655+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
c06b663c-129e-40f1-9c79-40d28a09236c	Hà Bùi Cẩm Tú	17/03/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:39.111+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, Xã Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
4cab838a-d4d3-40ba-9b2c-3606e2967345	Rơ Mah H’ Grinh	11/05/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:40.626+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung le - Ia kla - Đức Cơ-Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
7d45f1fd-0035-49c1-b1a3-749a4d4924e2	Chu Thị Thanh Linh	12/07/2010	Nữ	Tày		f	10A7				2026-03-23 13:55:42.157+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl, xã Ia Krêl, Tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
451c59ea-bad9-4481-8bb9-aa6169aa1b82	Rơ Lan Lê Thành	16/08/2010	Nam	Gia-rai		f	10A7				2026-03-23 13:55:43.661+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, xã Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
ff827b54-e647-4664-8e3d-e8c1e31d46b3	Lê Đình Anh Tuấn	22/09/2010	Nam	Kinh		f	10A7				2026-03-23 13:55:45.139+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, xã Đức Cơ, Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
2375a2a4-52d9-47f2-a97f-43a6eff54db5	Nguyễn Thị Thanh Hà	10/11/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:46.616+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
cc0f58bb-8992-418c-a807-b58f61771378	Nguyễn Thị Hương	24/12/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:48.098+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
6c3a83f2-8687-45b1-b3ef-3842e7f29e24	Kpuih H' Ngon	17/12/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:49.611+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
e0d186ce-0005-4163-bb8e-9292c89d19bd	Đặng Phương Thảo	30/01/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:51.094+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
753fe8e5-5cbc-4e9c-9264-5b6f65ab1f3e	Rơ Lan Kim A	04/04/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:52.576+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép -Xã Iadơk- Tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
c0d96e9d-0b1e-4b4a-9faf-1cf50b39e0a1	Lương Kim Anh	18/02/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:55.523+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
e5366ddc-62ec-41d1-b6f2-8ef027107025	Lê Thị Việt Hà	22/10/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:57.138+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
d0d515ad-3673-46cc-98ce-02e1b3ecb8f5	Trần Lê Xuân Mai	25/05/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:58.688+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
93bd3405-6133-4087-a140-6cf0ebf86419	Nguyễn Hồ Quỳnh Anh	14/10/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:55.706+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 7 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
c426e0a2-3764-48af-8a62-80c2fdbc1181	Ksor Hân	19/01/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:54.081+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krol, Xã IaKrêl, Đức Cơ, GIa lai	5d2969a5-0d68-4845-bcab-407f002e89b1
20b4bcbf-7b45-4176-8d86-6360d624f909	Trần Thị Ngọc Mai	08/10/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:55.671+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
e8a0938e-adad-4d7c-bd03-84f56748c585	Trần Anh Quân	21/06/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:57.168+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
bc79b6ed-26fc-4988-98a6-835d31d4cd0f	Lê Trần Anh Trung	20/06/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:58.692+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, xã Ia Dơk , Tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
85247163-36df-412e-9bb2-4fc9e7e549f2	Hà Thanh Lâm	25/08/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:01.803+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Xã Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
6a8deaa2-586c-4c99-b914-02abacb33589	Rơ Mah H' Niê	27/07/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:03.359+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè, Xã Ia Dơk , Huyện Đức Cơ , Tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
ce4d2760-9643-4d56-96a9-de07a4ebad9d	Rơ Lan H' Bạch	14/07/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:06.325+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
84696ed3-f819-467a-9391-59dfbaacb6b4	Hồ Thị Như Hoa	21/06/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:07.884+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
355f918b-fc5b-4d55-aee8-7e3239dd1561	Phạm Nguyễn Nhật Linh	30/01/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:09.391+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
17a1717c-3d99-4605-aa90-835c2045326b	Lê Thế Quý	12/02/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.899+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
8b3c6882-a993-473c-b6f5-e19a51fa02e1	Phan Bảo Ngọc	21/04/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:51.477+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Mang- Ia Dơk- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
561aebed-c038-4fad-92a5-6f41f830d9de	Nguyễn Thị Hoài Ân	20/04/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:12.38+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
d9d8f7d6-f68f-4c1d-99ee-e70e3f02a3f3	Nguyễn Thu Hà	23/04/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:13.95+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
5279daa6-ad57-4da3-970d-7136269d3a93	Hồ Thị Ngọc Trâm	2010-12-11	Nữ	Kinh		t	10A10	2025-09-07	0343400608		2026-03-26 02:05:31.445+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
5d823d24-0a48-4e55-9782-67bff369ad8e	Nguyễn Thị Thu Hiền	01/06/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:49.195+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
f75a97d6-60ef-4a00-9a7c-d10bb23df620	Đàm Thị Thanh Hà	03/04/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:33.73+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Đức Cơ, Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
1765a7d6-f5e2-4244-b537-2eec009698a5	Ksor H' Khuê	10/10/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:35.176+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krol, xã Ia Krêl, tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
b9dae8b9-a64c-4fbb-9e3e-2d16981ab5fb	Nguyễn Sỹ Nguyên	16/05/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:36.635+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N		846cdc56-d3b7-494e-b805-6e584dcd9392
3005239b-53f2-441c-9aad-49414e6166b4	Lê Thị Anh Thư	28/09/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:38.104+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, Đức Cơ, tỉnh Gia Lai	846cdc56-d3b7-494e-b805-6e584dcd9392
5e2c6463-923b-4dbe-afe3-5b74b27123cc	Nguyễn Hoàng Thu Hiền	22/04/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:57.277+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 1 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
965aa45f-d05a-4fd8-805e-7be4387dad0d	Hoàng Văn Nam	17/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.866+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
97f732d7-96c0-4293-902b-a70ac4f7098a	Nguyễn Xuân Sang	30/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:00.357+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
fafcbf94-121b-4df0-b417-fd2085f40dfb	Dương Thị Thanh Thúy	29/03/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:44.106+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
599b49cc-1992-4526-ae52-5bf7d940e264	Phan Thị Thu Hằng	17/05/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:47.069+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
e9ace483-8b33-4256-ab68-e6df2b6a0be9	Nguyễn Nhật Kha	01/01/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:48.564+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
629c4eaa-bbc5-4381-bb9f-d9bbfa4dc147	Vũ Thị Tuyết Như	11/07/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:50.06+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
4ac64c46-dd0e-4be9-8e5f-891e494d2e55	Kpuih Thuy	09/02/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:51.539+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	02180031-0a4d-4aa7-b43b-0d3549779653
9bf3e426-823b-4df8-a37a-f0d0804807d8	Lê Khả Tuấn Anh	26/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:53.006+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
99f632c6-652b-4da8-8572-6f4e2bbe5807	Rơ Lan Khiếp	04/02/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:54.548+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông xã Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
8c9ecfb1-967c-453b-908e-6209993dcc3e	Rơ Lan H’ Nasi	10/10/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:56.144+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung le - Xã Ia Kla - Đức Cơ - Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
4ce065b3-09d8-4366-8fc8-c8eaf6377908	Nguyễn Thị Thảo	01/04/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:57.607+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
cdafe818-3f41-48b3-b8fc-38924c6c70e7	Kpuih Lan Văn	24/12/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:59.141+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, IaKriêng, Đức Cơ, Gia Lai	5d2969a5-0d68-4845-bcab-407f002e89b1
7a8debc4-53db-482e-bc06-6eb6e38bf10f	Trần Bá Hoàng	03/09/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:00.657+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
905ccb7f-b98f-459d-b287-6e1cebd633f0	Rơ Châm Thảo My	10/10/2009	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:02.306+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
0b3d45ef-dd2d-4a2b-b3aa-3d1729ab4ff7	Hoàng Anh Tú	11/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:05.338+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaMang -Iakla - Đức Cơ Gia Lai	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
b06cef60-b9df-4f2d-aa17-bfe2f275fce1	Rơ Mah H' Chúc	28/01/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:06.812+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
46d7d6b2-ae19-4f9f-956a-8c35c52d6b84	Nguyễn Hữu Huy	02/06/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:08.339+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
9ac0856c-e82a-43cd-88e2-3b1824c18201	Trần Nhật Minh	29/07/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:09.844+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
891d1a70-3418-48b4-a27e-4a1c02c51bbb	Mai Thị Thắm	09/11/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:11.345+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	87881984-264c-4c97-b336-69ef0999dd67
62d75473-75c5-43ae-991a-c1b0e1f2d69b	Phan Minh Cường	24/02/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.864+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
9cc1fd4f-ab5d-4f42-9ca4-37e623d28559	Nguyễn Thanh Hiền	12/05/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.427+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP2- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
d2aa0eb0-0246-4a90-a70a-5f9339a13367	Nguyễn Thị Ngọc Anh	09/05/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:55.882+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
d78f4f0a-c96c-44f4-bd3c-919f02040616	Hoàng Văn Hiếu	13/07/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.456+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
2272eeb2-fd81-4497-aee9-c7672928c5cf	Lê Ngọc Thái	01/05/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:00.518+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 7 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
89fec2ef-32f5-4c1c-b3c0-90b5b97086ba	Phan Nguyên Khang	02/08/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.604+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 3 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
9dadc88f-5410-4beb-9925-34e4a79afbc2	Văn Tiến Mạnh	11/12/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:49.821+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
efdc6863-c8e6-4448-a6ac-8daa29963681	Đào Quang Minh	19/10/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:50.768+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
47ba941a-a089-46af-8cec-8ac580e12644	Phạm Thanh Bảo Ngọc	09/11/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:51.196+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP6-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
4705c16f-7bd3-4db7-ad23-3221f865d73e	Trần Bảo Ngọc	10/11/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:51.744+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP1-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
8741d17a-55f5-4b4e-8dfd-d1d67290784f	Phan Trần Gia Nhi	04/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:51.98+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thanh Giáo- Ia Krêl- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
1c00b9e3-210a-4cfd-a499-c01c64ff46fb	Nguyễn Tấn Phát	29/10/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:52.454+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP6- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
215ef349-fb6f-433b-8308-942ada78510e	Lê Minh Phương	06/05/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:52.726+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP7- Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
9ee80d9b-3b38-4a29-88e3-0c078674244e	Nguyễn Ngọc Nhã Phương	28/03/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:52.998+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Chư Bồ 1- Ia Dơk- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
139249a6-aed8-45fd-aaa9-90ca4dbdb25d	Cao Nhữ Hoàng Quân	13/09/2009	Nam	Mường		f	11C1				2026-03-23 13:57:53.305+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp -  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
f7330a95-e5af-46dd-b557-b3e391e99285	Hoàng Thủy Tần	16/06/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:53.493+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP7-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
a459bf02-a11e-4fba-bbf8-4562708197c9	Cù Lê Gia Thanh	06/04/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:53.688+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Lâm- Ia Krêl- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
ea23a775-b453-498c-841a-0ae17d4246a4	Lê Thị Ngọc Thư	11/06/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:53.887+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol- Ia Dơk - Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
0be561a7-b9d1-4539-a565-33762c6da77c	Nguyễn Thị Minh Thư	17/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.055+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP6-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
12f520ea-a11f-4065-97e3-4197564fb24b	Đặng Đình Tiến	17/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:54.239+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Bua- Ia Pnôn- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
873b9dfa-551d-4bb7-a7df-25c07775495e	Nguyễn Huỳnh Yến Trang	06/06/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.436+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ DP3-  Đức Cơ- Gia Lai	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
a1218f08-ffc9-468c-8f38-ffe68df01a5b	Đặng Thị Thảo Vy	14/05/2010	Nữ	Kinh		t	10A7				2026-03-26 02:29:33.297+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Triêl- Xã Ia Pnôn - Tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
31362a01-8e42-4d12-9b29-5cabbe9a7d44	Nguyễn Phi Hậu	20/08/2009	Nam	Kinh		t	10A7				2026-03-26 02:31:29.66+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	141be337-7bb7-4d92-bd8e-21330ef7702f
956b039e-da8e-4e33-ad6c-68f9ad79f22f	Trần Thị Khánh Ly	02/09/2010	Nữ	Kinh		t	10A7				2026-03-26 02:33:00.762+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ I, Ia Dơk, Gia lai	141be337-7bb7-4d92-bd8e-21330ef7702f
4de7f2d8-b38c-43e6-a535-2ed51a7998a2	Phan Thanh Nhân	15/06/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:59.183+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 1 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
502ad2e8-ef81-4a90-a401-f7d181a02ea5	Bùi Thị Anh Thơ	23/03/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.661+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
88b633e6-6a8b-4879-a530-036e235f8126	Cao Đăng Quang Tùng	05/06/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:02.143+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết  -Xã Ia Dơk- Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
d381d186-4ea7-46e7-8352-cb0d5cc05fe5	Trương Gia Long	24/05/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:05.112+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
e5e7a250-7eb6-422b-bb69-315ce69e8406	Mai Nguyễn Quốc Cường	01/08/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.17+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lâm Tốc, Iakrêl, Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
7296b526-bd56-4a6a-9300-fa6b4b625c85	Lê Ngọc Bảo Trâm	28/07/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:28.589+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
77ce3140-5697-4d8c-960a-d48e08aa1c6f	Rơ Mah H' Dulen	02/12/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:30.176+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, Ia Dơk , Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
90e42e2a-4a4f-4538-a5e4-27640cfc455d	Vũ Thị Thùy Trang	11/09/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.961+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - xã Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
a35680ca-d653-4ac2-9c58-e09d7a3be4eb	Nguyễn Văn Huy	04/09/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:03.909+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh giáo -  Xã Ia Krêl  -  Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
9b4dbe3d-af5a-4df8-bda1-fde86d13ec23	Hoàng Hoài Băng	26/09/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:09.895+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tốk - Xã Ia Krêl - Tỉnh Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
a3d210a6-cf7c-4481-86b7-e7e25dd35672	Hoàng Thị Hợp	28/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:31.657+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
b82cc3d8-2da6-4566-bb9a-974ca6887dfc	Rơ Lan H' Lyna	12/03/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:33.146+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
55492d8c-6809-49b2-b9b3-1aea0da70712	Đinh Đức Thắng	29/11/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:34.583+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Lang Krol, Xã Ia krêl, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
ace23fbc-2b31-41fa-8979-6e8354fa83a7	Rơ Mah H' Chi	01/11/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:37.576+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
eca3f4e4-0d44-4210-8828-ed9b8045cffa	Rơ Mah H' Hiệp	14/06/2007	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:39.014+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
52e98590-c955-42b2-96dd-d74e2864389a	Ksor Net	01/08/2009	Nam	Gia-rai		f	11C8				2026-03-23 13:58:40.475+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
ded08e2b-8668-4663-b6e1-028c89ed6510	Phạm Thị Bích Thuận	02/11/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:41.863+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
82a75688-7acd-4015-a2ae-ad5806e282b1	Lường Viết Việt	08/09/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:43.368+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
04eccc7d-8439-421e-aee8-ab07b4dec31b	Vũ Quốc Huy	12/06/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:53.282+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
298eec5c-3e66-4c72-8b28-854bbdb75cb5	Nguyễn Hồ Khải Hoàng	29/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:11.385+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
9515aa68-817b-4449-a5ad-d5cebc02c306	Hồ Bảo Yến Nhi	28/11/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.845+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
7b647e29-8e11-420d-9400-4c551b27e442	Nguyễn Thị Thương	17/05/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.339+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Tang - Ia Dơk- Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
1a9d963f-ffa0-4892-95c8-45043eaf7b64	Đào Duy Anh	18/10/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:15.803+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 1, xã Đức Cơ, Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
ff953529-746b-40b8-bc40-1b33cb6b57b5	Nguyễn Thanh Hà	11/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:17.288+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
a6d30d03-30e6-4907-abb8-5540b284466e	Nguyễn Lê Quỳnh Mai	14/08/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.736+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
5c7ec2d9-286d-4e38-a5d2-60b345b1cfc1	Khiếu Thị Như Quỳnh	30/10/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.204+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
ec09764f-aa9e-4954-a62f-69bb2a5cd9ca	Trịnh Đình Tuấn	01/01/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.628+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Ia Krêl, Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
1bf1a97a-5581-4ace-b80f-099e1c669ec9	Hoàng Nguyễn Thành Trung	11/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:28.907+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Iakrêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
e052696e-c811-4581-9d4d-310ffe710102	Nguyễn Quang Dũng	25/07/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:30.492+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, Iakrêl, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
da04c58e-b041-46af-a7cc-e741cd23bc22	Mai Nguyễn Tuấn Hưng	29/11/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.97+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, Xã  Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
6501ebe8-3a77-4c1b-b2af-8bad0b68f5bf	Ksor Kỳ Vọng	22/07/2008	Nam	Gia-rai		f	11C7				2026-03-23 13:58:36.382+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le tung, Xã Ia Dơk,  Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
45ffe0e0-7031-4734-b848-4a1e36fcff45	Nguyễn Công Danh	28/09/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:37.855+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
b39af8fc-cd54-42d9-9dea-957a5793ba78	Hồ Thị Thu Hoài	16/12/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:39.289+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
ca605f17-703e-429e-a363-28fb82004dee	Lê Diễm Quỳnh Ngân	31/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:40.763+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
c8310e18-83ea-4a5e-840e-8cc4d2c3aff8	Rơ Mah H' Lệ	16/12/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:46.61+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ia Dơk Ngol - Xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
41114c2f-e5c0-4a65-92ba-7b27adc49544	Cao Chấn Đông	13/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:23.055+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Grôn, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
56f2d642-1cb8-4645-b045-0583d0252fe3	Bùi Ngọc Tĩnh	19/09/2009	Nam	Kinh		t	11C3				2026-03-26 02:03:13.465+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
b7c5f9b2-172f-4d65-aca3-8c9f3866b6d0	Cầm Thị Quỳnh Mai	30/08/2009	Nữ	Thái		t	11C3				2026-03-26 02:03:31.524+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
8d22bd54-fd9c-4192-80ef-5c4889c246d0	Đàm Quỳnh Anh	10/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:03:36.918+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
3f6d9bbe-2382-4698-a090-5c71836ffc6f	Trần Gia Như	06/05/2009	Nữ	Kinh		t	11C3				2026-03-26 02:29:40.641+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP2 , Xã Đức Cơ, Tỉnh gia lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
797fdb83-47b6-48b1-8af5-f20ffd5e7247	Võ Văn Huân	18/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.534+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
27de95a7-b314-4a37-906e-44bb03e532fb	Nông Lê Yến Nhi	26/08/2009	Nữ	Tày		f	11C4				2026-03-23 13:58:12.996+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
d2905eef-7569-4a4d-85b2-2173d8954678	Hồ Vĩnh Tiến	11/09/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:14.475+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết - Ia Dơk - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
7a12b0b2-110f-4dce-bbbb-4d1e086bb3e3	Hà Vĩnh Hoàng Anh	07/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:15.955+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 4, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
6be6a9dc-e8d5-4382-8697-71fdc3764084	Nguyễn Văn Hào	22/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:17.433+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
85cf9679-309b-40ae-9ebc-0ec626b0e755	Phạm Sao Mai	22/06/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.888+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 8, phường Hội Phú, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
6feeafcb-822f-44e4-b5cc-97333a10c6de	Hồ Vĩnh Duy Tài	17/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:20.36+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 1, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
ee502bc9-8cf4-448a-9470-04253d7094d1	Lã Thị Tố Uyên	05/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:21.766+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
d80156c3-5009-4bdb-9f96-0737eab7340b	Hồ Thị Ngọc Hà	23/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:23.211+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP2, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
df178bdb-aa0e-422f-9ce0-c2a8279b966e	Đỗ Thị Ngọc Mai	02/05/2009	Nữ	Kinh		t	11C3				2026-03-26 02:03:42.962+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dấn phố 1 - Xã Đức Cơ -  Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
40a5ed2a-3e0f-46f5-bbf6-6cce00bf6b5f	Hoàng Thị Kim Oanh	21/02/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:00.95+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tdp7, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
ab87653b-5dcd-4a06-87f2-1d0d7acabd2a	Ngô Thảo Vy	15/11/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:29.066+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ngo Le 2, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
31f518ac-da83-4dae-890c-0dfbc1ea9a47	Rơ Mah H' Xari	10/03/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:29.234+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, Xã Ia Dơk , Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
f999cb05-84a5-49b6-9e99-061b00bd01b3	Đỗ Hà Lan	28/10/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:32.255+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krel, Xã Đức Cơ, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
e957a8d2-550c-420a-bc2e-ce3edf295a47	Hồ Tuyết Nhi	21/11/2008	Nữ	Kinh		f	11C7				2026-03-23 13:58:33.706+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 3, Xã Đức Cơ, Tinh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
c72122c4-6774-4328-822b-8e8cf894492f	Nguyễn Vũ Trúc Thy	02/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:35.197+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
6f8767ac-14b8-4d38-be86-43b29d348045	Nguyễn Thanh Huyền	30/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:57.332+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
f3ae58fa-e2ab-4bb8-bb13-66b347f4cfc2	Phạm Minh Anh	17/04/2009	Nữ	Kinh		t	11C3				2026-03-26 02:10:21.102+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2 - Xã Đức Cơ-Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
8a6035fd-a4d8-43ba-9296-2fbfcd300d6e	Vũ Thùy Trang	15/10/2009	Nữ	Kinh		t	11C3				2026-03-26 02:30:04.773+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
a1755292-551e-4c73-b67e-3552fcd9173f	Phan Trần Yến Minh	14/06/2009	Nữ	Kinh		f	11C3				2026-03-23 13:58:05.741+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Kpă Klong, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
e812a2f7-4836-4edb-877c-b3194221f942	Nguyễn Trọng Bình	19/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.18+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai - xã Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
53e63949-39b3-4bee-a891-47776ab15ba6	Lương Phi Long	05/06/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.665+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tôk - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
aa86d92e-5c18-42ef-aff0-734abc20dd22	Hoàng Thị Hải Yến	27/09/2006	Nữ	Kinh		f	11C7				2026-03-23 13:58:36.683+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
f7f744b7-183b-4404-9ad7-961bdbc3208b	Phan Trần Thành Đạt	27/01/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:38.175+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
85b7e1db-bd32-4f4e-8cf7-ad1390616a21	Nguyễn Thị Mai Lan	16/04/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:39.602+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Trol Đeng - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
0636d010-1927-4102-ae8a-4612a8ec10f7	Hồ Diên Nhật	24/07/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:41.044+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
90013f38-f277-4bf7-9b06-9e74ee1f3a10	Đỗ Thị Huyền Trang	31/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.427+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ I - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
9de0ffed-2437-4f57-8086-d633bdf42c9c	Đỗ Nguyễn Thiên Ái	08/12/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:29.366+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Chư bồ 1- Ia Dơk- Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
a24e2c56-d104-43f5-a023-31c854cebe21	Trương Nguyễn Quỳnh Như	18/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:13.137+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
233e3135-7263-41c8-8fe3-29005e6d4950	Nguyễn Thị Thùy Trang	02/10/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.621+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1- Ia Dơk - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
61a08e7a-3e63-4308-8701-615d42207b5f	Hồ Quỳnh Anh	27/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:16.097+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
ad33184d-6f2a-4ab3-9a32-6fe67f475a60	Nguyễn Thị Minh Hoàng	10/08/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:17.574+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
daafd810-2363-49e2-9aad-2f2e62c3dabf	Nguyễn Lê Mạnh	14/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:19.015+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã Ia Dơk , tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
83c2bde5-6030-4fc3-946e-029de5300b98	Nguyễn Xuân Thành	05/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:20.501+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
836d5331-f382-468b-8483-7082bde20cd1	Đinh Đức Anh	10/09/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:21.917+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
bcd71496-703b-4147-afd9-4da246e1c4ec	Hồ Hữu Đại	15/09/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:30.936+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã Đức Cơ - Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
3107d2be-c342-40a7-9664-dfd7cc38d186	Rơ Mah H' Lang	08/06/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:32.406+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang Hrang, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
6cd458b6-8f6b-42be-a53e-70c2f98ddf5e	Thiều Hoàng Yến Nhi	03/07/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:33.864+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 3, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
db87c044-75f2-4446-91e7-84148a3f40f6	Nguyễn Như Tình	10/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:35.366+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
0f7c0fa5-7ba2-4f4a-ac47-38dc43384f4d	Rơ Mah Điềm	20/06/2008	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:38.33+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Lớn - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
fa3c23b5-70f6-426c-98e9-6e4c49b51325	Rơ Lan Lâm	26/08/2009	Nam	Gia-rai		f	11C8				2026-03-23 13:58:39.758+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
0a99db8e-575b-4350-8221-c723fa97e1ac	Vũ Quang Nhật	27/03/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:41.213+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ II - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
f9c48044-beb9-4ca0-ae76-13586115e60a	Kpuih Trí	17/09/2009	Nam	Gia-rai		f	11C8				2026-03-23 13:58:42.578+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
16f0e3d0-1bfe-47f6-a737-35e4a7452a0d	Nguyễn Thị Vân Anh	27/08/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:29.516+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krel- Iakrêl- Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
3f2c8c4b-aa9a-4758-9a60-ac47ff8d5765	Nguyễn Phùng Đạt	30/06/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.078+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
0ec6631f-5028-41fe-b3d0-dd81abac3c80	Đinh Thị Thuý Hiền	13/07/2009	Nữ	Tày		f	11C6				2026-03-23 13:58:23.365+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP9, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
cabc5369-ca9c-4cd4-9013-c1cd4cc15b81	Huỳnh Văn Phúc	14/02/2009	Nam	Kinh		t	11C3				2026-03-26 02:04:50.537+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh giáo-Xã Ia Krêl-Huyện Đức Cơ Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
623b00fa-8175-42a6-8bc6-42c22abcffc5	Nguyễn Thị Lan Hương	19/03/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:24.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng gron -  Xã Đức Cơ - Tỉnh gia lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
7261a333-17b9-45bb-b280-ea6b276fc00c	Thiều Thanh Trúc	16/09/2009	Nữ	Kinh		t	11C3				2026-03-26 02:26:51.538+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
07ad3692-61ff-4392-9541-bd82a7b77782	Trần Gia Bảo	13/07/2009	Nam	Kinh		t	11C3				2026-03-26 02:28:42.864+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
606f0d11-11ad-4dab-b8a7-de0b5e24ea9a	Phạm Hồng Diễm	25/11/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:10.339+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
d46db213-a03a-4d36-96a4-38013bc6b8aa	Hồ Thị Nhung	11/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:34.014+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
d9831a87-b463-4d27-8ea3-dc80092d495d	Lương Thị Linh An	24/09/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:37.009+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
60751503-b03e-4720-9d0a-ee4a2a84246e	Rơ Mah H'phương	23/01/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:38.464+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
0a4e59dc-cf48-41c9-9554-c7ed639e2539	Đặng Thùy Linh	25/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:39.91+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
81fdfcc7-aff9-4443-a168-eb45fa3d3734	Nguyễn Hoài Bảo Như	31/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:41.339+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
ea717622-a82a-44b4-b2dc-c96197af3e89	Mai Trung Tuyển	12/10/2008	Nam	Kinh		f	11C8				2026-03-23 13:58:42.748+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
ca785681-53e3-42ab-8071-dc665a45ef31	Nguyễn Gia Ân	05/08/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:44.234+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết - Xã Ia Krêl - Tỉnh Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
7567d038-4a7e-40c2-9c0f-1bba44b12137	Ksor Hòa	01/04/2009	Nam	Gia-rai		f	11C9				2026-03-23 13:58:45.71+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
146fdb02-0c4c-49b2-b32f-efb174b3f886	Bùi Lương Hải Đăng	12/08/2009	Nam	Mường		f	11C10				2026-03-23 13:58:52.669+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TỔ dân phố 3, Chư Ty, Đức CƠ, Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
2ed5d5f2-7e4c-4278-a557-79afd0fb8bcb	Lê Trần Gia Bảo	03/01/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:29.685+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Phường Pleiku, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
4e9086d7-48ad-40e2-a99a-1fda9c824789	Nguyễn Thị Thanh Hằng	29/08/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:31.223+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Đức Cơ, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
1bfb3547-34d9-40b0-ab85-eaea57ba1ffd	Mai Xuân Long	20/01/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
ad8e9960-4383-470b-82ee-4c4f7a8e8f44	Nguyễn Văn Phúc	08/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:13.281+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Lâm - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
4d64f75b-b7d5-4884-9a25-31f582601d49	Trần Thị Thùy Trâm	13/05/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.777+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
0cc547d5-3920-4b71-b1e8-d4040d7e8f73	Phạm Nguyễn Việt Anh	27/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.243+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 6, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
48afbb4b-fef8-4575-b889-67ca218fb8a2	Lường Quốc Huy	23/04/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:17.721+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
824eb43a-b1f2-4ddf-a6de-9f2b68159f88	Bùi Phan Bảo Ngọc	18/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.157+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
c6775b1c-7f69-498c-b50e-c1faf1197953	Đặng Anh Thư	16/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.654+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
af68e96b-51bc-461c-8fb6-fe4e89f74bb5	Đỗ Hạ Nguyên Anh	17/01/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:22.06+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP6, Xã Đức Cơ, tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
9ab2c379-baf8-4f74-8a45-2574bf546c07	Siu H' Li-ya	08/04/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:32.675+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
4f47a42a-98d1-4ded-b9ad-c2d0ee96b8be	Đinh Thị Quỳnh Như	16/09/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:34.148+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
52eff953-ea0f-454d-8143-2f10e35847d7	Hoàng Anh Tuấn	18/06/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:35.652+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
db5e3772-492a-49f6-be61-07736f135a06	Rơ Mah H' Bạch	20/01/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:37.16+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
6e803843-4f5e-46ae-bbd0-96f40dc0943f	Trần Thị Mỹ Hạ	29/10/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:38.602+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
a2d29e5e-7d7a-4516-9bb6-0f4f351c2f68	Đinh Thị Thùy Linh	21/07/2008	Nữ	Kinh		f	11C8				2026-03-23 13:58:40.06+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
b2fdf05a-ed13-407c-ac24-107e4a0331d1	Rơ Châm H' Plil	19/07/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:41.475+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
28b22e7b-7e12-42e2-b936-3d5092413259	Rơ Mah Hân	26/11/2008	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:31.363+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang Pong, Xã Iadơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
fab400ab-d92e-4467-bd6c-c7b868440277	Nguyễn Thị Thanh Hoài	02/06/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:23.522+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
8b5bfed8-0f21-4c63-9c4f-1f34c69f90fd	Hồ Ngọc Bích	02/02/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:11.028+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
1b9f7174-583e-4f07-87cb-afd522f1b37f	Hồ Thanh Tâm	06/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:23.463+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
fa259129-a95c-41c0-b8eb-89ced6e293d4	Huỳnh Nguyễn Trà My	20/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:42.83+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Ia Mút - Ia Dom - Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
3749caa1-7b29-4cb5-ad07-9d95732bd29b	Lê Hoàng Tuấn	20/10/2009	Nam	Kinh		t	11C3				2026-03-26 02:05:48.049+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ I, Xã Ia Dơk, Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
ba0631d6-f91d-4118-92cd-7cc6ab2abe93	Nguyễn Thế Khang	09/03/2009	Nam	Kinh		t	11C3				2026-03-26 02:07:09.177+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
251643c9-c20a-46c7-b461-4e117d4f8e3d	Lê Hồng Trúc	12/11/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:01.539+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Ia Dơk - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
0b90f39a-7f6f-4c8d-acf8-9b8ead01fc6a	Nguyễn Nhật Tân	24/12/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:07.596+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
424aedd1-4870-4d21-93e1-f2d8238f19ff	Lê Anh Dũng	24/01/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.485+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
16748258-0e33-4a8d-8f0f-8f65a2d14f32	Hoàng Ngọc Bảo Long	09/06/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:32.823+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iatang, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
de58d862-f04b-4552-a136-416efbac62b0	Cù Ngọc Sáng	29/07/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:34.292+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
5d8b0e52-a867-4472-9593-603d651b99c5	Mai Thị Ánh Tuyết	01/06/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:35.799+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
332b53cd-3f1b-499a-9921-5abd3d1dd4b2	Trịnh Thị Hồng Bích	26/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:37.305+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm - xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
2fc7eb58-93d6-4f03-884b-e79ce398f759	Hà Gia Hân	16/01/2009	Nam	Thái		f	11C8				2026-03-23 13:58:38.744+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Grôn - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
2083d0ed-7b13-42b2-9920-e5cc79aeb529	Ksor Mai Linh	28/12/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:40.2+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
af48a2ca-937f-4649-9811-323774b1faa6	R Mah H' Yu Ri	10/10/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:41.605+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
d48e3588-3ba5-4692-b9c2-a4e71e7bd98a	Võ Đặng Ngọc Châm	15/09/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:30.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 9, Đức Cơ, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
e568c161-e745-4ac1-b5c7-c476c399cac2	Vũ Tiến Long	25/07/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.97+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
1a23b66a-cca3-446b-adb4-425c18ba8563	Phạm Văn Quân	03/06/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:13.42+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
e70ddf31-aefa-4aed-b906-c38c8417cc89	Trà Minh Trí	27/11/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:14.921+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thanh Giáo - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
d4339819-dad5-4164-a570-a69055af3526	Lê Thị Thanh Bình	03/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:16.38+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
7359aa5a-bac0-4859-bc28-c812d8d544ff	Phan Tấn Huy	18/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:17.875+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Nuk, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
de2b26e5-e86b-4e23-af02-dc7c6facce1a	Đinh Thị Bảo Ngọc	19/07/2009	Nữ	Mường		f	11C5				2026-03-23 13:58:19.297+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang ,Ia Dok ,Đức Cơ,Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
9a1966af-0200-4130-ade0-2afe185c330f	Phạm Anh Thư	20/09/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.794+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
f7f58791-54ce-4d0e-9e61-4a2334ef539a	Đỗ Đình Bảo	26/09/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:22.193+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
0b9aba8f-043a-4e72-919b-4668d1fc8d85	Nguyễn Thị Thu Hoài	14/08/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:23.668+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7, Xã Đức Cơ ,Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
daa9ff1c-563b-4635-8e46-380fb650657a	Nguyễn Xuân Hiệp	20/11/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.513+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Kom Ngó, Xã Iachia, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
029ee39a-3c58-4536-9df6-cb3762208b47	Hứa Thị Lưu Luyến	18/10/2009	Nữ	Nùng		f	11C7				2026-03-23 13:58:32.978+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
e1a1cc4a-daba-4f04-b37a-6928f17653b6	Rơ Mah H' Sơrka	02/02/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:34.435+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
494ece49-4327-40c5-885c-e0b1c3e636d2	Phạm Đức Bin	11/04/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:37.432+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
f913e407-a879-4bd6-b492-ff93a0675db1	Lê Minh Hiệp	20/02/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:38.872+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
ddbe469a-6c2f-44bb-85cd-1a653aaf62c1	Nguyễn Đức Mạnh	12/10/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:40.334+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
77788384-5040-4a69-84a8-f1c272ae9264	Nguyễn Thị Mỹ Tâm	09/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:41.741+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
6b45e3c2-c794-4d7f-9106-ca009f621515	Ksor Dũng	23/02/2009	Nam	Gia-rai		f	11C7				2026-03-23 13:58:30.321+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung le kép,Ia Dơk , Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
67c16ed5-0cab-44c0-9ae6-9294833f2a48	Hoàng Lê Ngọc Nam	26/05/2009	Nam	Kinh		t	11C3				2026-03-26 02:03:56.322+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 3, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
71e83e3c-485f-4f6d-abd5-7ad47086d7ce	Lê Nguyễn Giáng Châu	08/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:09.431+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
dfddf2ea-eeac-4752-8757-a4408d5e0b11	Nguyễn Trí Vĩ	23/10/2009	Nam	Kinh		t	11C3				2026-03-26 02:25:38.34+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Đường Quang Trung, TDP 2, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
0ec78550-c28d-410c-a4f0-2d32bf704195	Rơ Mah Vũ	13/09/2008	Nam	Gia-rai		f	11C9				2026-03-23 13:58:51.232+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
fa37f754-ce4f-4edd-aaf9-600d03853354	Trần Anh Khoa	01/05/2009	Nam	Kinh		t	11C3				2026-03-26 02:27:19.813+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dấn phố 7, Chư Ty, Đức Cơ,Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
1ec2c0bc-84a6-4447-b7cc-b32cb2b0bbcb	Nguyễn Thị Diễm Quỳnh	21/09/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.216+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Ia Dơk - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
038116f8-eaa7-45de-8db2-8c67a61e8a33	Lữ Thành Tú	30/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.695+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
6f0028c7-3f97-4bb2-88ad-fcf84f64056a	Cù Hoàng Gia An	02/03/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:09.195+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
95d0db16-b907-4332-8406-44c95d0d53c4	Trịnh Phan Kim Chi	23/08/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:21.811+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
a25123eb-dd94-4039-96c4-16a8c245a51f	Vũ Đình Đạt	26/08/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.615+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
2cd83bc6-581a-461a-b03b-fec7a7d2fa89	Nguyễn Anh Dũng	02/04/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.636+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
7d5f0524-7e14-49f6-8256-797c15db7594	Rơ Lan Ai Quyết	13/01/2009	Nam	Gia-rai		f	11C4				2026-03-23 13:58:13.585+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
0051947c-1f9f-4d34-9667-236bcc58ae60	Nguyễn Thị Diệu Trinh	13/12/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.066+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
b907a383-6201-4589-8bbc-ef1d62de7a1d	Phạm Thị Kim Chi	27/02/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:16.524+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
9a74b5d3-0741-4145-8477-abbfd6179e89	Hồ Hoàng Hưởng	01/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:18.015+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
9e741bd7-79a3-444c-b54e-9b4dbf91581a	Bùi Văn Hoàng Nguyên	23/08/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:19.439+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
bb6d376d-8056-4acf-a8de-f05bc4de297f	Dương Thị Thùy Trang	14/07/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.934+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
517f6af7-404c-47b3-967b-25c192f4ebc9	Rơ Lan H' Sa Bét	27/11/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:22.33+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
fb4be1a9-98e0-4b7f-9419-70165b1e91a0	Rơ Lan H' Hoài	31/07/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:23.805+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
3fe46f87-61f8-46bb-91b0-8974bc5b6a8e	Đồng Gia Khôi	04/02/2009	Nam	Kinh		t	11C3				2026-03-26 02:03:51.431+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
186fe7fc-162b-4f23-914f-44e61cd8543b	Hoàng Thị Kim Thoa	16/12/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:05.941+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 4- Xã Đức Cơ- Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
d73cf1b4-4762-498d-a121-82387a818110	Lê Thị Hồng Ngọc	17/10/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:24.05+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP7, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
21ce3fe0-0dd2-4bd9-b0e2-cfdf4c6292e6	Nguyễn Đình Dũng	15/12/2009	Nam	Kinh		t	11C3				2026-03-26 02:06:38.363+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, Xã Iakrêl, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
e4282849-e3e5-4d9f-90a1-bdb1c1af6569	Lê Anh Tuấn	27/02/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.837+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 4 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
02add307-04a3-4535-abf0-1d69331766ef	Đào Lê Minh Anh	20/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:09.342+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
aa3e2ec9-bc2e-47b9-b44e-961c591a9725	Vũ Hải Hà	20/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.79+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
cb6d72fe-e323-4ec5-80b5-1f0960d33d11	Lê Phương Thảo My	08/02/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.25+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 2 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
d934a219-66ed-415b-b0eb-9c3fdad6c2fa	Hoàng Thị Thanh Sáng	20/04/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:13.738+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 -  Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
266837ce-8c03-4a75-acc5-12433c664048	Trương Phương Trinh	16/03/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.218+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - xã Ia Dơk - Gia Lai\r\n	b7b2f041-de5d-49db-8186-5dd8db250052
9e204875-9e12-4f96-9150-423a82aee36e	Nguyễn Thành Công	16/05/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.681+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
9c868e89-7b3c-4e13-9b07-3197f434276c	Nguyễn Hoàng Gia Khánh	03/10/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:18.15+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 7, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
0c3a6b82-c874-4a0c-9a16-08ac32d5cbd1	Nguyễn Lê Yến Nhi	23/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.57+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
85675ff6-eb57-4ba7-bbb9-dec6ad0be0ce	Trần Minh Trí	17/10/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.075+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
060f1731-c412-49f7-b32a-c8ff26c53e62	Khuất Duy Công	16/06/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:22.478+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 , Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
ccf56243-3adc-4b3f-93aa-7b406cea605f	Nguyễn Minh Hoàng	17/11/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:23.959+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
88d1f008-a3dd-4d33-a880-46f1cd84fc4d	Hồ Thị Anh Thơ	04/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:32.426+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP2- Xã  Đức Cơ-Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
ce544b20-5dc5-4cbc-98d9-29028144fb52	Lê Đình Đại	30/09/2009	Nam	Kinh		t	11C3				2026-03-26 02:05:01.575+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ấp, Xã Đức Cơ, GiaLai	fdc18dde-9e98-4ceb-831f-2944f68998d4
c6945a7e-bfb9-4edc-81c5-a42d4a7b1de5	Nguyễn Công Ngọc	21/06/2009	Nam	Kinh		t	11C3				2026-03-26 02:06:30.646+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn ia Mang, Xã Ia Dơk ,Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
78aec30f-e89b-4919-a844-4a28abb35c43	Nguyễn Trần Thùy Linh	21/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:58.37+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4- Xã Đức Cơ- Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
d2199296-6a58-4d20-b17b-112a3d5a956b	Hồ Minh Nguyệt	29/01/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.02+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân - xã Ia Krêl - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
2ad8ba7d-2776-48e7-9f12-473d1b0932d4	Trần Nguyên Tuấn	14/03/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.978+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - xã Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
aedc3d80-8df2-4f9d-a311-7acaaba6aecf	Trần Trịnh Nhất Gia	15/08/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:03.46+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7 -  Xã Đức Cơ - Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
ea90cc0a-7a61-4728-a0b3-ccf6ae43aef0	Nguyễn Khắc Việt Anh	09/02/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:09.48+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
c98f1745-b0c3-43df-8b58-73f99b3cb2c3	Phạm Nguyễn Bảo Hân	24/11/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:10.939+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
83113869-0bef-4f3c-95bd-8f43d0e8073e	Hà Nhật Nam	11/06/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:12.39+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 2 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
423a4553-f919-4490-834f-81283499ac24	Nguyễn Khánh Sương	19/10/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:13.913+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Lâm - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
c86b3feb-8dc1-4a46-85e1-1e2b58fcb3e2	Trương Vũ Cẩm Tú	25/07/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.354+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
8d8e1371-92d8-443a-b14c-e3752d47c0a1	Giang Hải Đăng	30/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.851+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
1fe5d840-e64f-4d7b-9ce0-4ce035cf4623	Phạm Thùy Linh	20/03/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.29+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang , xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
016c27c5-685a-42d3-8ff5-6d5a7889ad71	Lê Thị Thu Phương	29/04/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.721+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
c3a47f7a-64dd-45f8-9264-f73c1ef792ff	Nguyễn Hữu Trung	20/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.195+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
c5c7336a-d21e-4ffb-9c3d-32e360429c2a	Nguyễn Công Dân	02/03/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:22.623+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
0e49699d-fab1-40db-b974-b957dbdaf591	Phan Công Hoàng	05/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:24.104+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
0fde7158-e64e-43cd-9920-a574a793169c	Nguyễn Quang Long	07/02/2009	Nam	Kinh		t	11C3				2026-03-26 02:06:49.681+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7 - Xã Đức Cơ- Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
37100e9d-91b4-42f2-8d99-f1b2747ce4c6	Nguyễn Thị Ái Thuận	24/09/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:16.157+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP1- Xã Đức Cơ-Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
e00c0d37-3125-42d9-b8c6-8f3808361e2d	Trịnh Thị Bích Ngọc	19/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:29:48.384+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ia Mút, Xã IaDom,  Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
7198612f-7b60-4fd6-ae1c-f44a985f412c	Phạm Đình Ánh	15/10/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:09.61+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
c8f4fa0a-27c8-4aee-9d1c-03ee016efd84	Nguyễn Trung Hiếu	15/04/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.086+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 -Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
7181e1ae-ea3d-4484-91dd-36da3d070218	Lê Thị Bảo Ngọc	29/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.549+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Sung Le Tung - Ia Dơk -  Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
23cd1229-73bb-47b7-b4d7-11a7bf1224a9	Lê Phú Thành	06/04/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:14.065+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Lâm - Ia Krêl - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
e57753f0-e6b5-47a3-9252-fdb74c66f921	Lê Thị Hồng Tuyết	14/02/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.504+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 9 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
ea020c65-cdad-4926-8071-673f30c2789e	Rơ Mah Bom	19/01/2008	Nam	Gia-rai		f	12B9				2026-03-23 14:01:03.814+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
a2bda564-75fd-4508-a791-d34ee0912d7a	Nguyễn Hữu Đức	05/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.991+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
9a27c07a-2e91-4e35-952b-81871ea2aaf3	Tăng Văn Hải Long	12/01/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:18.445+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
91f3d2b2-2f07-4f43-9370-32466584356b	Nguyễn Thị Linh Phương	31/05/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.883+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
189a18cc-7e13-449c-8b92-56776514bf94	Trần Xuân Tú	26/01/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.331+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
e5c88258-512c-4037-aa7a-d6e48b2ffaa4	Vũ Thị Duyên	30/11/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:22.768+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 4, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
b5825ec6-40a5-427c-9da6-1fe07e4745e6	Phan Ngọc Khánh Huyền	01/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:24.235+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
367a4cd3-520e-4afc-8fea-c7806a7f9091	Bùi Thị Yến Nhi	01/02/2009	Nữ	Kinh		t	11C3				2026-03-26 02:03:24.151+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tdp2, Xã Đức Cơ, Tỉnh Gia Lai.	fdc18dde-9e98-4ceb-831f-2944f68998d4
a40a021d-41e6-4ffc-bba4-2efa06c4f92a	Bùi Công Gia Bảo	21/09/2009	Nam	Kinh		f	11C2	2025-09-19			2026-03-26 02:05:32.115+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
0b44dce8-9eac-49df-b6b0-4c2d0a154f56	Nguyễn Hoàng Bảo Hân	25/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:42.882+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
e984e8c1-2250-4b56-87a7-893640fe24c4	Phạm Hoàng Anh Thư	22/10/2009	Nữ	Kinh		t	11C3				2026-03-26 02:10:27.066+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
b602543d-440b-46af-a537-fbebd1e42361	Phạm Đình Khánh	06/02/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.745+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 2 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
fa1a4e8b-951a-4099-a284-11377d747281	Nguyễn Thị Yến Nhi	27/02/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.376+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 7 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
c6adab7a-bc5e-49e1-b5c4-95f699a61ec0	Trịnh Tâm Thư	01/11/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.814+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tdp 6 - Đức Cơ - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
e4705265-1745-4a99-9fb1-fc3f6f2f7c70	Vũ Sơn Tùng	07/10/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:02.286+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Klăh - xã Ia Dơk - Gia Lai	325ddee6-e5ad-47d5-8351-b12c1eb67acc
a7cab8f1-58ba-4f65-9fb4-10dd4a318e66	Vũ Đức Tiến	22/08/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:08.333+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
1c96441e-2d7a-4b5b-9953-7114afe9cf37	Huỳnh Ngọc Bảo	09/02/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:09.745+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 2 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
21f113bd-468c-4808-a0e5-ee3f62f8ef60	Nguyễn Hoàng	05/01/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.223+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Grôn - Ia Kriêng - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
06d4851e-7cae-4994-870d-9d57885c88bd	Nguyễn Thị Bảo Ngọc	22/09/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.694+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Chư Bồ 1- Ia Dơk - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
c17bc08c-c887-4984-9c88-2f0b2d9d3967	Hồ Thị Anh Thư	24/07/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.213+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
15ba57c2-2fff-4d89-85d4-515f876a90e4	Nguyễn Ngọc Như Ý	13/07/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.653+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 9 - Đức Cơ - Gia Lai	b7b2f041-de5d-49db-8186-5dd8db250052
ba6ba7c7-a0e8-437f-9de5-211f040b8e38	Võ Hương Giang	05/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:17.141+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
8d2a3d07-d382-463a-8fdf-9d08b6ebc0f5	Lê Bùi Xuân Mai	11/04/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.578+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
2b67e6f6-fa90-4015-ba31-6e32e6cb60b5	Bùi Minh Quân	27/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:20.047+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Chư Ty, Đức Cơ, Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
93e4c1df-a235-47cb-9ebb-c98186a9bfa0	Phan Trọng Tuấn	25/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.483+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	25d78477-f93d-401d-85b3-3a39ba2e83e7
1e8cc3e8-a50e-4d85-8db3-a51d1b2d7e7a	Ksor Dứ	01/10/2009	Nam	Gia-rai		f	11C6				2026-03-23 13:58:22.913+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
4fdf5821-8c5e-4f74-a466-ebdaf6512eae	Trần Khánh Huyền	12/12/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:24.391+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 , Xã Đức Cơ , Tĩnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
76a7ae09-83c7-442a-b64d-795bcb42f968	RMah H' Jin	31/10/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:24.528+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Kắt, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
e7d179a6-70b2-4a20-91de-f7c63a4e9544	Nguyễn Đăng Khoa	03/10/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:24.669+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
3e4e390e-4501-45a8-b170-460abed64f84	Đào Quách Hạ Lan	06/01/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:24.983+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang , Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
79550dd9-80e0-4b8e-8682-6c09b1383969	Vũ Đỗ Thùy Lâm	01/12/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:25.119+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
4e29f357-4997-44c7-a64b-275378cbf2aa	Rơ Mah Liêm	06/09/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:25.28+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
5c8297bd-cdd8-430f-b4f1-f29e7180ecad	Đặng Thị Hà Linh	17/08/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:25.419+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Triêl, Xã Ia Pnôn, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
ea24cd60-67bc-4a46-a5f6-70bd772abeac	Nguyễn Thị Ngọc Linh	25/06/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:25.55+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
de0e07cb-cfdc-4447-b3ee-9de56b636d76	Đinh Mai Loan	13/03/2009	Nữ	Mường		f	11C6				2026-03-23 13:58:25.705+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl, Xã Iakrêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
5a31628e-edd8-4c53-9b49-42e475b770bf	Trần Văn Long	14/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:25.848+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
077c6095-64b4-4599-8148-eb646209a6f8	Phạm Gia Bảo Lộc	28/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:25.989+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
d1222f2b-7862-4d3b-b31f-6d4676ffc4fa	Nguyễn Thị Lượng	10/01/2007	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.128+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
c5ba6c36-88f6-475a-be9c-5557ba4d9562	Phan Thị Thúy Ly	17/11/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.272+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
63c78be7-713e-45bb-be13-ca45d7f4d3ef	Phan Đình Minh	06/06/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:26.431+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
59381e5a-27aa-4aa0-8236-1c51bb8e291a	Ksor H' Mlan	09/03/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:26.58+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
42287fbd-089e-418c-be55-4b93e4952c57	Đỗ Thị Hải My	22/05/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.735+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 9, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
20ee3cd9-d292-4fee-8421-8660fc971614	Lưu Thị Thảo Nguyên	24/07/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.882+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP7 , Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
b5db3da7-da08-4057-b8cf-dc36fd186086	Hồ Thị Nguyệt	29/12/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ , Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
c2293c28-3a92-4917-a3b0-13fa024cb963	Nguyễn Thị Gia Nhi	06/05/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.161+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân , Xã Iakrêl , Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
81214e59-b082-44ab-b5ff-cb5ee6a43417	Nguyễn Thị Quỳnh Nhi	20/01/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.296+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
d653118c-d8c2-40cc-af0f-d4562ac708cb	Trần Linh Nhi	22/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.438+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
24a48163-cf7a-446f-8234-6121d3f686db	Nguyễn Tài Phát	23/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.583+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
3f4b1823-485a-4b62-a021-50f48c81164f	Trần Trung Quân	10/10/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:27.737+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
29131a6e-2554-4250-aebc-b91005c6fa7c	Rơ Lan H' Rêny	10/03/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:27.896+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
c0f7e869-fd25-41c9-8772-24d1b5cfc86c	Siu Run	04/12/2007	Nam	Gia-rai		f	11C6				2026-03-23 13:58:28.076+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
22b4effb-c2c7-42c2-857b-3c1233857dee	Rơ Lan H' Tâm	21/07/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:28.239+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
40310a1a-6235-4c1b-8687-55c47c56b751	Trịnh Thủy Tiên	14/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:28.421+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
b3f0f83a-d339-4714-a742-b7a628f0cb77	Hồ Thị Mai Trinh	17/07/2008	Nữ	Kinh		f	11C6				2026-03-23 13:58:28.734+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai	1d712008-dda7-4791-8b18-a2078c091830
c6ec4e8e-6a1b-45d6-a900-e70c691be9f5	Siu Đỗ Tuấn Hùng	09/03/2009	Nam	Gia-rai		t	11C3				2026-03-26 02:26:11.734+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Trol Đen, Xã Đức Cơ, Gia Lai	fdc18dde-9e98-4ceb-831f-2944f68998d4
f6f8386d-2eee-45c0-935d-b15f705fb3f1	Rơ Lan H' Thoại	11/08/2009	Nữ	Gia-rai		f	11C10				2026-03-23 13:58:56.346+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
debc3d6c-b3c9-43e5-bec4-04d6bbc79fdc	Trần Văn Đạt	29/01/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.33+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3- Chư Ty- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
e91eccf5-a2a0-48ef-b54a-42476b8b32bc	Trần Thị Diễm Quỳnh	25/10/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:01.48+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
835afa3d-b955-424f-bb3e-088c79875680	Lê Thị Xuân Mai	21/10/2009	Nữ	Kinh		t	11C11	2024-09-19	0344040341		2026-03-26 04:50:16.232+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
20af80d9-8c54-471f-a317-2a066dbe720c	Nguyễn Ngọc Bảo Trâm	17/11/2009	Nữ	Kinh		t	11C11	2024-09-14	0706131033		2026-03-26 04:51:51.334+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 9- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
d9077bf3-6a69-4f26-bedd-958dbf04cb41	Lê Thị Nga	05/10/2009	Nữ	Kinh		t	11C10				2026-03-27 01:06:11.534+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
6bdd3e87-dfcd-4627-8ad5-7edc06dabab5	Rơ Lan Điệp	26/07/2009	Nữ	Gia-rai		t	11C9				2026-03-28 10:48:13.581+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Dơk Klăh - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
177bf43c-e295-49ac-bbec-144e021d6cf2	Phan Thanh Trà My	16/05/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:04.215+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
7cef6cdb-1638-46b9-82cd-528170dcd480	Hồ Thị Thúy Kiều	14/10/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:46.123+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP2 - Xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
fdd21df6-a7a9-4780-a5fe-82c8a32f372a	Đặng Hải Yến	17/08/2009	Nữ	Kinh		t	11C9				2026-03-28 10:50:23.236+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - xã Đức Cơ - Tỉnh Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
097d15fe-c46e-472d-ae67-3b1f3ee9ef9c	Lưu Thị Thu Trang	01/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:52:06.474+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn Kết - Xã Ia Dơk - tỉnh Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
97a5867d-cbe4-4cfa-b2d6-978f586483ad	Nguyễn Khắc Tường	2009-05-22	Nam	Kinh		t	11C7	2024-10-21	0344580369		2026-03-29 10:05:56.134+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn 2, Xã Phú Riềng, Tỉnh Đồng Nai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
e639dd8e-2b58-41a7-a4d1-1fd9fd546167	Tống Thành Đạt	25/06/2008	Nam	Kinh		t	11C12				2026-04-28 13:43:29.26+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
7b82b3f8-73c7-43c8-896d-3efdaecdaa26	Mai Xuân Khánh	29/09/2009	Nam	Kinh		t	11C12				2026-04-28 13:44:10.387+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
eef38dec-b9d1-4a11-9247-828a47a491f9	Chu Đặng Nhật Phương	06/07/2009	Nữ	Kinh		t	11C12				2026-04-28 13:44:50.566+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
d9c0a6fc-8aaa-4477-8cee-f5b80f5e20cc	Lê Đoàn Thị Thủy Tiên	30/01/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.155+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
39300d24-b2ac-4374-a34b-7b876cddbc11	Bùi Thanh Xuân	14/06/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:43.642+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	07/05/2008	Nam	Kinh		f	11C10				2026-03-23 13:58:53.6+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
2b17aacb-578d-49d5-9e05-34bc64b315fb	Hồ Anh Thư	13/11/2009	Nữ	Kinh		f	11C10				2026-03-23 13:58:56.953+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
5d9d3085-14c0-4279-828e-724554c134c3	Hoàng Trung Hiếu	01/06/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.65+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iatang- Iakla- Đức cơ- Gia lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
5181ceb1-7b78-4dbe-8c89-1358a0fa2e1a	Lê Anh Minh	14/12/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:00.262+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
4e128bd3-0d5b-4e47-a6d1-95db4b8ae83f	Cao Thái Sơn	26/05/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:01.799+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
3e631f27-48da-4a5f-8f0b-adacdccd5f99	Nguyễn Văn Tuấn	16/09/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:03.325+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
8f412ae2-f76f-4f2f-9aec-dffbf1043a48	Nguyễn Thị Thùy Linh	19/05/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:06.322+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
25808d2f-e5f8-4e3e-afd1-6b8c4555390e	Nguyễn Ngọc Tiên Nhi	26/02/2009	Nữ	Kinh		t	11C10				2026-03-27 01:07:00.688+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm Tốc, xã Ia Krêl, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
731211bd-f11b-47d2-b43a-b8220940edcf	Nguyễn Vũ Hải Anh	11/09/2009	Nữ	Kinh		t	11C10				2026-03-27 01:08:00.023+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
ecc7e4b7-edf3-4895-a9e1-08c50d2a861d	Lê Quỳnh Như	25/03/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:14.852+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 6 - xã Đức cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
49ffd0c1-3d18-4bbc-b3cf-554c194dfba0	Rơ Mah H' Hần	13/09/2009	Nữ	Gia-rai		t	11C9				2026-03-28 10:51:01.326+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Kép - Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
43d92203-94f2-4534-b5d1-9c2388e6169a	Lê Tây Hùng Trường	21/12/2009	Nam	Kinh		t	11C9				2026-03-28 10:52:42.36+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
288f3df5-11f6-45d3-971f-8dd2e163172f	Hồ Thị Nguyên	2009-07-03	Nữ	Kinh		t	11C7	2024-05-06	0369569267		2026-03-28 22:53:56.109+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
80393b63-96a7-4fc6-8678-d72f4a6b7bf4	Văn Võ Anh Thơ	2009-07-02	Nữ	Kinh		t	11C7	2026-01-19	03354213		2026-03-28 22:55:37.377+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
ca5c8ee4-7988-438d-8cee-b7068064f86f	Lại Hoàng Bảo Hân	29/05/2009	Nữ	Kinh		t	11C12				2026-04-28 13:43:44.405+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, Phường Pleiku, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
09a3934d-30bf-43e1-876f-04dbdf2badb5	Đặng Duy Quốc Quân	04/09/2009	Nam	Kinh		t	11C12				2026-04-28 13:45:00.147+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
84ac0880-6825-48e5-8aeb-decb2b61402f	Nguyễn Hữu Duy	21/01/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:30.648+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang,Ia Dơk, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
c6f6665c-15bd-423e-a177-55c5ad77a556	Nguyễn Hồng Lai	17/04/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:32.117+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
de6619e0-2001-426c-bab5-b7fcf5e108ab	Rơ Lan H' Thư	29/03/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:35.061+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
9894332a-f038-4d38-b32f-103b13dc254f	Ksor Long Vũ	22/07/2008	Nam	Gia-rai		f	11C7				2026-03-23 13:58:36.538+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung, Xã Ia Dơk,  Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
610044a0-55d0-4590-8fc4-c0821bf8f328	Lương Thị Mỹ Duyên	17/11/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:38.022+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iatang, Ia Kla, Đức Cơ, Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
05a6f664-7c39-4008-8872-3470bb07b204	Nguyễn Ngọc Hưng	04/10/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:39.434+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
b905d8dc-5ca3-4db1-84e8-553ea8cb855b	Phạm Thảo Nguyên	08/11/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:40.908+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
a5983fb6-06da-4e98-99af-4568e92ecdc1	Lê Thị Thủy Tiên	30/03/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.291+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Chư Ty, Đức Cơ, Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
6e909183-d169-4fa4-adc6-0b0a1e8f0bfe	Rơ Mah H' Xuân	17/11/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:43.799+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
d7253c52-2efb-4b00-acb4-51edd46b02d4	Phạm Ngọc Khánh Băng	04/11/2009	Nữ	Kinh		f	11C10				2026-03-23 13:58:52.136+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
b6385120-f9f0-4c28-964e-6594b2aaabd5	Mai Hoàng Phi	10/07/2008	Nam	Kinh		f	11C10				2026-03-23 13:58:55.206+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
fa8124cb-5c38-4526-962d-42189be91762	Ngô Đức Hiếu	24/09/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.805+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4- Chư Ty- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
8afcb311-be53-432d-b167-5ec73c58615f	Nguyễn Khắc Tân	23/10/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:01.947+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7 - Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
69a061d8-edbd-4261-99d2-1960bea8ebcf	Vũ Diệu Thảo	26/09/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:08.108+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
8b99282b-51cf-411f-b377-20e10f3ae0f1	Kim Ngọc Long	16/09/2009	Nam	Kinh		t	11C12				2026-04-28 13:44:20.355+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
c3c9e8e3-bb7d-40c6-bafe-16c3640bf2b8	Huỳnh Thị Diễm My	18/01/2009	Nữ	Kinh		t	11C11	2024-12-28	033 6850730		2026-03-26 04:49:01.351+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 9- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
47fb78ed-d332-4e96-9a48-a3aa8213b383	Mã Thị Kim Tuyến	16/01/2009	Nữ	Kinh		t	11C11	2024-09-14	0392466042		2026-03-26 04:49:43.584+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn chư bồ 1-iadok- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
fbc232dd-112e-4d25-8f7a-0c93b4363ca7	Lê Văn Tiến	30/09/2009	Nam	Kinh		t	11C10				2026-03-27 01:06:23.242+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
c34ec979-147f-4a00-bbdd-8efb79f1efb2	Rơ Mah H' Hyưng	05/01/2009	Nữ	Gia-rai		t	11C10				2026-03-27 01:08:18.21+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
b07f85a6-eb20-4339-a3a5-04e33d119260	Siu Quyết	2009-07-30	Nam	Gia-rai		t	11C9				2026-03-28 10:43:56.812+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Làng Hrang - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
49b0089a-191d-4124-9549-e0b7b7dfebef	Ngô Phạm Thùy Linh	24/07/2009	Nữ	Kinh		t	11C9				2026-03-28 10:51:17.808+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng TrolĐeng - xã Đức Cơ - tỉnh Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
984ceeeb-c970-4243-9fc0-2143e88e7b62	Ngô Thị Thảo Nguyên	2009-08-19	Nữ	Kinh		f	11C7		0358280046		2026-03-28 22:56:40.488+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krel, Xã Ia krêl, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
fb3d6b03-d3ea-4641-b44f-5f866668e30b	Trần Đình Tú	09/03/2009	Nam	Kinh		t	11C9				2026-04-27 15:48:25.327+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Tang - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
ea629791-0320-4363-acb1-22828ee96f1f	Nguyễn Thị Ngọc Hân	2009-09-06	Nữ	Kinh		t	11C12				2026-04-28 13:43:49.443+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm Tôk, Xã Ia Krêl, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
0fba99ba-6789-43a8-98a2-474dbd8df77d	Trần Lê Ngọc Anh	23/06/2009	Nữ	Kinh		f	11C9				2026-03-23 13:58:43.938+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
a11b688f-7467-4cbc-8bf7-141d0bc9966c	Nguyễn Ngọc Hiếu	05/10/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:45.428+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
ebc991e9-0bfa-4008-ab41-89ac79626754	Phan Nguyễn Anh Tuấn	09/08/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:50.497+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
c8e5bcc6-dd6a-44ff-b008-249cb82a2dac	Siu Châm Khang	09/11/2008	Nam	Gia-rai		f	11C10				2026-03-23 13:58:53.896+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	06/01/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.354+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
4187fc2a-ecb1-4b47-8d0d-818f132cf4a9	Kpuih H' Tinh	07/02/2009	Nữ	Gia-rai		f	11C10				2026-03-23 13:58:57.262+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Trol Đeng, xã Đức Cơ, Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
fa15a5c0-2db3-4869-83bb-83eb8af8de4b	Rơ Mah A Thanh	12/10/2009	Nam	Gia-rai		f	11C11				2026-03-23 13:59:02.099+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng sung Le Tung- ladok - Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
4cc1238f-4257-4064-b012-90999b3d401c	Lê Quang Hiếu	09/04/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.074+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
9ab2b93a-25c6-4659-a188-a3fed4d2f066	Phạm Trần Anh Thư	29/10/2008	Nữ	Kinh		f	11C12				2026-03-23 13:59:08.276+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
abc80259-d940-46bf-b946-8ba67506e87b	Bùi Thị Tường Vy	2009-10-03	Nữ	Kinh		t	11C11	2025-09-14	0345685398		2026-03-26 02:23:59.102+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn chư bồ 1- Iadok-Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
afc32642-87a3-47f9-aeb9-7326c9f3102c	Trần Minh Hiếu	21/01/2009	Nam	Kinh		t	11C11	2025-01-09	0327889830		2026-03-26 04:51:04.888+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
05e00bfa-db20-47fe-8dda-3ea2194c8609	Đặng Bảo Nam	04/08/2009	Nam	Kinh		t	11C11	2025-01-09	0398869302		2026-03-26 04:52:35.461+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
5a90323c-b9bb-48a8-b3b8-2ca43c7fac7d	Lê Đình Dụng	17/03/2009	Nam	Kinh		t	11C10				2026-03-27 01:05:30.165+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng ấp, xã Ia Kriêng, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
81ae88f1-3c99-463a-bc92-fa5b3e23d5b9	Đỗ Thị Thanh Thảo	03/03/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:58.273+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
adaa5d5a-b1f1-4ed3-aba0-9676706dfa05	Ngô Thị Khánh Ly	14/06/2009	Nữ	Kinh		t	11C9				2026-03-28 10:46:34.268+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
9264b026-bf60-4f34-ac71-4e3173b9dc71	Nguyễn Thị Mỹ Duyên	2009-11-10	Nữ	Kinh		f	11C7		0868220435		2026-03-29 10:01:51.364+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 9, Chư Ty, Đức Cơ, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
0b91027f-3501-478b-8821-e889defd8904	Hồ Hữu Mạnh	29/10/2009	Nam	Kinh		t	11C12				2026-04-28 13:44:24.499+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
6b64130b-7240-4b2f-8c60-381babc8eb71	Kpuih H' Tuyết	07/04/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:50.684+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
deea0c5e-6693-438b-95fd-bed7773331bf	Nguyễn Thị Mai Linh	15/12/2009	Nữ	Kinh		f	11C10				2026-03-23 13:58:54.051+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
982edc30-d71e-45de-b860-2dbd2a26e4d7	Trịnh Quốc Quân	30/08/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.523+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
4df92eaf-43f5-466d-88de-474c7c111c39	Nguyễn Văn Nguyên Hoàng	20/04/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:59.145+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang- Đức Cơ - Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
a3b4c2d8-b70b-464a-8282-c77ad9e70605	Kpuih H' Ngát	10/08/2009	Nữ	Gia-rai		f	11C11				2026-03-23 13:59:00.714+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Xã Iakrieng- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
647de030-3be1-4f59-91f0-a9f19b993352	Phạm Khánh Hoà	01/08/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.226+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
87c87f73-e750-4c2d-b91c-e5f109ff2e33	Nguyễn Anh Thịnh	30/04/2009	Nam	Kinh		t	11C11	2024-01-09	0372442289		2026-03-26 04:53:55.204+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4 - Đức cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
542ca34b-93db-4a05-9cfd-688fd8266197	Mai Thị Huyền Trang	26/09/2009	Nữ	Kinh		t	11C10				2026-03-27 01:06:48.276+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức cơ, tỉnh Gia lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
51b84e02-5b81-4cf8-92c1-7cdd446a9f09	Nguyễn Trương Đắc Đạt	08/04/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:43.141+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Iamang, xã IaDơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
40724bd9-1c8a-4f9d-baa2-84e4803c01a6	Bùi Mai Hoa	18/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:46:47.019+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krêl - Ia Krêl - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
785bec33-d4d0-45d7-80a3-49b2a3859173	Trần Nguyễn Mai Anh	28/07/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:20.031+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
7fdc5e38-5773-4fed-b710-a7a855b0f31c	Lường Viết Thuận	23/08/2009	Nam	Kinh		t	11C9				2026-03-28 10:52:26.542+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Lệ Kim - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
c4757cd2-4478-4e0d-aa1a-f895dfd9f2ed	Phạm Ngô Hoàng Yến	2009-07-06	Nữ	Kinh		t	11C7	2024-04-21	0344307611		2026-03-29 10:03:56.863+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 6, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
46dee9e9-0e6e-4b90-ad43-9ff5c2237596	Rơ Lan H' Lysa	12/01/2009	Nữ	Gia-rai		t	11C9				2026-04-27 15:48:41.719+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Le Kắt - Xã Ia Dơk - Gia lai	61a554f0-87f5-4dbd-a152-22cebed82925
f0869dd8-0c61-4e2b-bad0-4dc402f477aa	Trần Thành An	09/12/2009	Nam	Kinh		t	11C12				2026-04-28 13:43:14.545+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Chia, Xã Ia Nan, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
df50fd43-81cd-47da-848b-28d2f7df861d	Kpă Mathê	17/04/2009	Nam	Gia-rai		t	11C12				2026-04-28 13:44:29.224+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
0c6b04b7-2a4c-4b08-978f-605588ed49f6	Trần Thị Anh Thư	29/10/2009	Nữ	Kinh		t	11C12				2026-04-28 13:45:16.093+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
1394f89b-1f75-4624-820e-a773b5d62a3c	Kiều Tuấn Sang	07/10/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.666+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	xã Ia Kriêng, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
8cdd1e55-2614-4e9a-ab36-09099d1b97e2	Nguyễn Tiến Vinh	11/11/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:57.584+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
b87c4788-bb06-46d6-a302-91d3ce976de9	Nguyễn Văn Lâm	18/11/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:59.303+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn chư bồ 1- Iakla- Đức cơ - Gia lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
d7466a45-637c-4355-ab6a-37037696e1c0	Hoàng Thị Thanh Thúy	18/09/2009	Nữ	Kinh		t	11C11				2026-03-26 02:18:27.992+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4 - Đức cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
11754698-c919-45eb-bc73-913ec4700980	Bạch Thị Bảo Ngọc	16/07/2008	Nữ	Kinh		t	11C11	2025-09-14			2026-03-26 02:23:37.625+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 9- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
c15ea371-e3c3-4007-9206-2f88c7d56b2f	Hoàng Nguyễn Bảo Long	09/10/2009	Nam	Kinh		t	11C10				2026-03-27 01:05:16.636+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
d8ba8902-effe-49f7-a926-085946260049	Tăng Văn Mạnh	08/01/2009	Nam	Kinh		f	11C9				2026-03-28 10:25:05.719+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Ia Lâm - xã Ia Krêl - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
edaafec7-1f49-4741-a4cb-cb17ea29e040	Lê Bảo Uyên	21/06/2009	Nữ	Kinh		t	11C9				2026-03-28 10:50:01.663+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 6 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
ec03b35f-dfed-47af-8caa-c62bdf5f0dbd	Nguyễn Anh Thư	18/08/2009	Nữ	Kinh		t	11C9				2026-03-28 10:52:56.302+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
9dccd05c-526f-4e43-98e1-c3d16bb8fd4e	Đoàn Thị Mỹ Lệ	2009-09-13	Nữ	Kinh		t	11C7	2023-11-20	0387058713		2026-03-28 22:51:11.562+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Chư bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
8f8a1a5d-692a-4243-9196-5f901d21b4d2	Trịnh Ngọc Khánh Trang	31/05/2009	Nữ	Kinh		t	11C7	2024-09-18	0345181657		2026-03-28 22:54:21.513+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
739a4ffa-2149-4054-9d38-8a564fc6728d	Siu H' Dịu	22/01/2009	Nữ	Gia-rai		t	11C12				2026-04-28 13:43:08.386+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
9a1c1fc5-be1f-47fb-86b8-6a48bdadf3df	Phan Công Hùng	10/03/2008	Nam	Kinh		t	11C12				2026-04-28 13:43:55.81+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
d0ad0ef5-3523-4ee8-98df-00c41cd69f16	Hồ Thúy Nga	21/11/2009	Nữ	Kinh		t	11C12				2026-04-28 13:44:35.827+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
80d0b73a-bb20-456b-81f8-a9e9ce236ae0	Trần Tố Uyên	28/06/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.931+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
b821ee27-a45a-4a67-a02c-acae88f78837	Rơ Mah H' Bdít	12/10/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:44.401+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pong - Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
cf35b19c-6a66-4cf1-a3ae-ff2ec40481f6	Phùng Chí Long	28/06/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:54.314+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
71767878-bb5f-43d2-a409-17a95f26ff39	Nguyễn Văn Sang	13/11/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.82+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
3b86ae24-61e0-46ed-a553-e48ba54b6e8d	Lê Đức Bảo	31/05/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:57.824+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Iatang- Iadok- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
f6d8265b-6a9e-4b84-b7da-8859f8db0866	KSOR H' LIA	06/04/2008	Nữ	Gia-rai		f	11C11				2026-03-23 13:58:59.466+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung - Iatuk - Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
71d89426-a1a2-49f4-881f-5c9898718bf9	Nguyễn Hoàng Gia Huy	18/07/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.517+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
ca26d313-1cc3-4afc-8b47-bcd94628bbd6	Lương Thị Yến Nhi	19/03/2009	Nữ	Kinh		t	11C11		038 4626009		2026-03-26 02:25:05.342+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
f1f7e40a-a5d6-47df-adc2-40fda1c32d13	Trần Hồ Anh Thư	09/10/2009	Nữ	Kinh		t	11C11	2024-01-09	0967874123		2026-03-26 04:53:13.609+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
4c229b52-6a6b-485c-ad5b-5a6ce5cfbbd2	Nguyễn Xuân Hà	22/01/2009	Nam	Kinh		t	11C10				2026-03-27 01:08:07.191+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
9fc0cea3-2187-460c-a070-2af5c87bac8a	Nguyễn Sỹ Hoàng	12/12/2009	Nam	Kinh		t	11C9				2026-03-28 10:46:20.833+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Tân - Ia Krêl - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
78c88923-615a-43aa-85ae-db9ce325b993	Hoàng Yến My	09/04/2009	Nữ	Kinh		t	11C9				2026-03-28 10:47:57.943+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1 - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
77337c4c-6f0c-47ef-8ddd-caf97c2a556a	Hoàng Ngọc Huyền Trang	28/06/2009	Nữ	Kinh		t	11C9				2026-03-28 10:48:29.209+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Ia Tang - xã Iadok - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
062e518f-b6ba-4bf5-b3ea-05cb92eb5b7e	Rơ Mah H' Uyên	28/11/2009	Nữ	Gia-rai		t	11C9				2026-03-28 10:51:33.271+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Tung - xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
8bc698e4-3e3e-4263-b581-4a35a5fa5f87	Nguyễn Đức Dương	24/10/2009	Nam	Kinh		t	11C12				2026-04-28 13:43:03.01+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
5b4cd120-6b29-4ec6-b695-c2ba6a4effac	Hoàng Bảo Ngân	11/07/2009	Nữ	Kinh		t	11C12				2026-04-28 13:44:41.186+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Kom Ngó, Xã Ia Chia, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
91817b2c-508b-4124-ae7e-1939a8301e87	Hồ Thị Thanh Vân	05/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:43.084+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
804d98d5-4bca-4973-bd31-a50df2d1244e	Mai Văn Tuấn Đạt	14/03/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:44.539+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 2 - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
a403da2f-c3e0-4ea9-9583-c051154fe4d2	Rơ Châm H' Hà	09/12/2009	Nữ	Gia-rai		f	11C10				2026-03-23 13:58:52.993+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Ia Kiêng, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
7b3b945b-4956-4eba-af49-d6af3cfce237	Dương Hữu Lộc	16/03/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:54.464+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
86563e05-62a2-4979-8fe7-e4989e11d977	Bùi Quang Dương	01/02/2008	Nam	Kinh		f	11C11				2026-03-23 13:58:57.991+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9- Chư Ty- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
57df4632-5181-4070-a25e-60e6211d5271	Phạm Lê Hoài Thương	08/11/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:02.728+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
3ee749f7-ac66-44d0-b8ff-8d06d989b4d1	Nguyễn Hồ Nhật Hưng	27/11/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.675+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Kăm, Xã Ia Krêl, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
30a8b007-0db3-4a1d-a56c-713af0dd6f6d	Phạm Nguyễn Hoàng Linh	12/05/2009	Nữ	Kinh		t	11C11				2026-03-26 02:19:33.108+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4-Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
5ab534b7-3bfe-4120-9e29-21fd96e046f7	Vũ Minh Phương	21/09/2009	Nữ	Kinh		t	11C11	2025-09-14	0375374792		2026-03-26 02:25:38.763+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2 - Iadok - Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
440b60d2-0be6-401a-9ca6-03787396db35	Nguyễn Văn Tài	06/10/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:53.02+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
a17a332e-eac6-4700-9172-8e34e6fe7e54	Hoàng Thị Cao Trang	24/05/2009	Nữ	Kinh		t	11C9				2026-03-28 10:44:32.887+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
45d3d5cb-d945-4183-89b4-475bf7cb698d	Lê Thị Trà My	15/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:48:56.18+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 4 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
78a4a0f0-0bc5-4e5b-8654-0c364f55f136	Cầm Thị Hường	19/03/2009	Nữ	Thái		t	11C9				2026-03-28 10:50:35.734+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krai - Xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
884638a5-4bc2-4aa2-a53e-568e101bea20	Phan Khanh Hoà Bình	2009-11-25	Nam	Kinh		t	11C7	2024-09-18	0328348334		2026-03-28 22:52:42.321+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Chư bồ 1, Ia Dơk, Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
e9596774-8bea-4462-855c-60d1e7edf0ae	Trương Đắc Dương	10/07/2009	Nam	Kinh		t	11C12				2026-04-28 13:42:49.303+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ Dân Phố 4, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
8b29cbc7-baf4-4f12-aa52-adce4774dcf3	Mai Thanh Nguyên	28/10/2009	Nam	Kinh		t	11C12				2026-04-28 13:44:45.183+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
e75b87f9-ee4b-41e3-a76f-b5c4227f3cf7	Nguyễn Thị Bích Vân	20/04/2009	Nữ	Thổ		f	11C8				2026-03-23 13:58:43.231+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
6441c4c8-e88a-4381-a3f0-e87afed358f8	R' Mah Hy-lia	14/02/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:46.175+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép - Xã Ia Dơk - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
096954c7-591e-49f4-afc1-6da9d7f1111b	Nguyễn Thế Thành Đại	17/06/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.171+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1- Chư Ty- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
2f26724f-0e53-4b43-82f9-ca2d6f87f06d	Đoàn Ngô Vũ Luân	04/10/2008	Nam	Kinh		f	11C11				2026-03-23 13:58:59.795+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng DơkKiah- Ia Dơk- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
76691235-4889-43c5-912f-22ec7dbfb5f3	Chu Thị Quỳnh	12/10/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:01.328+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
024fbd36-51e3-4530-8f16-f098b0134cac	Lê Thị Quỳnh Trang	29/08/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:02.885+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư BồI, Iadok, Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
dad8ab2d-e120-4784-9660-d77b801119d5	Đặng Quang Thành Đạt	29/07/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:04.345+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
d78a83dd-fcb3-4376-8aa0-bf1550182273	Trần Đăng Phong	23/09/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:07.414+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
b4581b56-01f7-4b0f-bb3a-f8a9cb75aa82	Nguyễn Quang Huy	25/07/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:08.753+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
50517434-db92-4415-86fe-330f5067431d	Nguyễn Trọng Tâm	05/04/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:34.741+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
fbc40e20-d8df-41ba-818e-6ce834dc3513	Rơ Mah Si Mô	30/11/2009	Nam	Gia-rai		t	11C10				2026-03-27 01:08:24.639+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung le , Ia Dơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
bdc39df0-476c-454d-b0df-36e5d9de613f	Nguyễn Lệ Trà My	13/11/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:32.481+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
ca916969-ebc4-4fab-bed2-ed8eaf8fd643	Trần Tiến Đạt	10/04/2009	Nam	Kinh		t	11C9				2026-03-28 10:48:43.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
572e1040-aa60-4ed3-a758-7fa16940426a	Trần Thị Kiều Vy	22/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:29.769+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 2 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
ef02ad98-049b-4fb9-990c-688ee9079dba	Lương Thị Đoan Trang	13/01/2009	Nữ	Mường		t	11C9				2026-03-28 10:50:47.505+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krai - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
8d1f498c-6f11-44e1-a2bb-536451ff7314	Nguyễn Thị Kim Tuyết	2009-06-17	Nữ	Kinh		f	11C7		0349738669		2026-03-29 10:04:44.06+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Đo, Xã Iadơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
2d4aa584-fd50-472b-828e-986a7abf9992	Vũ Nguyễn An Khang	07/01/2009	Nam	Kinh		t	11C12				2026-04-28 13:44:02.507+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ Dân Phố 2, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
dc34afe3-54e8-469f-b3ea-2c3790902765	Nguyễn Quang Huy	06/08/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.821+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaTang - Xã Ia Dơk - Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
ccaa6f72-343e-44b5-bd9d-d30c468203e0	Lê Nguyễn Trà My	16/08/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:33.285+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
7f2e57dc-7262-4a88-97a2-91fdbbe9802e	Nguyễn Ngọc Thông	06/01/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:34.742+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn chư bồ 2, xã Ia Dơk, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
7adf467d-f80a-417b-ae47-4da667a4b6ce	Ksor H' Vệ	08/07/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:36.232+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp, Xã Iakrêl, Tỉnh Gia Lai	0c673b7d-6199-4fbd-b3ce-5a11324113b6
73362900-3a34-43be-ae47-1d7413bb629d	Trần Thị Khánh Chi	05/08/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:37.713+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
9fe0bc0c-5be7-4eeb-8f79-76eca2c9500c	Nguyễn Trung Hiếu	06/01/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:39.159+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
2c1151ec-2d2b-4fb4-988b-669c1b344ad8	LÊ THỊ MỸ	26/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.049+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
8b42bf9e-4c68-4abd-a688-fe765316507d	Rơ Mah H' Ngâm	18/09/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:40.61+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
eb0cc01b-e7f7-488f-99a6-2c640cafc2b7	Trương Thị Hoài Thương	10/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.006+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
7f6eef3a-6a8d-4244-9fe3-e833a19a2717	Lê Thảo Vy	11/10/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:43.498+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
bf28accd-a226-49f7-8715-c05bf8857353	Đậu Quang Thỏa Hiệp	13/03/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.495+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm tốc- Iakrel- - Gia lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
82a6c205-d925-48d9-9f98-f0559b639f9a	Nguyễn Văn Mạnh	17/12/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:00.105+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
6f1665b3-349a-4e60-85d1-8e41e32cbde6	Kpuih Sen	26/10/2009	Nam	Gia-rai		f	11C11				2026-03-23 13:59:01.64+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung- Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
e43db322-3873-41ee-84ba-07ec32e28940	Lê Thị Huyền Trân	03/04/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:03.178+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Đức Cơ- Gia Lai	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
215b997d-a041-4264-b99a-67fa8f07e662	Mai Văn Hoàng	2008-01-23	Nam	Kinh		t	12B1	2023-03-26	0375346667		2026-03-26 13:06:52.756+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
9f2c6377-386b-4248-814f-518974076d1b	Nguyễn Trịnh Gia Bảo	2008-08-26	Nam	Kinh		t	12B1	2024-04-22	0869899621		2026-03-26 04:59:51.107+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
0c67a6e3-c8bd-4934-99e4-5231462c9c90	Hà Minh Đức	2008-11-13	Nam	Tày		t	12B1	2026-01-18	0373462577		2026-03-26 04:58:46.706+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
b4f44e9e-af2d-44a3-a90e-825fca1e5e34	Nguyễn Đức Hoàng	2008-05-04	Nam	Kinh		t	12B1	2025-04-24	0349315963		2026-03-26 04:59:04.059+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 3 -Xã Đức Cơ -Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
12b5bcba-e952-494f-8743-f52dec7d161d	Nguyễn Ngọc Giáng Hương	2008-01-04	Nữ	Kinh		t	12B1	2023-09-20	0377295803		2026-03-26 04:59:22.275+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1- Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
d49220f5-b7d2-4a99-97fd-091184a01be8	Dương Minh Đức	2008-07-08	Nam	Kinh		t	12B1	2025-01-09	0865646339		2026-03-26 13:02:28.643+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
ebeaa4c4-bead-4ea0-b118-30ea7426095d	Nguyễn Thị Diệu Linh	2008-05-17	Nữ	Kinh		t	12B1	2023-09-20	0328875445		2026-03-26 04:59:37.979+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krêl - Xã Ia Krêl - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
dd3c804e-75b9-4814-8477-17fc4910e3f9	Lê Đức Giang	2008-09-02	Nam	Kinh		t	12B1	2025-01-09	0398171374		2026-03-26 04:58:56.357+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 7 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
b2bf647e-c742-4a0f-8ac7-1c5e501b59ff	Nguyễn Hoàng Anh	2008-03-06	Nam	Kinh		t	12B1	2023-03-26	0366927743		2026-03-26 04:59:12.674+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
220853d7-7555-4da8-8e86-5481c2a416bf	Cao Thị Thanh Mai	2008-03-13	Nữ	Kinh		t	12B1	2023-03-26	0328444459		2026-03-26 04:58:30.546+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
aa10a0dc-63f2-4c16-ad54-15bf93e68121	Nguyễn Quang Huy	2008-06-20	Nam	Kinh		t	12B1	2025-04-24	0396036852		2026-03-26 04:59:31.362+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
2e4bdf78-f62b-4914-b197-d343c6df748e	Phạm Ngọc Gia Hân	2008-10-12	Nữ	Kinh		t	12B1	2023-09-20	0983029959		2026-03-26 13:04:28.354+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
faffb8ff-2084-4fc2-a189-0a15a0e0c058	Đoàn Trần Anh Thư	15/04/2009	Nữ	Kinh		t	11C10				2026-03-27 01:05:04.842+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
c7853e57-adac-4fec-a22e-8a00a083cbb3	Đỗ Đình Mạnh	2008-01-26	Nam	Kinh		t	12B1	2023-03-26	0348607726		2026-03-26 13:09:56.461+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
e37126c7-6438-4097-8af1-734fce2c0ca1	Nguyễn Vũ Đức Minh	2008-03-15	Nam	Kinh		t	12B1	2023-03-26	0373807315		2026-03-26 13:11:15.691+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
82165843-b5cc-426b-b143-236a811566b9	Nguyễn Ngọc An	2008-04-01	Nữ	Kinh		t	12B1	2025-01-09	0333855032		2026-03-26 14:33:10.51+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
755ab2a2-f1f8-4761-b4a3-59b7d69c4079	Lê Thị Bích Ngọc	12/09/2009	Nữ	Kinh		t	11C10				2026-03-27 01:05:38.158+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
e3c26229-9eaa-4eae-8ac4-39574857d2ac	Lê Thị Lan Hương	03/12/2008	Nữ	Kinh		t	11C10				2026-03-27 01:06:02.221+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
6f549b5d-6d68-482d-94b5-e89086362d0d	Nguyễn Thị Thanh Ngân	17/04/2009	Nữ	Kinh		t	11C9				2026-03-28 10:44:58.877+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 4 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
d1878cd5-5c6d-4064-86e0-be443e1dc5d6	Nguyễn Thị Yến	22/09/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:48.099+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7- xã Đức Cơ - Tỉnh Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
1e66add3-6f72-40f0-a236-822cda2dbc5d	Trần Thị Ngọc Lan	30/08/2009	Nữ	Kinh		t	11C9				2026-03-28 10:46:59.48+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
7fd6e40a-54b1-4ec7-bb33-a767d8265667	Lê Duy Đức	13/12/2009	Nam	Kinh		t	11C9				2026-03-28 10:47:11.859+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
83a8d7e0-c42b-4dae-8ee9-c31b12a27ab8	Nguyễn Thị Quỳnh Trang	19/05/2009	Nữ	Kinh		t	11C9				2026-03-28 10:52:12.406+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - xã Đức Cơ - Gia Lai	61a554f0-87f5-4dbd-a152-22cebed82925
1130623a-825a-4f51-8b26-0a627a6740cc	Nguyễn Trần Gia Huy	2008-06-22	Nam	Kinh		t	12B1	2026-01-18	0973227717		2026-03-30 14:09:24.211+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 3 - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
bb030ea0-1fa1-4c3c-8a27-1e3830ae550e	Doãn Thị Hồng Hạnh	20/05/2009	Nữ	Kinh		t	11C12				2026-04-28 13:43:34.921+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
8b922185-4fc3-4026-ac3e-1bcfb8cff236	Nguyễn Phùng Khánh	09/02/2009	Nam	Kinh		t	11C12				2026-04-28 13:44:14.883+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
13f76236-96ab-41d0-ac24-8bf2d814bbba	Đoàn Ngọc Nam Phương	27/12/2009	Nữ	Kinh		t	11C12				2026-04-28 13:44:55.224+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
cefade75-ab69-48c4-8e90-b8512369c4ef	Kpuih H' Thứ	26/09/2009	Nữ	Gia-rai		t	11C12				2026-04-28 13:45:04.973+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Trol Đeng, Xã Đức Cơ, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
77afc10e-f33f-4e28-8dad-3566bc4b63f6	Kpuih Trần	18/12/2009	Nữ	Gia-rai		t	11C12				2026-04-28 13:45:20.234+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai	450ff56c-ab21-4927-a712-9e9e155646b7
98812f85-c454-4c4b-90c6-856350ceb915	Lê Đình Nam Anh	23/07/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:21.217+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
48611046-f7e9-48ae-bc0a-cba8d32102b5	Hồ Văn Đức	08/06/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.769+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
cb57f506-3593-4196-8f3b-b138b29839d1	Nguyễn Thị Bảo Ly	27/06/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.309+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
bfb5b809-bb5f-422d-8852-3945e84e1948	Nguyễn Thị Anh Thư	25/02/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.802+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
6e8d79bd-912b-4be6-b6a6-4541e98eb616	Đỗ Võ Tuấn Anh	17/08/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:27.46+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
1513bbe3-61b1-424a-84a7-2f7485dbf0c3	Hồ Thái Dương	20/12/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.929+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
db06f205-cf40-4c9b-b80b-72cac448dc58	Trần An Lợi	14/10/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:30.443+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
9cccfa10-98e8-4e96-8aaf-040692de5b5e	Lê Thị Mai Phương	25/10/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.949+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
c16d2489-e91d-4f21-b656-5fe7b2889ddc	Phan Hoàn Vũ	26/07/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:33.489+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
6ee012f0-a2c0-4515-877a-288e91ba25b7	Lê Văn Phụng	26/06/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:07.026+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Chư bồ II - Ia Dơk - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
7b34c619-c863-4656-8446-b2482cd18b06	Lương Quốc Chiến Dương	25/02/2008	Nam	Tày		f	12B5				2026-03-23 14:00:34.971+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
4d000028-a3f2-40d7-99f3-dee2ea576edb	Đỗ Thị Tuyết Ngân	23/02/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.438+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm - xã Ia Krêl - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
e9bfb6e7-d97b-4a59-9385-b8f9b666bf7b	Trần Ngọc Quốc	19/06/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.973+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thanh Giáo - Iakrêl - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
43da93a4-e591-46e9-95a6-da05ac356c8b	Lê Thị Ngọc Trang	09/04/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.43+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
cd03fd6f-ef16-4fc9-b9f7-09bd0aab3712	Ksor H' Uyên	21/10/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:40.908+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Le Tung - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
0790f0fa-9841-4576-a8e2-296ed742c09c	LÊ THỊ ÁNH ĐỨC	18/08/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:42.394+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Tang - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
1c2454f6-60e7-4170-b9aa-17681999ea9e	NGUYỄN THỊ KHÁNH HUYỀN	09/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:43.982+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Lâm Tốk - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
daedc3c8-03de-4774-b82a-1a706032e2e0	PUIH H' NHE	12/02/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:45.499+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
ca743bb2-01cc-4408-9efd-218c5de5075e	NGUYỄN THỊ DIỆU THẢO	01/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.067+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
0b5bbf91-ab2f-46ab-8421-0d9387503c27	PHAN ANH TÚ	10/06/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:48.731+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
7e6d804b-4bb7-4790-becd-6146d8d46a07	Lê Đại Đồng	15/03/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.861+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân - Xã Ia Krêl  - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
4279c481-4639-4c4c-83d0-73e077471151	Nguyễn Hà Thảo My	10/05/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.431+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
4fabd4c6-0367-4e37-9683-55ec3900641f	Trần Thị Thảo	05/12/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.001+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
c286c4bc-ce2b-4176-9a80-7ca0a3c9223b	Thái Hoàng Mỹ Uyên	20/04/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:02.51+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm - Ia Krêl  - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
522e7e6c-82c8-4dd3-9c0f-bbd2bbb7c1ae	Nguyễn Văn Cường	26/10/2007	Nam	Kinh		f	12B9				2026-03-23 14:01:04.102+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Dơk Klăh, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
6689140b-b1e4-46d9-ab08-d7000ebd45e3	Rơ Châm Trung Nguyên	07/03/2008	Nam	Gia-rai		f	12B10				2026-03-23 14:01:13.304+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Bi - Xã Ia Dom - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
a5c3f1ee-2de2-4365-a10e-629586ceddab	Mai Văn Sơn	07/08/2008	Nam	Kinh		t	12B9				2026-03-26 02:06:56.413+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
da4048d5-7dad-483f-b278-a94dc4f2aac0	Nguyễn Lê Diệu Linh	06/03/2008	Nữ	Kinh		t	12B9				2026-03-26 02:07:17.931+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP1, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
f92c3902-dc44-44f0-8182-c75102267f4c	Thái Tú Trinh	30/08/2008	Nữ	Kinh		t	12B9				2026-03-26 02:13:47.396+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Tiên Sơn 1, xã Biển Hồ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
fc1adb1e-9636-4103-beaf-ffab98331be7	Nguyễn Thị Bích Ngọc	2008-02-27	Nữ	Kinh		t	12B1	2023-03-26	0362367022		2026-03-26 02:28:11.872+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Hrang - Xã Đức Cơ -Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
a8bd55a6-6031-4549-b670-3e93fc6ba7df	Nguyễn Thị Minh Uyên	2008-08-22	Nữ	Kinh		t	12B1	2023-01-09	0355425605		2026-03-26 04:59:42.835+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 1 -Xã Đức Cơ -Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
4408c016-3444-47a3-86bd-2b36da2d3bb4	Lê Thái Châu	22/01/2008	Nam	Kinh		t	12B10				2026-04-04 09:53:56.258+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
df653b68-26f9-44fe-a521-9df394182282	Hồ Thị Bảo Phúc	2008-01-29	Nữ	Kinh		t	12B1	2023-03-26	0386701578		2026-03-26 04:58:50.167+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
7def4cfc-11ef-4778-a941-99d5a5000b60	Nguyễn Công Hiếu	31/01/2008	Nam	Kinh		t	12B10				2026-04-04 09:55:12.432+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mang, Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
3402f21d-9054-4f8e-a0f0-c984c05a272c	Nguyễn Thị Cẩm Tú	12/05/2008	Nữ	Kinh		t	12B10				2026-04-04 09:56:30.707+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
db5368db-f848-4390-966d-09d1e07c620e	Phan Tấn Đức	16/05/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:02.926+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
1162ee66-aafb-4640-a4b9-38cda1c4f05b	Phan Văn Long	11/11/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:59.173+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
2cf32bf0-41e5-4fc1-a714-a4a303999133	Lê Thị Xuân Thu	01/01/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:40.278+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
77033a63-6963-49f8-8036-a3cba878d51e	Vũ Thu Ly	25/05/2008	Nữ	Kinh		t	12B7				2026-04-25 11:22:11.904+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
c0c99a07-9b7d-431f-89cb-dbb7b2f59422	Lê Thị Hoài	03/06/2008	Nữ	Kinh		t	12B7				2026-04-25 11:22:38.966+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
73afdc9f-a846-41ce-be40-3dce2aadfec3	Rơ Mah H' Vân	19/12/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:25:34.801+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Le - xã Ia Dơk - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
48936d5b-c1f2-4e21-8a06-c95435d1d2e4	Phạm Thị Thùy Dung	26/02/2008	Nữ	Kinh		t	12B7				2026-04-25 11:43:46.621+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 6-xã Đức Cơ-Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
f7c69ce2-07ac-4435-828a-477e445c053b	Nguyễn Thị Hồng Phương	14/02/2008	Nữ	Kinh		t	12B7				2026-04-25 11:44:08.068+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Lâm Tôk- Xã Ia Dơk -Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
8cdbe5ad-9a05-4f45-ab11-fa6f756d0674	Lý Trâm Anh	31/10/2008	Nữ	Nùng		f	12B3				2026-03-23 14:00:21.371+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
d5a18a60-4b57-4281-adc6-8ba9b19f93df	Vũ Thị Thanh Giang	08/01/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:22.921+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
8479210f-ce52-42bc-8103-6e46bf731af8	Nguyễn Nhật Minh	16/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:24.476+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
bf8ff2b8-31d1-4e45-88e4-2c5a5b64956e	Trần Minh Thư	16/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.952+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
192d9aca-7cc0-452b-bc42-d0869d581e2d	Phan Thị Ngọc Anh	29/08/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:27.614+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
3ecd7eb2-5d77-4827-91b5-6f39e70bd506	Hà Ngọc Hạnh	30/04/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.067+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2 , xã IaDơk, tỉnh Gia Lai 	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
18863ceb-a1e9-4b21-a213-31ce35339b2e	Phan Vũ Thành Luân	25/08/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:30.584+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
44d2bae7-5b4a-4fe6-b491-79e549cf05d2	Nguyễn Thị Phương	05/09/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:32.101+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
6a2299e5-9ef8-4ee6-8713-1200cfb1d8f0	Đinh Hoàng Anh	14/10/2008	Nam	Mường		f	12B5				2026-03-23 14:00:33.625+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Mang - Ia Dơk - Gia Lai (cũ)	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
fd88f4bf-194e-4c8b-8906-27fda8e6a296	Lê Viết Đạt	04/03/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:35.125+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl - Ia Krêl  - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
5806caa7-2c91-4a3c-b74c-b1c4a2bffd30	Nguyễn Thị Hồng Ngọc	01/12/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.581+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ II - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
4cab72c9-4483-4684-bc1f-2c82b76c7c21	Kpuih H' Si	20/01/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:38.12+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang  - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
f0ec2d32-f776-4c86-b344-30ee8fe4cda3	Phạm Thị Huyền Trang	25/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.577+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1  - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
d37ac663-6905-40e6-8186-b266cb357352	Nguyễn Thị Hải Yến	13/04/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:41.064+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thanh Tân - Ia Krêl - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
1de55e42-2ff6-4087-b2bb-45a3e4ce3038	LÊ NGỌC KIÊN	27/09/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:44.135+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 2 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
30fb2c2d-22d3-418f-b3de-3ebe95879912	KSOR THEO	01/01/2008	Nam	Gia-rai		f	12B6				2026-03-23 14:00:47.21+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
a15ee922-af29-4364-92d0-eb3084501371	RƠ LAN H' TUỆ	27/11/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:48.88+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
dde005b5-13a8-4642-a2a6-2194f5641fb2	Nguyễn Hoàng Gia	18/12/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.002+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
d7d3766f-b453-44ff-af8d-0da223e683e2	Trương Thị Thu Na	09/04/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.611+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
2f1e630f-cc24-419e-8ee4-c492dc1875d6	Đặng Nguyễn Thu Thủy	11/02/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.143+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
87acdd03-fa06-4223-bb18-ce9fdd75666c	Nguyễn Trương Anh Vũ	12/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:02.668+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Mang - Ia Dơk  - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
7994dab9-614a-4f9d-ae27-c76996ac0a34	Rơ Mah Dấu	14/11/2008	Nam	Gia-rai		f	12B9				2026-03-23 14:01:04.265+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
a109f481-e19a-4375-a321-897acf8974c7	Rơ Mah Luy	29/04/2008	Nam	Gia-rai		f	12B9				2026-03-23 14:01:05.836+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Hrang, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
ce788c35-70e4-4230-8da8-8fc188eb3a7c	Trương Minh Vũ	11/11/2007	Nam	Kinh		f	12B9				2026-03-23 14:01:08.916+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
64228e3d-77ee-47b3-b225-d475560864ee	Kpuih H' Nhàn	31/01/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:13.45+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
f9902433-6495-41d8-b4e6-6be2f07062a8	Hoàng Thị Diệu My	02/09/2008	Nữ	Kinh		t	12B7				2026-03-26 02:04:48.808+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Đường Tăng Bạt Hổ, Tổ dân phố 9,  Đức Cơ, Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
dcf6f56c-49ce-4852-a8ff-94e848e5cc0d	Bùi Đức Tài	13/01/2007	Nam	Kinh		t	12B9				2026-03-26 02:04:50.462+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		TDP 7 - xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
987dac80-3d3a-493c-9316-f7cf064d5363	ĐẶNG THỊ YẾN NHI	18/06/2008	Nữ	Kinh		t	12B6				2026-03-26 02:05:15.813+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
5b559020-fc99-4e84-8e60-d0e432084ef2	Nguyễn Thành Nhân	2008-01-22	Nam	Kinh		t	12B1	2025-01-09	0383800177		2026-03-26 02:16:22.572+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Le Tung - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
ed25adb1-556f-4a7c-a8b6-a19e543664c5	Nguyễn Công Chiến	15/09/2006	Nam	Kinh		t	12B10				2026-04-04 09:53:59.871+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
d14d7465-8213-4acb-97e8-f174ee4d6cd0	Nguyễn Lê Vy	2008-02-14	Nữ	Kinh		t	12B1	2026-01-18	0356918059		2026-03-26 04:59:17.365+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Mook Trang - Xã Ia Dom - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
6b0c00d6-e5f1-4a77-a1c3-a169f6043204	Đoàn Anh Quân	2008-10-26	Nam	Kinh		t	12B1	2026-01-18	0867942248		2026-03-26 04:58:41.443+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn Kết - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
0593006d-35bf-4ac3-9049-c3fb0a595a7e	Nguyễn Huy Hoàng	21/11/2008	Nam	Kinh		t	12B10				2026-04-04 09:55:16.686+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
53d5a892-dace-4c6f-baee-9499138a16e4	Hồ Đức Việt	23/01/2008	Nam	Kinh		t	12B10				2026-04-04 09:56:34.512+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
fac1df30-2515-4311-85d4-f962126e8ba8	Trần Thị Bích Hằng	13/07/2008	Nữ	Kinh		t	12B2				2026-04-05 09:04:06.521+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
1c80abd0-67a7-4386-bf28-791613746a58	Lê Thị Mai	02/05/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:02.464+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
e6251d75-2242-44ea-bd1a-4771504c50be	Đoàn Anh Thư	02/10/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:44.195+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	THÔN ĐOÀN KẾT, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
3024cd81-df29-42f1-915b-cc03f2fef35c	TRẦN LÊ THU HÀ	19/12/2008	Nữ	Kinh		t	12B6	2026-04-09			2026-04-08 15:34:20.005+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Đoàn Kết - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
03337fd9-bcc7-45bc-9b67-840253859c76	Nguyễn Thị Ngọc Phượng	04/05/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:21:54.44+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
2cf34699-c8d1-4f84-b7bc-46bf86555ddc	Phạm Đình Hùng	02/02/2008	Nam	Kinh		t	12B7				2026-04-25 11:22:34.84+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4, xã Đức Cơ, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
14d2fda5-8218-4fa5-9efd-7d3e22b2a2e8	Nguyễn Sỹ Dũng	07/01/2008	Nam	Kinh		t	12B7				2026-04-25 11:26:58.533+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6 - Đức Cơ- Tỉnh Gia lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
a6931248-5e04-487f-8d2e-6bdcf0ec7270	Rơ Mah H' Vị	17/06/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:43:26.809+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Kép - xã Ia Dơk- Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
7ff4fd75-482d-4ecd-a3c2-21f399e2c004	Nguyễn Hà Anh	22/12/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:21.523+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
eb1f7847-bc4f-4b44-bead-4951b9cf81a8	Lê Nguyễn Hồng Hà	09/06/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:23.073+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
8dfbb737-86fa-49c4-8333-05c79204cafc	Lê Diệu My	21/08/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.645+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
5fd16c23-5628-44ca-b810-32642cc1c344	Đoàn Huỳnh Mạnh Tiến	05/07/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:26.113+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
bf20e7ab-141c-40a3-ac0d-fd72052e7a6e	Phan Tùng Anh	12/03/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:27.739+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
975edefc-c756-497d-bad7-f70ccaf2aa8b	Lê Thị Thu Hiền	29/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.216+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
3b716902-7062-4b3c-82cb-69c0f4e6cf0b	Trần Hải Ly	03/11/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:30.723+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
5f92d89d-48cd-4088-8d05-b9d393a1ed5e	Trần Minh Quang	01/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.266+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
c19553fc-9cbd-44b3-82df-9dde159122eb	Hoàng Việt Anh	10/07/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:33.757+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Đức Cơ- Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
2c8a6736-8d59-439e-8f20-0ea17a854734	Mạc Phạm Hải Đăng	11/09/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:35.268+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
6e16ff30-e7b1-4ea8-9198-d9f4d44fb341	Tào Trần Bảo Ngọc	26/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.729+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 - Đức cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
e81697e9-1ced-4536-a43b-b069f9fa8e26	Kpuih H' Soa	08/06/2007	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:38.248+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Bua - Ia Pnôn  -Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
fd8d05db-40d4-4d6d-ab3b-bd794eadc10b	Rơ Lan H' Thuỳ Trang	01/11/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:39.736+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
9d5662d0-023f-425c-b675-d6f5b7976c85	KSOR H' HOÀNG ANH	10/07/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:41.213+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Kép - Xã Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
ddfafa59-9703-44e4-ac1d-117c9aa726c5	KPUIH H' HAO	21/04/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:42.692+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
3aee2c4d-fd4f-4502-8f46-c7893b247764	LÊ THỊ THÙY LINH	18/03/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:44.28+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
c532cc21-8885-43e9-b82c-73868b1a0f70	TRẦN BẢO NHI	28/12/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.787+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
b92386ce-aa6d-4aa2-867f-b2a4671c8481	QUÁCH ĐỨC THỊNH	08/06/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:47.365+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krol - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
8f44da22-e44c-4fbe-9eac-f3f7b1591398	SIU VIÊN	06/04/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:49.028+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
49c12e12-98aa-4395-b653-78244d03bae9	Rơ Mah H' Hà	04/10/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:00:58.143+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Kắt - Xã Iadơk- Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
ef558d67-138f-4993-a951-88629b9b44a3	Hồ Thị Thúy Nga	04/09/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.81+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
6790af23-60bd-4ac9-910e-15309dac06cf	Hồ Ngọc Anh Thư	04/11/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.309+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
17c0731b-2f8b-4f2b-95e6-873e94a4dca0	Lê Nguyễn Thảo Vy	21/02/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:02.842+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang - Xã IaDơk- Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
93c82600-6d32-4e2c-a86f-772e943d1507	Hoàng Thị Mai	04/05/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:05.991+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
53b01c4f-b7a6-41f5-b6c2-123c90766d78	Nguyễn Thị Hải Yến	06/04/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:09.062+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
5711d9f1-d232-44ac-aff2-50383fba2ff2	Ksor H' Diệp	24/06/2008	Nữ	Gia-rai		t	12B9				2026-03-26 02:06:13.812+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Kép, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
8ed1bcf2-3916-4f3f-89cf-cf7316df8988	Ngô Đức Sỹ	2008-12-03	Nam	Kinh		t	12B1	2024-01-14	0862246494		2026-03-26 02:35:15.227+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
a12f298d-0116-4768-adbf-796de7a08268	Trần Đức Tài	13/09/2008	Nam	Kinh		f	12B9				2026-03-26 02:13:40.19+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6 - xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
c471def1-7bf4-4b0b-b068-d11bac427a8a	Trần Thị Chính	26/01/2008	Nữ	Kinh		t	12B10				2026-04-04 09:54:03.856+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
98e83d70-42cb-4cbc-baab-e1410533b772	Bùi Thị Tú Nhi	2008-05-09	Nữ	Kinh		t	12B1	2023-01-09	0385397067		2026-03-26 04:58:21.14+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
db9db073-6740-49e4-9061-2446cc87cf2d	Nguyễn Ngọc Hùng	17/12/2008	Nam	Kinh		t	12B10				2026-04-04 09:55:21.03+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
631b6641-095f-45fc-b682-5ce9a577f739	Văn Đức Hoàng Phúc	30/09/2008	Nam	Kinh		t	12B10				2026-04-04 09:56:00.979+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
f53b1209-34b8-4de1-b5f6-c6d905f64385	Nguyễn Quốc Việt	20/12/2008	Nam	Kinh		t	12B10				2026-04-04 09:56:39.792+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
d334fa93-aa99-46c1-a4e7-db9e9ec4c31c	Lê Quang An	11/12/2008	Nam	Kinh		t	12B2				2026-04-05 09:03:11.558+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
b03bffec-b32e-4490-bbc3-2d1e6eb75d68	Phạm Tuấn Hoàng	20/01/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:09.865+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
f94f4b6e-b430-4e56-aa7c-c3f53c51f81a	Cao Thị Trà My	14/08/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:05.591+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
8650a090-c27c-4be3-9929-7d9edfe84616	Nguyễn Bùi Anh Thư	28/11/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:47.356+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
f47a78a5-8b86-4dff-95e3-63ef9f74c0a3	Hà Thị Lan Hương	25/08/2008	Nữ	Thái		t	12B7				2026-04-25 11:24:28.112+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krái, Xã Đức Cơ, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
778bf6eb-03c9-45b8-8365-26256af0d735	Nguyễn Thị Duyên	31/07/2008	Nữ	Kinh		t	12B7				2026-04-25 11:26:29.94+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7 - Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
1302ed8d-8cb3-4202-8962-336ce5a35d88	Hồ Hoài Ngân	02/04/2008	Nữ	Kinh		t	12B7				2026-04-25 11:34:24.898+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ II - Ia Dơk - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
96840637-b85e-4eba-a0b2-ee53083d34f9	Nguyễn Mạnh Quân	28/10/2008	Nam	Kinh		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 – Đức Cơ – Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
660e4094-17b4-4e26-adac-b064767c0ac4	Nguyễn Ngọc Vũ	25/04/2008	Nam	Kinh		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9- Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
f6b604a1-b109-4a9f-8610-113d45fdab83	Trần Gia Bảo	28/02/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:21.672+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
a186e1c4-d046-4ec8-81b1-bc22cda32a23	Nguyễn Gia Hân	01/02/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:23.211+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
95373280-be3e-4d27-8e64-61eab1cdaa54	Lê Võ Thanh Nguyên	20/08/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:24.779+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
b60b7002-9d44-4145-9a43-4bb1981f5002	Phạm Thị Huyền Trang	16/09/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.263+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
a0dd3f66-abc9-4caf-be52-97a40ed286da	Hoàng Thị Kim Ánh	01/02/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:27.875+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
71812587-ca41-4e53-81b0-cc6c1af73e2b	Vương Thị Hiền	28/06/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.37+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
465bddef-b56e-46fb-a631-9a1357a735f6	Đàm Cảnh Minh	07/04/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:30.876+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
b10235d9-5e80-4398-b9c9-a45805b0425e	Trần Khánh Quân	05/10/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.42+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
c7d01113-e171-43ad-9c83-bf8e46d3e120	Lê Công Ngọc Anh	25/06/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:33.904+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - Đức Cơ  - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
5febe599-3eb1-472c-9758-679337c56d14	Trần Thị Vân Giang	23/08/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:35.408+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
df3d058a-ae56-4685-aa21-e1eb8e89a388	Trần Thị Thanh Nhàn	15/02/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.876+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Tang - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
1904fab1-ef63-4218-81b6-481d02a11853	Hồ Thanh Thanh	18/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:38.396+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 -  Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
7589e41e-000a-4c46-ad9e-231f5e6015cf	PHẠM THỊ VÂN ANH	14/04/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:41.35+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Lâm Tôk - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
fe908b0e-06b5-4bb9-8545-4712bc17cc94	NGUYỄN HÀO	04/07/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:42.841+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
b7243717-ec9c-45d0-bab3-9e53be60449a	NGUYỄN THỊ PHƯƠNG LINH	17/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:44.437+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Đoàn Kết - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
68e5e9b0-7386-4e4c-8693-e4b15fd31c4c	TRƯƠNG THỊ HỒNG NHUNG	01/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.947+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Tang - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
863a4692-6fcb-4181-bd84-40115904e3b5	NGUYỄN THỊ BÍCH THỦY	02/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.525+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
0d12676f-06e1-41a6-8496-55d4f5a1d418	Nguyễn Thu Hiền	22/07/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:58.298+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2 -Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
cf5e3e39-f305-4365-b972-811829ec9fff	Kpuih Ngân	17/03/2008	Nam	Gia-rai		f	12B8				2026-03-23 14:00:59.971+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Ngol - Ia Dơk  - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
7c9f12d7-d8a9-4890-9da6-0bf91b9bfe56	Nguyễn Xuân Tiến	04/05/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:01.469+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
bc7bfc36-6049-4e79-929e-300430e2ce06	Rơ Mah H' Yumi	20/11/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:01:03.013+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Le Kăt - Xã IaDơk- Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
9f6d8ea1-ea7a-4470-88fe-012bd8189b07	Phạm Khánh Duy	30/12/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:04.589+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP2 - xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
ea95d4a1-6792-44c8-9a45-07f974dd2bfd	Trương Anh Ngọc	09/04/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:06.144+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
953fbdbe-e072-4ed0-8527-2ab3b881ea57	Trần Thị Hải Yến	09/03/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:09.212+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
a746ab31-0add-4e6f-909f-2224882ebff2	Đinh Thái Nghĩa	28/12/2008	Nam	Kinh		t	12B7				2026-03-26 02:04:39.906+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Tổ dân phố 1 -  Đức Cơ - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
0fdc65a7-703d-465c-a13f-ec517f30940a	Lê Tiến Công	2008-05-12	Nam	Kinh		t	12B10				2026-03-26 02:05:10.696+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
2599fe3a-9d72-4c77-a6bb-a98f38fd0d41	Đinh Thị Yến Nhi	2008-04-22	Nữ	Kinh		t	12B1	2024-12-05	0354844896		2026-03-26 04:58:35.771+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 3 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
863d2837-882a-4fb6-825f-63983b871f31	Dương Quỳnh Trâm	17/06/2008	Nữ	Kinh		t	12B5				2026-03-26 02:05:17.738+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		TDP 6 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
c1a121e9-d6aa-4dff-9736-56bf57296aeb	Ngô Sỹ Thêm	17/08/2006	Nam	Kinh		t	12B9				2026-03-26 02:07:12.031+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Lâm Tốk, xã Ia Krêl, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
ec737772-c13d-4b58-b705-1b4a5e6e80a1	Lê Khanh	26/06/2008	Nam	Kinh		t	12B10				2026-04-04 09:55:25.315+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 6 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
0968a4b1-ad38-4f2d-b524-082a6f7db231	Đinh Hoàng Thu Thảo	26/03/2008	Nữ	Kinh		t	12B1	2023-03-26	0794643167		2026-03-26 02:22:46.897+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Lung Prông - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
c6cb6d4a-ba83-4eb8-b701-503c780f3543	Nguyễn Ngân Anh	20/10/2008	Nữ	Kinh		t	12B2				2026-04-05 09:03:15.757+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
4e154d85-e207-495d-a0d7-81ea460fbf90	Vũ Văn Quân	29/04/2008	Nam	Kinh		t	12B10				2026-04-04 09:56:04.68+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
fe6fc0e2-e4ef-404f-a971-001dd2657bb3	Trần Lê Huy Hoàng	10/03/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:13.163+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
4db0cde0-30dc-4256-a7c0-c8136c742d3a	Phạm Lê Hoài Nhi	02/01/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:09.33+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
c29c6ce0-3b52-4e93-bc6f-37b63d13fe6d	Võ Hoài Thương	12/06/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:52.464+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
1299580c-c9d3-4aab-b3a9-62ff91ef79e8	Rơ Mah H' Y-Su-In	16/05/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:26:03.526+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Sung Kép - IaDơk - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
c80bcc49-262e-4322-9dab-dff7f5442016	Rơ Mah H' Điệp	08/01/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:26:25.791+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Sung, Ia Dơk, Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
a7c4e27f-1e2a-4429-8e3a-ab0f488f32d9	Lê Nam Thiên	24/06/2008	Nam	Kinh		t	12B7				2026-04-25 11:32:08.11+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 2, xã  Đức Cơ, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
71c8598a-556e-46fd-b823-22989f74109e	Hồ Thị Ngọc Yến	27/11/2008	Nữ	Kinh		t	12B7				2026-04-25 11:37:17.151+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tdp9 , Đức cơ , tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
626fbadc-25a8-4e88-8fab-ac8ac7cab153	Lê Văn Khánh	05/10/2008	Nam	Kinh		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7- xã Đức Cơ-Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
4513cbe1-3f68-47c2-accc-350504325682	Nguyễn Khắc Hùng	22/01/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:23.391+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
25af07a3-214e-4966-9a34-82741cfb0cf8	Nguyễn Thị Ánh Nguyệt	12/04/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.921+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
eecc6503-dd6a-4cb1-ba78-2ad04aa6a719	Trần Cao Thùy Trang	25/11/2007	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.435+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
7e359d7b-edff-426e-bad6-dc1831b5d8c0	Nguyễn Thanh Bắc	17/02/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.02+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn IaLâm, xã Ia Krêl, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
d56b292e-01b8-4347-b481-f716f87b98ba	Đỗ Ngọc Hoàng	24/04/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:29.527+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
600579a6-9b6c-483c-89aa-168b597a8b32	Võ Hoàng Minh	23/06/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:31.012+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
975db041-e368-42e6-b013-c4fd31668915	Trần Minh Quân	21/09/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.565+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
55d9b0ce-d2d3-4918-8c20-8f48ee7ea50c	Nguyễn Hoàng Anh	29/12/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:34.048+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
e261c136-2e2a-4909-b692-909c5df0fbd8	Lê Thị Thanh Hằng	29/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:35.55+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lâm Tốk - Ia Krêl - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
9745b2f1-855a-43cd-bfaa-9d3b7ffb231d	Đinh Trọng Nhân	08/09/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.049+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông - Ia Kriêng - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
176638cd-84e5-4afb-873c-a49c33938ee2	Phan Chí Thành	02/02/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:38.532+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
bc1042e2-f070-4adc-a555-f225484863ad	Nguyễn Thị Trâm	14/12/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:40.042+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Mang - Ia Dơk  - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
7a3fd32a-6563-4049-bd0b-028cf80699ae	LỤC VÕ THÁI BÌNH	11/09/2008	Nam	Mường		f	12B6				2026-03-23 14:00:41.509+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
f8e5b7b6-70b7-4ddb-8c59-3eea0fbb40a5	HOÀNG THỊ THÚY HẰNG	14/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:43.033+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
821fef90-4bc7-4f69-b846-882c8cd6f482	Hồ Hữu Lộc	11/05/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:44.583+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1,TT Chư Ty, Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
3788aab0-6af0-4675-b2dc-a85a8908595d	NGUYỄN THANH PHƯƠNG	24/06/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:46.111+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
d43c006f-a52e-4caf-ada9-85f601457e5b	TRƯƠNG THỊ THANH THỦY	20/10/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.677+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 2 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
282fef23-b806-4b83-b7fe-69d6d5ba7272	Đào Trần Gia Như	05/08/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:00.114+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã Đức Cơ - GiaLai	84ee092b-3b6d-48aa-8324-f4eafda5b546
7c5182ea-58d5-4764-875a-bd9fff4d36ee	Luyện Tiến Tình	23/05/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:01.607+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
4e1d3528-0282-41f6-a17c-b04f7a5bb22d	Bùi Lê Trung Nguyên	01/01/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:06.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
4237ef4b-1eaf-4a70-8e3f-ad014563b483	Nguyễn Thị Kim Thu	09/11/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:07.837+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
2ed6f272-9525-4da5-b8bc-401736d0acfe	Hồ Hữu An	19/04/2008	Nam	Kinh		t	12B9				2026-03-27 13:00:49.243+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố1 - xã- Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
37073a9a-f49a-40f9-a4f5-c2d06fc49b59	Hồ Vĩnh Hạnh	03/02/2008	Nam	Kinh		t	12B9				2026-03-26 02:05:43.262+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 9, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
5a7150d8-5904-41bd-a81a-2795235f7906	Hoàng Thị Phương Thảo	2008-10-29	Nữ	Kinh		t	12B1	2026-01-18	0389905667		2026-03-26 14:32:06.744+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
9f584a6c-9db1-4dab-a915-d223f7a695fb	Nguyễn Thị Nguyệt Nhi	2008-01-27	Nữ	Kinh		t	12B1	2023-03-26	0854427247		2026-03-26 04:59:46.131+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
6c0e569c-1a13-4df8-af86-dd08dbf5033c	Phan Ngọc Gia Bảo	19/07/2008	Nam	Kinh		t	12B2				2026-04-05 09:03:19.597+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
cdad5bb4-20a1-4e7a-9d3f-71565b1d5f46	Ksor Khởi	24/05/2008	Nam	Gia-rai		t	12B10				2026-04-04 09:55:29.418+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Le - Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
002d140f-f3d7-4a8e-8d08-9373485e8abd	Nguyễn Từ Tài	16/09/2007	Nam	Kinh		t	12B10				2026-04-04 09:56:08.144+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
4e74b97f-7e2a-4e78-bdf6-3760ef88ac4e	Kpuih H' Diệu	23/03/2008	Nữ	Gia-rai		f	12B10				2026-04-05 08:36:15.021+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Ấp - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
16536226-1435-49fe-bb97-d006c613c18a	Hồ Sỹ Huy	02/01/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:16.381+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
f45ab8da-c689-492e-aab6-3221086d65a0	Dương Lê Thảo Phương	17/09/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:12.713+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
5dfe42a9-e356-47c9-9fbb-0ddf84dad8eb	Nguyễn Thị Ngọc Trâm	20/01/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:55.964+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
aac97621-0d84-43ff-b0ad-8bd7656c5754	Lê Trường Thịnh	17/07/2007	Nam	Kinh		t	12B7				2026-04-25 11:21:46.995+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2, xã Đức Cơ , Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
04a6b33a-196b-4b5b-9c8d-c468fe341d1b	Nguyễn Thị Ngọc Yến	05/06/2008	Nữ	Kinh		t	12B7				2026-04-25 11:23:13.541+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn krel ,xã ia krel , tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
9254323a-d17b-48b1-b357-ddb124c7c766	Trần Lê Ngọc Khánh	09/01/2008	Nữ	Kinh		t	12B7				2026-04-25 11:23:40.344+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Đoàn kết, Xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
ce0c7e8e-131b-47c2-a649-268d1095ee94	Lương Hà Anh	07/09/2008	Nữ	Thái		t	12B7				2026-04-25 11:27:32.29+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krai - Đức Cơ - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
de19ec21-3be3-41a2-a97f-a055c61a3d63	Lê Đình Đức	13/03/2008	Nam	Kinh		t	12B7				2026-04-25 11:28:09.238+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6- Đức Cơ – Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
40b5bfc9-5b2b-4f1b-a0c5-1ec23b42b374	Đỗ Khánh Ngọc	11/04/2008	Nữ	Kinh		t	12B7				2026-04-25 11:28:28.238+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Pnuk-  Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
367101d5-a069-46a2-99c1-ec40bfd45437	Nguyễn Trọng Cảnh Duy	28/12/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:21.966+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm Tốk, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
6dbb142e-17ee-475c-8346-fbe6c5cac59b	Dương Công Huy	24/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:23.564+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
d672953c-6649-4413-a88b-acdd5f2dc52f	Cao Thị Yến Nhi	12/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.084+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
2c2859c8-a399-4b37-80a5-ef58fe4101c9	Lương Thanh Trúc	06/10/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.594+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
296656d9-c8d1-4981-858d-2500be27f4f1	Hoàng Hải Bình	27/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:28.172+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
4f5f0e20-b05a-4cd8-8f5f-9ea9d131de4d	Nguyễn Thị Thu Huyền	06/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.677+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
8a78bee0-72f2-4763-b656-2863ffba7abe	Hà Thị Trà My	19/09/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.166+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2, xã IaDơk, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
eef33700-72ef-40c7-9a83-df4b6c3a308a	Nguyễn Cảnh Tân	05/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.709+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
0857f74c-82c8-4d8c-8ac2-208139216c0a	Trần Đinh Hoàng Anh	18/04/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:34.187+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP1 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
b40bbeb9-bc12-4c77-9625-edfcabcc37af	Lý Gia Hân	30/05/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:35.699+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo - Ia Krêl  - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
f390fd1e-ceee-41d1-b01e-5af0773efe42	Nguyễn Thị Linh Nhi	10/10/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:37.184+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân - Ia Krêl· - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
4a76cfb0-70fe-4760-8959-a34f60ba6926	Phan Thị Phương Thảo	27/04/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:38.692+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, Iakrel, Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
dddfa51d-ad9e-4e7b-85ac-14cc2a71de4f	Rơ Mah Trân	28/08/2008	Nam	Gia-rai		f	12B5				2026-03-23 14:00:40.196+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ấp - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
d2eae698-3b31-458d-b3f0-cfd109c29b8b	NGUYỄN HỮU CHỨC	22/06/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:41.673+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP6 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
9149b326-91ef-4edd-93b6-eb66041f14d2	LƯƠNG THỊ THU HẰNG	18/09/2008	Nữ	Thái		f	12B6				2026-03-23 14:00:43.204+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai - Ia Kriêng - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
44e65627-dca7-40a7-858f-9b3021c5a08a	NGUYỄN HOÀNG HỮU LƯỢNG	11/09/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:44.729+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
f0ed3c7e-1f3f-4500-a995-af0d69014a73	PUIH PLÝ	02/06/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:46.275+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
9a2d7088-0b0e-4541-be1e-cd46093523c0	NGUYỄN BÙI ANH THƯ	09/09/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.858+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
80ea8573-9dfe-4540-bb09-5aefd89dc5a3	Rơ Lan H Khâm	11/06/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:00:58.615+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung Le Tung - Xã Iadơk- Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
4309e016-21c7-4f68-85c2-26e635208bc5	Lê Hoàng Hạ Phương	06/10/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:00.258+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm - Ia Krêl - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
5c75cd61-6999-44fa-81a4-14a12adb9fd8	Rơ Mah H’ Trang	21/01/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:01:01.751+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
f1ca01f0-619d-4789-a271-b77408e4679b	Kpuih Nhan	09/06/2007	Nữ	Gia-rai		f	12B9				2026-03-23 14:01:06.43+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Dơk Ngol, xã Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
c9b57d09-3368-4697-a499-778d72440840	Lê Thị Minh Thư	29/04/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:07.991+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng H'rang,, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
5d442b14-0bc4-4e4f-878b-bce8bd8a9e64	Rơ Mah H' Diệu	23/01/2008	Nữ	Gia-rai		t	12B10				2026-04-04 09:54:31.703+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Dơk Ngol- Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
911a0b92-86be-4c39-834c-5aa4a0b8dbd6	Lê Thị Hiền	22/05/2008	Nữ	Kinh		t	12B9				2026-03-26 02:06:29.157+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố I, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
b2fea11b-52ad-49b5-ad74-91721c6254a3	Nguyễn Hương Thảo	2008-09-30	Nữ	Kinh		t	12B1	2025-01-09	0347745938		2026-03-26 02:13:03.187+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
5d4a576a-431f-41fe-8673-0be04fd2cac5	Phạm Lê Gia Nhi	2008-10-28	Nữ	Kinh		t	12B1	2025-01-09	0977823975		2026-03-26 02:29:31.175+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
5b727795-d975-41cc-8854-ee5a186cac6e	Hồ Văn An	18/11/2008	Nam	Kinh		f	12B9				2026-03-27 13:18:36.859+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Lung Prông- xã Đức Cơ- Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
4b463588-7bd1-45ae-b554-3c5b195ea877	Lê Thị Thúy Kiều	24/02/2008	Nữ	Kinh		t	12B10				2026-04-04 09:55:33.847+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
1b92e9c8-1ef8-412f-ab0b-39c081dd2080	Đoàn Thị Mỹ Tâm	12/06/2008	Nữ	Kinh		t	12B10				2026-04-04 09:56:11.531+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
eacfe4a6-e5f4-4300-8b52-883450632f81	Nguyễn Thị Bình	01/02/2008	Nữ	Kinh		t	12B2				2026-04-05 09:03:32.574+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
c8b4e087-cb01-4fef-9a70-2d7eebf6013a	Nguyễn Anh Phương	08/09/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:26.234+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
2492fc08-0d6c-4b14-a015-729fdd1c803f	Hồ Sỹ Huy	27/07/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:25.425+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
d270dd5f-da28-4f5d-90a9-20f62338e466	Trịnh Lâm Trí	28/03/2008	Nam	Kinh		t	12B2				2026-04-05 09:05:58.938+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Bi, Xã Ia Dom,Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
f8506008-599b-453f-96fa-f4ee85158249	Nguyễn Hồng Hạnh	10/05/2008	Nữ	Kinh		t	12B7				2026-04-25 11:43:51.44+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Bua, xã Ia Pnôn, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
15becc7c-fdbb-4368-a2de-2a455f2b4a66	Phan Đình Hoàng Anh	2008-12-24	Nam	Kinh		t	12B8				2026-04-12 06:56:59.917+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
eef5ff90-cdd8-4360-93aa-c85d74139988	Kpuih Khoa	12/11/2008	Nam	Gia-rai		t	12B7				2026-04-25 11:22:28.117+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung le tung, Xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
47ed7345-c3e5-45f0-830e-cd4bf7844b98	Nguyễn Thị Ngọc Anh	29/10/2008	Nữ	Kinh		t	12B7				2026-04-25 11:22:55.635+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3- xã Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
0dbe9589-0cbd-41bd-a9dc-bb7ba7e4361c	Nguyễn Thị Khánh Ngọc	31/12/2008	Nữ	Kinh		t	12B7				2026-04-25 11:23:48.7+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7 - xã Đức Cơ – Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
a99cbc2b-41bf-4b55-9844-4f2026c0b768	Nguyễn Đình Tiến	01/06/2008	Nam	Kinh		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ DP 6 -  Đức Cơ - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
ac26f03f-6aa3-4169-886a-ecf60ff9cd07	Lê Thành Danh	19/07/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:15.772+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TỔ DÂN PHỐ 7, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
c931216e-dfef-4df9-bebf-235bebf30693	Lê Văn Đạt	22/07/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.119+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
add056e6-633f-4513-a9ea-3b6c3268fc6c	Trần Thị Lan Hương	03/10/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:23.703+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
066cd95e-59cc-452f-8750-7882b68eab82	Nguyễn Ngọc Phương Như	17/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.226+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Nú, Xã Ia Nan, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
e803bd36-ea79-4bd7-b894-29ac803e6d98	Hoàng Khương Kiên Trung	19/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:26.784+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ 6, Phường Thống Nhất, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
3f8fbcc1-4a52-4f08-9661-63eb62c6c361	Nguyễn Ngọc Chương	22/12/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.32+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 1, xã IaDơk, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
870a2781-ca46-4a5b-8281-15d1e08ce611	Đinh Thị Hương	16/10/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.837+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
ac4da855-3d61-4bf6-bf98-b6b0fd02eaa7	Tăng Ngọc Nam	06/11/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:31.319+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
175af990-74d0-4e58-b396-40775116269c	Nguyễn Hữu Thắng	09/12/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.875+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
73703faa-1726-454d-bf40-9c0df35722c3	Rơ Lan H' Bích	01/10/2007	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:34.346+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Sung le Kắt - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
66e59e76-018e-4548-bf28-4efa446bf994	Vương Tiến Hùng	29/08/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:35.868+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krêl - Ia Krêl - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
d61c81f0-1a38-41c9-9a99-95b2156e7182	Nguyễn Thị Hồng Nhung	21/02/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:37.339+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thanh Giáo - Đức Cơ -Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
b81aaeaa-2886-430b-a981-d76be304d491	Hồ Phúc Thịnh	07/02/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:38.857+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP4 , Đức Cơ ,Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
aad7adf5-ca55-418f-8c6f-a9b85f347e87	Lê Văn Anh Tuấn	02/03/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:40.335+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Kăm - Ia Krêl -Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
3f70de70-385c-41f1-8a1b-d717f0572d3b	RLAN H' DIỆU	28/10/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:41.819+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Le Kắt - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
3465251d-593b-4694-af6d-652ab1ac0eb2	NGUYỄN NGỌC BẢO HÂN	28/07/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:43.387+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
03c425d7-b523-48d9-a5f9-f4d283ea8bf6	RƠ LAN H' MƯNH	04/06/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:44.885+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Kép - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
135ef86b-608e-4265-9980-665425a6b8b2	Hoàng Long Quyền	18/11/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:46.426+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
1f30e8f5-f518-4958-93b8-ea96c0baf6c4	NGUYỄN LÊ HOÀI THƯƠNG	29/10/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:48.008+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
37cee3da-3e60-49ca-9012-a5f622db3279	Đặng Gia Bảo	20/09/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.247+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
815c61e0-22eb-4e24-9874-a04174ff10b5	Đỗ Đình Lâm	29/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.779+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lang - Ia Dơk - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
5f1b6845-92e9-4b5d-a37e-2b6536c805cb	Hoàng Thị Quế Trân	10/02/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.902+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
60509c94-6d43-4f23-ae58-067e6f4f787a	Châu Thanh Hoàng	01/06/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:05.056+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Kom Ngó, Ia Chia, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
45ee9d02-8ddb-4e2f-b145-a4f93b887308	Y Linh Nhi	20/06/2008	Nữ	Xơ-Đăng		f	12B9				2026-03-23 14:01:06.604+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè,xã Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
751c748c-9aa5-41d6-aac8-495e85ee8f42	Cao Thục Quyên	2008-06-28	Nữ	Kinh		f	12B8		0333481577		2026-03-26 00:53:03.322+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
7eb62d3c-f9cb-4386-9df9-6cd71c4b6391	Đinh Thị Ngọc Anh	13/01/2008	Nữ	Kinh		t	12B9				2026-03-26 01:47:25.642+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Làng Dơk Klăh, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
d6ae2d2d-c066-4623-862e-85e65eb8a809	Lương Thị Thủy Tiên	12/10/2008	Nữ	Kinh		t	12B9				2026-03-26 02:06:47.495+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Lệ Kim, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
31e7b682-8f52-4ef8-aa53-d81dce9e46df	Lê Tâm Như	2008-10-09	Nữ	Kinh		t	12B1	2025-04-01	0975046279		2026-03-26 14:31:13.031+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Ia Lâm - Xã Ia Krêl - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
8ed1f656-50db-404f-9530-8b034378a8d4	Nguyễn Đức Thắng	2008-09-09	Nam	Kinh		t	12B1	2025-04-01	0839687889		2026-03-26 04:59:09.02+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 7 - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
00b35e54-24f6-4602-9b8b-d03b4c6ba5e8	Đinh Hải Anh	19/01/2008	Nam	Kinh		t	12B10				2026-04-04 09:53:40.075+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Dơk Ngol - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
821bb8ec-2c51-4ceb-961f-d93410638567	Lê Thị Anh Đào	30/01/2008	Nữ	Kinh		t	12B10				2026-04-04 09:54:56.164+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
a09136ff-d80c-4bef-8424-eedc928b9301	Hoàng Thị Khánh Linh	25/11/2008	Nữ	Kinh		t	12B10				2026-04-04 09:55:43.645+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
7ad7f163-53e9-4aa7-8209-54fc4eb2a052	Lưu Thị Phương Thảo	18/03/2008	Nữ	Kinh		t	12B10				2026-04-04 09:56:15.058+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Lâm Tôk - Xã Ia Krêl - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
81db37b4-ea37-4c90-b483-cd26206a2f7c	Nguyễn Chí Quốc	27/11/2008	Nam	Kinh		t	12B2				2026-04-05 09:05:22.754+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
c13a7d3d-486f-4473-a3d8-5a84ebac1db0	Trần Quang Huy	13/05/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:32.321+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Mook Trang, Xã Ia Dom, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
dacdc150-bec0-4dac-94b0-a45dfd1b7519	Nguyễn Đình Văn	24/02/2008	Nam	Kinh		t	12B2				2026-04-05 09:06:01.895+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
b887f276-28f4-437f-9389-213219a5b231	Dương Văn Bảo	18/03/2008	Nam	Kinh		t	12B7				2026-04-25 11:43:38.426+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7 - Đức Cơ – Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
151e88e9-fdac-4e3d-9dd9-2e68e666b7f2	Rơ Mah H' Lan	16/06/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:28:19.267+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Hrang -xã Đức Cơ - Tỉnh  Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
47a4fb58-9dcf-48d8-83d8-d04482c2306f	Vũ Phương Yến Ngọc	14/02/2008	Nữ	Kinh		t	12B7				2026-04-25 11:28:48.242+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung tung - Xã Iadơk- Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
d481540e-cbbe-4014-94c3-61840e097124	Rơ Mah H' Hát	19/10/2007	Nữ	Gia-rai		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung -Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
67d2ade5-ffe5-4b70-ac95-f79f2f9d175e	Rơ Lan Tiếp	07/08/2008	Nam	Gia-rai		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Đo, xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
9d975242-8822-4d59-9ea3-88c05be2513c	Đoàn Thị Ngọc Diệp	26/01/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:15.932+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
5592e235-1a16-437e-bc5e-fe467c6bb116	Nguyễn Thành Đạt	29/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.282+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	 Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
0ddfb5eb-7c58-4244-9ed2-b511fa92b79a	Lương Nguyễn Anh Kiệt	29/11/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:23.85+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
dc299478-2c81-48e4-993e-46f7a5696e84	Nguyễn Văn Quyền	29/02/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:25.364+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
1c223398-697d-4178-833f-9619aace9423	Từ Thị Ngọc Tuyên	28/08/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.936+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
bdf566ab-f80f-47ec-b378-ffb134c8eab8	Lê Tuấn Dũng	06/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.486+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
509d5d5e-4d18-4a7d-8941-363a782a2443	Đặng Thu Hường	12/06/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.987+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
c22dd1ed-5c26-42be-bba9-168bc2b8992c	Nguyễn Thị Quỳnh Nga	21/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.465+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
ba3f2636-6731-4d7b-9e42-a770dd4f1834	Phạm Anh Thư	14/12/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:33.03+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
fc990922-7be4-4a37-a99b-728db753b2cd	Hoàng Thị Quỳnh Chi	09/11/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:34.501+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3  - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
f3b46399-66eb-4656-8362-9d0c1777ab76	Lương Trung Huy	18/07/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:36.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Tang - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
24b6f0ac-86b3-4e66-af39-523d2f21e5b5	Rơ Mah Phiên	13/10/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:37.496+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè - Ia Dơk  - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
fd3e72f9-0292-4ec6-ab47-5670e6ed9f4c	Vũ Hồ Anh Thư	12/11/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.008+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 6, Đức Cơ , Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
2d5c39de-aa33-4039-850e-487fd6421a95	Rơ Mah Tuấn	02/07/2008	Nam	Gia-rai		f	12B5				2026-03-23 14:00:40.479+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pong - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
a077bb60-c826-47ab-92e1-4a8866c58670	Hồ Thị Thùy Dung	12/05/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:41.959+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2,TT Chư Ty, Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
c044cdb7-4422-4911-b004-86e9b4560331	TRẦN MINH HIẾU	03/08/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:43.533+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
eb8f7447-2398-45d5-acd0-a8df3923a089	RMAH H' LY SA	05/01/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:46.595+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Le Kắt - Ia Kla - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
8f0539ce-d58e-4666-9a06-e3c024654752	TRƯƠNG ÁI MỸ TIÊN	29/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:48.24+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
5a5765ad-1305-40f7-82f3-24e65a995c2d	Hoàng Gia Bảo	18/10/2008	Nam	Sán Dìu		f	12B8				2026-03-23 14:00:57.398+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
b9cd09c5-26e5-4bc1-833c-ec8145073a36	Đinh Quang Lộc	09/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.958+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
edb2c247-8cf0-4a3d-a803-c9e1fbcc2da1	Rơ Mah H' Quỳnh	06/04/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:01:00.565+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp - Ia Krêl  - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
10c4503b-ee11-4239-97ce-8e2eb878d10e	Lê Khả Tuấn Tú	10/06/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:02.058+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
5609c740-ff28-4573-9637-39ea8d9a1733	Trần Gia Hưng	23/09/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:05.2+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Lệ Kim, Xã Ia Dơk ,Tỉnh Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
2915eda8-3f13-4d03-8b84-08198b41e52f	Trịnh Hoàng Long	12/09/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:12.85+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
df73b4e5-693a-497f-aceb-90b67fc6836f	Lê Thị Hồng Nhung	15/02/2008	Nữ	Kinh		t	12B9				2026-03-26 02:06:38.016+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Khóp, xã Ia Krêl, Gia Lai.	539248e4-4825-42e2-b5e1-52dd70ae3fba
a191c6e0-2c9f-4602-89a0-a5998768ebba	Nguyễn Thành Tín	04/08/2008	Nam	Kinh		t	12B9				2026-03-26 02:07:25.497+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3, xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
da5590cc-d266-47b8-b0c8-9f82ea87a79a	Nông Hoàng Diệp Bình	07/07/2008	Nữ	Tày		t	12B9				2026-03-26 02:07:55.947+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1, Xã Ia Dơk,Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
f51a0119-252e-49f4-b948-8f5beede90d5	Đinh Thị Thanh Thùy	2008-11-25	Nữ	Kinh		t	12B1	2025-01-09	0833827587		2026-03-26 02:14:10.54+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
39b75e25-4553-419b-a470-7781402ec0b3	Trần Ngọc Ánh	09/12/2008	Nữ	Kinh		t	12B10				2026-04-04 09:53:44.623+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
ef7883d1-b42b-4816-805e-c2f0461bed45	Ksor Ngọc Hân	26/07/2008	Nữ	Gia-rai		t	12B10				2026-04-04 09:55:00.55+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Đo - Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
d5f577c0-c80d-4347-994e-8590d5df231a	Trịnh Tâm Như	2008-08-14	Nữ	Kinh		t	12B1	2023-03-26	0789725567		2026-03-26 04:59:57.594+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ 6 - Xã Đức Cơ- Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
bef97884-4450-46d3-b542-e2e7daa13e2b	Mai Thị Thảo	04/07/2008	Nữ	Kinh		t	12B10				2026-04-04 09:56:18.76+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
cac87fb2-3566-41b6-b947-8f2de83c086a	Nguyễn Thị Diễm Quỳnh	07/02/2008	Nữ	Kinh		t	12B2				2026-04-05 09:05:29.968+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	ThônThanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
97e161ea-32a2-48e5-8007-878eea143513	Nguyễn Thị Hiền	10/12/2008	Nữ	Kinh		t	12B7				2026-04-25 11:22:44.375+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
9e83712a-d214-4c05-836a-7d3b14bd7142	Phạm Nguyên Việt	04/12/2008	Nam	Kinh		t	12B2				2026-04-05 09:06:04.779+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
b1d95700-efa0-4f80-a77d-89ca94043c31	Hoàng Thị Thu Huyền	14/03/2008	Nữ	Kinh		t	12B2				2026-04-05 09:16:56.969+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
f9d9726a-819f-4b1c-acaa-eef518022b9d	Rah Lan H' Ru Bi	28/11/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:23:26.956+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung le kăt, Xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
a7cd57d6-1b09-49a2-9e34-c7a0b89a073b	Nguyễn Hải Lâm	12/01/2008	Nam	Kinh		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn ia lam- xã Iakrêl - Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
71af3a99-14f6-4076-9eae-8b04da85a96e	Quyền Đình Trọng	11/12/2008	Nam	Kinh		t	12B7				2026-04-25 11:25:28.304+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
20ebc8e9-5126-4e3e-8cf9-9cfe674d2db2	Rơ Lan Nhung	28/09/2007	Nữ	Gia-rai		t	12B7				2026-04-25 11:44:02.577+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung- xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
2c003304-4d9d-4511-bb2f-6181686e3dac	Nguyễn Tiến Đạt	27/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.439+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
122e6e7e-60e7-482f-b8ec-9108cfa8ecd7	Nguyễn Việt Linh	16/10/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:24.006+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
73fd5eb9-d6a9-47be-b1aa-5392d2466618	Trần Thị Mỹ Tâm	28/09/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.509+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
8de405c4-8ff1-4071-97c1-fc7429879305	Phạm Minh Vũ	24/10/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:27.104+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
73867a61-1489-4d04-8d5a-370db6cd586b	Mai Tấn Dũng	20/02/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.643+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
06b6c8af-bbe8-47ee-9e74-126a36ebbb09	Ngô Đức Linh	31/07/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:30.154+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krê, xã Ia Krêl, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
33a34d8d-28de-4609-83b9-6e22fd6bc398	Chu Nguyễn Bảo Ngọc	18/08/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.613+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
0f26470e-a037-409a-9021-2c91f9e2c0dd	Nguyễn Thị Thùy Trang	13/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:33.186+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
f7e545c2-0e26-4aea-8c85-813db14521bf	Hồ Ngọc Quế Chi	26/10/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:34.666+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 4 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
90b1cfcc-f351-42c4-9fd0-2c214ee74618	Nguyễn Trần Minh Khôi	01/09/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:36.159+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 1 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
fa8b40e7-511f-4cea-b4e8-904e3014cd01	Phí Mạnh Phúc	25/01/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.647+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Chư Bồ 2 - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
d88b763e-9215-407a-83ff-a242b7a8df93	Lê Xuân Tiến	25/10/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:39.149+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
3e2bbebf-7a9d-4acb-a30d-a2dbfbec49ad	Rơ Mah H' Tuệ	12/12/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:40.623+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pong - Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
e17d31d0-a8ad-49b2-9972-47a9eb4ae3a3	NGUYỄN THỊ DUYÊN	02/10/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:42.109+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP7 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
a029fd18-2dea-491f-bfa8-f82007a35f7f	KPUIH H' HÚI	23/04/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:43.677+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
7d0c240e-82fd-48ae-a669-80653c39c7a9	NGUYỄN THỊ HỒNG NGỌC	29/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.209+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Đội 12 - Ia Chía - Ia Grai - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
2181db6e-9b3d-441a-bc69-a4db1b146a88	SIU LI SA	26/03/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:46.769+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
d5b9feaa-c94d-4a36-b2e4-67af8cf7c939	LÊ THỊ HUYỀN TRANG	11/04/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:48.417+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
781e1550-6997-4030-8c5d-78f2b3359bcc	Nguyễn Trần Nhật Đang	16/09/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.549+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
0b51473e-4c9e-4db2-93a6-f852b71e180b	Nguyễn Ngọc Mai	10/10/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.112+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
8e239664-a6fa-4cd9-8f03-ba74607678d4	Nguyễn Văn Sỹ	04/06/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:00.72+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thanh Giáo - Ia Krêl - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
d06913f3-7e8d-4706-a1a6-4233258945a0	Nguyễn Quốc Tuấn	19/08/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:02.21+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
3629e93f-e662-4798-9a0e-fd10327fd3ad	Võ Duy Hưng	28/09/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:05.356+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 9 - xã Đức Cơ, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
81fcc328-a5ea-439e-8521-062dd08c2760	Rơ Mah H' AYưng	24/01/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:09.899+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Khóp - Xã Ia Krêl - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
93fe0665-7970-46b9-9e71-4dbaeee859cc	Đỗ Quỳnh Tố Như	23/09/2008	Nữ	Kinh		t	12B9				2026-03-26 02:05:14.675+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thanh Bình, xã Bàu Cạn, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
0083cea7-e3e1-496b-b8fc-2071d71db7ab	Hoàng Thị Bảo Trâm	10/11/2008	Nữ	Kinh		t	12B9				2026-03-26 02:05:26.308+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Lệ Kim, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
5c64d923-7527-4400-b617-ad638b8035dd	Nguyễn Thị Trầm Thương	2008-01-11	Nữ	Kinh		t	12B1	2023-03-26	0395372178		2026-03-26 02:26:58.528+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
c77e4670-587c-4675-844a-a691ab08b0ed	Đỗ Hà Phi	2008-01-06	Nam	Kinh		t	12B1	2022-10-16	0382316601		2026-03-26 13:07:48.141+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
6763fd9a-dd17-435d-b71a-02bbfdfd7560	Lương Gia Hân	29/12/2008	Nữ	Kinh		t	12B10				2026-04-04 09:55:04.449+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
4a3d995f-ca7d-4809-a983-ca766d83e986	Rơ Lan Hoa Mai	22/11/2008	Nữ	Gia-rai		t	12B10				2026-04-04 09:55:49.496+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Poong - Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
1b91d0ea-9fd6-44b4-805b-de6173527264	Vũ Thị Thu Thảo	24/10/2008	Nữ	Kinh		t	12B10				2026-04-04 09:56:22.759+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
2d054e22-5389-4d58-b275-d5228b404630	Đào Duy Hưởng	16/06/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:47.447+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Lâm, Ia Krêl, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
cd630baa-3309-4581-b346-41ffdeb30125	Phan Văn Dũng	14/10/2008	Nam	Kinh		t	12B2				2026-04-05 09:03:58.767+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
c5a9f3ec-eafe-467f-ad27-43041f30d9dd	Võ Duy Tài	06/10/2008	Nam	Kinh		t	12B2				2026-04-05 09:05:33.741+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn IaLâm, Xã Ia Krêl, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
5cb9a5d3-18fa-4dad-8a7b-9358218b2bd5	Lê Thị Yến Vy	18/07/2008	Nữ	Kinh		t	12B2				2026-04-05 09:06:11.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
68549c64-0e11-4ef7-9556-3457d6bd399d	Kpuih H' Như	20/04/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:24:08.719+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Lung Prông-  Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
a986da86-eab1-4a7d-a8f1-ba9e01ae9d0d	Nguyễn Thị Thu Hiền	14/11/2008	Nữ	Kinh		t	12B7				2026-04-25 11:24:38.41+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 2,  Đức Cơ, Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
1390fd9b-a37e-4456-89f2-c779d07d916e	Rơ Mah H' Trúc	28/11/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:25:47.069+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Sung Le - Ia Dơk-  Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
8f5dcc7d-552a-4412-9a4c-45ae1ec162ad	Rơ Châm H' Lệ	23/10/2008	Nữ	Gia-rai		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	làng dơk ngol ,xã ia dơk , tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
a04ac8ce-c777-4167-8f5c-2fe3b2443207	Kpuih H' Chúc	15/09/2008	Nữ	Gia-rai		t	12B7				2026-04-27 07:42:52.042+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Lung Prông -  xã Đức Cơ - Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
bd5740bc-dd57-49be-9620-8c02826ff329	Nguyễn Trần Khánh Lợi	30/01/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.15+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
d78eb5c4-c164-4c35-88f2-d281803b1fc6	Trần Thị Lệ Thanh	29/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.66+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
97b01cd9-1c32-40ca-b7ce-208ea15dd64a	Mai Tiến Dũng	20/02/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.791+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
b2fddc4e-27d2-40c7-9f4d-f9428e6157dd	Nguyễn Ngọc Hồng Linh	06/08/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:30.299+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
ebbd3731-9f01-47ca-bb5f-4993539aa4ca	Mai Thị Yến Nhi	27/05/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.787+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
99261e54-0c12-46dd-9e30-2d357167b0f0	Nguyễn Xuân Việt	15/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:33.332+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
d1e1de5d-683e-45c9-a76d-1b68c38e6b71	R Lan H' Diệp	19/04/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:34.819+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Sung Lê Kắt - Ia Dơk- Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
55fdbc60-d17a-43df-8942-8e45163d0dec	Hồ Lê Phương Linh	27/09/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.304+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP1 - Đức Cơ - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
280a8629-c319-4584-aafd-9dfa85cdc9dd	Đậu Tiến Quân	05/03/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.815+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết- Ia Dơk - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
074fd61a-7962-468b-8fba-c9a953675059	Hồ Thị Tình	24/08/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.277+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết - Ia Dơk  - Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
80848897-b43e-47e7-8eaa-40c9de625db7	Rơ Mah H' Út	30/09/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:40.77+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Lung Prông, Đức Cơ ,Gia Lai	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
ebd03a81-7ee2-466c-9094-f8db1fbdc84e	NGUYỄN THẾ ĐẠT	10/03/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:42.25+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 3 -Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
5a05b740-9952-4b40-8b8c-de1e9757b22d	RƠ MAH HÚY	12/10/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:43.839+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
344c216b-bf6e-492d-9694-b9358eb12621	NGUYỄN PHƯƠNG THẢO NGUYÊN	10/09/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.364+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
8646134a-4e2e-4470-873d-0ced8b7c3cb0	KHUẤT ANH TÚ	30/03/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:48.588+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
c2a04152-a093-4fd9-97e4-0d24c86f1175	Nguyễn Văn Định	27/10/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.708+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Ia Kăm - Xã Ia Krêl - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
04b0c602-ccdd-41cd-bbcf-c0c1812daeff	Lê Thị Trà My	05/06/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.27+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
06afd6ad-6d46-4c51-832c-c1ba2c04250d	Mai Văn Tâm	17/11/2007	Nam	Kinh		f	12B8				2026-03-23 14:01:00.858+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Xã Đức Cơ- Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
d8dfea21-94ff-4d5d-8ac4-2316e49d0410	Đặng Thị Khánh Uyên	30/09/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:02.361+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Tổ dân phố 6 - Chư Ty - Đức Cơ - Gia Lai	84ee092b-3b6d-48aa-8324-f4eafda5b546
90946272-8103-4c43-a2d6-dc9b8adae117	Lê Khả Cơ	16/05/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:03.953+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Thôn Đoàn Kết, Ia Dơk, Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
fea6b89b-71fd-4031-bddc-2007e6e95b82	Phan Bảo Trâm	11/12/2008	Nữ	Kinh		t	12B9				2026-03-26 02:08:03.817+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 3 - xã Đức Cơ - Gia Lai	539248e4-4825-42e2-b5e1-52dd70ae3fba
50e22537-3dac-4c07-9451-3041a3e6e009	Phạm Thành Đạt	2008-04-11	Nam	Kinh		t	12B2				2026-03-26 02:12:07.131+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ Dân Phố 6, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
00aaab14-f21e-443c-a5e3-7d6be1c4909c	Rơ Mah Hà Trúc	08/09/2008	Nữ	Gia-rai		t	12B7				2026-04-25 11:21:26.644+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Sung Kắt - xã Ia Dơk - Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
4ebe940f-0294-42fa-a80c-d3ff973e93d2	Nguyễn Thị Thùy Dung	13/04/2008	Nữ	Kinh		t	12B7				2026-04-25 11:26:39.009+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia tang, Xã Ia Dơk, Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
3dccb7ad-7e97-4961-bff3-48629141ce1a	Đỗ Công Tuấn	2008-02-06	Nam	Kinh		t	12B1	2025-04-22	0987802574		2026-03-26 13:05:30.157+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
6d5355ac-0641-4002-8f5a-6bb8454fb456	Hoàng Văn Phúc	2008-01-14	Nam	Kinh		t	12B1	2023-03-26	0376083663		2026-03-26 13:08:35.559+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
e0db9d99-c3a5-4c18-9449-d91de9b08fcd	Trần Nguyễn Gia Bảo	03/10/2008	Nam	Kinh		t	12B10				2026-04-04 09:53:52.135+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
78efc992-8679-4f5b-8af3-c9c54a596aa2	Phan Thị Kiều Vy	2008-04-03	Nữ	Kinh		t	12B2				2026-04-05 09:06:16.67+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
b4f1e0ce-7df1-48da-94e7-aa28e4858a35	Nguyễn Văn Mạnh	07/10/2008	Nam	Kinh		t	12B10				2026-04-04 09:55:53.281+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
b2c73d89-3c9e-48c8-845d-20bc521a9aec	Mai Thanh Lâm	23/12/2008	Nam	Kinh		t	12B2				2026-04-05 09:04:54.267+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Thôn Ia Chía, Xã Ia Nan, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
01183682-945d-470f-bc40-07df0a1e6950	Ksor Thịnh	07/08/2008	Nam	Gia-rai		f	12B10				2026-04-05 08:37:29.37+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Làng Krol - Xã Ia Krêl - Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
f0363907-9f7b-4a1a-a1bd-601f624f0b36	Lê Hữu Thành	08/09/2008	Nam	Kinh		t	12B2				2026-04-05 09:05:37.046+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	c9981426-89cd-4565-8c8e-5f1119f30018
3024cc64-b6a2-45b4-83d7-df1f9c2a1043	Hoàng Uyên Vy	2008-05-12	Nữ	Mường		f	12B3				2026-04-08 16:45:37.688+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	93ed547c-5b97-49e5-be05-b64ade9a6586
f3744194-6c47-4042-a33a-015d40093649	Hồ Nguyễn Khánh Ly	21/07/2008	Nữ	Kinh		t	12B7				2026-04-25 11:22:17.052+00	e27632bc-c3ce-41fa-97c8-f525e02b0376		Thôn Đoàn kết, Xã Ia Dơk,  Tỉnh Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
b4512934-dbd6-467e-91e6-0beea904a079	Vũ Hoàng Diệu Hiền	04/11/2008	Nữ	Kinh		t	12B7				2026-04-25 11:24:34.017+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Tổ dân phố 6-  Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
09a13ccc-4b17-4311-9346-273473f9a5e4	Kpuih H' Nhưng	11/10/2008	Nữ	Gia-rai		t	12B7	2026-04-22			2026-04-25 11:42:43.804+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	Làng Pnuk- Đức Cơ- Gia Lai	33250f94-6931-47dd-ac2f-bb4e8a5535b1
2b3669db-9f34-43a0-b366-5a97426de76b	Dương Như Hoàng Anh	01/03/2008	Nam	Kinh		f	12B10	\N			2026-05-04 06:47:54.789+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 9 - Xã Đức cơ- Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
7c2d600c-2ccf-481a-bb87-0d319d77f0a9	Đậu Tuấn Anh	31/12/2008	Nam	Kinh	Học sinh	f	12B10	\N			2026-05-04 06:48:49.566+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	TDP 1 - Xã Đức cơ- Tỉnh Gia Lai	44722561-7fa7-44ef-9a26-cdfeb098934f
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat") FROM stdin;
f9e89d24-1fd4-4e89-8764-e929cabf9b12	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	Đợt 4	2026-04-01	2026-06-13	t	f	Đợt cuối	2026-05-02 23:16:46.21+00
2882e532-cf63-4e4b-baf8-43adf3c80d38	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	22	2026-05-04	2026-05-10	f	f		2026-05-03 22:25:13.466+00
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian") FROM stdin;
1b671eeb-04c9-417a-8bd7-b1aba8f07518	14	2026-04-29 13:45:42.476892+00
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by") FROM stdin;
default	hohuuthe/SAOLUU_CSDL_QL_THIDUA_CHUANCSDL	main	supabase-backup.yml	supabase-restore.yml	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	2026-05-02 09:35:07.76+00	Admin
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "isdefault", "islocked", "updatedat") FROM stdin;
e27632bc-c3ce-41fa-97c8-f525e02b0376	2025-2026	t	f	2026-03-20 07:58:43.861+00
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc") FROM stdin;
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "quyen_chi_doan_phu_trach", "ngay_cap_nhat", "nam_hoc", "quyen_xem_tat_ca_chi_doan") FROM stdin;
2211	BT	baocao	t	f	f	f	f	2026-05-09 09:26:21.282+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2212	DV	qlchidoan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2213	BT	doanvien	t	f	t	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2214	BT	tieuchitd	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2215	BT	phancong	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2216	BT	chamdiem	t	t	t	t	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	t
2217	BT	namtuan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2218	BGH	qlchidoan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2219	PH	doanvien	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2220	PH	tieuchitd	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2221	PH	chamdiem	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2222	PH	baocao	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2223	GVCN	ptdoanvien	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2255	BCH	phancong	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2256	BCH	chamdiem	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2257	BCH	namtuan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2235	GVCN	doanvien	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2617	BTV	tongquan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2618	BTV	phanquyen	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2619	BTV	saoluu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2904	BCH	tongquan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2250	BGH	baocao	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2251	BCH	qlchidoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2252	BCH	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2253	BCH	doanvien	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2905	BCH	ptdoanvien	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2906	BCH	phanquyen	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2907	BCH	saoluu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2908	GVCN	tongquan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2909	GVCN	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2910	GVCN	cauhinh	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2911	GVCN	phanquyen	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2912	GVCN	saoluu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2913	BT	tongquan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2914	BT	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2915	BT	phanquyen	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2916	BT	saoluu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2917	DV	tongquan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2918	DV	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2919	DV	ptdoanvien	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2920	DV	phancong	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2921	DV	namtuan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2922	DV	cauhinh	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2923	DV	phanquyen	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2924	DV	saoluu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2925	PH	tongquan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2926	PH	qlchidoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2927	PH	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2928	PH	ptdoanvien	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2929	PH	phancong	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2930	PH	namtuan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2931	PH	cauhinh	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2932	PH	phanquyen	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2933	PH	saoluu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2236	DV	doanvien	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2237	DV	tieuchitd	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2239	BT	trogiup	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2240	BTV	chamdiem	t	t	t	t	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2224	BT	ptdoanvien	t	t	t	t	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2225	BTV	ptdoanvien	t	t	t	t	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2226	GVCN	gioithieu	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2227	BGH	gioithieu	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2228	BTV	gioithieu	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2229	BCH	gioithieu	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2230	BT	gioithieu	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2231	DV	gioithieu	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2232	PH	gioithieu	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2233	BGH	ptdoanvien	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2234	DV	baocao	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2238	BT	cauhinh	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2241	BTV	namtuan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2242	BTV	baocao	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2243	BTV	cauhinh	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2244	BTV	trogiup	t	t	t	t	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2258	BCH	baocao	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2259	BCH	cauhinh	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2260	BGH	phancong	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2261	BGH	trogiup	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2262	GVCN	trogiup	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2263	BTV	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2264	BTV	doanvien	t	f	t	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2265	BTV	tieuchitd	t	t	t	t	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2266	BTV	phancong	t	t	t	t	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2267	BCH	trogiup	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2268	GVCN	qlchidoan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2269	GVCN	tieuchitd	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2270	GVCN	phancong	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2271	GVCN	chamdiem	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2272	GVCN	namtuan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2273	GVCN	baocao	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2274	BT	qlchidoan	t	f	t	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	t
2275	DV	chamdiem	t	f	f	f	t	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2276	DV	trogiup	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2277	BGH	tongquan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2412	BGH	taikhoan	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2245	BTV	qlchidoan	t	f	t	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
2246	BGH	doanvien	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2247	BGH	tieuchitd	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2248	BGH	chamdiem	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2249	BGH	namtuan	t	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N
2254	BCH	tieuchitd	f	f	f	f	f	2026-05-09 09:26:21.283+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	f
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
8137644a-c5d3-4e72-bd2c-d4a87610a78f	660e4094-17b4-4e26-adac-b064767c0ac4	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:39:38.337+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
15319043-5c78-46e9-bc81-0e632e386b19	a99cbc2b-41bf-4b55-9844-4f2026c0b768	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:39:52.387+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
823bfcce-3e7b-4bf2-bd83-b12c44631bdd	96840637-b85e-4eba-a0b2-ee53083d34f9	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:40:02.022+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
e295be29-a39c-4ada-ba1e-0d862e57f154	67d2ade5-ffe5-4b70-ac95-f79f2f9d175e	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:40:11.237+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
7fbd0fe8-ee13-47dd-9a07-8e88da9fd093	626fbadc-25a8-4e88-8fab-ac8ac7cab153	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:40:19.928+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
99cd0298-9713-46cd-bac2-daa3d9b77a48	db5e3772-492a-49f6-be61-07736f135a06	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-03 00:01:14.94+00	2026-05-03 00:01:14.94+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
d29b6b71-6ba5-4cae-972a-343a518d9a8a	09a13ccc-4b17-4311-9346-273473f9a5e4	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:40:44.357+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
410d1171-fb44-41bf-a749-349663cd18eb	d481540e-cbbe-4014-94c3-61840e097124	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:42:13.28+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
f853db94-aad5-4bd2-a060-66c42aa94e4c	8f5dcc7d-552a-4412-9a4c-45ae1ec162ad	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:42:26.463+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
73c6cb98-c20a-47db-a4e5-97072de7e8ff	a7cd57d6-1b09-49a2-9e34-c7a0b89a073b	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	t	2026-04-07 03:38:27.194+00	2026-04-25 11:42:27.082+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	QD-68	2026-04-22
a7aff79c-c303-4385-b95a-19206222c638	9de0ffed-2437-4f57-8086-d633bdf42c9c	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-03 00:12:13.667+00	2026-05-03 00:12:13.667+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
02c35786-2b40-43d7-9866-b42f700c9bf8	3024cd81-df29-42f1-915b-cc03f2fef35c	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-04-05 10:16:37.318+00	2026-04-20 09:44:23.678+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
b6bd3ceb-536e-44a9-b13c-c023ce1230eb	642ec80c-f1dd-4bc3-bb7d-d5a3c171b6ee	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-03 00:23:30.194+00	2026-05-03 00:23:30.194+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
9851f435-dd33-481d-a49a-58ed6deb4485	424aedd1-4870-4d21-93e1-f2d8238f19ff	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-03 00:31:18.698+00	2026-05-03 00:31:18.698+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
a63039e0-fb4f-4b2d-9063-35f23a91b9e8	2b3669db-9f34-43a0-b366-5a97426de76b	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-04 07:52:39.611+00	2026-05-04 07:52:39.611+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
7d2c599c-59bd-40cd-86f1-5b18f2eec91a	81fcc328-a5ea-439e-8521-062dd08c2760	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-04 07:53:01.048+00	2026-05-04 07:53:01.048+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
d08613f3-39ce-445d-8c21-196abea41fc3	6689140b-b1e4-46d9-ab08-d7000ebd45e3	f9e89d24-1fd4-4e89-8764-e929cabf9b12		0	f	2026-05-04 07:53:22.112+00	2026-05-04 07:53:22.112+00	e27632bc-c3ce-41fa-97c8-f525e02b0376	\N	\N
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat") FROM stdin;
33250f94-6931-47dd-ac2f-bb4e8a5535b1	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-04-25 11:33:40.711+00
61a554f0-87f5-4dbd-a152-22cebed82925	11C9	Sáng	XH	4			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-23 13:44:53.524+00
b43602fc-3d2e-48a1-b281-4fa1b7aabef9	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm 		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 01:50:54.926+00
87881984-264c-4c97-b336-69ef0999dd67	10A11	Chiều	XH	6			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-25 14:31:12.568+00
84ee092b-3b6d-48aa-8324-f4eafda5b546	12B8	Sáng	XH	15	Quế Trân		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 01:53:47.778+00
5ef21e40-6b45-40d8-a24d-6bee8c1f432c	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-27 01:01:52.847+00
f7501580-cc9c-41c9-a00d-0f8c54c13bcb	11C1	Chiều	TN	12	Lê Minh Phương		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-23 13:44:52.019+00
539248e4-4825-42e2-b5e1-52dd70ae3fba	12B9	Sáng	XH	16	Thành Tín		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 01:51:51.215+00
fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	11C11	Sáng	XH	6	Bùi Thị Tường Vy		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:39.26+00
44722561-7fa7-44ef-9a26-cdfeb098934f	12B10	Sáng	XH	17	Lê Tiến Công		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:03:02.639+00
325ddee6-e5ad-47d5-8351-b12c1eb67acc	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:44.046+00
450ff56c-ab21-4927-a712-9e9e155646b7	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\n	e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:43.495+00
8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:23.574+00
09d8ade5-bb92-46ab-98e7-3ab869d59f75	10A4	Chiều	TN	8	Phạm Hà Anh		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:28.616+00
fdc18dde-9e98-4ceb-831f-2944f68998d4	11C3	Chiều	TN	14	Phạm Minh Anh		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:39.592+00
b7b2f041-de5d-49db-8186-5dd8db250052	11C4	Chiều	TN	15	Cù Hoàng Gia An		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-31 03:26:24.158+00
65560ab5-035b-496a-9133-a50d9bf0a0d0	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-31 16:14:17.367+00
c9981426-89cd-4565-8c8e-5f1119f30018	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-04-05 09:02:55.176+00
846cdc56-d3b7-494e-b805-6e584dcd9392	10A6	Chiều	XH	1			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-25 14:35:27.61+00
25d78477-f93d-401d-85b3-3a39ba2e83e7	11C5	Chiều	TN	16			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 01:59:44.84+00
93ed547c-5b97-49e5-be05-b64ade9a6586	12B3	Sáng	TN	10	Nguyễn Gia Hân		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-04-08 16:44:22.937+00
fce39a4b-0928-4944-b3bf-d8efe09ddaf3	12B4	Sáng	TN	11			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-23 13:44:54.703+00
141be337-7bb7-4d92-bd8e-21330ef7702f	10A7	Chiều	XH	2	Phạm Khánh Chi		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:00:31.468+00
1d712008-dda7-4791-8b18-a2078c091830	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-04-24 01:39:33.543+00
02180031-0a4d-4aa7-b43b-0d3549779653	10A8	Chiều	XH	3			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-25 14:35:12.401+00
642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:01:34.76+00
0c673b7d-6199-4fbd-b3ce-5a11324113b6	11C7	Sáng	XH	2	nguyễn hồng lai		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:03:06.395+00
6d3e0c06-4ed8-460c-8ebc-67ade36f0276	11C8	Sáng	XH	3	Nguyễn Trung Hiếu 		e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-26 02:02:26.289+00
1c86cf6e-19bd-42ea-8cb0-8137cb63988a	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-04-24 01:38:26.043+00
5d2969a5-0d68-4845-bcab-407f002e89b1	10A9	Chiều	XH	4			e27632bc-c3ce-41fa-97c8-f525e02b0376	2026-03-25 14:35:05.657+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc") FROM stdin;
6b802b3a-6b0a-4ffd-9089-614e55a53afa	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT Lê Hoàn xoa HK2	300		AIzaSyDI0Spcjx9DeI3O-I9aliRdUlgx8zLImTc	100		\N	\N	\N	\N	21:00	30	Lỗi không nộp phiếu chấm điểm tuần	t	Hệ thống	0		ĐOÀN XÃ ĐỨC CƠ\n[B] ĐOÀN TRƯỜNG THPT LÊ HOÀN\n***\nSố:   BC/ĐTN	[U][B] ĐOÀN TNCS HỒ CHÍ MINH\n\n[I] Đức Cơ, {{FULL_DATE}}	[C][B] NGƯỜI LẬP\n\n\n\n\n{{HOTEN}}	[B] TM. BAN CHẤP HÀNH\n[B] BÍ THƯ\n\n\n\nLê Trung Thành	ĐOÀN XÃ ĐỨC CƠ\n[B] ĐOÀN TRƯỜNG THPT LÊ HOÀN\n***\nSố:   BC/ĐTN	[U][B] ĐOÀN TNCS HỒ CHÍ MINH\n\n[I] Đức Cơ, {{FULL_DATE}}	[L][I][B] Nơi nhận:\n[L][I] - Chi bộ (BC);\n[L][I] - BGH (BC);\n[L][I] - GVCN (Ph/h);\n[L][I] - Chi đoàn (T/h);\n[L][I] - Lưu ĐTN.	[B] TM. BAN CHẤP HÀNH\n[B] BÍ THƯ\n\n\n\n\nLê Trung Thành	e27632bc-c3ce-41fa-97c8-f525e02b0376
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "chidoan1111", "updatedat", "chidoan_id") FROM stdin;
d82e0536-4f2e-49ee-8066-952858c62525	Vothile1	$argon2id$v=19$m=65536,t=3,p=4$ngacA26569mU/2SiI4x01w$izVEAotiUs8e/q5TDdG9e2N72OuAfNS/ZifiAT4fAIQ	Thử 1	BGH	\N	2026-05-09 01:29:08.249+00	0c673b7d-6199-4fbd-b3ce-5a11324113b6
dde7c79b-200a-4341-8413-2b17ac995e56	bithu_11C71	$argon2id$v=19$m=65536,t=3,p=4$qfeWrFAyY1y8Cg5OqtskeQ$Ea3bI2Vk0+NPG0Bvp8ERphxXIFX7jZRq2R0kJXvhbc0	Thử 1	BT	\N	2026-05-04 03:31:40.247+00	0c673b7d-6199-4fbd-b3ce-5a11324113b6
ff25a6e4-bc15-4eeb-a1a8-2204a64ec714	bithu_12B61	$argon2id$v=19$m=65536,t=3,p=4$DPbc4ZxdWDk9JD8R9pfPTQ$/l8lPzeSUBlEDSQfCan6iropaXMS5CqPTVfLqYb1L3E	Thử 1	BT	\N	2026-05-04 03:31:41.424+00	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
b2eddc4f-185d-41e2-aa34-77fee5e68dc9	bithu_11C61	$argon2id$v=19$m=65536,t=3,p=4$7NdJztgCdWViHEuRF4G0cQ$Yyqgz0t59HfxL6nA/XkIDyhgDEZFk/L7qtJT3A0/H8c	Thử 1	BT	\N	2026-05-04 03:31:42.337+00	1d712008-dda7-4791-8b18-a2078c091830
060e27f5-285e-4b51-a8c0-57608679ed27	bithu_10A91	$argon2id$v=19$m=65536,t=3,p=4$7f2vg00tiKBJDPXldM+jfg$8lxRNryq2utqcvOuKfocteU5UcxASjaVANoZGmrxeAE	Thử 1	BT	\N	2026-05-04 03:31:43.078+00	5d2969a5-0d68-4845-bcab-407f002e89b1
fa40e143-9cdf-4688-b773-5bf45742d72e	bithu_11C101	$argon2id$v=19$m=65536,t=3,p=4$ynMPLE/5Dz8lJqrkYWs4AQ$PeCTbbf6h4DXwchMO5VKnWkxPnvb4IoOTqSWpHU2NBI	Thử 1	BT	\N	2026-05-04 03:31:43.879+00	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
16496709-d83d-4bb4-ad19-7d3237853e2d	bithu_11C81	$argon2id$v=19$m=65536,t=3,p=4$2THqj1eLUsvLcMe8S4SSew$rN0lf8Z+V0XEHR8jQ6ELimQ6aA1A0jNWXBykML4BaO8	Thử 1	BT	\N	2026-05-04 03:31:44.429+00	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
a183028d-91ec-4df6-8618-c3ff3317eb57	Quet	$argon2id$v=19$m=65536,t=3,p=4$uTdDfKZp6aZSh6hcx1e5gA$Lh29TBwBBJCh9Q0aBEVHYxW5hBrqxBNWFWfKCaPRqyU	Ksor H Quet	BTV	\N	2026-04-01 01:21:20.059+00	\N
c76a9ace-8cf2-4c87-a204-3b26690ed8c2	bithu	$argon2id$v=19$m=65536,t=3,p=4$8OZ9xEiTtpx5VelSTO9l6A$2UmkfgjM8+tpBAUjUKLqXMHyx1cMtmOAfW7f1GgUBvw	Bí thư- test	BT	12B10	2026-05-09 09:16:53.459+00	44722561-7fa7-44ef-9a26-cdfeb098934f
edfbd9cb-15c5-42f8-b51a-e6d90f02fb0b	Letrungthanhbtv	$argon2id$v=19$m=65536,t=3,p=4$7aDAvPslz8ibeTD/gb9zjg$bQfwrr3EqOBNqZoxgyF77g2nIZNcM5T7qm3gjWtbbIg	Lê Trung Thành -Bí thư ĐT	BTV	\N	2026-03-26 07:42:27.886+00	\N
a9bad279-3cdc-4762-9b5f-cd6d5c1a2608	Leminhphuongbtv	$argon2id$v=19$m=65536,t=3,p=4$Y5lYDc9Had+EJM/PWm5qJg$c8+0lKGVEPdXzzpdycZ0PxEtEIEL7ZARyIXE2HljcBo	Lê Minh Phương BTV	BTV	\N	2026-03-28 22:36:04.141+00	\N
bdbc9f67-cba9-473d-ae13-196065e1fbba	Admin	$argon2id$v=19$m=65536,t=3,p=4$RqimiH+e/jHVLJHaIl051A$gJLELmgI+X9dLd1V8DVI1loZaY7HL5iGKp3eq62fNkY	HHT - QT	Admin	\N	2026-04-08 04:15:26.537+00	\N
fe1ed425-96ce-49db-96b5-57f36b7acd91	Tranthithuytam	$argon2id$v=19$m=65536,t=3,p=4$bkPCIo+4RA3SG6cN1PFGKQ$sXwdHUWz4LBsxqAaQa54NQsVQeTOrhv1HGejsiXVwMM	Trần Thị Thủy Tâm - Phó BT ĐT	BTV	\N	2026-03-26 07:42:51.396+00	\N
4ddeba70-9b17-4e3d-ae90-ba1816ffcc75	Nguyenanhducbtv	$argon2id$v=19$m=65536,t=3,p=4$dDnpDR6ARTsfblW0TOq7bA$9Slsfi2pP5kA2SJIXwy9tr4RASgNHI6hen70+u0aBE0	Nguyễn Đức Anh (Người phát triển PM)	BTV	\N	2026-03-26 07:34:29.394+00	\N
d2b5682e-c0cf-4b5a-8ceb-6632603741d2	Huynhhuuthua	$argon2id$v=19$m=65536,t=3,p=4$0kvR83MxVaqvQ8r93Mkr/A$N4jhlAs+yCLNQlh+jGJJuY82brq+Jda3x39/iS+VX9k	Huỳnh Hữu Thừa - Hiệu trưởng	BGH	\N	2026-05-09 08:58:21.373+00	\N
845094a2-9598-4bfd-92ee-c3c6222e15fd	Hohuuthe	$argon2id$v=19$m=65536,t=3,p=4$e93OnBCM3QW+gaGft0aoeA$HNxw26/1iTuNss1YU+1jl/Qfb35+FexyNfU0K+Je2YQ	Hồ Hữu Thế - Phó BT ĐT	BTV	\N	2026-05-09 09:07:52.736+00	\N
3f1f29dd-7b75-4a94-a85d-149b6ce0c8cd	Nguyenvanteo	$argon2id$v=19$m=65536,t=3,p=4$Bj0HapoiS9UH+WrHcCLSvA$axU8lB87xHPVL7mbYcTFUDuu8Vx9wIbxxg3Z2UzAMTM	Nguyễn Văn Tèo - Phó HT	BGH	\N	2026-03-26 07:41:24.036+00	\N
faf551e3-c757-4078-a239-fa5823211ee0	Nguyengiahanbtv	$argon2id$v=19$m=65536,t=3,p=4$w+X6XyZlE1xqKRaCOb3V2g$oe7AMmeni3pBDapc1WuMe+DhgZPCSTKD10TS7whA+7o	Nguyễn Gia Hân (BTV)	BTV	\N	2026-03-29 07:58:50.656+00	\N
7a498305-4214-41ef-9d00-932f9b62062f	Gvcn_11C8	$argon2id$v=19$m=65536,t=3,p=4$O/ibcfhuAz/zafB5EONxLA$0ohIaBWC9wyWAsc3qQXnKxM6LTRdyww+iw8Iqf2+MFA	Gvcn_11C8	GVCN	11C8	2026-05-09 09:24:59.884+00	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
0be3d7dc-3295-4c28-a53c-37898b806bf3	Gvcn_12B7	$argon2id$v=19$m=65536,t=3,p=4$y+K76rlDgikngMZUNtOBcQ$tfl9GZG0Zj4KHY+b+mkAihi7KEd+xgCqvXhmbrCniS8	Gvcn_12B7	GVCN	12B7	2026-04-06 02:08:04.664+00	33250f94-6931-47dd-ac2f-bb4e8a5535b1
23eb748c-4638-4d08-9dff-577d58f01a4d	Gvcn_11C9	$argon2id$v=19$m=65536,t=3,p=4$holIPrVBuvEpeWWsNeYVuQ$pyZczTGeCk2IzO/LD8bdBxJ3n/21RIcMLxuM3UuEFqs	Gvcn_11C9	GVCN	11C9	2026-04-06 02:07:58.921+00	61a554f0-87f5-4dbd-a152-22cebed82925
aaa99277-b873-4d9e-8ccf-e821661f104e	Gvcn_12B8	$argon2id$v=19$m=65536,t=3,p=4$uFuBqCt0pLf9gKYArqEhzA$6To/ThyquhLLVFmdUH7gx3xvVkYpXRF/X0tUlnDttSc	Gvcn_12B8	GVCN	12B8	2026-04-06 02:08:05.443+00	84ee092b-3b6d-48aa-8324-f4eafda5b546
a2c3971c-a1df-4179-9cd7-91e51fd79bb6	Gvcn_12B9	$argon2id$v=19$m=65536,t=3,p=4$Y0+RJccnCzZH+0CcJfKblw$+/7cDnJng58jWumWXl1iyjkXdXbbC35fPA2UH7wVeCk	Gvcn_12B9	GVCN	12B9	2026-04-06 02:08:06.242+00	539248e4-4825-42e2-b5e1-52dd70ae3fba
d0380e97-0aa5-43c8-bbf3-465c9ac985b2	Gvcn_12B10	$argon2id$v=19$m=65536,t=3,p=4$aoC/Re1ieFTerxYbT3DoXg$0FP/mBvRCJl2igCEggsi+5fas152UXzku7j9szZK40w	Gvcn_12B10	GVCN	12B10	2026-04-06 02:08:00.485+00	44722561-7fa7-44ef-9a26-cdfeb098934f
5b016ab2-a517-4673-a1d5-f48c3cfad6a5	Gvcn_12B1	$argon2id$v=19$m=65536,t=3,p=4$XY1rijgbSztFM2Tm6er5jw$6NsEeJI9M4cs7U6r3lWDDshpTB8Ca4vjolUoXlWANzQ	Gvcn_12B1	GVCN	12B1	2026-04-06 02:07:59.686+00	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
41334668-cf93-439b-9f63-5451a84711f5	Gvcn_12B2	$argon2id$v=19$m=65536,t=3,p=4$KzkLV1ITTCEhRCvDpw+g6w$t4dM2NYnC0k79k+DJEoakuadnlvjZHCTdHP/q3dpg4Y	Gvcn_12B2	GVCN	12B2	2026-04-06 02:08:01.19+00	c9981426-89cd-4565-8c8e-5f1119f30018
9f1bb600-d97b-4c77-a9e7-55aeeb73a909	Gvcn_11C5	$argon2id$v=19$m=65536,t=3,p=4$ddZrtQCmc9JRLkpkGvKtIQ$TEfXDc16+Tqf+I9Z25PARbjMYcTD15Jr87OrCgfuLmU	Gvcn_11C5	GVCN	11C5	2026-04-06 02:26:12.498+00	25d78477-f93d-401d-85b3-3a39ba2e83e7
ac8fe010-035d-414c-8d84-f408c16d6130	Gvcn_12B4	$argon2id$v=19$m=65536,t=3,p=4$ufF/Res94Kiv+LfjYHM79g$bLJRM3aj/UY7IXXDJreSImnfq6/KsIs1YNkg1AshcUg	Gvcn_12B4	GVCN	12B4	2026-04-06 02:08:02.582+00	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
3652fbc6-a99f-4c49-abd6-383a7598d6ad	Gvcn_11C6	$argon2id$v=19$m=65536,t=3,p=4$YyEykb0xgaRPbYehm9jNLA$N6fNvCCVGe1u463ARCssfJyyF28BCinK9cFTomznWMs	Gvcn_11C6	GVCN	11C6	2026-04-07 23:47:58.804+00	1d712008-dda7-4791-8b18-a2078c091830
db0b166e-5d4c-4794-92fa-662a83020db6	Gvcn_12B5	$argon2id$v=19$m=65536,t=3,p=4$IEhHk3gCerD3/xP9fL9vfQ$TKS7GlelDyCojHQ1V8g95yP+9BFbpCJMJSIORFtaMmY	Gvcn_12B5	GVCN	12B5	2026-04-06 02:08:03.268+00	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
6844bb1a-26f0-4b78-bfdc-945937f0b990	Gvcn_11C7	$argon2id$v=19$m=65536,t=3,p=4$reepFJM1RUxaEFig3DhE6g$Wj9sXoKZsXOF6bT8Xb1ZrTevMtpwh1G0RgmtnZfaf1A	Gvcn_11C7	GVCN	11C7	2026-04-06 02:07:57.457+00	0c673b7d-6199-4fbd-b3ce-5a11324113b6
cc0ec485-8a7e-4f88-a4eb-2b76824c7738	Gvcn_12B6	$argon2id$v=19$m=65536,t=3,p=4$mWYkkaQcchKk3JTj6IPQcQ$AWvwyheaXbAa+IkscmQT5AgV82AnEvfkyQkNY4eslTI	Gvcn_12B6	GVCN	12B6	2026-04-06 02:08:04.002+00	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
437a976a-822d-42a0-a8f0-4b78907e752e	bithu_12B7	$argon2id$v=19$m=65536,t=3,p=4$LJYQSjXRrSMgWyEFB56yVQ$UyDCo+zJ46xqXsykMcxz6ua5bu7l3ik8opYagtmEd/I		BT	12B7	2026-03-26 01:46:01.624+00	33250f94-6931-47dd-ac2f-bb4e8a5535b1
27a7d29b-53a3-43e1-a6b0-389dae9e60da	bithu_11C9	$argon2id$v=19$m=65536,t=3,p=4$MqbIBfVZvxa97z7DZKJCLQ$Mc1ZOXzE+W6ehQu61Le4hLT+C+1bp8UCeMCnMvQlgas	‎	BT	11C9	2026-03-26 11:11:10.629+00	61a554f0-87f5-4dbd-a152-22cebed82925
e5c6b90c-1c95-41e3-863f-60646a4546b5	bithu_10A10	$argon2id$v=19$m=65536,t=3,p=4$/pEH6owgFSbrSDinvY7fig$nEPhrx/KpHYDownCj3FUD3xrDY7n8LlyR0G+T60j+aI		BT	10A10	2026-03-26 01:47:06.766+00	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
ef53d6c0-dd33-4d9b-963b-2d6e54e2898c	Gvcn_10A10	$argon2id$v=19$m=65536,t=3,p=4$ITIm9ljG/UqhUazzOSSUvg$gOL+s/HCyj++nRJ8Vd0/77Q/S3fHkOHdK2ckmOHzu9I	Gvcn_10A10	GVCN	10A10	2026-04-06 02:07:42.091+00	b43602fc-3d2e-48a1-b281-4fa1b7aabef9
64d4132b-d465-4d71-8ce4-92eb7b563001	Gvcn_10A11	$argon2id$v=19$m=65536,t=3,p=4$rW6yK8qTrX6XafwtYFwlCQ$zqnHVhZ5HFuD1gIKWibqHnW3bGxz+2v56Fomw6uiqck	Gvcn_10A11	GVCN	10A11	2026-04-06 02:07:43.042+00	87881984-264c-4c97-b336-69ef0999dd67
9faae225-ab41-4e22-b462-3a137401fbc4	bithu_10A11	$argon2id$v=19$m=65536,t=3,p=4$MLDoZZ9arqRjHzqpZsg/JQ$mGCQ2iqo/xzmyAlOEuCKIsf/0NjROs4ah8urKEPW+BU		BT	10A11	2026-03-25 22:50:25.036+00	87881984-264c-4c97-b336-69ef0999dd67
d8f987cf-8769-4de1-b121-e6b65bd23eba	bithu_12B8	$argon2id$v=19$m=65536,t=3,p=4$qyHMBTjDnVjmPFKzFEe0+g$W8C7GkgWwReffvaX6ev2T5/7EmMLjp6veLpHGmQoTqc		BT	12B8	2026-04-01 01:48:58.299+00	84ee092b-3b6d-48aa-8324-f4eafda5b546
6ac940eb-1720-4bc6-b9a0-046728c8e8cf	Gvcn_11C10	$argon2id$v=19$m=65536,t=3,p=4$Xh4ij1J3ZOu9GitdlbSu/Q$j2S95W34nSGsUVI9uvVllWA5Yom9eBp002qemtkPwg4	Gvcn_11C10	GVCN	11C10	2026-04-06 02:07:51.203+00	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
34d551c4-fcbd-48a6-83f6-7597d4ff47fe	bithu_11C10	$argon2id$v=19$m=65536,t=3,p=4$kDTX6Pfsffh4kWdBDgD81g$Lc/tzmPAfLsHmARIgVQ+CMSPDj1V+lNleIWttgBqpiw	Nguyễn Ngọc Tiên Nhi	BT	11C10	2026-04-13 01:41:43.565+00	5ef21e40-6b45-40d8-a24d-6bee8c1f432c
51a97a71-e214-45ab-8e56-6458871ad4dd	bithu_11C1	$argon2id$v=19$m=65536,t=3,p=4$A3XXNTpZA5bf51zYZMZaqA$ZQSM0IylrwQvmF73M9LiAvQRRTjU22VxIvNfiwPtz9E		BT	11C1	2026-03-25 22:50:25.715+00	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
e2b6ba70-07d7-4ff1-bdb4-2da5fbe23bc5	Gvcn_11C1	$argon2id$v=19$m=65536,t=3,p=4$DQU6/3YpM/czmyCu1yXZJA$le2oTTMkls24I0VbATXCY5WfJyeHhMlt3ioFh2QAlcU	Gvcn_11C1	GVCN	11C1	2026-04-06 02:07:50.415+00	f7501580-cc9c-41c9-a00d-0f8c54c13bcb
62af8dea-36be-46bc-9c18-484f72ab0e50	bithu_12B9	$argon2id$v=19$m=65536,t=3,p=4$7Xcd9oalzWnzxsFVOwKRSg$uuLzfv8L1qUPyv6vu1CUzCMfnoIBYKMwXzOcd3aGa/A	Nguyễn Thành Tín	BT	12B9	2026-03-26 09:08:21.479+00	539248e4-4825-42e2-b5e1-52dd70ae3fba
7cdd95f2-0938-4c22-91e4-ed7f4a8d0dda	bithu_11C11	$argon2id$v=19$m=65536,t=3,p=4$hsBXN5UF1e42vzkf/jtPTw$WwuBsKernL+Rv8bUlewnxlRMneGHnEnp5Yb2uqawsis		BT	11C11	2026-03-26 01:47:55.212+00	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
e30070d0-46f7-46d2-b94e-ebe2f72c3609	Gvcn_11C11	$argon2id$v=19$m=65536,t=3,p=4$eLhsl14Vr6jwrktpHJIbZg$CXC7szcdI2iZv7knq6l8oB1jVp0vRIW2YQITUrutbg8	Gvcn_11C11	GVCN	11C11	2026-04-06 02:07:52.008+00	fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa
a640ae9c-f460-45a2-bbce-d695cb8a5a27	bithu_12B10	$argon2id$v=19$m=65536,t=3,p=4$I7Z54mCMJW1b7prOY54njA$7Gnx/875KxojIk5eQgVvkheIzH3G1HKtTgRUSdcZnbI		BT	12B10	2026-03-26 01:49:57.084+00	44722561-7fa7-44ef-9a26-cdfeb098934f
ccaa778a-bd26-4e1a-a93a-e9c76f4e034f	bithu_11C2	$argon2id$v=19$m=65536,t=3,p=4$UxvUSbrNyJuRKA5zUrtcog$l6L832BJY4AMDWShUIVK8IzOU1QOZFaLYveMuB2XHSg		BT	11C2	2026-03-26 01:48:51.313+00	325ddee6-e5ad-47d5-8351-b12c1eb67acc
4d3fe584-d2e1-466a-bb22-7551b2f4bdb5	Gvcn_11C2	$argon2id$v=19$m=65536,t=3,p=4$wz2Lw4H0HWPCzQMIVsKzbg$zIXRCmv6Bia5Y0lx6lCecdrTxmhOjZjgxV5wvPvD4WQ	Gvcn_11C2	GVCN	11C2	2026-04-06 02:07:53.605+00	325ddee6-e5ad-47d5-8351-b12c1eb67acc
a7a41eb7-b7fb-455c-9649-d1b26269cca1	bithu_11C12	$argon2id$v=19$m=65536,t=3,p=4$kFEYeCJRUvBtHaG07EDeiQ$Euh17bWZ8jAGyBEfJK5qC4qtUEo8oDH642PyL2I89RM		BT	11C12	2026-03-26 01:49:04.039+00	450ff56c-ab21-4927-a712-9e9e155646b7
6c78f14e-3fc2-49ba-bfc4-6268080795a3	Gvcn_11C12	$argon2id$v=19$m=65536,t=3,p=4$T85nHpbamAxMnhnbD++IMg$9gDufDQOAkhshbyCFJTJDQCIDjbfIAG1P1CQBtRjJ9w	Gvcn_11C12	GVCN	11C12	2026-04-06 02:07:52.816+00	450ff56c-ab21-4927-a712-9e9e155646b7
8d2acf0d-abb8-41a6-89b2-fa9f16b97236	bithu_12B1	$argon2id$v=19$m=65536,t=3,p=4$tflNqp7LwGXimaImr8SsqQ$Xa8S2XcQrP41nKCvR3rrBSE/V2mOA2IIhLTkM/ZCJ+A		BT	12B1	2026-03-26 01:45:27.42+00	8f89e1c2-c38c-45a6-9dad-b4fdde2153c3
9c05960f-b5ff-41c0-b108-215c607d3ffa	bithu_10A4	$argon2id$v=19$m=65536,t=3,p=4$yHWUTVXNFGY136MCgLS95A$4Lmi6Nu7X7hMaqqw1PTiHHT2VCYpd+amyAeQ6sjNWM4	Phạm Hà Anh	BT	10A4	2026-04-02 14:08:04.987+00	09d8ade5-bb92-46ab-98e7-3ab869d59f75
0c14e308-1dc7-4071-97bc-a47f085d1298	Gvcn_10A4	$argon2id$v=19$m=65536,t=3,p=4$smWczL6N/Q/Y0u9RY+ek/g$w0zj30YDAvu7nt59JDqXR0qWj2pWHnakYk23pqdf6Wk	Gvcn_10A4	GVCN	10A4	2026-04-06 02:07:45.613+00	09d8ade5-bb92-46ab-98e7-3ab869d59f75
103d82c0-7d34-4be4-ac94-6e9376cfd9ce	bithu_11C3	$argon2id$v=19$m=65536,t=3,p=4$VZ1GDASwpOrPN+tYOkqYcg$59m8bDg9Qk90M75IoKKuqnXYdEHj9sIoPrNfEjp9W+s	Phạm Minh Anh	BT	11C3	2026-04-23 16:19:23.048+00	fdc18dde-9e98-4ceb-831f-2944f68998d4
d26b5975-420e-4acd-a23a-7303f6a08b5e	Gvcn_11C3	$argon2id$v=19$m=65536,t=3,p=4$5q/xEPbJkw14v8Futcj/FQ$jNoZB87Y9rhZu7v9v3W7uy510CirqJQh7zzz68tpDoQ	Gvcn_11C3	GVCN	11C3	2026-04-06 02:07:54.403+00	fdc18dde-9e98-4ceb-831f-2944f68998d4
c91ec7de-9f26-4549-bc61-4bc606d736ee	bithu_11C4	$argon2id$v=19$m=65536,t=3,p=4$UqQXg1xoiLEQWJDkuPL2MQ$B3uLX1vqxbZHjMXvWFAPM/cyhqLxNGC6iv6kP4DnRGU		BT	11C4	2026-03-25 22:50:27.773+00	b7b2f041-de5d-49db-8186-5dd8db250052
78a244f5-629f-49b0-9c3a-acf642dd7ab1	Gvcn_11C4	$argon2id$v=19$m=65536,t=3,p=4$rSTNyKf8gRNUsNSOZqb6pg$gOkY+CjUpSfrVtvRNkCMvEhfBsRBby0zX+7xhTA4RsQ	Gvcn_11C4	GVCN	11C4	2026-04-06 02:07:55.134+00	b7b2f041-de5d-49db-8186-5dd8db250052
ab9b81ce-d9a7-458b-9810-5d6e5aa6c271	Gvcn_10A5	$argon2id$v=19$m=65536,t=3,p=4$1PYDc8sykhCDdXYZXOgOeA$jnU/jOHv0fCxTk+08413R/gF/96+UHmIV2m3LZuwqYY	Gvcn_10A5	GVCN	10A5	2026-04-06 02:07:46.404+00	65560ab5-035b-496a-9133-a50d9bf0a0d0
256a15f8-eb31-40e2-b163-d1ed7affdd85	bithu_10A5	$argon2id$v=19$m=65536,t=3,p=4$CRty040B4rQ5pvbv691s6A$Zz12vlfskBKuzXq3CttVMTv6H7IwfOQFWHHL/m0gzr4		BT	10A5	2026-03-31 16:10:47.979+00	65560ab5-035b-496a-9133-a50d9bf0a0d0
11abefbb-e34f-40e6-9dcf-3c13e8bb370f	bithu_12B2	$argon2id$v=19$m=65536,t=3,p=4$jl1wPCJGoIJv7Ss0mXi6BQ$ffG/yzG91o++9Z+uCgdqNIKB2MITli+te1yiF4u/m2Q		BT	12B2	2026-03-26 01:47:58.435+00	c9981426-89cd-4565-8c8e-5f1119f30018
0a95b060-b84f-4448-830b-6bc34d6b56a6	bithu_10A6	$argon2id$v=19$m=65536,t=3,p=4$qPn/AoJvU0yj4VAcSDHpOw$mju2qWuF70QfMKV6Yr6Zbbkev07QzsCfMxhTcT7KxeI		BT	10A6	2026-03-25 22:50:21.553+00	846cdc56-d3b7-494e-b805-6e584dcd9392
0a5e0a1c-1e78-4e21-ae0f-b231f890a42e	Gvcn_10A6	$argon2id$v=19$m=65536,t=3,p=4$bgsHfkuWnmWQ3zZLhNouYA$iVis0qJiQzjRcDtvQQutuwQwmuM8xWmV0tUu5KV01Gg	Gvcn_10A6	GVCN	10A6	2026-04-06 02:07:47.205+00	846cdc56-d3b7-494e-b805-6e584dcd9392
31fac42a-cfde-44bb-a58f-ffa1aad1eabf	bithu_11C5	$argon2id$v=19$m=65536,t=3,p=4$Kv1mbfbiYSL2Ls8wh1S4zQ$7JXQLckscr5glHYubdAsJyyxws/IBUMxV9H4yzGuOcU		BT	11C5	2026-03-25 22:50:28.467+00	25d78477-f93d-401d-85b3-3a39ba2e83e7
77c59f8f-f43b-4762-8f39-e49f8c11c227	bithu_12B3	$argon2id$v=19$m=65536,t=3,p=4$DMD+b2awGzGArajfZwWF5w$7HNbFuELqJx2FhAqX871U7rbFbhc2c4Ia0ZoBRbaPBU		BT	12B3	2026-03-25 22:50:35.244+00	93ed547c-5b97-49e5-be05-b64ade9a6586
3aa4b898-7353-4fc5-9b62-cbd147cd567c	Gvcn_12B3	$argon2id$v=19$m=65536,t=3,p=4$g9WOxM1NvZxiBtYdcgoSpg$jBhUJaQNTe7BpjXynknX516Dx9mNNx/lJwET38JBHk8	Gvcn_12B3	GVCN	12B3	2026-04-06 02:08:01.892+00	93ed547c-5b97-49e5-be05-b64ade9a6586
2c242149-e440-477e-a203-2b92e6fe60d0	bithu_12B4	$argon2id$v=19$m=65536,t=3,p=4$2uU3+ztge/ykHbTWYCQzlw$8fJ4Ng7XfltU2tZO7s8+pIP5hkt/j++TsnSumjsBOms		BT	12B4	2026-03-25 22:50:35.926+00	fce39a4b-0928-4944-b3bf-d8efe09ddaf3
ffca73db-7dd4-4ae8-b2e8-f00e95c23639	Gvcn_10A7	$argon2id$v=19$m=65536,t=3,p=4$Dzg1YtGKRldEpq1kP8HpGw$DIBQ3P++7jVXs7SnIsRAVdJeKUfgCnwNJcsgBbhxc+U	Gvcn_10A7	GVCN	10A7	2026-04-06 02:07:48.009+00	141be337-7bb7-4d92-bd8e-21330ef7702f
694f19ef-c392-40bd-97ca-2f8856567c6c	bithu_10A7	$argon2id$v=19$m=65536,t=3,p=4$3pv1Jp1RPce0QJTYhkyeDg$BPL4sG5+SEWhysUTMGk7NvuR3qTXWRmckjRmw+hFWcs		BT	10A7	2026-03-26 01:56:59.593+00	141be337-7bb7-4d92-bd8e-21330ef7702f
734e9d70-6e1a-4a93-84e5-9d17a246e14b	bithu_11C6	$argon2id$v=19$m=65536,t=3,p=4$JwfdXe1VSp/Ulwkc8pzMgQ$MzQjpZ/mnIOOgAr8sbHLHN5yo8jFH1xyjbZgmSmuDBY		BT	11C6	2026-03-25 22:50:29.143+00	1d712008-dda7-4791-8b18-a2078c091830
77972dca-26bf-4f9e-861d-3292940b3c21	bithu_10A8	$argon2id$v=19$m=65536,t=3,p=4$3GeoPx27U33crGmrrg2h9Q$Fg1omrQdXPHhVrp1jtzxuvnbYs8EO0zIRBJuKxnVAK0		BT	10A8	2026-03-25 22:50:22.949+00	02180031-0a4d-4aa7-b43b-0d3549779653
d746a240-5ea2-4b82-b68c-f44d7503b320	Gvcn_10A8	$argon2id$v=19$m=65536,t=3,p=4$Zm/gHXAoSAhOyJwzcS+hHQ$ef4qaFo2g8Pv904GGHxCSzify+1dvheBM84dX9MdkZA	Gvcn_10A8	GVCN	10A8	2026-04-06 02:07:48.761+00	02180031-0a4d-4aa7-b43b-0d3549779653
6129c974-ea5f-4821-b089-89554b4b8e3e	bithu_12B5	$argon2id$v=19$m=65536,t=3,p=4$TN+S1fbDGXfL26tyRRnfpQ$1Z4Vys9vMAX4pKOnnsRYAA1n8cLeXO1lesdzfUhfsz0	Hoàng Thị Quỳnh Chi	BT	12B5	2026-04-13 10:01:49.155+00	642e5a53-7b49-4a42-8e3b-bd59a55fe4c8
315cca99-e267-48fd-acce-74be2ff037b5	bithu_11C7	$argon2id$v=19$m=65536,t=3,p=4$WuwlC5YtKf5l7fk5IX2DKg$W95oNZ7DZAovgGLR/Y2AQa/rThGXbH34lepjnvYOHuY		BT	11C7	2026-03-26 01:46:55.69+00	0c673b7d-6199-4fbd-b3ce-5a11324113b6
60780226-b402-4d18-b821-745106ed39d2	bithu_11C8	$argon2id$v=19$m=65536,t=3,p=4$bDCtS1TTYPF1cP0RXl1i7Q$wD8xuXTXN6ou+nqJyJFl4E5kFDAmoBEnzLiMkteAXj8		BT	11C8	2026-03-26 01:44:34.537+00	6d3e0c06-4ed8-460c-8ebc-67ade36f0276
49db569c-4af3-4f08-9fae-01b2042d311b	bithu_12B6	$argon2id$v=19$m=65536,t=3,p=4$wKACyI/+euZwb6Ons8qm3A$8aMSrOHn+tBMqo01f+w3wUFswa9xiimo5YOStmSTnu8	Nguyễn Thanh Phương 	BT	12B6	2026-03-31 09:35:59.64+00	1c86cf6e-19bd-42ea-8cb0-8137cb63988a
761742a4-3ca6-4d20-b714-5735209b5668	bithu_10A9	$argon2id$v=19$m=65536,t=3,p=4$Xy8qsmm34klecsGoKi9Xdw$bizlfEC590EXvNxvyNZ+k+4VPmAFGYGnAWNJPRYfYdE		BT	10A9	2026-04-20 06:36:22.075+00	5d2969a5-0d68-4845-bcab-407f002e89b1
0c45a126-18be-4777-804f-a0f9809645d7	Gvcn_10A9	$argon2id$v=19$m=65536,t=3,p=4$cTmo8U/Syg/20SBL4HzOww$1WUwAzzRRODsMov0rGnRZ1yZ0Vj+TKDns9RfZu6yncs	Gvcn_10A9	GVCN	10A9	2026-04-06 02:07:49.609+00	5d2969a5-0d68-4845-bcab-407f002e89b1
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc") FROM stdin;
f227e7b5-d461-473a-98b8-4ed43e475b7a	TC01	Đi học muộn		Vi phạm	2	0		2026-03-27 03:27:21.684+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
a7c8acbe-6275-4b44-9b44-2861c8220254	TC02	Cúp tiết		Vi phạm	5	0		2026-03-27 03:27:22.217+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
7859e009-5ffe-4f07-ae8f-8a3567f17dbf	TC03	Cúp chào cờ		Vi phạm	5	0		2026-03-27 03:27:22.437+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
17e79f77-18c7-4375-99f4-e926b3e70e96	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-03-27 03:27:22.815+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
66819621-23a7-4a5b-890c-14d187b115bb	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-03-27 03:27:23.222+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
0ce2ba3c-82f1-47ef-ae4c-b72d6571e9e0	TC06	Không sơ vin		Vi phạm	5	0		2026-03-27 03:27:23.616+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
186bb01e-3440-41f2-b51a-aac506767f1b	TC07	Không bảng tên		Vi phạm	5	0		2026-03-27 03:27:23.849+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
b9da23aa-6bbc-4aeb-8cb3-e2376d4ad85e	TC08	Sai đồng phục		Vi phạm	5	0		2026-03-27 03:27:24.176+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
62853a7d-98a5-4d19-8d22-a262f0cff4e2	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-03-27 03:27:24.455+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
2ab65d28-61a5-4cfc-8895-e823ef900573	TC10	Không quai dép		Vi phạm	5	0		2026-03-27 03:27:24.863+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
160fe479-8cd6-4d96-8f2a-b1fbfab90ced	TC20	Học sinh để xe không đúng quy định		Vi phạm	30	0		2026-03-27 03:27:26.764+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
35ca3edd-79da-49ee-b42b-3824a14634ca	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-03-27 03:27:28.375+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
068deeab-d18d-4df1-9793-7fd8980bd598	TC40	Đi chấm trễ		Vi phạm	2	0		2026-03-27 03:27:29.899+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
484018b2-56aa-48c6-bcea-acdce91360d6	TC11	Đi dép lê		Vi phạm	5	0		2026-03-27 03:27:25.181+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
e2a9a267-03b3-4bb7-a2b8-479b825c2b43	TC21	Hút thuốc lá		Vi phạm	30	0		2026-03-27 03:27:26.937+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
288e5ad6-ee59-4dc7-8c18-e8f69e1e1752	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-03-27 03:27:28.534+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
4d94581a-aa5b-4b06-8d4a-a801d5186b09	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-03-27 03:27:30.066+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
b3239b98-03e7-4431-aa00-669de580de20	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-03-27 03:27:25.337+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
feebe392-ac90-403c-a6b9-b4ec2d3e4a4d	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-03-27 03:27:27.113+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
a89089c1-f1fb-4ea1-8d75-8041d775939d	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-03-27 03:27:28.671+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
2f03e0e1-5c9e-4992-9571-0510b58ca42d	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-03-27 03:27:30.232+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
b34d683b-ecc4-47ed-9fb6-ea435a2815ea	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-03-27 03:27:25.512+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
512833ab-33c9-4c21-985f-efbb341b4728	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-03-27 03:27:27.276+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
c1beab83-95ed-46d1-abe6-d29be9bc9ddd	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-03-27 03:27:28.81+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
8299c451-bf7e-4070-b77e-6894277f7b99	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-03-27 03:27:30.389+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
c3561322-7a30-418c-8e3b-c4eedeb4aaae	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-03-27 03:27:25.757+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
aee6a59f-62df-42ec-b7ce-16881e6735c3	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-03-27 03:27:27.441+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
51f2556c-557b-4a51-86f4-d8846f2ff1c3	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-03-27 03:27:28.969+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
65ae0928-5d52-4f98-b854-38dbc7d0e06f	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-03-27 03:27:30.546+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
469b66bc-7135-4dc0-9866-9e849cf8cce0	TC15	Sơn móng tay		Vi phạm	5	0		2026-03-27 03:27:25.946+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
3d5db440-ea8a-409c-82d3-031e60e9d20c	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-03-27 03:27:27.625+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
6edfc343-3702-48a9-8241-b65dfcf0f53c	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-03-27 03:27:29.128+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
50d57011-07c8-48e2-a3f7-efcda0f5fa66	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-03-27 03:27:30.689+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
f3d27821-d1fc-4280-97c0-eaadc8311ea3	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-03-27 03:27:26.116+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
b74a2da6-436a-4945-9c36-a3cb505ec19f	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-03-27 03:27:27.776+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
fec831a3-40d7-44b2-9a8a-0178ad6f0b51	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-03-27 03:27:29.287+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
f8335471-9ed3-4fbd-a762-c2a35d7dfc81	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-03-27 03:27:30.841+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
abd9fb8a-c28f-4028-af0d-eb7bf981a6dd	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-03-27 03:27:26.299+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
62a0917b-bbde-44bf-84b1-5e32eb619b3a	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-03-27 03:27:27.925+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
afa978a2-456b-4c3c-beef-3d1cdd2f2568	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-03-27 03:27:29.433+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
f9920d76-b760-4980-87e1-efe2e93373f6	TC18	chở quá số người qui định		Vi phạm	30	0		2026-03-27 03:27:26.452+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
f0db0d72-f917-4323-8828-59f3793bc044	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-03-27 03:27:28.069+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
8d4e49cf-be84-42f8-b28a-6ac9c05466c9	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-03-27 03:27:29.584+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
2bb79d17-8bec-495a-bd11-653b46626a2f	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-03-27 03:27:26.612+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
5041ef8e-50ac-47f8-af0d-8edf8d79d0c3	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-03-27 03:27:28.216+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
f9777ed8-b6b1-42d5-98d9-1c7c6ff00b6a	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-03-27 03:27:29.736+00	HK1	e27632bc-c3ce-41fa-97c8-f525e02b0376
a685b107-0a1d-47d1-bb57-f79a8c47c3df	TC01	Đi học muộn		Vi phạm	2	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
ff2b6e62-ab99-42e2-969a-797a5428d6c2	TC02	Cúp tiết		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
bb06b0cf-7758-48c1-843e-254d63d4e4b2	TC03	Cúp chào cờ		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
0c435c60-b729-4ee9-9565-eb9588027728	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
1065a0b8-4375-4893-84c8-0f0d013c5c59	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
eb0a2a1b-adf4-48e5-9bcb-9c1c9a6daefe	TC06	Không sơ vin		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
085fed03-292b-46ad-a731-81425937f218	TC07	Không bảng tên		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
b96cd9de-8515-42dc-9e5c-7937d82effa3	TC08	Sai đồng phục		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
7c8e8850-9d9f-42b8-af39-4d36c01aad71	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
a06ea414-2dde-4426-af10-101fdd5b2f46	TC10	Không quai dép		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
a52bf37f-4189-47c0-bd7c-e4a2a0e56c64	TC11	Đi dép lê		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
4aafcbef-c2ec-4641-93e2-a69b2246a345	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
1b120598-23eb-4cc6-88e4-42fceaa483f4	01	Nhặn đc tiền		Thành tích	0	9		2026-05-08 12:13:08.798+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
3e4a1829-ff0b-4456-9bab-e8162c922c16	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
e02bcfc8-80c3-45d7-97e6-c3fe87d27322	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
2d7825f2-cb70-4122-8264-7f5d475b52f5	TC15	Sơn móng tay		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
4287e556-9a6f-4197-9d90-757bd10d3380	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
616a5da9-7635-4b70-b4ab-eee77d338b34	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-05-06 23:34:48.913+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
cc3850da-ffed-4d80-9045-7166751b71d8	TC18	chở quá số người qui định		Vi phạm	30	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
b0882fec-1c4b-4d50-828e-07be197bd972	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
8b59f7c9-9a67-43b3-94f4-d87342ec58dc	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
f23535e5-9a4e-4167-a40b-232ce1ded8a0	TC21	Hút thuốc lá		Vi phạm	30	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
04137362-54ed-45c8-a099-fb921aed47fe	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
aa17d0f0-f54a-4c13-8d1b-430690fc4cf4	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
600e13a6-1650-482d-8ac9-72be523166d5	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
b9fb0bbd-f69a-4b69-9acb-3bf415c0867a	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
ace2f1b9-407d-445e-8e82-edd7f74139b0	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
7c4c2079-2c88-429a-892f-2b1a15b1734e	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
582a95da-87e3-451e-8c47-d187d0d960ae	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
2ea1efe0-caa6-4ec5-8f6b-55ea9cc9c5f0	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
f87a19cf-9fc9-4048-b955-9766c6e6d598	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
050dd360-a4df-4631-b2f2-2b8d08ffe903	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
ed72ef79-a805-4837-9c17-669cc8d53b09	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
cbbf7dff-c6d2-426f-8e5b-db4a4d8aaaef	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
a39e4c3e-c129-47c7-8237-fe642ab6ea58	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
d4adca4f-371a-4563-bd44-fdd76c49ce45	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
e1bbb5db-d1f0-47a1-8ae5-6c3817dffc0b	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
702d4110-0157-4cdb-ad60-175cba67423c	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
fb674b9d-e321-42f3-ac6f-bba7596e407f	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
8638d013-3101-41b1-a906-944f08d1d735	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-05-06 23:34:48.914+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
dd909177-91f9-468b-a097-9dae0a3807ec	TC40	Đi chấm trễ		Vi phạm	2	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
4efe1603-146e-47fa-866a-3d488ed5775f	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
3ff683b1-c754-40ba-8221-c80c956f8630	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
7239d327-d8c7-435f-955b-df4864c5fd37	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
e8a155b6-e0a9-4b4b-b533-37063499bde4	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
fe805113-6ace-48d3-a5af-1c5067683b81	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
0e6b57cd-7264-42c6-b7cf-4b287a9015d3	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
88161b13-9dc2-4087-86aa-b49b0ae38482	TC47	Học sinh tham gia đăng bài có nội dung xuyên tạc nói xấu nhà nước, cơ quan chức năng, đơn vị, xúc phạm nhân phẩm danh dự người khác vi phạm pháp luật, gây mất đoàn kết (nếu có bằng chứng).		Vi phạm	50	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
cb11585f-24ab-4cb7-bd05-d2efba5bfaa7	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
f3ee9d46-72a1-494d-b9a4-7ced5a74a298	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
810976d9-8680-4e7b-bed7-c90d936391ba	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
f6214968-3257-4d12-b286-f73db73579f2	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
27e835cd-eb98-40b8-9557-4ff4ce461d90	TC52	Không đi chấm		Vi phạm	5	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
2fcc510d-a06f-471b-b2e7-44e02e5b3a70	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-05-06 23:34:48.915+00	HK2	e27632bc-c3ce-41fa-97c8-f525e02b0376
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "updatedat", "ghichu") FROM stdin;
78e5a384-d173-4b38-91eb-88e5513a1cc5	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	28	2026-03-30	2026-04-05	f	t	2026-04-18 11:21:21.793+00	
6848847d-981e-4fd4-abcf-fc0c456ce34f	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	30	2026-04-13	2026-04-19	f	f	2026-04-20 07:12:32.349+00	
d9e6a1f5-50cf-4685-96d0-66e927db11f7	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	27	2026-03-23	2026-03-29	f	t	2026-04-18 11:21:12.96+00	KTGHK2
855884a9-7c3e-49f2-a575-f5d1925aeb92	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	31	2026-04-20	2026-04-26	f	f	2026-04-20 02:11:25.682+00	
63f4c8cf-8de6-4afc-b40d-68097a2f221e	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	29	2026-04-06	2026-04-12	f	t	2026-04-18 11:21:36.343+00	
43fe87d5-c3b2-4c2c-bcbc-9f91e04ae74b	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	34	2026-05-11	2026-05-17	f	f	2026-05-03 21:04:20.67+00	
e3237a6c-a482-4e44-bb99-86f9e230cb88	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	35	2026-05-18	2026-05-24	f	f	2026-05-03 22:21:14.871+00	
931b8533-b0c4-4146-be83-01b4f0d87520	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	32	2026-04-27	2026-05-29	t	f	2026-05-08 08:40:24.022+00	nghỉ lễ 30.4-1.5
384bf9f0-3544-4ebe-94f2-970710627046	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK2	33	2026-05-04	2026-05-10	t	f	2026-05-03 10:05:17.755+00	
fe30823a-587a-4c9e-8e3d-6db5958c9823	e27632bc-c3ce-41fa-97c8-f525e02b0376	HK1	1	2026-05-04	2026-05-08	f	f	2026-05-08 10:01:44.562+00	
\.


--
-- Data for Name: messages_2026_05_06; Type: TABLE DATA; Schema: realtime; Owner: postgres
--

COPY "realtime"."messages_2026_05_06" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_07; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_07" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_08; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_08" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_09; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_09" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_10; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_10" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_11; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_11" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_12; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_12" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-03-29 11:07:20
20211116045059	2026-03-29 11:07:20
20211116050929	2026-03-29 11:07:20
20211116051442	2026-03-29 11:07:20
20211116212300	2026-03-29 11:07:20
20211116213355	2026-03-29 11:07:20
20211116213934	2026-03-29 11:07:20
20211116214523	2026-03-29 11:07:20
20211122062447	2026-03-29 11:07:20
20211124070109	2026-03-29 11:07:20
20211202204204	2026-03-29 11:07:20
20211202204605	2026-03-29 11:07:20
20211210212804	2026-03-29 11:07:20
20211228014915	2026-03-29 11:07:20
20220107221237	2026-03-29 11:07:20
20220228202821	2026-03-29 11:07:20
20220312004840	2026-03-29 11:07:20
20220603231003	2026-03-29 11:07:20
20220603232444	2026-03-29 11:07:20
20220615214548	2026-03-29 11:07:20
20220712093339	2026-03-29 11:07:20
20220908172859	2026-03-29 11:07:20
20220916233421	2026-03-29 11:07:20
20230119133233	2026-03-29 11:07:20
20230128025114	2026-03-29 11:07:20
20230128025212	2026-03-29 11:07:20
20230227211149	2026-03-29 11:07:21
20230228184745	2026-03-29 11:07:21
20230308225145	2026-03-29 11:07:21
20230328144023	2026-03-29 11:07:21
20231018144023	2026-03-29 11:07:21
20231204144023	2026-03-29 11:07:21
20231204144024	2026-03-29 11:07:21
20231204144025	2026-03-29 11:07:21
20240108234812	2026-03-29 11:07:21
20240109165339	2026-03-29 11:07:21
20240227174441	2026-03-29 11:07:21
20240311171622	2026-03-29 12:35:40
20240321100241	2026-03-29 12:35:41
20240401105812	2026-03-29 12:35:41
20240418121054	2026-03-29 12:35:41
20240523004032	2026-03-29 12:35:41
20240618124746	2026-03-29 12:35:41
20240801235015	2026-03-29 12:35:41
20240805133720	2026-03-29 12:35:41
20240827160934	2026-03-29 12:35:41
20240919163303	2026-03-29 12:35:41
20240919163305	2026-03-29 12:35:41
20241019105805	2026-03-29 12:35:41
20241030150047	2026-03-29 12:35:41
20241108114728	2026-03-29 12:35:41
20241121104152	2026-03-29 12:35:41
20241130184212	2026-03-29 12:35:41
20241220035512	2026-03-29 12:35:41
20241220123912	2026-03-29 12:35:41
20241224161212	2026-03-29 12:35:41
20250107150512	2026-03-29 12:35:41
20250110162412	2026-03-29 12:35:41
20250123174212	2026-03-29 12:35:41
20250128220012	2026-03-29 12:35:41
20250506224012	2026-03-29 12:35:41
20250523164012	2026-03-29 12:35:41
20250714121412	2026-03-29 12:35:41
20250905041441	2026-03-29 12:35:41
20251103001201	2026-03-29 12:35:41
20251120212548	2026-03-29 12:35:41
20251120215549	2026-03-29 12:35:41
20260218120000	2026-03-29 12:35:41
20260326120000	2026-05-03 11:13:24
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-03-29 11:07:19.986384
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-03-29 11:07:20.013179
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-03-29 11:07:20.017897
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-03-29 11:07:20.097159
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-03-29 11:07:20.622223
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-03-29 11:07:20.630588
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-03-29 11:07:20.641979
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-03-29 11:07:20.647677
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-03-29 11:07:20.652654
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-03-29 11:07:20.660073
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-03-29 11:07:20.673859
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-03-29 11:07:20.692666
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-03-29 11:07:20.757269
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-03-29 11:07:20.762235
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-03-29 11:07:20.767263
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-03-29 11:07:20.944514
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-03-29 11:07:20.955467
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-03-29 11:07:20.965666
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-03-29 11:07:20.971212
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-03-29 11:07:20.981453
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-03-29 11:07:20.9865
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-03-29 11:07:20.993933
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-03-29 11:07:21.028096
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-03-29 11:07:21.044403
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-03-29 11:07:21.049974
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-03-29 11:07:21.058404
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-03-29 11:07:21.064792
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-03-29 11:07:21.069209
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-03-29 11:07:21.074012
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-03-29 11:07:21.078587
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-03-29 11:07:21.083136
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-03-29 11:07:21.088878
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-03-29 11:07:21.096871
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-03-29 11:07:21.102499
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-03-29 11:07:21.108148
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-03-29 11:07:21.114418
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-03-29 11:07:21.119708
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-03-29 11:07:21.124114
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-03-29 11:07:21.135386
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-03-29 11:07:21.157554
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-03-29 11:07:21.162121
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-03-29 11:07:21.166646
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-03-29 11:07:21.17123
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-03-29 11:07:21.176242
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-03-29 11:07:21.181547
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-03-29 11:07:21.187118
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-03-29 11:07:21.227439
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-03-29 11:07:21.232766
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-03-29 11:07:21.237486
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-03-29 11:07:21.2672
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-03-29 11:07:21.27285
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-03-29 11:07:25.087069
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-03-29 11:07:25.089842
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-03-29 11:07:25.114783
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-03-29 11:07:25.117684
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-03-29 11:07:25.11957
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-05-03 11:13:12.452636
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-05-03 11:13:12.469465
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-03-29 11:07:25.159066
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-06 01:59:36.853256
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-06 01:59:36.863371
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 302, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 3539, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 83651, true);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_06 messages_2026_05_06_pkey; Type: CONSTRAINT; Schema: realtime; Owner: postgres
--

ALTER TABLE ONLY "realtime"."messages_2026_05_06"
    ADD CONSTRAINT "messages_2026_05_06_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_07 messages_2026_05_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_07"
    ADD CONSTRAINT "messages_2026_05_07_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_08 messages_2026_05_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_08"
    ADD CONSTRAINT "messages_2026_05_08_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_09 messages_2026_05_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_09"
    ADD CONSTRAINT "messages_2026_05_09_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_10 messages_2026_05_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_10"
    ADD CONSTRAINT "messages_2026_05_10_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_11 messages_2026_05_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_11"
    ADD CONSTRAINT "messages_2026_05_11_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_12 messages_2026_05_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_12"
    ADD CONSTRAINT "messages_2026_05_12_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_namhoc" ON "public"."chamdiem" USING "btree" ("namhoc");


--
-- Name: idx_chamdiem_thoigian_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thoigian_context" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_doanvien_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_id" ON "public"."doanvien" USING "btree" ("chidoan_id");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_dotptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_namhoc" ON "public"."dotptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phancong_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_namhoc" ON "public"."phancong" USING "btree" ("namhoc");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_qlchidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_chidoan" ON "public"."taikhoan" USING "btree" ("chidoan_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tieuchitd_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_namhoc" ON "public"."tieuchitd" USING "btree" ("namhoc");


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_namhoc" ON "public"."tuanhoc" USING "btree" ("namhoc");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_06_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: postgres
--

CREATE INDEX "messages_2026_05_06_inserted_at_topic_idx" ON "realtime"."messages_2026_05_06" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_07_inserted_at_topic_idx" ON "realtime"."messages_2026_05_07" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_08_inserted_at_topic_idx" ON "realtime"."messages_2026_05_08" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_09_inserted_at_topic_idx" ON "realtime"."messages_2026_05_09" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_10_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_10_inserted_at_topic_idx" ON "realtime"."messages_2026_05_10" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_11_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_11_inserted_at_topic_idx" ON "realtime"."messages_2026_05_11" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_12_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_12_inserted_at_topic_idx" ON "realtime"."messages_2026_05_12" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_key" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter");


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_05_06_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_06_inserted_at_topic_idx";


--
-- Name: messages_2026_05_06_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_06_pkey";


--
-- Name: messages_2026_05_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_07_inserted_at_topic_idx";


--
-- Name: messages_2026_05_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_07_pkey";


--
-- Name: messages_2026_05_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_08_inserted_at_topic_idx";


--
-- Name: messages_2026_05_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_08_pkey";


--
-- Name: messages_2026_05_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_09_inserted_at_topic_idx";


--
-- Name: messages_2026_05_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_09_pkey";


--
-- Name: messages_2026_05_10_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_10_inserted_at_topic_idx";


--
-- Name: messages_2026_05_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_10_pkey";


--
-- Name: messages_2026_05_11_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_11_inserted_at_topic_idx";


--
-- Name: messages_2026_05_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_11_pkey";


--
-- Name: messages_2026_05_12_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_12_inserted_at_topic_idx";


--
-- Name: messages_2026_05_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_12_pkey";


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_chidoan; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_chidoan" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Admins can view all activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all activity logs" ON "public"."activity_logs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: activity_logs Authenticated users can insert activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users can insert activity logs" ON "public"."activity_logs" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: chamdiem Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."chamdiem" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: doanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."doanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: dotptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."dotptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: namhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."namhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phancong Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phancong" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phanquyen Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phanquyen" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: ptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."ptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: qlchidoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."qlchidoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: settings Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."settings" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: taikhoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."taikhoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tieuchitd Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tieuchitd" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tuanhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tuanhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: github_settings Cho phép Admin quản lý cấu hình github; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: github_settings Cho phép người dùng đã đăng nhập thao tác github_se; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: taikhoan Enable read access for all users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable read access for all users" ON "public"."taikhoan" FOR SELECT USING (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "postgres";

--
-- Name: supabase_realtime chamdiem; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chamdiem";


--
-- Name: supabase_realtime doanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."doanvien";


--
-- Name: supabase_realtime dotptdoanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."dotptdoanvien";


--
-- Name: supabase_realtime namhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."namhoc";


--
-- Name: supabase_realtime phancong; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phancong";


--
-- Name: supabase_realtime phanquyen; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phanquyen";


--
-- Name: supabase_realtime qlchidoan; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."qlchidoan";


--
-- Name: supabase_realtime settings; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."settings";


--
-- Name: supabase_realtime tieuchitd; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tieuchitd";


--
-- Name: supabase_realtime tuanhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tuanhoc";


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "vault" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "supabase_realtime_admin";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_05_06"; Type: ACL; Schema: realtime; Owner: postgres
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_06" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_07"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_07" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_07" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_08"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_08" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_08" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_09"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_09" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_09" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_10"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_10" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_10" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_11"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_11" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_11" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_12"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_12" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_12" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "anon";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "service_role";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "supabase_realtime_admin";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";
GRANT ALL ON TABLE "realtime"."subscription" TO "supabase_realtime_admin";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "supabase_realtime_admin";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict 3HCfSdS47hFWP9u2XTqb4d4QZwG9WMRG5FW0tpzpkwEkfjYrn2nybTlMO9MfLj4

