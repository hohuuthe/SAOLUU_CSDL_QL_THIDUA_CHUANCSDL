--
-- PostgreSQL database dump
--

\restrict 3TLQ8p4wI6izf3fCr4OeYviLoI5XdHktW9MuJKZUXGiV37qB8PdHLQIzLV7Vf3m

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Enable read access for all users" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phancong";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."namhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."doanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Authenticated users can insert activity logs" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Admins can view all activity logs" ON "public"."activity_logs";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_key";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_namhoc";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_namhoc";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_taikhoan_chidoan";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thoigian_context";
DROP INDEX IF EXISTS "public"."idx_chamdiem_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_13" DROP CONSTRAINT IF EXISTS "messages_2026_05_13_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_12" DROP CONSTRAINT IF EXISTS "messages_2026_05_12_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_11" DROP CONSTRAINT IF EXISTS "messages_2026_05_11_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_10" DROP CONSTRAINT IF EXISTS "messages_2026_05_10_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_09" DROP CONSTRAINT IF EXISTS "messages_2026_05_09_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_08" DROP CONSTRAINT IF EXISTS "messages_2026_05_08_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_07" DROP CONSTRAINT IF EXISTS "messages_2026_05_07_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_13";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_12";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_11";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_10";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_09";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_08";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_07";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT * FROM taikhoan WHERE username = p_username OR username = lower(p_username) LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_
        -- Filter by action early - only get subscriptions interested in this action
        -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
        and (subs.action_filter = '*' or subs.action_filter = action::text);

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL AND ppt.tablename NOT LIKE '% %'),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  -- Count raw slot entries before apply_rls/subscription filter
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  -- Apply RLS and filter as before
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  -- Real rows with slot count attached
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  -- Sentinel row: always returned when no real rows exist so Elixir can
  -- always read slot_changes_count. Identified by wal IS NULL.
  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "hocky" "text",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "quyen_chi_doan_phu_trach" boolean DEFAULT false,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "quyen_xem_tat_ca_chi_doan" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: COLUMN "phanquyen"."quyen_chi_doan_phu_trach"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."quyen_chi_doan_phu_trach" IS 'Giới hạn phạm vi dữ liệu chỉ trong chi đoàn của user';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_05_07; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_07" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_07" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_08; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_08" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_08" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_09; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_09" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_09" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_10; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_10" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_10" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_11; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_11" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_11" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_12; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_12" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_12" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_13; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_13" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_13" OWNER TO "supabase_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_05_07; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_07" FOR VALUES FROM ('2026-05-07 00:00:00') TO ('2026-05-08 00:00:00');


--
-- Name: messages_2026_05_08; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_08" FOR VALUES FROM ('2026-05-08 00:00:00') TO ('2026-05-09 00:00:00');


--
-- Name: messages_2026_05_09; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_09" FOR VALUES FROM ('2026-05-09 00:00:00') TO ('2026-05-10 00:00:00');


--
-- Name: messages_2026_05_10; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_10" FOR VALUES FROM ('2026-05-10 00:00:00') TO ('2026-05-11 00:00:00');


--
-- Name: messages_2026_05_11; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_11" FOR VALUES FROM ('2026-05-11 00:00:00') TO ('2026-05-12 00:00:00');


--
-- Name: messages_2026_05_12; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_12" FOR VALUES FROM ('2026-05-12 00:00:00') TO ('2026-05-13 00:00:00');


--
-- Name: messages_2026_05_13; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_13" FOR VALUES FROM ('2026-05-13 00:00:00') TO ('2026-05-14 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
c869d8ce-23e0-47e9-b7b8-7678ddd70597	c869d8ce-23e0-47e9-b7b8-7678ddd70597	{"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": false, "phone_verified": false}	email	2026-05-10 05:19:49.313863+00	2026-05-10 05:19:49.314312+00	2026-05-10 05:19:49.314312+00	265cf928-6816-4b56-9c4e-e63d7c9c6723
39c8bd8e-417e-4f88-bf13-f8800858bdbe	39c8bd8e-417e-4f88-bf13-f8800858bdbe	{"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-10 05:26:03.226927+00	2026-05-10 05:26:03.226975+00	2026-05-10 05:26:03.226975+00	ac6cd08d-29cf-40db-bc4c-dea5392613da
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
5b72536a-9b8e-4162-a0e1-c01a979a8acd	2026-05-10 05:19:49.519185+00	2026-05-10 05:19:49.519185+00	password	aac2f87b-7a9d-4d50-b4a5-8f643b5019db
6f5146a2-99a0-404f-89cd-e13e5ef546ed	2026-05-10 09:33:32.583129+00	2026-05-10 09:33:32.583129+00	password	d9a949ac-9bd2-4249-9c76-c485935714d1
e5cad0cd-81be-43c2-b2dd-8be48aae28eb	2026-05-10 05:26:03.318739+00	2026-05-10 05:26:03.318739+00	password	cec6872c-6b84-4fb3-a6be-0630dd5d4340
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	332	ka3b5frw6pa6	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-10 05:19:49.50707+00	2026-05-10 06:19:59.518231+00	\N	5b72536a-9b8e-4162-a0e1-c01a979a8acd
00000000-0000-0000-0000-000000000000	337	s7g7h3yrjqmc	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-10 09:10:01.022838+00	2026-05-10 09:10:01.022838+00	say47mw2rymm	5b72536a-9b8e-4162-a0e1-c01a979a8acd
00000000-0000-0000-0000-000000000000	333	tlsxwleljedb	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 05:26:03.2933+00	2026-05-10 06:26:13.630216+00	\N	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	338	rlzl5zdixrm3	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 09:13:17.797041+00	2026-05-10 10:12:21.053497+00	xv5brkl5wa77	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	334	say47mw2rymm	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-10 06:19:59.536193+00	2026-05-10 09:10:01.011519+00	ka3b5frw6pa6	5b72536a-9b8e-4162-a0e1-c01a979a8acd
00000000-0000-0000-0000-000000000000	339	3ylhgcfvxaxs	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-10 09:33:32.559501+00	2026-05-10 09:33:32.559501+00	\N	6f5146a2-99a0-404f-89cd-e13e5ef546ed
00000000-0000-0000-0000-000000000000	335	mlsqa4wg3lqc	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 06:26:13.644504+00	2026-05-10 08:14:21.398618+00	tlsxwleljedb	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	340	4bk5ll3rmryq	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-10 10:12:21.067697+00	2026-05-10 10:12:21.067697+00	rlzl5zdixrm3	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	336	xv5brkl5wa77	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 08:14:21.415583+00	2026-05-10 09:13:17.781867+00	mlsqa4wg3lqc	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
5b72536a-9b8e-4162-a0e1-c01a979a8acd	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-10 05:19:49.500233+00	2026-05-10 09:10:01.038338+00	\N	aal1	\N	2026-05-10 09:10:01.038234	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e5cad0cd-81be-43c2-b2dd-8be48aae28eb	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 05:26:03.264427+00	2026-05-10 10:12:21.099561+00	\N	aal1	\N	2026-05-10 10:12:21.099059	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6f5146a2-99a0-404f-89cd-e13e5ef546ed	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 09:33:32.526805+00	2026-05-10 09:33:32.526805+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	c869d8ce-23e0-47e9-b7b8-7678ddd70597	authenticated	authenticated	admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com	$2a$10$yICCU7VKh.xcTxEgXsA12eTwe4J8vVjXQhn0twACSa47wWF8/uXz2	2026-05-10 05:19:49.477261+00	\N		\N		\N			\N	2026-05-10 05:19:49.499915+00	{"provider": "email", "providers": ["email"]}	{"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}	\N	2026-05-10 05:19:49.273939+00	2026-05-10 09:10:01.031421+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	39c8bd8e-417e-4f88-bf13-f8800858bdbe	authenticated	authenticated	admin@gioithieu.com	$2a$10$MVYZSibwWIE9ePWAoyBziOMl53MeSct2CMnIVMGrdO9UKjpFOHG1q	2026-05-10 05:26:03.249173+00	\N		\N		\N			\N	2026-05-10 09:33:32.520685+00	{"provider": "email", "providers": ["email"]}	{"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-10 05:26:03.202812+00	2026-05-10 10:12:21.084597+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "hocky", "diachi", "chidoan_id", "createdat") FROM stdin;
15c6c396-f606-4ad9-bee0-a227846bd947	Phạm Dương Anh	01/02/2010	Nữ	Kinh	Hộ Nghèo	t	\N	17/01/2026	935078895	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai.	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
b931252c-c4d8-4409-9d3d-02eabc642958	Phạm Văn Bé	04/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4,xã Đức Cơ,Tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
d67fd1c4-47dd-4bfe-a034-065ba1e1c77b	Lương Thanh Bình	05/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Đo,xã Ia Dơk,tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
4a03389b-7887-4e36-a280-48b1859c314a	Bùi Ngọc Đạt	08/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân, IaKrêl, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
f1b44aae-bab4-4237-a7a7-f09224d072a1	TRẦN KHÁNH HÀ	02/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Đoàn kết, xã iakla, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
2dfa8382-8faa-43bb-a9f5-ef463475b88f	Nguyễn Công Hậu	25/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
0c66b07d-6b71-4153-b808-f2105d8754ef	Nguyễn Đức Hiếu	21/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
f3d4fb60-b2ba-44d8-a604-dccf1410e5ee	Nguyễn Văn Hiếu	13/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
eb293e78-74f3-4956-984a-4ec747b244bc	Lê Thị Thúy Hoài	09/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
4b2d1983-855d-4202-af97-4253d197bd4a	Đinh Ngọc Khánh Huyền	11/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
420bdac4-d80e-47aa-9c5d-64666f937e07	Phạm Quốc Hưng	25/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
af167c16-11e6-4db6-bff9-b10865dc42ac	Đào Viết Khánh	29/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
b794dd7e-0057-41bc-b3fc-fef6fc87afca	Nguyễn Quang Kiên	07/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Thanh giáo, xã ia Krêl, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
63cb4da9-c135-4241-82fd-bda4f0b434ff	Nguyễn Khánh Linh	14/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
b843e22b-e866-47e6-b526-b7bb968da387	Nguyễn Phi Long	02/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn chư bồ,xã Ia Dơk, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
4b16e2e1-0b3a-4f6e-96fe-a4af8e471478	Trần Đức Lương	20/06/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngo Rông , xã Iakrêl , tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
64a6ad1d-27dd-43a3-9bdd-7e11e501ce97	Hồ Thị Khánh Ly	01/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
b9924361-1b04-4603-ae89-56ef88cdb4c5	Nguyễn Hoàng Bảo Minh	25/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
d3dc6635-68b3-4290-999c-bf035b7e2a9f	Hồ Thu Nga	13/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
d4e35c91-5b63-4f41-aae1-e5473b658c54	Trịnh Thị Hằng Nga	28/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Ia Krêl, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
51d43d04-e624-4087-af22-7953cd2ece42	Nguyễn Lục Ngạn	26/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
933dfcca-3664-4853-b627-bea5517140f9	Lê Hoàng Mỹ Ngọc	01/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
271fdbef-cc7c-418e-ac22-98a4049f71c8	Lê Thị Bảo Ngọc	29/04/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
c56a6efd-2470-4685-86d9-9b1f9f3c24fa	Cao Anh Nhân	24/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
f2392161-5ce9-4239-b970-23ee49459cde	Lê Võ Thanh Nhật	01/12/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
52555a46-137a-47a0-93ac-71c8c2bc093f	Đặng Thị Thu Phương	04/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua - IaPnôn -Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
d5bc1bb8-3a98-49f4-9018-f86ce13d25d6	Đỗ Bảo Quang	07/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
6b62e92f-21b9-4cf1-bb07-b78b6a47022e	Hồ Hữu Quang	07/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
b07135ac-6bf4-4a5f-a77d-779891e1fa79	Hô Khắc Anh Quân	21/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Thanh giáo, Xã Ia Krêl, Tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
a8aacf75-34eb-49f2-bdbb-fbd57631bc5a	Hồ Sỹ Quân	22/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Đức Cơ, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
4a82b6d2-4aa8-42ef-a29b-4c8269a41b32	Phạm Vũ Như Quỳnh	03/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
c71a7dda-7243-4a30-a5f4-c21c105f5680	Nguyễn Ngọc Lan Thanh	07/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
e1f8d831-b566-4526-8848-ef33c96234d9	Võ Hạnh Thảo	26/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
3b7ff4ec-e00a-4dd9-8bec-5a370b1bbaaf	Trần Hồng Thế	24/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân ,xã Ia Krêl, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
8ccbd898-8820-4423-a070-61706f47626e	Dương Đức Thịnh	07/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
987179bd-6fff-4cb5-b1a8-3129583e524a	Phan Ngọc Thịnh	02/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, Đức Cơ, Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
89ba0e4d-84f5-45b9-83d6-7b04ea0119c8	Bùi Thị Lý Thu	05/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua - Xã Ia Pnôn - Tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
5100860e-43e2-477f-9d3b-7be3160c4e73	Hồ Nguyễn Khánh Trang	09/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
c6a8d65d-4cc2-4b01-8db8-12da5c37b069	Hồ Thị Thùy Trang	22/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
85a59cb3-1b79-4155-a891-c321458ac81b	Lê Thị Thùy Trang	25/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1,xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
b374e116-4112-4a40-a136-aedb5b38bd59	Nguyễn Thị Huyền Trang	11/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
5f726187-8c7c-4abd-b3c4-788ad1d5ed50	Nguyễn Trần Huyền Trang	10/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lâm Tôk , xã Ia Krêl, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
37307b98-882a-4bdd-a257-c47cdcb7de61	Nguyễn Quốc Trọng	11/05/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1,xã Đức Cơ, tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
4e935a89-4ef3-41b4-b53b-7547a03691e5	Đoàn Tường Vy	11/04/2010	Nữ	Kinh	\N	t	\N	24/03/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngo le 1 - xã Iakrêl - tỉnh Gia Lai	e32bc02a-8fe4-4b79-88dd-eb3020f764cd	2026-05-10 10:10:12.673721+00
9859157f-f75e-48d9-bcc2-8256e6fca394	Lê Hồ Hoài An	28/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ  3, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
4a9a9272-c3d2-430c-8197-4aa80bd47e08	Lê Thị Hoài Anh	29/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
758f3078-e6ed-4163-8384-cc140113a109	Lê Thị Thanh Ánh	04/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua, xã Ia Pnôn, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
2834850c-be9d-4e51-899d-4276b515d9c2	Nguyễn Quang Ánh	11/02/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
849e8d18-da1a-4a36-b0a6-a695acf9c12a	Nguyễn Tuấn Anh	17/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
676427dc-1569-457d-bcb4-efb002c92bd7	Trần Quỳnh Anh	26/04/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
eb723400-a9ba-45ea-b8b4-d8d63d8e5f52	Phạm Lê Gia Bảo	27/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
7ee15f70-73d3-4047-bc5b-55d6b7c9c4e8	Lường Thị Ngọc Bích	19/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thống Nhất, xã Ia Krêl, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
6435b3a3-c769-436d-adf1-b0d69b96af41	Đặng Bảo Châu	19/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Xã Ia Dơk, Tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
24a29b99-402f-405c-af32-e4a469bebc4e	Nguyễn Thị Kim Cúc	10/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
5a736cdc-2f0e-412f-ba28-ac9db04f94c3	Bùi Thị Thùy Dung	23/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
6433c976-2317-4926-b04e-eb9ba11af962	Hoàng Lê Trung Dũng	30/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
adc7b28c-ec80-456f-9b17-a57db4248ffb	Nguyễn Hoàng Đức Duy	26/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaTang, xã ia Dơk, tỉnh Gia lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
f5f89e18-0de8-43c2-89b5-630024b817c2	Nguyễn Ngọc Quỳnh Dương	14/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
d730f082-c02c-457c-ba7a-88960cec54cd	Lê Đức Đạt	05/11/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
586fd465-beb5-4a89-8268-7e53358c3a63	Hồ Việt Đức	13/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
7cca94c6-2436-4a9f-8616-c311fb6c73cc	Vũ Ngọc Trường Giang	18/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
6e52205e-3804-4cd9-b623-c4788f331458	Nguyễn Hồ Thanh Hà	10/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
6e51e2d6-621d-4c41-a5e6-4c2da4f3786e	Đào Ngọc Hân	24/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
688d1406-681e-4a34-a976-07ef8f08c100	Lê Minh Hiếu	02/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
624182a2-19d1-4e75-a68b-dc53c13070cc	Hà Thị Kim Huệ	01/09/2010	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
31855767-4cb2-4602-b620-4a118e51af9d	Nguyễn Văn Quốc Hùng	02/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
cd0def6d-310e-43c9-8e3e-725d00950d4f	Đinh Thị Nhã Hương	08/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
addeaba2-74e8-4e5d-bd3e-be10e127976d	Phạm Lê Gia Linh	09/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua, xã Ia pnôn, tỉnh Gia lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
7f926ef5-cde8-40b3-8421-c273db00f80f	Bùi Thanh Luân	14/02/2010	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
a345a9c8-1e3d-456b-b7bf-595d5a3ce4a3	Lê Ngọc Hoàng Minh	23/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
cd5255f7-3edc-415c-a18a-871f3ef41e26	Đoàn Thị Trà My	09/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn đoàn kết, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
1e2f3900-72e3-4a86-89fd-169bef4ead6c	Đỗ Như Nguyệt	01/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
982d8b4c-89f6-43a1-81d8-97fc4995dfef	Hồ Thị Như	04/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
a43f485b-3259-4eb4-bfaa-f9659c426836	Lê Quang Phú	07/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk , Gia lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
875f4012-e384-4070-922f-b33ff551575a	Võ Hồ Thanh Phúc	06/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
7d916694-2eee-4d84-a2d9-b03f085f892d	Đinh Hồng Quy	22/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
79f56c3f-21e1-43fa-a372-252832b0e1bb	Lê Dương Nhất Tâm	01/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
defb6bd5-be5f-43a1-80ce-6577104495db	Lê Đức Thành	05/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
d375eb4e-9714-4bd4-b308-a56a4f4585b3	Võ Văn Thành	19/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
4ce43714-11f5-45c7-8209-9a4998a68003	Hồ Diên Thuận	24/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
6c2e73d6-11c6-4fb7-8886-f780567e1d5a	Nguyễn Hoàng Anh Thư	26/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
5a4a3826-ae44-4a82-ac1a-fa86720ed2f5	Võ Anh Thư	18/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Bình, xã Bàu Cạn , tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
46242627-0deb-4628-b533-27cceb516840	Đặng Việt Tiến	31/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
2cec188b-3384-41eb-8ff4-84498e7207ac	Nguyễn Minh Trí	11/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
bfc6f46f-b6d6-4810-a161-017ae412dc39	Đỗ An Triều	01/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
bb0c4e2f-55b8-4714-ab42-64a5a30929bb	Phạm Đức Trung	13/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
c188470a-0578-4547-93d5-596a5bc0565d	Nguyễn Đình Tuân	21/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
bdd51f5c-b28c-4369-a5d4-458ed89ee354	Nguyễn Hoàng Vi	11/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	71aecc43-796f-4f77-8113-57663aa7ba79	2026-05-10 10:10:12.673721+00
88bc5421-990e-47fb-86f7-7b462968034a	Hồ Xuân An	26/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
78da5c0a-6f11-440c-9411-7c211064867a	Nguyễn Trường An	05/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
c459456b-099f-44f3-bc6c-8d52f7952662	Huỳnh Thị Ngọc Anh	13/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
72c74452-fbe4-4b87-b756-9a0c3ea575f6	Nguyễn Thị Trâm Anh	14/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
23cd73c0-2cee-4718-82d8-b801c23af979	Hồ Nguyễn Khánh Băng	17/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
e4f65f80-c31e-46e0-87f1-c0ec27285c26	Kpuih Bân	09/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Klăh, xã Ia Dơk, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
f9010f38-2463-4940-9e42-54f904861869	Vũ Thị Ánh Dương	15/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
d8ed5eae-f27f-4fd2-a80c-e6b7b8bebcd4	Lê Anh Đức	27/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
7e412beb-e5e6-43a3-802a-94771ae1c7fa	Phan Anh Đức	10/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
3f9ea69d-230f-4c3c-b781-af17f683deb1	Lê Hương Giang	07/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
3b5b7eb2-6f0a-4eba-8730-f9a8f15762cf	Hồ Ngọc Hậu	21/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
96faea6f-2dd3-4c44-b36c-fadf43696b1c	Bùi Việt Hoàng	18/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
b91a9e54-b626-4d17-a4b9-414487660b48	Mai Văn Nguyên Hoàng	23/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
9348c89f-7501-4c49-9b0b-fc11ce4ccf54	Võ Đại Hùng	02/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
31e47da3-83ec-49a4-b034-0e010223c572	Lê Thu Huyền	26/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
e7fb60ad-5f37-4f56-b5ae-f71582a7edc8	Nguyễn Ngọc Lan	02/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
bbb29645-a9ec-4675-9131-41c8166cbca6	Lữ Thị Mỹ Linh	20/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
e9a18682-077a-4ec1-8598-54cb79ec464c	Lương Võ Hà Linh	14/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaTang, xã Ia Dơk, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
42eb7463-fca6-4cd4-a6f7-8ae8850905b7	Trần Thị Thùy Linh	03/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
81e1ba28-c519-41be-b909-f31976aaa43c	Võ Đại Mạnh	02/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
367560a4-7b79-4177-a2af-f2e4b7a54204	Nguyễn Thảo Minh	02/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
b73bbf94-100c-454d-9d33-3970b7eba037	Nguyễn Thị Kim Ngân	30/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
4e21bcad-cdc1-4f09-b828-0555df83d538	Trương Nữ Kiều Ngân	08/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
31fe1f33-cb10-4ae5-b989-ea5eef7ca485	Hồ Đại Nghĩa	30/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
090241b4-d533-44a6-9f49-42dcdb992bb6	Lê Nguyễn Hồng Ngọc	29/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
0beeae60-4ff3-4b1a-b3ab-c1417c4ea371	Hồ Trần Gia Như	15/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
a6441538-21ec-4ed2-b195-20d6af7c6753	Lê Thị Uyên Phương	29/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
d171881c-7cc8-42d8-8c46-b2ea33b12d67	Nguyễn Ngọc Anh Quân	10/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
7d32e574-93ae-4aaa-9325-b9acb9795310	Trương Đình Cảm Thái	07/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
bdc02e7d-e144-4903-b802-272a2099e8b7	Huỳnh Nguyễn Phương Thảo	10/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã Ia Dom, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
206c7606-6168-4387-b8ff-45b2e390b674	Võ Thị Anh Thơ	09/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
0aa3f7c9-e7be-4cbb-aa36-122f45e20a77	Phạm Thị Anh Thư	11/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn 3, xã Ia Krăi, Ia Grai, Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
6477422f-2b0f-465a-9fa3-f6fe09f6ce64	Trần Thị Thu Trang	03/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
15d7ed27-a287-4d7b-9ef3-8bad90ff4fd5	Võ Ngọc Minh Trâm	14/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
f394a79c-9f90-48a9-95a9-4371043fc54d	Nguyễn Minh Trí	04/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
cf8916af-f8a3-40b1-a8f0-89483bad4a62	Võ Huỳnh Trung	09/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
d86f2402-4378-46a0-961c-90f329a70390	Nguyễn Khắc Anh Tuấn	19/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã Ia Krêl, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
b81ac705-9381-4dec-ab33-72ba821cfdc7	Hồ Nguyễn Thục Uyên	16/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
cefa0100-a268-4fc1-93c0-a1b0604eef7f	Thiều Quang Vinh	20/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
cd09f753-dc4d-4269-a366-98cf52301bbd	Nguyễn Quách Uy Vũ	23/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
042b35f2-d689-4bf2-9da4-4e7205636304	Bùi Thị Tường Vy	15/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	0486a847-676e-4993-90d5-c90ff8debed2	2026-05-10 10:10:12.673721+00
094c60b6-f21d-4c8c-a543-129546c907ed	Hồ Ngọc Trâm Anh	22/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
204f3c92-19aa-484b-be1f-822808f21c59	Phạm Hà Anh	23/01/2010	Nữ	Kinh	\N	t	\N	25/04/2025	0901910680	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
e3c0d228-4d89-4ab8-ab85-e8a6bf912394	Vũ Thị Hà Anh	17/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
7f0650ea-4cf8-4575-838f-80aace45437d	Lê Thị Khánh Băng	16/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
e24c1489-3397-4c2f-be34-4fd3a50c1ef9	Hồ Anh Dũng	17/07/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
dc49912c-bf0b-4f96-a1e1-5d9da8b1f15f	Lê Quang Dũng	24/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
2e536b51-12b2-49a0-8e3a-7ba4a0b7ee47	Đỗ Viết Đạt	16/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
ed5fc7d9-ce95-4424-b348-af6b32a1c1c4	Hà Tiến Đạt	04/07/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
b30adf40-8365-4fa4-bfc6-5feb050ad687	Đào Gia Đức	10/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Ia Krel tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
b4572736-be60-493e-97ce-cc2a84d7c697	Bạch Thị Ngọc Hà	08/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
d4d93e70-ef92-40f4-8903-206e91f20299	Hồ Ngọc Hải	29/09/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
0e65d1f9-60af-4571-a8e8-e8404d17798f	Nguyễn Đăng Hoàng	10/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
567e8e0c-7186-49d9-94fa-1828b5f7447e	Nguyễn Đăng Huy	12/10/2010	Nam	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
c77abe6d-6b7b-43d0-80e0-cbb59cb826f0	Nguyễn Văn Huy	29/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
799e1bc5-b84b-4b10-9925-10a46c1d540a	Võ Đình Huy	17/05/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	tổ dân phố 7, xác Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
99182111-b810-4caa-a085-120279d008cb	Nguyễn Phùng Tuấn Hưng	09/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đội 12, xã Ia Chía, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
bc6eb8ac-d494-4ddb-b651-0ef866e3574e	Trần Đăng Khoa	28/12/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
de2e1eb8-b6de-491f-915b-d8c27fa866c4	Lê Đình Lâm	02/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
0cf3b87b-fb57-45a5-b1ca-fdc7df7d9e41	Quách Thùy Linh	21/02/2010	Nữ	Kinh	\N	t	\N	25/04/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
1c11e102-57f1-4582-af21-1f31d38b0233	Nguyễn Bảo Ngọc	03/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
a6b9d8a6-343b-4bd8-a036-aea327a89bdd	Võ Trần Bảo Ngọc	03/10/2010	Nữ	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
176f09b0-5a20-4863-9e38-dba1a3c91dff	Trần Đức Nguyên	25/02/2010	Nam	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
c045ce2e-b3ee-413e-afdd-1957956a23b2	Hoàng Mai Nhi	19/09/2010	Nữ	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
874f0e28-ebc7-445f-aff3-315a809f6ddf	Hồ Thị Yến Nhi	20/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng ấp, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
d75e123a-701d-4893-9356-61aa00c86a8b	Hoàng Lâm Phú	10/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bi, xã Ia Dom, huyện Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
592635fc-2d56-44ec-9983-cd624248ef5c	Lại Minh Quang	12/12/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
55746fb8-33c3-4b28-a65e-e54b31bfd10b	Dương Thị Hồng Quyên	29/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
86dbecc7-11a2-4d9f-acd8-6162fee5d8c2	Nguyễn Thị Như Quỳnh	14/02/2010	Nữ	Kinh	\N	t	\N	20/04/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
a71d384b-2c79-4517-b2f4-6feacefdcd3f	Hồ Văn Tài	22/02/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
b8cc08be-415a-4829-b3a5-e1af755ccc71	Trần Thị Tuệ Tâm	03/05/2010	Nữ	Kinh	\N	t	\N	26/03/2024	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai.	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
476dc48c-e50c-4e2b-9dc7-9d538d87a1cd	Võ Lê Thanh Thảo	02/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
32758f3d-abc1-46ce-a924-ae48181fdaa9	Hồ Diên Thiện	30/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, xã Iakrel, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
b32e7c57-ac5d-4c97-aa87-8a3cce53470e	Võ Hoàng Ngọc Thiên	07/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ấp chợ, Xã Thống Nhất, Tỉnh Đồng Nai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
9a7fbd52-3e26-4936-9b7c-2847001078fc	Võ Huỳnh Thiên Thư	04/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
082048ed-bcbe-4c21-8d8e-fdab2badffaf	Trần Trọng Tiến	11/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
7c957d39-bdb3-48de-82b4-54f1f0e01682	Võ Văn Tiến	01/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
2b0cd9b8-ede7-4acf-a964-5b15c3c6054e	Nguyễn Thị Thảo Trang	22/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
4526a91e-e5f1-474a-b619-8796e1b6cee8	Nguyễn Thị Thùy Trang	17/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
b92534c5-eb63-49ff-8351-22b4d6ede071	Nguyễn Ngọc Quỳnh Trân	25/08/2010	Nữ	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
97d5864e-a822-451b-b39e-c16a58526788	Phan Văn Trọng	28/04/2010	Nam	Kinh	\N	t	\N	25/04/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
fdd73380-cf88-4df5-a17b-aff0d8f6b3d3	Trần Văn Trọng	09/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
6a3d3408-8e28-4d76-b005-674734f8d7c3	Nguyễn Huỳnh Như Trúc	27/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
60af6ab9-db76-4496-9ba6-96600f3c8717	Trần Đỗ Uy Vũ	23/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	7cbf7380-c57c-430c-a810-957d07ae3b31	2026-05-10 10:10:12.673721+00
28fda8be-8774-49ce-8e0c-70872107ac58	Mã Quỳnh Anh	29/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
2b65206e-7380-4cd5-aeeb-9880a7924731	Nguyễn Thị Mai Anh	24/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
8433565a-1274-4072-853f-d2b8bbeef5ad	Nguyễn Ngọc Bảo Châu	10/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
058d7799-4828-46db-af1f-28d87c39fd10	Rơ Lan Chun	31/10/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le Kắt, xã Ia Dơk, tỉnh Gia La	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
fb5bc503-94e8-48af-b34e-f289158e96a1	Kpuih H' Han	10/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
4d1ef33b-c5ea-4ccb-aef8-97eb0952d4cc	Nguyễn Thị Minh Hằng	01/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
01664b27-9e7c-4ec2-874e-27e654fc387a	Phạm Công Hậu	02/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo. xã Ia Krêl, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
d0509a17-1a82-4272-806a-0eed98236bd2	Võ Xuân Hiền	09/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
31dcfbfc-26ca-4b5d-9b41-79dff5ede6c5	Hoàng Thị Thu Hoài	02/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
3e80776a-b190-4848-8176-e379b2b3e797	Lê Đình Huy	24/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
00621d64-9f23-4fe6-8f10-55eebde69a29	Trần Thị Khánh Huyền	07/12/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
337ff4c6-67e9-45f8-bd2d-9b4dd19277db	Lưu Thị Phương Khanh	22/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
2c7552bb-6116-4619-9f25-d999db8bfab1	Phạm Ngọc Cao Kiệt	20/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lâm Tôk, xã IaDơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
0f56f858-a61a-4dbd-8589-bc9039e27654	Kpuih H' Lăk	10/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, xã IaDơk, tỉnh GIa Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
54a32706-6ba1-486c-983f-4a355f4d472a	Rơ Mah H' Liên	07/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong, xã IaDơk, tỉnh GIa Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
65cf051d-447d-4a9d-89f9-aa4c4bef2099	Bùi Thị Khánh Linh	09/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
9690e02d-6614-4a71-8f24-1165893c9d4d	Đào Thị Thùy Linh	20/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
8cd33f56-eaea-442b-be28-d5e3725ab03b	Hồ Thị Mỹ Linh	07/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
1020d3ee-e402-4036-9057-432cdc5f7c4d	Lê Hoàng Kiều My	07/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
dab5e183-33d7-44a2-a77a-d8afabad7aac	Nguyễn Hà Thảo My	02/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
5d32e4be-1734-43ac-a389-f302ba7cf98d	Rơ Mah H’ An ne	12/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le Tung, Xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
e01934ae-4351-4032-bb0a-568173fb2b99	Nguyễn Thị Tố Nga	01/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Grôn,  xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
009706e1-4e5f-4718-b025-3ca34ca480d9	Hàn Thị Hồng Nguyên	15/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
b5f0cb5d-ad3a-4607-a3f1-09f361d68fde	Dương Thị Như Nguyệt	14/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
a7f6d33a-105f-479b-a4ce-3d6ea1496f31	Nguyễn Thị Quỳnh Như	11/06/2010	Nữ	Mường	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
caee3feb-f2a2-4bed-ace6-8412d346535e	Ksor H' Za Ni	21/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, xã Ia Dơk tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
597a29b2-d324-447a-b83d-df56624c269f	Phạm Thị Oanh	18/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
5d45d69c-235b-4f73-906e-d8b412051e75	Mai Tiến Quân	19/04/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai,xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
92cc29fe-dc1c-46bd-86ed-9ab95b24328a	Rơ Lan A Sở	05/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
bd07ef7f-ee20-485e-b8f6-ecaf6215e247	Trần Văn Thái	25/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
6a485cb3-a80d-41db-b711-d2b950a71147	Hồ Thu Thảo	12/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
d548360b-7666-4195-b496-aab20fb7bfe3	Rơ Lan H' Thiết	27/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Đo, xã Ia Dơk , tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
56dd4d44-3910-45c3-b8b7-d1291bb8d11a	Rơ Mah H' Thủy	26/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kắt, Xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
c3063c7c-bf5f-4108-920a-6d275706feda	Trần Vũ Anh Thư	16/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
b766ddbf-3b37-41bd-98bb-d5c164c4c97d	Rơ Măh Thương	11/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
25268626-e4fe-470d-aedb-c46a0a108e94	Đinh Thị Thùy Trang	24/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
399152a8-566a-4a36-a7da-fe45e92b5611	Hồ Thị Huyền Trang	26/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
9fd4d0ae-a318-4a0a-862f-e6ad80e25343	Hồ Thị Ngọc Trang	20/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
bd2c669a-b141-4a7e-93e9-086912687b13	Kpuih H' Trinh	26/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Đo, xã Ia Dơk, tỉnh Gia Laỉ	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
901f40d7-0d93-4962-bed0-2a49f90f44b9	Rơ Mah H' Trinh	19/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
dcb33590-adab-4c42-8cf0-dce74aed6e45	Nguyễn Ngọc Trung	21/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
5e36e361-576f-4521-8fda-6c20541b794f	Hàn Quốc Tuấn	11/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ , xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
3e048495-d832-4a3d-8559-0620138871c1	Kpuih H' Yên	06/08/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
06bf25f0-aa52-4aa5-b3a9-3bb0826069b7	Trần Thị Bảo Yến	27/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
4e51ec62-f28c-4452-8cd0-deee275aa3e2	Trương Thị Hồng Yến	27/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai	44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	2026-05-10 10:10:12.673721+00
b4a716d5-2831-45d5-b9dd-54a7ceacbfba	Lê Hồ Lan Anh	22/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - xã Iakrêl - Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
6936da25-ecbc-42b3-ba6e-f6d629a0c791	Lê Thị Mai Anh	08/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl,tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
2673a315-fdf0-4b51-adff-ec10da3c0145	Lương Thị Hà Anh	25/12/2010	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
926fefce-2ba1-4e89-8e58-4bfc896e1948	Rơ Lan Anh	12/02/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè- IaDơk,Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
0dd46b67-b16f-40d3-ab71-b15d2393b46e	Rơ Lan H' Bích	20/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le, Xã Ia Dơk, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
faefcd44-d72a-4af2-b5ee-7ff743f79720	Nguyễn Hoàng Hân Di	22/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7,Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
99ec468b-52d6-44a8-8cb5-df1ec9edfd0b	Đàm Thị Thanh Hà	04/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
151b1743-4a6d-459d-8202-c000e6af0618	Lê Minh Hoàng	18/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
d453f3d7-7c05-4fd7-b95c-e7c8791d9235	Nguyễn Việt Hoàng	18/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
189e0f95-eab3-44ff-b8f6-f8474e110e92	Nguyễn Thị Hồng	21/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
e9aa98b7-0e0d-4dfe-a787-07690706b603	Hồ Viết Tường Huy	18/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaMang, xã IaDơk, tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
036b9187-d3e5-4b63-8fe9-6385143a73e0	Hoàng Thị Thanh Thanh Huyền	24/03/2010	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Đức Cơ, tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
d39df0fb-e536-47f7-8afe-e8422093d8d8	Rơ Châm H' Huyền	19/03/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang, Ia Dơk, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
3789fe2d-3601-438b-8cd6-01a55de8a18e	Hoàng Thị Cúc Hương	08/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
3d01430b-4a90-45a1-aa28-fec2efa99324	Lê Đình Khánh	30/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
01ff985b-2d03-44db-9a18-3f06c89d41a4	Nguyễn Duy Khánh	06/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl, IaKrêl, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
058b55de-0cda-408b-a18c-4355675f1ab0	Ksor H' Khuê	10/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krol, xã Ia Krêl, tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
6e2ce31b-d6de-48fc-b644-ae7a59d591f0	Nguyễn Văn Quốc Kiệt	10/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
e7cc5468-6a0e-412f-9727-b603189c4b00	Bùi Thị Mỹ Linh	05/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
ba3b0e40-76a4-4696-a597-e9146f0880d6	Rơ Mah Thị Thanh Mai	14/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, Xã Ia Dơk , Tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
4ea46e25-ad17-4ef8-8d78-a71bd1498c71	Rơ Châm H' Mẫn	20/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong, IaDơk, GIa Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
3736cf38-a197-4509-aae7-1ed8d5a4ad5c	Nguyễn Hoài Diễm My	24/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Đức Cơ , Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
7883c08a-580e-482a-8501-2662abd9d046	Nguyễn Phan Trà My	06/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố , Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
b4a0d7c5-7851-49df-aac6-c124c73337c8	Nguyễn Thị Thanh Ngân	31/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngole, xã Ia Krêl, Tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
89b053a8-8242-4346-be14-cf0944a6f66e	Hà Như Ngọc	12/01/2010	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đội 8, xã Ia Púch,tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
bced5be8-9d83-4c89-8e9b-ceea2cbaf0b4	Nguyễn Thị Thanh Ngọc	28/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân, IaKrêl, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
a8ab0e0b-7c9b-41fe-8b60-a2ab2a7e29ca	Nguyễn Sỹ Nguyên	16/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	\N	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
ce10c457-cd5f-4ba8-b9dc-9a9438a7eb2c	Kpuih H' Nhanh	24/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk - Đức Cơ - Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
a38a833b-b46b-458c-8efd-e1987d71aa77	Nguyễn Ngọc Bảo Như	11/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
e7da27e5-0a90-4dfd-b6fc-bb2ca717da22	Đinh Nhương	26/11/2010	Nữ	Ba na	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, xã Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
674d9d5f-e4ac-4686-b9f1-bed6d04cc512	Nguyễn Thị Như Quỳnh	22/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iamang, IaDơk, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
528289bf-8b08-4d16-ae6b-48dcaec07120	Rơ Mah Y H’ RiLa	28/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung le - Ia Dơk- Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
ac2dab6f-30f0-48dc-a9d1-4070ac757e6e	Rơ Lan H’ Sương	20/12/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Le 2, Ia Dơk, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
e1ce9933-3449-494a-b89d-ffd1d3aaf1c8	Nguyễn Phùng Thành	18/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
19346a25-8273-469d-a6f2-0385268c7f0c	Lục Phương Thảo	18/01/2010	Nữ	Sán Dìu	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Iadơk, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
fcd60293-354b-4382-8671-fe9f37c436f3	Đậu Thị Anh Thư	02/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm, Ia Krêl, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
04b0f6fa-54d1-4dc7-933c-37ca7f2c3965	Lê Thị Anh Thư	28/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, Đức Cơ, tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
e28e9ad5-cbbb-4216-abca-ad63b58bc5a7	Rơ Lan H' Thư	17/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
2a1d7b76-20c3-4c9f-a13a-0a95b2cbd115	Trần Anh Thư	24/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Đức Cơ, tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
bf45f266-3c85-4701-bf08-165cb5a626a9	Rơ Lan H' Thương	27/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung Le - Ia Dơk, GIa Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
1d4653a0-a314-4fa9-9b29-5b50a74d0fe8	Ksor Nguyễn Tráng	29/04/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Mới, Xã Ia Dơk , Tỉnh Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
80912106-1e80-4637-8070-080bdc373ed6	Rơ Châm Vũ Bảo Trang	17/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngo Le 1 - Ia Krêl - Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
e65d0ee0-6ac8-48c6-8078-18788b18e192	Kpuih H' Trâm	22/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
140c1651-0b1f-4b30-9bb7-253a6fe86df9	Hà Bùi Cẩm Tú	17/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, Xã Đức Cơ, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
98615676-3542-45c2-b070-a3f01f688af1	Vũ Hoàng Minh Tuấn	16/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim, Ia Dơk, Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
553e9543-a7c2-4760-889b-e3c999692bed	Lê Thị Hạ Vy	11/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Hợp Nhất - Ia Hrung - Gia Lai	1a7fa50d-808c-4664-b089-da58329a9210	2026-05-10 10:10:12.673721+00
37959452-917c-4f03-ace8-3c756769a18a	Ksor H’ Lê A	23/08/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le kắt, xã Ia Dớt , Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
6d8dc9ec-2e80-4910-93c4-ebafd950018d	Đoàn Thị Ngọc An	05/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang, Ia Kla, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
c1f1a897-9c92-42e9-8751-48c2a9d966b4	Bùi Gia Bảo	17/09/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
0d1b0c16-e6af-4958-bd4f-1f35b952a59e	Siu H' Xim Bi	13/03/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung kép , Xã Ia Dơk, Gia lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
44aef34f-d49a-4ad2-825b-b585302f1642	Phạm Khánh Chi	19/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
f2fdf43d-8c17-4432-9664-0952d906e913	Ksor H' Giang	23/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, Xã Đức Cơ, GIa lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
0a621af5-2673-4f3f-bd2d-e9bf7e5ff67c	Nguyễn Thị Trà Giang	13/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
07fab9cd-4f53-464c-8a07-00c854f13e67	Rơ Mah H’ Grinh	05/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung le - Ia kla - Đức Cơ-Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
40284f65-a1c6-4298-974f-75a0a0ad73a1	Hàn Quốc Hải	13/02/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
cf2d02dd-3257-4775-ab79-a0eef58025ba	Dương Bảo Hân	12/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
e8ea44fd-d61f-456a-8541-f5b45bc529ce	Nguyễn Phi Hậu	20/08/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
1e036392-dd0e-4405-a8b7-92fa6f5c9a9d	Trần Thị Ngọc Huyền	04/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
81494a39-8a40-49ac-9ff1-3f2a06d8de60	Lê Thị Thu Hương	24/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl - xã Iakrêl - Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
69dd9f7c-ab6b-42c2-9f1a-adf79e3334bd	Lê Hữu Khang	13/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
2d97397a-67bf-49c8-87b9-86463d1af746	Trần Văn Khánh	29/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
4bfb5111-6de8-4d43-9369-3b4bffab0237	Mã Văn Kiệt	12/11/2010	Nam	Tày	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Grôn, xã Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
aed25be4-e3cb-41ed-a62f-d28c8b16ae9b	Kpuih H' Lin	02/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Ia Dơk, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
0714f7f8-89f7-41ab-9c7b-0a20ee89d84c	Chu Thị Thanh Linh	07/12/2010	Nữ	Tày	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl, xã Ia Krêl, Tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
2ce35a98-103c-4f4c-89fe-31fd25af9df7	Lê Thị Thùy Linh	04/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
9f7b72fb-4bd1-4724-abaf-04c86c5bc5e8	Nguyễn Thị Thùy Linh	28/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
9cade83e-2e15-41da-9b83-ad3342b58604	Trần Thị Khánh Ly	09/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ I, Ia Dơk, Gia lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
073621bd-754a-43fb-a219-8cdbae11953d	Lê Thị Trà My	21/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
620eb581-62b7-4044-81fd-f067cbad851b	Nguyễn Minh Nguyệt	14/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
7e644e32-c417-4823-8844-42622082976a	Kpuih H' Nhuy	11/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
d5c22368-628e-429c-b9ca-74bee1ad59a2	Siu En Ny	28/02/2010	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, xã Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
862910ef-e3f4-48b1-9e69-bcc7ea989d0f	Rơ Mah H' Quỳnh	22/04/2010	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
77df502a-9d52-41ac-952d-3bb63f6faac4	Kpuih Sữa	06/05/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, IaKriêng, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
8a563f0c-2275-44c9-b5a2-03cc6d7ad1f1	Rơ Lan Lê Thành	16/08/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, xã Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
8cc4bd92-52de-4076-89f9-e73ac0351fdf	Bùi Thị Thảo	12/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 , Đức Cơ, Gia lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
9b8d368f-5f18-4c95-9508-cf793dc27102	Hoàng Bá Thiên	21/06/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl- xã Krêl, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
aea180ed-77cc-4fb7-8557-4fd023cdb468	Dương Thị Thanh Thúy	29/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
d6d7d55a-76b8-4992-9330-2d5628e101dc	Trần Thị Thu Thủy	27/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim , xã Ia Dơk, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
ee6200ae-e51b-47d7-9f39-346f7c5502a6	Nguyễn Lê Bảo Thư	26/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, xã Ia Dơk, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
e211c3eb-4277-4288-812f-e72943ffa642	Nguyễn Ngọc Anh Thư	29/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
f6e5fdee-7a46-4834-8e49-a25643584842	Kpuih Y Lan Tina	02/05/2010	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, Ia Dơk, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
3f3b0871-9119-4f8b-89d9-6c15a0e4eeaa	Lê Viết Tình	24/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl, xã Ia Krêl, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
c0e93810-410b-4c74-a371-95d6b9137636	Nguyễn Bảo Trân	04/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
34bafb8a-001d-427a-89e4-d8b71125e313	Lê Đình Anh Tuấn	22/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, xã Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
f3d7680b-6b93-4ecf-8817-54aa4601d664	Rơ Mah H' Ury	01/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung Kắt - Ia Dơk -Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
50e5935d-5e87-4328-bcd0-fc17903bd2e7	Lê Thị Phương Uyên	04/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
7f2a86ab-e65a-488a-81a8-abb04cb039ce	Đặng Thị Thảo Vy	14/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Triêl- Xã Ia Pnôn - Tỉnh Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
6d604198-6246-4ce6-89fb-9137fc4da9a7	Rơ Châm Zaka	04/11/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, Đức Cơ, Gia Lai	b9ec8215-b493-4870-8316-34a4fad30aec	2026-05-10 10:10:12.673721+00
bdd377e8-1e1a-41f0-a919-53cace549810	Vũ Ngọc Bảo Anh	09/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
46e3c47e-b4db-4f06-a8e1-b9a5bdf877b9	Nguyễn Sỹ Thế Bảo	17/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
802b070e-519d-48dc-b9a0-3167dd6092b4	Nguyễn Thị Diệu	22/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
97f72c42-c340-41eb-a76a-3eb731e448af	Rơ Mah H' Đa	15/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
ec83f288-d593-4cee-ac44-406ec1b88bd2	Ksor H' Đuin	23/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
b6e03b85-1a17-4819-b98c-5af3cdf232c8	Nguyễn Thị Thanh Hà	11/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
1fba6932-aed7-4007-854d-04087becf284	Rơ Mah H' Hạ	18/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
0ee86563-553c-4f07-8496-25f9de02c3c8	Nguyễn Dương Thanh Hằng	24/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
9136f16b-ffa5-435c-b048-95626f7daad4	Phan Thị Thu Hằng	17/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
6b4cf943-1631-4a99-9091-0ed26ee7832b	Nguyễn Nữ Bảo Hân	15/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
af5e7944-67a7-4876-a0be-7d80ca38ee5d	Nguyễn Đình Hiếu	09/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
5040fa2a-cfc4-4466-b161-0056595afefe	Trương Văn Hiếu	05/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
c0b4d246-b6ca-4ace-9027-4a0f62ce55f3	Trần Đức Hoàng	08/06/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
7f6ae738-e981-49ad-ab6a-c0328ac3d67d	Nguyễn Lê Thu Huyền	13/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
38d32a93-467d-4ef0-818e-3e73f671fe64	Trần Ngọc Huyền	02/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
edb2be55-447f-4128-a707-525c0b37aa8c	Nguyễn Thị Hương	24/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
8d604549-582a-4cb7-8c6b-a45ddac42398	Rơ Mah H' Jin	26/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
abc84f40-c98a-417c-a596-375339762ff6	Nguyễn Nhật Kha	01/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
408f42cb-1ff2-4e64-80b0-fbc9eb6ac943	Rơ Lan H' Khuyên	30/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
5b077355-8d4e-4c0e-8b16-5fbaf0fd7bc8	Trần Doãn Kiên	20/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
5fd97d71-7646-44c9-9a2d-62dc80e778e8	Ngô Thị Kim Luân	08/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
b8fb5bea-ec96-4eb4-b341-44377b2ae366	Nguyễn Thị Ly Ly	12/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
89b2e96a-5769-454a-aa89-0160113eb42b	Phạm Gia Minh	23/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
c1d203e0-f366-4b48-b5a2-364cb37717cd	Đoàn Văn Nam	22/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
9df266ec-98ed-48b0-a5b3-8b9919d93af7	Trần Văn Bảo Nam	22/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
7d79b145-e995-4c92-b700-ac33351897d8	Kpuih H' Ngon	17/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
1cc587a5-ace0-428d-9b07-7a5a8e4ed370	Đỗ Bảo Nhi	13/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
ce0b35d5-866e-499c-99b7-e155ad7f231e	Ksor Hà Nhi	01/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
21a129a7-4783-4d82-9b12-2e3d46c1a699	Vũ Thị Tuyết Như	07/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
8d8df962-388a-41d8-9780-0fc6d8a38d85	Lường Thị Kiều Oanh	03/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
65cf3ef0-0e27-4ca0-9a12-10d83d117c79	Rơ Lan H’ Rubin	08/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
743dfbb5-f221-4eb3-bc17-2376f62f6c1e	Kpuih Sái	11/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
2b190ab4-360b-4f45-9137-fa31a232a6df	Kpuih H' Sen	28/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
6406dcb7-9904-471f-8a79-2061e35657b8	Rơ Lan H' Siu	13/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
6e95ba5b-129f-40ad-8bad-a219910229b7	Rơ Mah H’ Sôri	12/06/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
00cba152-122e-4250-b520-2b2636d4a322	Đặng Phương Thảo	30/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
63aac62c-1fb4-43e2-98b4-326f04a33ace	Phan Thị Phương Thảo	21/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
ed087aa7-29bd-4e91-bb81-a5c204c39b01	Hồ Hữu Thắng	16/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
207561fd-43f4-4496-b815-cd4cb1780bc6	Kpuih Thuy	02/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
066f7bc6-d850-4a94-831b-b34100971ddc	Rơ Mah Phạm Thị Thương	21/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
2786d667-998f-4d19-a697-a9c3407f8b81	Nguyễn Duy Tiến	25/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
0f1e90e5-8696-4d4e-b6b2-8baeaddb2a60	Đặng Thị Huyền Trang	17/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
2aebfed3-3d4a-478e-82ad-0235e38b2cf5	Mai Giang Tuyết	11/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
925bcfcc-3b86-482c-b2ac-7a139fe6c746	Kpuih H' Uyên	29/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
1c1b9516-e4cf-40b9-8d64-694b1e4d0d6c	Nguyễn Thị Hải Yến	24/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	1803c151-2cf9-4bc4-9963-7fa7c1591ee4	2026-05-10 10:10:12.673721+00
2bec6313-caac-4ddd-9fd6-23f0bdc593bd	Rơ Lan Kim A	04/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép -Xã Iadơk- Tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
1243c766-6400-46fb-bf09-34050ea2f555	Dương Bình An	02/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ dân phố 7, xã Đức Cơ, Tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
5df0c650-1b25-42e5-af15-70a55d6d816f	Lê Hoàng Anh	21/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
c7f0e44e-afae-4f87-a844-e2157c829b9c	Lê Khả Tuấn Anh	26/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
be2f57a1-f788-48b5-a11e-87f71abfda73	Lương Thị Ngọc Ánh	09/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
8defb6ad-4d2f-4ff9-8289-54cf41129ee7	Nguyễn Xuân Anh	21/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
77408d64-89ad-43f1-881e-d3c4b6a6b42f	Rơ Lan Anh	04/04/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, Ia Kiêng, Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
55fb6def-d442-46f8-bbc8-13da3993591e	Mai Thị Anh Đào	14/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
61150d59-ff12-4b4f-a720-169960dfde28	Kpuih Hải	04/02/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, Iakriêng, Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
796237a1-083e-4da0-b322-c49098eafe91	Đinh Thị Hằng	26/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
bd5da377-494d-4452-a602-4fbdda355db7	Ksor Hân	19/01/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krol, Xã IaKrêl, Đức Cơ, GIa lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
216e5164-4217-4572-ab36-cea05f3d9db9	Võ Hữu Hoàng	28/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
0f1f8347-8eb9-4f64-b592-75a80b0d3b8a	Phan Lê Quốc Huy	03/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
a93aa90f-5b52-433e-a0d2-ee80a7c091f8	Rơ Lan Khiếp	02/04/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông xã Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
b554cd0d-d6ea-4886-8bd7-5221aa5434c6	Khuất Anh Khoa	05/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
4a74987d-a24c-4f39-8288-f7a39d8884d1	Nguyễn Trọng Khoa	07/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
d080a451-696d-4d25-ad3d-1e06ba922656	Bùi Hữu Kiên	19/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
499a18b1-afa6-4b2c-83b3-c6ca62b4e294	Nguyễn Tuấn Kiệt	07/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
079b0ede-d11a-4e0e-933a-ef70bc17338e	Đặng Hồ Phương Linh	30/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
0e341fe2-c9fa-4d0f-945c-a69222fa6f11	Nguyễn Thành Long	07/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
2dca4ce5-f5b1-4827-9725-f19f33064462	Trần Thị Ngọc Mai	10/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
f188233d-8ed1-49e2-b8b8-7d1ab780e9e0	Trần Văn Mạnh	10/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
2b6ca6d5-4c3d-44e2-8ebc-f1cb36855c57	PHẠM TRỌNG BẢO NAM	11/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đội 15, Xã IA Púch, huyện Chư Prông	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
7c38b149-71f2-43ad-b0e7-53e01df4d50e	Rơ Lan H’ Nasi	10/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le - Xã Ia Kla - Đức Cơ - Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
26928dd5-004d-4cef-b739-75a4f25be0c3	Rơ Mah H' Ngiêt	17/03/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Ia krêl, Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
9d3c3f12-b431-4b41-9689-d31b61b2e5a9	Kpuih Nguyên	19/01/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Trolđeng, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
79159cce-271b-4c4a-b558-8751f601a8b6	Hồ Trọng Nhật	18/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
a2250daf-cd29-482d-9da2-7ee0f80ece0c	Mai Võ Yến Nhi	23/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
778607f4-3dc2-4ece-b96a-73778fbe30b0	Nguyễn Đình Phong	15/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
0cce0fd0-5cb8-408f-96f6-5b7f3868cf86	Lương Hữu Phương	13/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iatang, Ia Dơk tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
e267c979-889b-4ae7-9465-1b44b9ebf1ec	Trần Anh Quân	21/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
727a0292-6d37-4195-99ef-d974ccc336da	Rơ Mah H' Sarina	25/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung le -Iakla- Đức cơ - Tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
aa270eb0-bb0e-4c61-b025-3077ce27cb0e	Hà Ngọc Thành	13/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
2f74fbbc-3b5c-4467-9629-07e85fc4ddc7	Nguyễn Thị Thảo	04/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
fab5a6e1-db35-4915-bdf6-277535c76eb0	Vũ Thu Thảo	28/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
ef276cd0-8df8-4432-b9a0-acc224cd44ea	Bùi Sỹ Thắng	05/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
5057675f-c6c9-4f70-8a37-e4fd9a06485e	Rơ Lan H' Thư	10/12/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
26caf2e4-1897-41e4-b1a0-b6943569c023	Đào Nguyễn Lâm Tiên	29/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
aead5d11-71dc-41d6-b4c7-8ef4c509b614	Nguyễn Song Toàn	07/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
55817c6f-84c2-4b88-a104-5e3297ff399e	Võ Thị Kiều Trinh	25/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
278f8a43-9016-4ed0-9ab0-5bb3e457d832	Lê Trần Anh Trung	20/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk , Tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
e919ea99-f90a-4356-8701-1bbfd0ee7fb8	Nguyễn Thị Cẩm Tú	03/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
46c5b2d3-ad07-4b6e-92f9-bf88c3c99eb0	Phan Đình Tùng	21/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Chư Ty, Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
76bc3b0b-fb14-4917-bb17-74e18487c078	Kpuih Lan Văn	24/12/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, IaKriêng, Đức Cơ, Gia Lai	d711c8db-37c2-4444-8b55-68c90e3e1522	2026-05-10 10:10:12.673721+00
68f731b6-3c2c-408e-946e-4c6ae44c9707	Nguyễn Hồng An	20/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ I, IaKLa, Đức Cơ, Gia lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
84ff78d3-3f50-4241-9ab0-7ab353a2a1e5	Siu H' Beo	19/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, Iakriêng, Đức Cơ	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
5caf69e2-ea0f-4526-89d7-2755728dcd33	Nguyễn Đinh Ngọc Duy	26/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Păng tul - Ia Dơk - Đức Cơ Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
dd422a26-5294-4a84-849c-54b2b80f6e3e	Đoàn Hà Giang	16/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
78f7ab5f-d650-4fac-bc4d-526559425e08	Nguyễn Thị Thu Hiền	06/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
7b028905-7f39-433f-9a10-2acbbf042455	Cầm Trung Hiệp	14/11/2010	Nam	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
cf05e00d-153c-4ce8-bdec-6b7ebb79d318	Nguyễn Khánh Hoà	08/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, xã Ia Krêl, huyện Đức cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
befeadbb-a3a2-4e52-bbae-f68a7bd02978	Nguyễn Nhật Duy	08/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
4c81e89b-12b3-457e-b1fd-f6031093f7de	Trần Bá Hoàng	09/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
2e83f270-d9fc-4b82-b3f3-718f2a087032	Rơ Lan H' Hường	27/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Tung, xã IaKla, huyện Đức Cơ, Tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
aa061ac8-b711-4bd6-9e35-0d99a139b8ef	Võ Trần Gia Khánh	31/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
9c9286cb-1775-421a-99f8-f73b8b940900	Nguyễn Vũ Tuấn Kiểm	01/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
c5e7df78-1e6c-4fe2-92ac-8505c494afd6	Kpuih Kiệt	26/02/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Grôn, IaKriêng, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
d457cf15-58f8-43b0-b356-df187ac0c8c0	Rơ Mah Kiệt	09/12/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
c02e619f-0a95-46d2-9849-fc11dab1ae05	Hà Thanh Lâm	25/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
38ec9c70-c8f7-4bf1-a3cb-309a3ca1ff6e	Vi Thị Phương Linh	17/11/2010	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaTang - IaKla - Đức Cơ - Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
0c64ef23-0b03-4b8e-8a92-124ed1c7924a	Phạm Sỹ Hoàng Long	08/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
b2aa5c9c-b240-433b-9cea-14c11fe9de9e	Rơ Châm Thảo My	10/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
5e970142-6b33-49e9-9441-4093301f3f9d	Lê Bảo Nam	10/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Iadơk, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
676bb0f9-4765-4def-8cc1-aa6588753044	Phạm Quang Nam	01/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
857c2dd1-d87b-4d47-ad9c-9d56ec6a1bba	Nguyễn Hoàng Bảo Ngọc	17/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
2061de9f-c0a4-45d4-a82f-76ff9d25c623	Nguyễn Thị Bích Ngọc	09/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã Ia Kla, Huyện Đức Cơ, Tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
b7fff42c-e203-4b43-b368-6064cbe8addc	Phạm Thị Như Ngọc	09/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
869f6f63-51cf-4cdb-a4d2-f9676f2e2b89	Hồ Thanh Nguyên	15/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
260bcd29-7135-4e4a-83de-fe8d7f2342ab	Rơ Mah H' Niê	27/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, Xã Ia Dơk , Huyện Đức Cơ , Tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
f4a95402-03c3-4a27-8c0d-5f1653914924	Nguyễn Thị Diễm Phương	09/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 5,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
e84c9284-58c3-41db-a919-22a4d909a201	Ngô Trí Quân	13/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Kom Ngó, Ia Chía, Ia Grai, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
1aed6787-fb74-4c4f-a836-19a79a6157b9	Trần Đức Quân	19/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	\N	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
e99cf442-e41b-4b2c-b8ff-a1c68490c44b	Kpuih H' Quế	28/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Trol Đeng, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
a79ed1c2-a8f2-4d0e-895f-b571197af656	Lê Đình Tài	23/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 1 Chư Ty , Đức Cơ , Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
dc7130ce-9db0-4ec4-b881-6aca1ac3e82e	Nguyễn Thị Hồng Thắm	08/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã ia chía, Huyện Ia grai,Tỉnh gia lai.	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
a6a7eed4-0d01-436a-b6f7-9892b96e2f22	Nguyễn Xuân Thắng	06/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
4c1edf43-67b5-44cf-865a-c3cdeebaf338	Nguyễn Hiền Thu	10/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
c2cf9a1f-82ed-46aa-9e0b-e41907a974ac	Hồ Thị Ngọc Trâm	11/12/2010	Nữ	Kinh	\N	t	\N	07/09/2025	0343400608	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
53a4faaa-e5e3-45a9-8e89-c812adcfc655	Lương Quốc Trọng	16/11/2010	Nam	Tày	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, IaKriêng, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
6311da1b-baf9-4aa2-b03c-4a91352fc898	Kpuih Trực	15/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung Tung - Ia kla - Đức Cơ -Gia La	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
64887886-b5c3-4483-93f5-65a2a0ec6149	Hoàng Anh Tú	07/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaMang -Iakla - Đức Cơ Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
d817ca4c-b4e4-4fbe-a670-71a5e51e5899	Lê Văn Tuấn Tú	19/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iakăm, xã Ia Krêl, huyện Đức Cơ, tỉnh Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
e5d60860-c2f2-4c65-ab44-36d971ebfb1a	Rơ Mah H' Viên	02/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong, Ia Dơk, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
abb38191-4721-44d6-9c15-e8b09c97f74b	Phan Quốc Vương	03/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
b7df2c56-658e-4b78-b16e-1130f7d6c93e	Rơ Mah Xâm	28/09/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung kép 1 - Iakla -Đức cơ -Gia Lai	e4722370-a8ce-4512-8a49-3288b7618899	2026-05-10 10:10:12.673721+00
1e17cdd6-e673-48e0-95ce-abe2becbbd0c	Hồ Thị Nguyệt Ánh	30/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
e1118942-bc45-4481-a4b5-bdc8e5ce491c	Lê Thị Mai Anh	19/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
79c7c12d-8dcc-4d6c-a0f4-e283079c2595	Rơ Lan H' Bạch	14/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
b936add1-fd93-41f3-b420-376b9fe5a34c	Cao Trần Gia Bảo	21/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
5732fe3a-e5e7-40bd-ab59-99bbb58fe2a6	Hà Phạm Gia Bảo	28/10/2010	Nam	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
9a262319-2aca-4e5a-bfe2-b21f48b15273	Rơ Mah H' Chúc	28/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
386b9ddb-e895-45c0-a140-89c5e4675a16	Nhữ Thị Kim Dung	27/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
c2cab951-8d6f-4e91-aa4e-e6435aad2691	Kpuih H' Dương	18/08/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
2431ac3b-da62-486b-ac39-6a562864f244	Rơ Lan Điệp	14/06/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
d93d7e35-6a61-4793-b7e7-98f1f73d58ce	Ksor Đinh Đức	24/08/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 8, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
9e635dca-2e1c-4403-b356-c6f1b76e5b06	Nguyễn Thị Khánh Hà	09/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
521bcd5d-d361-4ed6-821e-cf4a1a6e86c0	Nguyễn Diệp Hân	13/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
cb319d63-278b-4829-8c56-ac21369d26f0	Hồ Thị Như Hoa	21/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
235af115-1084-4f32-a474-700124854182	Hồ Huy Hoàng	30/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
d1568012-1dfc-4a38-a749-c6c6fe47f3eb	Lương Hoàng Huy	18/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
18bf336f-3043-4347-a1d9-522a7e34a64b	Nguyễn Hữu Huy	06/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
8ed1505d-3489-48ee-9ca6-5f5b3a93dd5a	Lê Thị Lưu Huyền	28/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
e2d6a076-1367-4701-a1f5-fb7317f742af	Rơ Lan Khàng	02/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
16085063-e50d-47fd-9406-089b6311d6b5	Rơ Lan A Khiển	07/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
e130d1c2-bf46-4137-bcb2-34b034c97267	Kpuih Khruin	20/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
f517bc01-1af9-4932-bd6e-33aee4fe7e1c	Cao Thục Khuê	14/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
69ffaabf-a5a0-4c15-8b2b-ae74615b8ac9	Hoàng Tùng Lâm	12/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
98183191-40f8-4717-9d8f-975ab7773582	Phạm Nguyễn Nhật Linh	30/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
5cedcd1e-693f-42ff-b3f4-3773bbdaaac1	Siu Phương Linh	31/12/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
d9f38db5-6273-4034-ab5e-67a6467d7163	Nguyễn Hoàng Minh	11/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
10fbe102-c23d-41c0-913e-931fe774fc94	Trần Nhật Minh	29/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
9b01bc49-4ff3-4ee7-b265-5e82fe6c2411	Nguyễn Văn Bảo Nam	24/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
fc3e88f5-56f4-492b-bba0-949b52b93f81	Rơ Mah Nguyên	17/12/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, xã Ia Dơk, tỉnh Gia lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
7b991cb4-fc46-46db-83df-cb752f5e0358	Võ Phước Nguyên	20/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
c5980b2d-baf6-4217-8d7d-952eb291416a	Ngô Quang Nhật	09/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
22a8e856-a820-44c4-a5e8-51ac9b5ece5d	Hồ Hữu Minh Phong	05/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
51676fa3-bcba-4360-9621-3f8757b759b7	Hoàng Minh Quân	18/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
f3733371-077f-4577-880d-8201a2a85b16	Lê Thế Quý	02/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
bca0df87-9322-4041-8dbf-c713d0f0c0fa	Hồ Viết Sỹ	01/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
25caa4cd-53e5-4db7-8b4e-e446537cf36d	Bùi Sinh Thái	01/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn 9, Xã Chư Prông, Tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
45b46602-6fee-4883-8bfa-b966eba4f090	Mai Thị Thắm	11/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
e953dd21-a3b0-49a4-b11d-0dbea941ad3a	Kpă Tiếu	08/05/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
3ac7d8f8-ec16-4406-bc7a-65f91f7d9231	Nguyễn Vĩnh Triều	12/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
2a86aec8-372f-441e-a399-2f75a458b935	Hồ Sỹ Tuấn	06/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
a6ed8bd1-5c44-4f25-af8b-a05b1cae812f	Tống Minh Tùng	20/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	391e11c8-13ff-4f6a-bfab-f00158b3a5b3	2026-05-10 10:10:12.673721+00
083d3abc-2165-4ae3-a435-6bc0caeb6919	Hồ Thị Lan Anh	29/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP6- Đức Cơ- Gia Lai.	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
61d258a3-f256-4e56-a01f-736755f02b66	Nguyễn Mai Công Anh	22/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2- Ia Dơk- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
177c74d8-8246-4675-833c-f478ccf0119e	Nguyễn Thị Hoài Ân	20/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
9b332643-3374-4659-bd18-520a4851db77	Nguyễn Đình Gia Bảo	08/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ialâm - Iakrêl - Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
a4b34cb1-52cf-447c-8257-9033e4873cd2	Phạm Ngọc Chính	14/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung kép - Ia Dơk- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
b008f710-d4fc-4836-9446-c924076fda1d	Phan Minh Cường	24/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
4be82665-7fd8-41de-aebb-6eea3a6dd20a	Đào Tuấn Duy	29/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
1323f5a6-8443-4b61-b205-19345209c252	Bùi Thị Thùy Duyên	01/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP6-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
dcb9e6fd-fe93-4c90-9349-1ff4fc58e2a0	Nguyễn Tấn Đạt	26/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP4-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
df16cfc6-1047-42c2-9bea-e8600fda17a0	Nguyễn Hải Đăng	29/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
adef6ec4-a045-482b-85e3-00bb2c7ab6a5	Vũ Minh Đức	02/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung kép - Ia Dơk- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
c457cab5-d526-44fa-acb2-699b1d7fb4ee	Nguyễn Thu Hà	23/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
80d0c2ca-0a33-4af7-bec5-57fafd2ca210	Lê Khánh Hằng	09/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
bad84492-9ef0-490b-ae09-f42257cf8ac5	Diêu Gia Hân	01/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP9-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
3a6f6125-41d5-4ae5-a3e5-3c1205c33293	Nguyễn Thanh Hiền	05/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
f384599b-39fa-40d2-b27e-82e57bb17f73	Lê Phạm Công Hiếu	08/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
dedc8280-86b3-4e37-8e31-1b9e898cc5aa	Lê Thị Ánh Hồng	08/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
de6b19b2-382d-4df4-aec4-39ec5f9f9005	Lê Quang Khải	25/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 6, Đức Cơ, Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
0e12f13a-7774-4201-b973-38d505c29251	Nguyễn Đức Nhật Khánh	09/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP6- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
b897bb46-6d4e-4a37-a0a5-97f1b9ae1cc8	Nguyễn Phạm Phương Linh	02/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
412fb5a6-4015-4512-ae8d-170ec956dc13	Bùi Văn Lộc	27/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm - Ia Krêl  - Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
016ca56b-46ed-460d-9f77-c15bb1139e0f	Văn Tiến Mạnh	12/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
60cb8830-b0ff-42a7-85de-c8623a6c5515	Đào Quang Minh	19/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
6efc9879-b06a-41a8-8ca8-829f9487deef	Phạm Thanh Bảo Ngọc	11/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP6-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
5fc59e73-714e-4fd7-a9ea-2e276fe40370	Phan Bảo Ngọc	21/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang- Ia Dơk- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
372c280e-4103-4e88-9d46-4e0c1d066dae	Trần Bảo Ngọc	11/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
9a832311-a731-4f3c-a8e6-9cb8d052ab97	Phan Trần Gia Nhi	02/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Giáo- Ia Krêl- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
834a1a12-76a0-4efb-9d28-d92ce0ebd802	Bùi Nữ Vy Oanh	16/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP4-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
e85044c0-c016-49d4-bf9b-c6c28fdada61	Nguyễn Tấn Phát	29/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP6- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
45a67f64-1770-4bb8-964d-f46bc633523a	Lê Minh Phương	05/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP7- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
caafed30-0a3f-4d86-a6be-ebf5cddda857	Nguyễn Ngọc Nhã Phương	28/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Chư Bồ 1- Ia Dơk- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
424e6aa9-a709-4ea0-a938-e3dea3f9af46	Cao Nhữ Hoàng Quân	13/09/2009	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp -  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
bbdacd9f-612f-4b12-a8f4-dd32490e7f04	Hoàng Thủy Tần	16/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP7-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
4663a7c2-1df4-4d08-96ea-ce1b176c8838	Cù Lê Gia Thanh	04/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Lâm- Ia Krêl- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
25220206-a094-4327-984e-a8ad515ff46b	Lê Thị Ngọc Thư	06/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol- Ia Dơk - Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
4215d63c-c253-49dc-b36f-7dd4bb97e8db	Nguyễn Thị Minh Thư	17/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP6-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
7c410511-5ee8-4aa0-b543-e130e4375fb1	Đặng Đình Tiến	17/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua- Ia Pnôn- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
9993a664-96b8-4300-bae5-0332cdf488a1	Nguyễn Huỳnh Yến Trang	06/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP3-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
d60440b4-6c5c-4478-b8a6-26989365a49a	Nguyễn Hoàng Bảo Trâm	03/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
bbebdbc6-7d89-4287-a8e2-41ba92d7f430	Võ Hồ Yến Vi	25/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP1-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
6778d35a-f8f0-4210-9bbf-f519e6933091	Châu Ngọc Như Ý	18/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2- Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
f7c9ac62-5939-4112-8965-25292af58884	Nguyễn Ngọc Như Ý	28/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
1e44f01d-8b3a-4e3a-b1a1-2fe0adc8b1e0	Phan Thị Yến	20/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP2-  Đức Cơ- Gia Lai	05e16768-764d-4f10-92d9-192fa5e1c673	2026-05-10 10:10:12.673721+00
0f3bef78-2afe-4a61-865f-df2eaa61c934	Lương Kim Anh	18/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
720894d4-0576-4d56-bb5c-530bfc5eda17	Nguyễn Hồ Quỳnh Anh	14/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 7 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
53153455-d0b0-48e3-9d6c-2811f2a45063	Nguyễn Thị Ngọc Anh	05/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
28c857a9-80dc-4b0a-92ac-8c6fd03ed0b6	Bùi Công Gia Bảo	21/09/2009	Nam	Kinh	\N	f	\N	19/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
8145ad96-60b1-4539-9ee0-18e829eede5f	Mai Nguyễn Quốc Cường	08/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lâm Tốc, Iakrêl, Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
775ee65f-5847-40cf-8494-e7dcc3a78281	Hồ Ngọc Diễn	17/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 7 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
1891299b-574e-474b-820c-6360f9b35cd3	Hồ Nghĩa Dũng	12/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 9 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
b26f02b5-1391-4454-bade-ba0703d164f6	Nguyễn Thị Hồng Duyên	21/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
14c5ebe3-36e3-47f9-a02d-8ee32bcd92c9	Nguyễn Quang Dương	24/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Ia Dơk- Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
b062496c-b466-4f55-89bc-c89843f09ff6	Nguyễn Việt Đức	27/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
324b1bd6-c239-455a-a2f1-a134d6b811e6	Lê Thị Việt Hà	22/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
64583b06-94c7-4753-a2b2-e53635487632	Nguyễn Hoàng Thu Hiền	22/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 1 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
c1683121-a7e0-4a54-9fe6-7da25f18bb90	Hoàng Văn Hiếu	13/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
843cd596-ceb6-4efc-942a-caa6487405df	Phan Nguyên Khang	08/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 3 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
3a0a4b4a-637f-4775-bb34-e889eefb3a54	Phạm Đình Khánh	02/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 2 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
b5e77507-5889-4e8b-beee-bb256e4d5838	Trần Thiên Khánh	16/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 9 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
b22bbdac-d967-4738-bd05-f0ff3d42cf1f	Nguyễn Anh Kỳ	28/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - xã Ia Dơk - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
017cd65a-9b7b-4b2c-87e5-b74aaab2b78d	Phan Ngọc Lâm	03/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 1 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
ee8dedb3-63bf-471c-b749-a966471d8c5c	Thủy Ngọc Lĩnh	14/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
28eb9df6-04c8-48c3-be82-b11ab63fef4d	Phan Minh Bảo Long	07/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	681 Quang Trung - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
e97a6c74-5a3c-4e7a-bed5-bf9f2d1ecace	Trần Lê Xuân Mai	25/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
ea58d257-4c81-45d5-8f85-b6a3bce497e0	Hoàng Văn Nam	17/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
a9b17a7d-43f7-4ba4-a1d0-6c938f0a4e25	Hồ Minh Nguyệt	29/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
b9f9e5e7-345f-4856-b2ee-fc52fa864704	Phan Thanh Nhân	15/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 1 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
9855ec9c-3d2c-4d2e-969f-133132c13fc1	Nguyễn Thị Yến Nhi	27/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 7 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
d431bb0b-c01c-45d3-adac-7feb6c6bd94e	Nguyễn Yến Nhi	03/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
ddf35602-ac55-41e1-b2b2-de30e56ce6fe	Ngô Thị Tuyết Nhung	06/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
fe7d76f9-7793-427e-a91b-356aa996fc5a	Trần Gia Như	03/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 4 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
c694edf0-eaae-4fae-b85d-8c8a99d6a5e1	Nguyễn Thị Kim Oanh	15/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - xã Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
5237aea9-fc6a-40d9-bf76-3ea3b6f64e4d	Trần Gia Phát	26/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 1 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
82166dbe-ac0f-4ec5-a4e4-894a056c6c81	Nguyễn Thị Diễm Quỳnh	21/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Ia Dơk - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
d9238671-220c-4257-bc24-8acb6bce4eba	Nguyễn Xuân Sang	30/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
7e4f691e-e209-4f5f-a1e8-6af3299b1326	Lê Ngọc Thái	05/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 7 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
89f10288-f562-4a60-b990-8208dc2a1d24	Bùi Thị Anh Thơ	23/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
e1da19de-2bbe-4dde-a234-6a7f4e569018	Trịnh Tâm Thư	11/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 6 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
59869e53-1a8a-4c9b-aebe-0bd1d97eb5e7	Vũ Thị Thùy Trang	09/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - xã Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
8cf8d561-f86b-4b31-a21e-48bc0dc79793	Võ Hoài Bảo Trâm	01/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 1 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
f431baeb-e723-4180-80fb-86f34ea6eb53	Nguyễn Phan Bảo Trân	25/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân  - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
b5df5631-d57d-4a94-9916-a7bc83977c06	Nguyễn Phạm Đức Trí	04/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Ia Dơk - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
e2b2c051-7228-487c-982d-be2f799c80f5	Lê Hồng Trúc	11/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Ia Dơk - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
7b6290e4-4c0e-47ec-9821-ac1bc36d19ae	Lữ Thành Tú	30/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - xã Ia Krêl - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
0b3d759b-426d-4c1e-802c-8f8affbebab9	Lê Anh Tuấn	27/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 4 - Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
de067cfd-3b93-43bc-a5ac-7cebed285591	Trần Nguyên Tuấn	14/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - xã Đức Cơ - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
a06e46c9-d64b-4052-bf71-beff133ff52e	Cao Đăng Quang Tùng	06/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết  -Xã Ia Dơk- Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
347e4139-a1ea-4271-bb31-94bc3ab154b4	Vũ Sơn Tùng	10/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Klăh - xã Ia Dơk - Gia Lai	302f5070-e9c3-4687-b8f5-5be8c273ee6b	2026-05-10 10:10:12.673721+00
41fe4ad5-3756-4d40-af59-a968b77596ad	Đàm Quỳnh Anh	01/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
c372bb52-7cad-4ab7-b8ee-e80e48cc8efb	Phạm Minh Anh	17/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2 - Xã Đức Cơ-Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
8035e319-5243-420d-a8fe-51c88e58d50b	Trần Gia Bảo	13/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
0d1c7d23-2535-4a79-8c55-d87909106b33	Hồ Ngọc Bích	02/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
559fa34e-59ef-4f1c-8db9-30b352217cb5	Lê Nguyễn Giáng Châu	11/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
468be6e4-8325-4471-b3f0-b9adaba83e48	Nguyễn Đình Dũng	15/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Iakrêl, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
c02a41e2-544d-4671-91fe-c80a98029c3c	Lê Đình Đại	30/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, Xã Đức Cơ, GiaLai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
ac6b1a29-0f50-4194-babc-868050fb6f03	Trần Trịnh Nhất Gia	15/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 -  Xã Đức Cơ - Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
fd65d230-3631-48e6-9bb9-8f57dd0d05ad	Nguyễn Hoàng Bảo Hân	25/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
dd0ff2c2-d394-4ced-a7e8-99b3addd0fed	Siu Đỗ Tuấn Hùng	03/09/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Trol Đen, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
4053b4fa-efd2-49ea-9a76-1d1f351e9a6f	Nguyễn Văn Huy	09/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh giáo -  Xã Ia Krêl  -  Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
23c88181-dce1-4e45-83c2-0b4494e00e13	Nguyễn Thanh Huyền	30/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
a2fe6126-aec9-433c-a07c-c1fd2f18134b	Nguyễn Thị Lan Hương	19/03/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng gron -  Xã Đức Cơ - Tỉnh gia lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
36899879-62f4-4816-a3b6-f36196c47edc	Nguyễn Thế Khang	03/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
d3247cfb-388d-4357-9338-e71a94b33f33	Trần Anh Khoa	05/01/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dấn phố 7, Chư Ty, Đức Cơ,Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
53942e41-d2a3-458d-b041-04d4a46ef4f9	Đồng Gia Khôi	02/04/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
8e41c16b-8bf5-4048-9f4b-170d7df16432	Nguyễn Trần Thùy Linh	21/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4- Xã Đức Cơ- Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
50b3d36b-0332-4957-b851-143ca154d535	Nguyễn Quang Long	02/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Xã Đức Cơ- Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
c33e615b-f8ad-4791-a5e2-04ef50bef04e	Trương Gia Long	24/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, Xã Ia Dơk, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
223d3d6d-7185-4f2b-a059-b9fcdf09eb46	Nguyễn Thị Mai Ly	25/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, Xã Ia Dơk, Tỉnh gia lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
0218d99e-02b8-4688-a4e0-bc556da5079c	Cầm Thị Quỳnh Mai	30/08/2009	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
50f02f13-54aa-49c4-ae48-3073e87304d4	Đỗ Thị Ngọc Mai	05/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dấn phố 1 - Xã Đức Cơ -  Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
b2785a57-7715-41d4-b9ca-4c236ca70e39	Phan Trần Yến Minh	14/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Kpă Klong, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
635d8ac3-e5ff-4325-a4f9-00ce61578d07	Huỳnh Nguyễn Trà My	20/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mút - Ia Dom - Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
03f70d59-c359-468e-919c-8f9885fad6b8	Hoàng Lê Ngọc Nam	26/05/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
de89925c-d126-457d-affa-2ba755309e7f	Lê Thị Hồng Ngọc	17/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP7, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
7fa4d404-3ec9-4746-945a-3ab4b9f15318	Nguyễn Công Ngọc	21/06/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn ia Mang, Xã Ia Dơk ,Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
0f377d7d-4081-43c6-8fef-7f262e221a1c	Trịnh Thị Bích Ngọc	19/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ia Mút, Xã IaDom,  Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
68a12c65-b01d-4f73-ab38-616ed7a33171	Bùi Thị Yến Nhi	02/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp2, Xã Đức Cơ, Tỉnh Gia Lai.	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
7ec2880f-8e12-4bf0-932f-b484d09fc350	Nguyễn Thị Quỳnh Nhi	04/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang- Xã Đức Cơ - Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
37d75ea7-d1be-4486-96f0-72c66b20d762	Trần Gia Như	05/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP2 , Xã Đức Cơ, Tỉnh gia lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
d38830de-458e-486b-b18a-b09baf487b26	Hoàng Thị Kim Oanh	21/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp7, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
addce360-afe6-4005-b3b6-048757919de2	Huỳnh Văn Phúc	14/02/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh giáo-Xã Ia Krêl-Huyện Đức Cơ Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
432fd41b-6f37-471d-80e0-8e16e5a2c330	Hồ Thanh Tâm	01/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
344a124d-2775-4f0a-9801-0114d07a41b7	Nguyễn Nhật Tân	24/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
cfc585f8-2ab5-4a87-9129-972f876d13c1	Hoàng Thị Kim Thoa	16/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4- Xã Đức Cơ- Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
4423bde1-94e4-40d2-b234-8f87185d1f2c	Hồ Thị Anh Thơ	11/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP2- Xã  Đức Cơ-Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
0a3b515a-cc0b-4d4b-8e30-0258ec34ef3b	Nguyễn Thị Ái Thuận	24/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP1- Xã Đức Cơ-Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
7d8e389a-2d53-4486-9eea-1a303e945088	Phạm Hoàng Anh Thư	22/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
e3c32580-9719-4653-9230-cfa7f7c1dfc7	Vũ Đức Tiến	22/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
ef722e5e-3f18-4b8f-aac8-611fd10cde2c	Bùi Ngọc Tĩnh	19/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
ec9fa665-53f6-4618-9478-c802ac0e21f6	Vũ Thùy Trang	15/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
ee702522-36dd-4c24-85d8-0018b529fc24	Thiều Thanh Trúc	16/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
0c3edfcf-48c9-45a1-a601-f0b52b16fa6e	Lê Hoàng Tuấn	20/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ I, Xã Ia Dơk, Tỉnh Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
b49ca9e5-7092-42d0-bfce-3f605270f32b	Trương Vũ Cẩm Tú	25/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
b31d3315-2a47-4896-a7f4-978290fcf7c9	Nguyễn Trí Vĩ	23/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đường Quang Trung, TDP 2, Xã Đức Cơ, Gia Lai	9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	2026-05-10 10:10:12.673721+00
b35f887e-77ed-48ba-81a0-2ab277ddee34	Cù Hoàng Gia An	03/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
bb979d27-8297-45b2-ab49-bb3f47052763	Đào Lê Minh Anh	20/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
bf6ffbba-dfaf-48c0-b529-a7701a2fcac6	Nguyễn Khắc Việt Anh	02/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
b00a6352-be39-4567-baf0-b0d25cecb691	Phạm Đình Ánh	15/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
7ff92d97-599d-4b1f-bb92-b0e2975d997b	Huỳnh Ngọc Bảo	02/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
84a3c94e-4cc1-4c49-a2a2-7f575f8bbcf5	Hoàng Hoài Băng	26/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk - Xã Ia Krêl - Tỉnh Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
7909e578-1791-4648-b55c-51eb5ea27c48	Hoàng Gia Bình	15/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
01242485-17ed-436f-a25f-b5cc84b643a8	Nguyễn Trọng Bình	19/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - xã Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
5ef4259c-e54d-4ede-a12c-c5c3fb5c8bc4	Phạm Hồng Diễm	25/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
28c373ad-db2d-4961-ae27-7bd70602f403	Lê Anh Dũng	24/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
49794717-e337-400a-98c8-6f59e4772060	Nguyễn Anh Dũng	04/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
b6c327a6-5183-46e6-9834-6d9c5ca8596b	Vũ Hải Hà	20/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
5b110446-d1db-4d74-ab56-ef0625ed59cb	Phạm Nguyễn Bảo Hân	24/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
3997d553-bd24-4e66-9622-29ee8ecdb8ba	Nguyễn Trung Hiếu	15/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 -Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
6f7bcae1-06e9-4b4c-950d-52d3603c3f95	Nguyễn Hoàng	01/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Grôn - Ia Kriêng - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
34437760-b3e2-4c59-a37e-521a573e7477	Nguyễn Hồ Khải Hoàng	29/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
e1ab5075-3140-43e7-8c80-767b9cc40596	Võ Văn Huân	18/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
6a13c61a-b804-4dae-a4a6-02d785784d6e	Lương Phi Long	06/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tôk - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
6617adbf-86f4-4af1-9927-961005a890ff	Mai Xuân Long	20/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
67eef3a4-022a-4110-a39d-eb16697720a7	Vũ Tiến Long	25/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
1a4bd834-13bc-4c63-ab4d-23e7bc2a638e	Nguyễn Tấn Lợi	10/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
878ea07a-28e7-4c28-aa70-f635b64eb33f	Lê Phương Thảo My	02/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
617ec123-6a11-4350-9475-c4e426600241	Hà Nhật Nam	06/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
4e3d7405-9886-42c5-b3c7-8959db0c6f59	Lê Thị Bảo Ngọc	29/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Sung Le Tung - Ia Dơk -  Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
81f2992d-e876-471c-99d4-e567b1acad37	Nguyễn Thị Bảo Ngọc	22/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Chư Bồ 1- Ia Dơk - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
f4074ace-14ca-48f4-89d7-78cd8bdf4c5c	Hồ Bảo Yến Nhi	28/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
4d2115a7-3c60-418f-aa64-126c7818121d	Nông Lê Yến Nhi	26/08/2009	Nữ	Tày	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
91db4300-906e-45d3-b8d1-8e6463a9154c	Trương Nguyễn Quỳnh Như	18/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
d32c8054-3e4b-496e-b04b-5d3c6da90ff4	Nguyễn Văn Phúc	05/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Lâm - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
5fea35bc-0611-4be1-92f2-c30e167f80fc	Phạm Văn Quân	06/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
2a52215d-e7f9-45a6-a50d-d752193da61a	Rơ Lan Ai Quyết	13/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
f1815eb2-cbdf-4b2c-92a1-979f3377f1f5	Hoàng Thị Thanh Sáng	20/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 -  Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
e7619ff6-2fd5-478f-9c17-71c5952acb4f	Nguyễn Khánh Sương	19/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Lâm - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
5c8df7f6-6474-48b4-99ad-2d2057c7c180	Lê Phú Thành	04/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Lâm - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
89453595-40d5-408c-a35c-69250522d49a	Hồ Thị Anh Thư	24/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
af7b0dd3-15f5-46ce-bd38-5a7cf62599d0	Nguyễn Thị Thương	17/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang - Ia Dơk- Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
676b3340-ad07-4be8-81b1-c81d3cb2a7c0	Hồ Vĩnh Tiến	09/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Ia Dơk - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
7f1f38de-5c49-404d-9162-be74b6ffe0b5	Nguyễn Thị Thùy Trang	10/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1- Ia Dơk - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
91c9d46c-1338-4cab-943f-b13e0e2ef356	Trần Thị Thùy Trâm	13/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
1ec10b0b-e8b3-418e-a77b-bdc87de82fae	Trà Minh Trí	27/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Giáo - Ia Krêl - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
5f94c3eb-b971-4a7f-aaeb-dc0977b9b970	Nguyễn Thị Diệu Trinh	13/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
f258a932-0fec-4b4d-b36b-dca7fd125a23	Trương Phương Trinh	16/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - xã Ia Dơk - Gia Lai\r\n	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
e3762821-c3cb-4cf4-93a0-f09d35625aaf	Lê Thị Hồng Tuyết	14/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
fcf21b4a-2806-438e-b154-8d4bc4edc7bd	Nguyễn Ngọc Như Ý	13/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Đức Cơ - Gia Lai	5b462911-8d6c-4fe1-acfc-8164ecd0d90c	2026-05-10 10:10:12.673721+00
e89704ec-f549-4a44-a4b1-1cf765b8531d	Đào Duy Anh	18/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 1, xã Đức Cơ, Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
5efa67fc-165a-4011-8edd-c09a66adfb5c	Hà Vĩnh Hoàng Anh	02/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 4, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
81c6899c-e6ec-4c3b-90fe-8d4f0bc19b29	Hồ Quỳnh Anh	27/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
1428e011-9636-4109-9b74-266e490b1560	Phạm Nguyễn Việt Anh	27/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 6, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
8f75919d-7e9b-46c3-be79-b7d9f92370c0	Lê Thị Thanh Bình	01/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
e17a7bb3-9b04-423a-99ef-26a9ccfe2684	Phạm Thị Kim Chi	27/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
20aeaa62-4518-49ac-8aae-7a3a007a77c8	Nguyễn Thành Công	16/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
40edf505-b987-4524-8f05-877f9ec34695	Giang Hải Đăng	30/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
0214fbe4-c756-478a-aca8-78206ac3f1e3	Nguyễn Hữu Đức	12/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
6d1b377a-c44f-40ff-b8b5-576c6a5b58ad	Võ Hương Giang	11/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
870a0420-9e09-458e-9d0e-c587c5c0596a	Nguyễn Thanh Hà	11/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
078dacdf-7909-4193-9a9d-e1d734196477	Nguyễn Văn Hào	22/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
02903510-ff1e-4ad0-b8fc-4b2580587304	Nguyễn Thị Minh Hoàng	08/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
8a31409a-865a-494d-804b-0f61698fab74	Lường Quốc Huy	23/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
881f1fc9-291c-43a9-a38c-b630b0c8772a	Phan Tấn Huy	18/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Nuk, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
9849d007-2b52-4033-b218-dab98117b88c	Hồ Hoàng Hưởng	11/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
ce280e49-603e-4b82-ad0c-102291430302	Nguyễn Hoàng Gia Khánh	10/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 7, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
df1de102-5637-428a-8198-7438dad3ab86	Phạm Thùy Linh	20/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang , xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
bdb727dd-49b6-4d6c-a5ee-abf9e373463c	Tăng Văn Hải Long	01/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
0e291f1b-3a78-44ab-8b85-2d0bcb094eff	Lê Bùi Xuân Mai	04/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
65a4f0d8-5e4c-4702-9b15-71b705442c9f	Nguyễn Lê Quỳnh Mai	14/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
f8f0ea09-6b3c-4007-850c-ccb566de47d8	Phạm Sao Mai	22/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 8, phường Hội Phú, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
ae7e5a34-3a16-4f3f-9e1d-2d01779155c7	Nguyễn Lê Mạnh	14/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã Ia Dơk , tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
091e26e2-eb4d-4835-8a3f-be9524ef71ad	Bùi Phan Bảo Ngọc	18/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
7ca1b544-6474-43ff-a0d2-587f7d3c9735	Đinh Thị Bảo Ngọc	19/07/2009	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang ,Ia Dok ,Đức Cơ,Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
fd32a97e-b7d7-4e71-9c73-fc811577e993	Bùi Văn Hoàng Nguyên	23/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
c1944f9c-010d-4207-9c54-732872179bef	Nguyễn Lê Yến Nhi	23/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
a21a037e-8c10-408c-b241-2c30ddd1d0e3	Lê Thị Thu Phương	29/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
eee1deea-195d-4c52-be54-34751b7f2db2	Nguyễn Thị Linh Phương	31/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
390f6c81-6204-4dc3-ad90-93301943a76d	Bùi Minh Quân	27/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Chư Ty, Đức Cơ, Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
a1f39a91-3619-437d-bcc2-582c44548300	Khiếu Thị Như Quỳnh	30/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
b9620ac0-4358-4d93-a03c-255dff4c1c4a	Hồ Vĩnh Duy Tài	17/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 1, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
54b51e61-1cb6-42cd-8ad7-d6e681bbcfb3	Nguyễn Xuân Thành	11/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
d69bd288-ecc1-4fc8-bcf9-0bf1e4bd0a73	Đặng Anh Thư	16/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
622497b2-d565-4374-be82-0cfd11d1a1db	Phạm Anh Thư	20/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
01cc0729-41c0-4e9c-b974-eecf9107bb9c	Dương Thị Thùy Trang	14/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
5fbc9354-0863-4248-9195-673635627232	Trần Minh Trí	17/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
6be79ec5-7a86-4586-83b8-87a6c9d1a032	Nguyễn Hữu Trung	20/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
b5678d3d-97b9-4dee-af36-00ccb5378223	Trần Xuân Tú	26/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
5bdcb9b6-9edd-43a2-9b68-b0a82997d964	Phan Trọng Tuấn	25/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
3d2c6d75-a92f-4203-acbf-91fde7621f68	Trịnh Đình Tuấn	01/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Ia Krêl, Gia Lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
a678b50b-1700-43c9-aa92-6986b3aa4080	Lã Thị Tố Uyên	11/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia lai	57291d4a-4e9f-4c47-9597-8ca205bb54fd	2026-05-10 10:10:12.673721+00
8d573a5e-baf8-4f62-a739-bde5bf6434f3	Đinh Đức Anh	09/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
aa4dbeb4-ffc7-42be-9e49-3ff71e41f2bf	Đỗ Hạ Nguyên Anh	17/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP6, Xã Đức Cơ, tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
1896061c-09b5-4824-868b-8550f2cbb77e	Đỗ Đình Bảo	26/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
062f8499-a15a-45a5-804f-45f56e361418	Rơ Lan H' Sa Bét	27/11/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
877563db-a696-4157-8a2c-9f42ca973a03	Khuất Duy Công	16/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 , Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
0bcc9bb8-db66-4467-bbd6-e36259f9ab5e	Nguyễn Công Dân	03/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
3b16ffe5-ffcb-4443-967c-6cccd4ae177d	Vũ Thị Duyên	30/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp 4, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
14ce62ce-09d8-48a4-bfec-6a2bb1139fad	Ksor Dứ	10/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
05e68efb-37ab-4b85-ad4f-78ced1faaf82	Cao Chấn Đông	13/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Grôn, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
42d4140a-edbb-48af-9241-37aa802c8ba6	Hồ Thị Ngọc Hà	23/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP2, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
0ad219d5-a9f2-48a9-b850-3899c09e149e	Đinh Thị Thuý Hiền	13/07/2009	Nữ	Tày	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP9, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
6a117459-924f-44bb-8445-dca68b706872	Nguyễn Thị Thanh Hoài	06/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
cf88636a-bfb5-4e56-a665-4792daa3459f	Nguyễn Thị Thu Hoài	14/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7, Xã Đức Cơ ,Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
cd0e5ef5-8bdd-4254-9de8-7db9ff97ddfe	Rơ Lan H' Hoài	31/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
8c8136b4-fbdb-4acc-a1b4-c7e67844da91	Nguyễn Minh Hoàng	17/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
64b84771-7973-4c5a-8613-d62794a76073	Phan Công Hoàng	01/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
3076d670-64eb-4b74-8990-6e44221d444a	Phan Ngọc Khánh Huyền	02/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
be90ef36-b98b-4338-adc4-509a52a49751	Trần Khánh Huyền	12/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 , Xã Đức Cơ , Tĩnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
00bb2b41-a0af-438e-bc19-653415d650c1	RMah H' Jin	31/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
6f6415a0-bfcf-4d74-8c70-8d616da917ba	Nguyễn Đăng Khoa	10/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
156b6bfd-1b77-437b-9781-90e1b4ca5347	Kpuih Khuyên	07/10/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
42c0fad4-cb29-4915-8bc2-760537982555	Đào Quách Hạ Lan	01/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang , Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
039fb484-432d-490b-b256-b6b82e1e1eb5	Vũ Đỗ Thùy Lâm	12/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
a8ded68f-ca42-4bf2-a840-323af8e5f67e	Rơ Mah Liêm	09/06/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
b29086ea-1de1-47f6-8368-372c11624e22	Đặng Thị Hà Linh	17/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Triêl, Xã Ia Pnôn, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
f3883973-3f38-4ab8-97e8-f34a351ffea7	Nguyễn Thị Ngọc Linh	25/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
e7a9eefb-c809-4431-bf6a-f75689b4b608	Đinh Mai Loan	13/03/2009	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl, Xã Iakrêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
85c7f8f7-921e-4762-b2b8-ca8ca4d21142	Trần Văn Long	14/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
eb6dab1d-7e83-476c-8076-0a97e87b17bd	Phạm Gia Bảo Lộc	28/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
8a6c2374-b2ed-4474-9c52-3eb4abd33cc5	Nguyễn Thị Lượng	01/10/2007	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
7d459fc6-2677-43d5-a3cc-1f94fec9594f	Phan Thị Thúy Ly	17/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
892d714d-e617-43ef-9fb6-61a281c6e6ae	Phan Đình Minh	06/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
6c9f1050-b05d-427c-818f-6b471f4d7822	Ksor H' Mlan	03/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
f9ac71ae-c8d9-4197-bd63-80526ed53211	Đỗ Thị Hải My	22/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
2a1c557a-1405-46d4-b7ae-2ccd1475ec5f	Lưu Thị Thảo Nguyên	24/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP7 , Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
f3052cce-e4ee-4239-b146-cbcf5faa35f8	Hồ Thị Nguyệt	29/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ , Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
ab056890-3d46-4646-8af4-e92789b1f658	Nguyễn Thị Gia Nhi	05/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân , Xã Iakrêl , Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
151dcad5-16cd-47a7-80a6-b15323052a0f	Nguyễn Thị Quỳnh Nhi	20/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
b139d281-f744-446a-96d1-372342d4abd1	Trần Linh Nhi	22/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
a54251b0-a33d-4153-8439-58267ef09046	Nguyễn Tài Phát	23/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
1b40e9b7-1d12-43f2-b81a-c872dfcb98e8	Trần Trung Quân	10/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
889b62d9-0db8-42f5-9b67-b9569cd5e00e	Rơ Lan H' Rêny	03/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
57345b1a-f385-47ad-a51a-b380e9292b08	Siu Run	12/04/2007	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
c2e64e80-7643-4434-8931-49a0c3ba7f32	Rơ Lan H' Tâm	21/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
ed5468e8-c613-43ba-8a93-e354227ff675	Trịnh Thủy Tiên	14/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
29cd5902-86ec-4316-b185-5991e06d4ef0	Lê Ngọc Bảo Trâm	28/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, xã Ia Dơk, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
a545f245-dd06-4a9a-9f5a-5319ad9ec7e0	Hồ Thị Mai Trinh	17/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
f8e4bee6-ed63-4633-b66a-5db8141fd714	Hoàng Nguyễn Thành Trung	01/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Iakrêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
0295c973-26b3-425c-bb26-af7a7f725860	Ngô Thảo Vy	15/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ngo Le 2, Xã Ia Krêl, Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
57cf4ad2-3005-4de2-bc3a-a53c346cbe47	Rơ Mah H' Xari	03/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, Xã Ia Dơk , Tỉnh Gia Lai	59276cb1-56e1-49c7-9187-129615738e24	2026-05-10 10:10:12.673721+00
5605e477-23a6-4a49-897d-6a253999f07f	Đỗ Nguyễn Thiên Ái	12/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Chư bồ 1- Ia Dơk- Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
ac6a9288-1c19-4128-954f-49ca8ee19950	Nguyễn Thị Vân Anh	27/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krel- Iakrêl- Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
f211d9c0-b66f-4ab0-bb55-c847819b62ea	Lê Trần Gia Bảo	01/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Phường Pleiku, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
9f9030e8-d6f5-42de-9fab-baec09b82565	Phan Khanh Hoà Bình	25/11/2009	Nam	Kinh	\N	t	\N	18/09/2024	0328348334	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Chư bồ 1, Ia Dơk, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
1bf3624b-1da3-4b42-bbc0-d05f7f656095	Võ Đặng Ngọc Châm	15/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 9, Đức Cơ, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
0f07c98f-1c5d-4de6-9016-a1aae089361c	Rơ Mah H' Dulen	12/02/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt, Ia Dơk , Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
b3de9b42-c70d-4feb-bb7c-b994d760995f	Ksor Dũng	23/02/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung le kép,Ia Dơk , Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
9fea81ef-6e94-4b53-8266-fe0ce1c5c32e	Nguyễn Quang Dũng	25/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Iakrêl, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
9cd61f36-f605-49c3-b25f-a779286db72d	Nguyễn Hữu Duy	21/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang,Ia Dơk, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
e276bae6-f3ea-482b-aaab-93fdcca09275	Nguyễn Thị Mỹ Duyên	10/11/2009	Nữ	Kinh	\N	f	\N	-	0868220435	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 9, Chư Ty, Đức Cơ, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
a758efb5-e956-414c-a9da-9716783d00f9	Hồ Hữu Đại	15/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã Đức Cơ - Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
58cb7e17-ee81-48c0-b9ae-22acb8bbe904	Nguyễn Phùng Đạt	30/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
304716af-af40-4f4e-ac08-f202a8323e07	Nguyễn Thị Thanh Hằng	29/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Đức Cơ, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
381a411a-c009-4843-b380-750db7e96cd7	Rơ Mah Hân	26/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang Pong, Xã Iadơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
6600c4d8-1e1d-405c-831f-db36bfbf3cb9	Nguyễn Xuân Hiệp	20/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Kom Ngó, Xã Iachia, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
4f1bf79c-9abf-4823-b05e-01fc4731b3ab	Hoàng Thị Hợp	28/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
bcd13b39-477d-4cb5-98eb-3182b2977968	Nguyễn Quang Huy	08/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaTang - Xã Ia Dơk - Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
4dc63e26-d7c5-402f-a18b-34603a0aa074	Mai Nguyễn Tuấn Hưng	29/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, Xã  Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
b5d05b39-2167-41aa-a947-1e612ed14ae1	Nguyễn Hồng Lai	17/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
8289d4e5-eb60-4c37-aead-599cb436a047	Đỗ Hà Lan	28/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krel, Xã Đức Cơ, Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
5dacbffc-4a60-45b6-bdc3-8a1cf089d851	Rơ Mah H' Lang	06/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang Hrang, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
cf7a90de-cb0f-40bf-ba95-30c246d471b1	Đoàn Thị Mỹ Lệ	13/09/2009	Nữ	Kinh	\N	t	\N	20/11/2023	0387058713	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
5660f97a-db94-47d4-9cb8-5ddda30a2675	Siu H' Li-ya	04/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
b736d765-ff2b-48ff-af5b-b02620b4202f	Hoàng Ngọc Bảo Long	06/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iatang, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
02364c5f-fcd0-499b-b49f-bd9b306b0171	Hứa Thị Lưu Luyến	18/10/2009	Nữ	Nùng	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
4fa9bb0b-df1d-481e-a6b4-e7d18bee061f	Rơ Lan H' Lyna	03/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
61bdbdc6-a1e7-4f5a-92ef-a6d9f148e5d7	Lê Nguyễn Trà My	16/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
ac137c66-cf40-4420-bfc7-23e847d67ac0	Nguyễn Gia Ân	08/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Krêl - Tỉnh Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
d728db43-1379-4b2c-a854-d1dfb3f8346f	Hồ Thị Nguyên	03/07/2009	Nữ	Kinh	\N	t	\N	06/05/2024	0369569267	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
5be66371-b020-4d66-a382-f9c80c0e91de	Ngô Thị Thảo Nguyên	19/08/2009	Nữ	Kinh	\N	f	\N	-	0358280046	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krel, Xã Ia krêl, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
ab89d47b-be03-4c06-8e8f-c1ca71f07052	Hồ Tuyết Nhi	21/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 3, Xã Đức Cơ, Tinh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
b3fc2213-3a6b-4b53-836f-2db861802561	Thiều Hoàng Yến Nhi	07/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 3, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
9fc7edc8-fcbb-44e3-9f39-77780063c4e3	Hồ Thị Nhung	01/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
41ab4769-1d24-4015-8564-a750ed207840	Đinh Thị Quỳnh Như	16/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
46fad1f4-9336-45cf-b495-a80f9c50d517	Cù Ngọc Sáng	29/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
93088c29-9eb2-4b38-b70d-4433b02ef75d	Rơ Mah H' Sơrka	02/02/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
9242e84b-994a-4184-a674-20505d515d63	Đinh Đức Thắng	29/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Lang Krol, Xã Ia krêl, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
ac277a27-16ac-4f0e-ac6e-52d5e7324df7	Nguyễn Ngọc Thông	01/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn chư bồ 2, xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
0974401e-3021-46d8-bcdf-c42dae8a8de4	Văn Võ Anh Thơ	02/07/2009	Nữ	Kinh	\N	t	\N	19/01/2026	03354213	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
4c1af1db-253d-469c-b09b-135a3cf0ff84	Rơ Lan H' Thư	29/03/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
e954f485-f002-4e66-87cb-a9068e07e29a	Nguyễn Vũ Trúc Thy	01/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
930d7090-24bb-4aca-b0c8-f0d5ec201614	Nguyễn Như Tình	01/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
dd337163-5acf-4272-8d02-1dabe507e5b3	Trịnh Ngọc Khánh Trang	31/05/2009	Nữ	Kinh	\N	t	\N	18/09/2024	0345181657	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
f645486d-b869-484a-85ad-bae5489c2dad	Hoàng Anh Tuấn	18/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
f137f3b6-380a-45cd-af17-0b9abbce14fc	Mai Thị Ánh Tuyết	06/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
6c745d62-969d-4e83-bd48-e64414b9397d	Nguyễn Thị Kim Tuyết	17/06/2009	Nữ	Kinh	\N	f	\N	-	0349738669	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Đo, Xã Iadơk, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
5bf927b4-81ed-47b2-978b-ff21cccbe9f8	Nguyễn Khắc Tường	22/05/2009	Nam	Kinh	\N	t	\N	21/10/2024	0344580369	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn 2, Xã Phú Riềng, Tỉnh Đồng Nai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
836d9e52-9eca-4ee1-a582-4abd034e7031	Ksor H' Vệ	07/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, Xã Iakrêl, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
ae491b1e-3dc3-42e7-9902-44b8de31b661	Ksor Kỳ Vọng	22/07/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le tung, Xã Ia Dơk,  Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
bbf0903c-bb9c-4e74-accc-614be998b00e	Ksor Long Vũ	22/07/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung, Xã Ia Dơk,  Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
376859a6-f455-4596-951e-83e6e35fe7b0	Hoàng Thị Hải Yến	27/09/2006	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
c87956ae-2c22-40ce-b647-3937262a11dd	Phạm Ngô Hoàng Yến	06/07/2009	Nữ	Kinh	\N	t	\N	21/04/2024	0344307611	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 6, Xã Đức Cơ, Tỉnh Gia Lai	a263fb21-00df-476a-893e-c645216eec6c	2026-05-10 10:10:12.673721+00
c2176817-7a0c-4874-8d33-ae392ceda91d	Lương Thị Linh An	24/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
7798257e-1999-4a2f-bd2d-a5f8d177f71d	Rơ Mah H' Bạch	20/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
c78bae26-29aa-42e0-80fb-e4edd7ec28b3	Trịnh Thị Hồng Bích	26/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm - xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
2e56c2fe-cb8c-493f-8326-2e8f42966e7d	Phạm Đức Bin	04/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
2a17f09e-ea30-4480-bde7-c398ec8f2c58	Rơ Mah H' Chi	11/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
a80d2b92-02aa-4c81-87cc-6926961a367c	Trần Thị Khánh Chi	08/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
4a3a56c0-4e59-47a6-a7bf-5665c6c99a2f	Nguyễn Công Danh	28/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
321d054f-f05b-4780-bc0b-f7cb9bb3165a	Lương Thị Mỹ Duyên	17/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iatang, Ia Kla, Đức Cơ, Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
c77747d2-02ce-4a80-8f01-d79e98a5fb46	Phan Trần Thành Đạt	27/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
0081ca53-476f-4726-85f5-e7bcb14dfe09	Rơ Mah Điềm	20/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Lớn - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
b51ab8e1-b001-4762-82a6-fed6ddc7eebd	Rơ Mah H'phương	23/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
7b8c33c7-4a3c-4779-861b-06b08e7e29da	Trần Thị Mỹ Hạ	29/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
b80c9c9a-b2ea-4706-aa3b-9e70325cdc02	Hà Gia Hân	16/01/2009	Nam	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Grôn - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
769420e1-b5ec-45b8-a541-4ef5a22be55d	Lê Minh Hiệp	20/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
02a4686a-e6f7-4d66-9a6f-11f611ad8b28	Rơ Mah H' Hiệp	14/06/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
2e09ff01-a4a2-473c-88e4-bde889fdb728	Nguyễn Trung Hiếu	01/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
24c9657d-d37c-4079-b068-a2a1bab278f1	Hồ Thị Thu Hoài	16/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
510b7745-ed80-47c2-aa61-5c2c75f30443	Nguyễn Ngọc Hưng	10/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
059227e8-106f-4a58-bca1-7fa3f20305b9	Nguyễn Thị Mai Lan	16/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Trol Đeng - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
ac572d2f-f15f-4d58-a02b-dbd1b0747b9c	Rơ Lan Lâm	26/08/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
8b6cadad-a90b-4762-bab5-fa1a4d35a46f	Đặng Thùy Linh	25/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
e57abb0b-c4b1-4504-b707-56fa24fa6f73	Đinh Thị Thùy Linh	21/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
4c8ab229-d084-4a14-bb4e-b216ab1a8306	Ksor Mai Linh	28/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
acf93835-8c04-4c86-84f6-0a67e84b92b0	Nguyễn Đức Mạnh	10/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
0de0ff58-d68d-47ba-9851-63c702bf7867	Ksor Net	08/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
87d3780a-abab-4d7a-a268-0bcc2cfffe2c	Rơ Mah H' Ngâm	18/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
9574b8a1-770e-4b72-9431-fb9e9889db44	Lê Diễm Quỳnh Ngân	31/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
bc82b867-2678-4692-bc5f-744707dcf305	Phạm Thảo Nguyên	11/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
59bb7ce2-e341-4c25-832e-8dd839d6099e	Hồ Diên Nhật	24/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
53c5758f-86ea-46b5-a519-8df40f2d68e6	Vũ Quang Nhật	27/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ II - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
a483c481-65d7-495f-845d-3b051455b0cb	Nguyễn Hoài Bảo Như	31/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
4b593c11-cd4f-406c-ba50-1d90e628dadb	Rơ Châm H' Plil	19/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
1e746e1a-2723-4996-aae6-bfb94302ec97	R Mah H' Yu Ri	10/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
0843b7c1-e5ab-42bb-9f04-ee8d36de4f3f	Nguyễn Thị Mỹ Tâm	07/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
59cad810-c4d2-48af-b46f-fcc3167ed063	Phạm Thị Bích Thuận	11/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
dad40ef4-a022-4ca2-b901-103dfca483a1	Trương Thị Hoài Thương	05/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
c64b3014-2c8d-4299-89ed-f8a6cd8132b0	Lê Đoàn Thị Thủy Tiên	30/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
de7e6e0b-5949-46cc-ad9f-b65f7ed097a3	Lê Thị Thủy Tiên	30/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Chư Ty, Đức Cơ, Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
394f8f82-f22f-4dc0-802c-568dde9553e9	Đỗ Thị Huyền Trang	31/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ I - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
95e2b279-719c-47d8-aaf0-5289dfec2eee	Kpuih Trí	17/09/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
bad1e99b-3a95-445c-b34b-a5a279ee4e56	Mai Trung Tuyển	10/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
4394b460-d984-42b4-8cf5-ac7b4471412b	Trần Tố Uyên	28/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
1ea76ce7-7dbc-4223-929b-26d5f96ca7c5	Hồ Thị Thanh Vân	07/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
f9188dcc-be58-43b2-9f77-0ee168bbb135	Nguyễn Thị Bích Vân	20/04/2009	Nữ	Thổ	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
0c244449-f5d9-492c-847d-8c01beea1251	Lường Viết Việt	09/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
802cb786-7adf-41f6-bcef-52d392cc303f	Lê Thảo Vy	10/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
def9a68d-9aad-4dcc-a5b8-c7a8e7e7a11a	Bùi Thanh Xuân	14/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
dfb89dc3-6cad-4c4a-886a-736d29e6271c	Rơ Mah H' Xuân	17/11/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	2026-05-10 10:10:12.673721+00
5025d114-3b47-49fb-961a-e5d53c4115e9	Trần Lê Ngọc Anh	23/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
d4649d9c-8c08-41b9-8c31-5b2aad806cc3	Trần Nguyễn Mai Anh	28/07/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
977f11ed-0335-4190-8612-01c5cd78686a	Rơ Mah H' Bdít	10/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong - Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
0afb0a7e-0b98-4401-bab2-40ee968b1d92	Mai Văn Tuấn Đạt	14/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
52d84b75-e735-4cce-9105-33c716eb9fc4	Trần Tiến Đạt	04/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
6ec4780a-7491-4bc1-8241-3cc5f4c8573b	Rơ Lan Điệp	26/07/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Klăh - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
b083f9ea-9abc-4200-92c3-880ddc8a5a33	Lê Duy Đức	13/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
acd4815a-6beb-40b1-8158-1cbfb312e231	Rơ Mah H' Hần	13/09/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
627203ba-687f-4b5e-b770-9e64322d7ab4	Mai Đức Hiếu	27/02/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
a1d7601e-9c04-4ad9-bae0-90c3aef8bf19	Nguyễn Ngọc Hiếu	10/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
31010b1a-8e62-429a-8829-3fd67e435e3e	Bùi Mai Hoa	18/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl - Ia Krêl - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
3426ada2-a22b-48a2-baba-13838c00c107	Ksor Hòa	04/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
40cecb16-7842-4276-835a-12188ed911b1	Nguyễn Sỹ Hoàng	12/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Ia Krêl - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
8ddbb38f-3d0d-474e-b17e-9282493b9ea3	Cầm Thị Hường	19/03/2009	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
97414e18-f85a-4278-9fcb-4ea5e523c9d4	R' Mah Hy-lia	14/02/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - Xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
5552e7cb-5ca5-4dd2-8087-e5e4c0905877	Hồ Thị Thúy Kiều	14/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP2 - Xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
96bc2927-d99a-4cf0-9ac0-ab65dee9432c	Trần Thị Ngọc Lan	30/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
19715325-44e2-4bdd-b369-cdf549302bbf	Rơ Mah H' Lệ	16/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ia Dơk Ngol - Xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
62bfc4ba-6684-4854-a50f-e991d045e9e3	Ngô Phạm Thùy Linh	24/07/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng TrolĐeng - xã Đức Cơ - tỉnh Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
e886eff5-c33c-4f64-889f-8551baf1736e	Ngô Thị Khánh Ly	14/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
70b3ad06-c3c1-43da-97a3-b8c99f1d6c79	Rơ Lan H' Lysa	01/12/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Kắt - Xã Ia Dơk - Gia lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
c91d6959-fc7f-45a6-b4f8-fe5ad8dabdd0	Tăng Văn Mạnh	01/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Lâm - xã Ia Krêl - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
91b8ebb4-26be-424e-8547-0cf8ba159b3f	Hoàng Yến My	04/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1 - Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
5d64d99f-2fbf-4bed-9bfd-4a6743de1d2e	Lê Thị Trà My	15/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
f462133f-2d36-432c-970f-11e682ad7d39	Nguyễn Lệ Trà My	13/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
1fb649ce-6866-4119-b323-3dfc5daa694b	Phan Thanh Trà My	16/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
96518885-195c-43ad-ac7a-2ba118e75c51	Nguyễn Thị Thanh Ngân	17/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
38c54951-faec-4982-b94e-6655c87900df	Lê Quỳnh Như	25/03/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - xã Đức cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
22f46e6b-4509-4a44-9067-f30bb2a9d933	Siu Quyết	30/07/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
44eb4e89-8849-4b5c-95c9-fd01e8a24054	Đỗ Thị Thanh Thảo	03/03/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
bc54beae-a8b5-4f13-8786-524d432e86be	Lường Viết Thuận	23/08/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Lệ Kim - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
0afab544-a4d6-4a67-b5fc-c0d4fc43a5a2	Nguyễn Anh Thư	18/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
4623fc89-f550-4a1b-a4a2-afc80f78e7d6	Hoàng Ngọc Huyền Trang	28/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang - xã Iadok - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
751bb5e6-74fd-49aa-9a5f-923a55564667	Hoàng Thị Cao Trang	24/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
fc4788de-879b-432e-8cb2-9ee09ef38e5f	Lương Thị Đoan Trang	13/01/2009	Nữ	Mường	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
8cd26007-2eed-4adf-947e-e4a613ff6564	Lưu Thị Thu Trang	02/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Dơk - tỉnh Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
d8fecf4f-55c6-426f-b80e-236ac4ba0710	Nguyễn Thị Quỳnh Trang	19/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
5936bdbf-83cc-454c-9ac6-ac6c9d44c73c	Lê Tây Hùng Trường	21/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
168448cc-f676-4552-bfe0-e3dbeff3f342	Trần Đình Tú	03/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
83cce918-6eae-4fb1-adb2-1e66dac07772	Phan Nguyễn Anh Tuấn	08/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
f2830dde-ec92-40e5-8db9-b86a98e859f8	Kpuih H' Tuyết	04/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
d0d742f9-7e46-4e5d-9903-d3b3cadd11d3	Lê Bảo Uyên	21/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
6f587e48-d7cc-498b-9388-7178e86ee029	Rơ Mah H' Uyên	28/11/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Tung - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
ac64c602-34f2-422d-b08a-d473c28043ea	Rơ Mah Vũ	13/09/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung - xã Ia Dơk - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
c5bece86-f000-4070-a8bd-0342a51e468a	Trần Thị Kiều Vy	22/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - xã Đức Cơ - Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
91698a17-46de-4ec9-a8e7-a9e16ede8fc7	Đặng Hải Yến	17/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - xã Đức Cơ - Tỉnh Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
3d2c0295-c1f7-4789-9914-fa37aceb3c5e	Nguyễn Thị Yến	22/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7- xã Đức Cơ - Tỉnh Gia Lai	76434353-26ae-431a-b933-3b520076a8eb	2026-05-10 10:10:12.673721+00
64e3ef2a-7938-45a4-b4ad-709bce42c557	Nguyễn Vũ Hải Anh	09/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
ea5fa8b4-d712-446b-9252-b4336eb55b96	Phạm Ngọc Khánh Băng	11/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
de769061-8c6b-406a-abde-9aa1ae5f7552	Lê Đình Dụng	17/03/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng ấp, xã Ia Kriêng, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
22499551-fb1a-4810-a4eb-6517869945b2	Nguyễn Trương Đắc Đạt	04/08/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iamang, xã IaDơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
0da5a913-b46a-43c5-ade6-e453c592c64e	Bùi Lương Hải Đăng	08/12/2009	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ dân phố 3, Chư Ty, Đức CƠ, Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
73b8dbb4-b30b-4262-8fc2-48b33caaa241	Nguyễn Xuân Hà	22/01/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
85d12d6a-70d0-4aa5-942c-1e8f1209617e	Rơ Châm H' Hà	12/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Ia Kiêng, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
f8342456-2113-411a-8a79-c56cfbf31c0a	Nguyễn Quang Huy	25/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
ab3b08c0-44ea-4bda-8c52-f2718bb0ef87	Vũ Quốc Huy	06/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
dbf6eb01-8110-4a73-99a4-1c6db369da75	Lê Thị Lan Hương	12/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
3cafbfd3-24c7-40e5-9f79-2a61246f22d1	Đỗ Quang Hữu	05/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
2f873b55-ad78-40de-afbd-a87c10f5cf07	Rơ Mah H' Hyưng	01/05/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
7990ecae-5954-4c41-9b5f-68646e1382ba	Siu Châm Khang	11/09/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
a6e0d7fe-a9f5-46e0-bfb8-4ff71625afa4	Nguyễn Thị Mai Linh	15/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
d86ca2cd-d5fa-4505-a07f-a3061bbb36f0	Hoàng Nguyễn Bảo Long	10/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
5a336ff7-3f12-4ce0-a9b6-83ed54a84600	Phùng Chí Long	28/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
5f0cf785-2d13-4040-a592-796a59944c55	Dương Hữu Lộc	16/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
d68bf8d3-d715-497b-bcab-03b3e5e1051b	Rơ Mah Si Mô	30/11/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le , Ia Dơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
b790eb00-601e-456b-9b9e-f96d9fb0c6d1	Lê Thị Nga	10/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
e4a69bce-b968-4d2b-b622-60ec9ab0e330	Lê Thị Bích Ngọc	09/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
d7d76c83-68a4-4603-bca8-bec2edf51d54	Nguyễn Ngọc Tiên Nhi	26/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốc, xã Ia Krêl, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
3caadc92-fb50-48c0-9ac5-4751bcba8a84	Mai Hoàng Phi	07/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
258581ea-ab63-414f-ac52-d63217fbef93	Hoàng Quang Hải Quân	01/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
92bd7f6a-1316-47f4-a365-99994164dd1b	Trịnh Quốc Quân	30/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
d75c7c9e-b023-4e47-ae62-9e983ca08e1f	Kiều Tuấn Sang	10/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	xã Ia Kriêng, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
12e44e4e-2704-405c-aa1f-4a3f6f3c3101	Nguyễn Văn Sang	13/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
6c1123af-75a5-4061-a04f-5c567da6a226	Nguyễn Văn Tài	10/06/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
82452ddc-b8b6-45f5-9d12-ca97c2f98c3c	Nguyễn Trọng Tâm	04/05/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
8b1ac069-d740-4cb4-b697-05ac125005ca	Rơ Lan H' Thoại	08/11/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
15699d2e-cc80-43c6-b120-e81ed596e67c	Đoàn Trần Anh Thư	15/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
bb0640e4-c817-4ee2-adbf-2700339bf788	Hồ Anh Thư	13/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
fc772ac9-7aeb-41ee-b79e-868b3a119192	Lê Văn Tiến	30/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
505aa278-45f9-40af-920b-873c0e9649bc	Kpuih H' Tinh	02/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Trol Đeng, xã Đức Cơ, Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
62cce318-cc1b-4e63-84e5-e02c79c3dca4	Mai Thị Huyền Trang	26/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức cơ, tỉnh Gia lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
267c93ce-3807-4904-8db6-86123ccf1c5b	Nguyễn Tiến Vinh	11/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai	b901c879-d714-4743-b6da-7f39748743c3	2026-05-10 10:10:12.673721+00
a425eeda-e1ee-4a1f-b535-c2a030451863	Lê Đức Bảo	31/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Iatang- Iadok- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
c89492ac-29e0-4f14-a7b4-eee87963303c	Bùi Quang Dương	02/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9- Chư Ty- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
9b0662c9-0831-484c-b843-b515a40e76b1	Nguyễn Thế Thành Đại	17/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1- Chư Ty- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
7b7dbcbc-19e4-421b-93a9-5bd4256b7ad6	Trần Văn Đạt	29/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3- Chư Ty- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
4bd4aed1-3235-4e32-bdf8-1459d9dc7711	Đậu Quang Thỏa Hiệp	13/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm tốc- Iakrel- - Gia lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
5fba68eb-9d89-4a5b-9e44-af33a7493e25	Hoàng Trung Hiếu	06/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Iatang- Iakla- Đức cơ- Gia lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
cf1083d8-8932-402d-a86b-8232dd4de40a	Ngô Đức Hiếu	24/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4- Chư Ty- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
4ea3fd48-43bc-4e04-8745-bdd0b84ff79e	Trần Minh Hiếu	21/01/2009	Nam	Kinh	\N	t	\N	09/01/2025	0327889830	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
473f6266-93cd-4d59-9ba1-c1e2976d82ac	Nguyễn Văn Nguyên Hoàng	20/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang- Đức Cơ - Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
4ea4932f-e21c-4ea3-ba42-2f0d509f010e	Nguyễn Văn Lâm	18/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn chư bồ 1- Iakla- Đức cơ - Gia lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
b2266065-a357-4564-959a-4d9b883c5c09	KSOR H' LIA	04/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung - Iatuk - Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
40847364-22d9-49b0-baf6-80019eafef79	Phạm Nguyễn Hoàng Linh	05/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4-Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
07069409-68ad-4c94-9c74-e5871b482803	Đoàn Ngô Vũ Luân	10/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng DơkKiah- Ia Dơk- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
78329d20-d8ab-41c4-8357-ed91475ceacc	Lê Thị Xuân Mai	21/10/2009	Nữ	Kinh	\N	t	\N	19/09/2024	0344040341	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
b7530da7-359c-4e6b-8a6b-8d6241136e9d	Nguyễn Văn Mạnh	17/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
f0ee0764-6451-42ab-939b-4cc8f2510f5c	Lê Anh Minh	14/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
92df9377-3789-4c91-adfe-6e3e773884a6	Huỳnh Thị Diễm My	18/01/2009	Nữ	Kinh	\N	t	\N	28/12/2024	033 6850730	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
112665ac-5c98-4eef-841c-55a7891e09f1	Đặng Bảo Nam	08/04/2009	Nam	Kinh	\N	t	\N	09/01/2025	0398869302	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
c3f5df05-8e8c-4c3a-9dbe-ec3bfa1e60a0	Kpuih H' Ngát	08/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Xã Iakrieng- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
1122e098-d497-4805-95bf-00f0e1b3aff0	Bạch Thị Bảo Ngọc	16/07/2008	Nữ	Kinh	\N	t	\N	14/09/2025	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
bbcb6f12-4ae1-46ea-839f-0447d3c6db5e	Lương Thị Yến Nhi	19/03/2009	Nữ	Kinh	\N	t	\N	-	038 4626009	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
9a8b4244-a357-447b-80c6-dafce819b2e1	Vũ Minh Phương	21/09/2009	Nữ	Kinh	\N	t	\N	14/09/2025	0375374792	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2 - Iadok - Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
df1d571b-f1d4-4450-9d82-33360603d309	Chu Thị Quỳnh	10/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
349a28f0-cde2-431a-9272-bfeee9c79931	Trần Thị Diễm Quỳnh	25/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
fa998707-3337-40ce-929a-af6300b9bbef	Kpuih Sen	26/10/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
7fac06fe-a3b1-4c90-9821-63c503151cae	Cao Thái Sơn	26/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
48d98d98-70da-4dcf-8cab-74d9420a1f74	Nguyễn Khắc Tân	23/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
f123ce73-38f3-4378-80cc-2978abc48766	Rơ Mah A Thanh	10/12/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng sung Le Tung- ladok - Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
8ee11e5d-af92-4fb1-9df1-9c10d818f297	Nguyễn Anh Thịnh	30/04/2009	Nam	Kinh	\N	t	\N	09/01/2024	0372442289	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Đức cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
d33dda3b-76f4-486f-82ed-b5535dbdf1bc	Hoàng Thị Thanh Thúy	18/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Đức cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
bb8311f9-3a99-4749-aa18-ec763b794444	Trần Hồ Anh Thư	10/09/2009	Nữ	Kinh	\N	t	\N	09/01/2024	0967874123	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
d71a323a-70fc-4d13-acad-a39e9496d1a3	Phạm Lê Hoài Thương	11/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
2b736dde-e13e-4099-ad86-4482af051563	Lê Thị Quỳnh Trang	29/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư BồI, Iadok, Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
873c2787-fb1f-4084-97ef-c942ab96e1ce	Nguyễn Ngọc Bảo Trâm	17/11/2009	Nữ	Kinh	\N	t	\N	14/09/2024	0706131033	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
d376e735-62c0-44ec-b5fb-a5f953c48950	Lê Thị Huyền Trân	04/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
143f9f0b-187c-4320-9922-24ea937b3412	Nguyễn Văn Tuấn	16/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2- Đức Cơ- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
81176ee2-e0ab-4b0e-9f4f-b704b263655b	Mã Thị Kim Tuyến	16/01/2009	Nữ	Kinh	\N	t	\N	14/09/2024	0392466042	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn chư bồ 1-iadok- Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
29b80b83-d391-41d2-8ffb-a83647e95f43	Bùi Thị Tường Vy	03/10/2009	Nữ	Kinh	\N	t	\N	14/09/2025	0345685398	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn chư bồ 1- Iadok-Gia Lai	a8eaa04d-04fd-460d-9894-4219bd41e2c3	2026-05-10 10:10:12.673721+00
d57ffcda-b146-4731-899c-389d4b640d19	Trần Thành An	12/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Chia, Xã Ia Nan, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
4766c518-229f-416a-a0d8-0c864844cd54	Siu H' Dịu	22/01/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
7243a8bf-2252-4f24-abe3-7c2021370a60	Nguyễn Đức Dương	24/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
4f7e7910-185d-4476-870c-36a91763e71d	Trương Đắc Dương	07/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 4, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
0d143a66-e2e8-4580-8382-0017cfafefb3	Đặng Quang Thành Đạt	29/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
46400af5-c41c-46ce-a4fa-9c60e5eea549	Tống Thành Đạt	25/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
ecc36ed6-aee6-4b61-a62b-38c6ac862a94	Doãn Thị Hồng Hạnh	20/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
23f6d25f-20fb-41e3-8291-022a419794ff	Lại Hoàng Bảo Hân	29/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Phường Pleiku, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
14dc61aa-f7b0-45fb-994a-e5ee9ea01037	Nguyễn Thị Ngọc Hân	06/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tôk, Xã Ia Krêl, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
4b1ecc3b-25f1-492e-86e1-99c01a6c847e	Lê Quang Hiếu	04/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
745cb2ad-8154-4ec1-a8f6-1b82d2e991d1	Phạm Khánh Hoà	08/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
da1e1f51-12d4-496d-adb3-ecfb216a7522	Phan Công Hùng	03/10/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
e2ad8e56-1232-4e2a-91a6-a661875395ee	Nguyễn Hoàng Gia Huy	18/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
d2445dde-ffd1-441c-b96f-182e4b1aa1ab	Nguyễn Hồ Nhật Hưng	27/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm, Xã Ia Krêl, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
d31f0a36-05c9-4033-8910-b46c689188d7	Vũ Nguyễn An Khang	01/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 2, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
86bb6a0d-3f6e-4d3a-aa9c-c88d6f0981e5	Mai Xuân Khánh	29/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
ffd6e4cb-d880-49b2-a120-1a903b2afbfd	Nguyễn Phùng Khánh	02/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
9cc67f3a-977b-4844-8816-55baaea8043e	Nguyễn Thị Thùy Linh	19/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
02ac7de9-1ecd-431b-a452-cd690446840a	Kim Ngọc Long	16/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
d895f3f9-340c-4ea1-9225-060aed27d68d	Hồ Hữu Mạnh	29/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
ad0f160d-a196-4046-9e75-2780fa65ddcc	Kpă Mathê	17/04/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
a142416e-b39d-4144-a302-1737b16c9851	Hồ Thúy Nga	21/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
e918ef89-d5cd-494c-b27e-96b206278da2	Hoàng Bảo Ngân	07/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Kom Ngó, Xã Ia Chia, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
e886fef6-e8d3-4dfe-a15f-e34b3e258a2e	Mai Thanh Nguyên	28/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
3a608e06-06a8-4874-8ad8-f6720fd6def5	Trần Đăng Phong	23/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
ee24c1fc-ed95-447e-b3f2-43d572d16970	Chu Đặng Nhật Phương	07/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
9ca20519-a398-4b53-99c6-90ff0be260a3	Đoàn Ngọc Nam Phương	27/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
68fbbb25-c255-4418-8d45-fc2453b1d4fd	Đặng Duy Quốc Quân	09/04/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
56943f27-8235-48a7-afe3-d81d7eb62dc6	Vũ Diệu Thảo	26/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
8e69e2a7-cecc-4ca4-a4c9-1b1dbe7585c8	Kpuih H' Thứ	26/09/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Trol Đeng, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
4c50462f-5fdf-4552-a4c5-997e9bc69ed5	Phạm Trần Anh Thư	29/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
a8bf01c9-3c08-4c43-8813-c7cf175ca151	Trần Thị Anh Thư	29/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
7a6b9de0-d78c-467f-baae-4a5859946bb3	Kpuih Trần	18/12/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai	e362306b-fa85-4fd5-8caf-a05c20b49cc1	2026-05-10 10:10:12.673721+00
b066ed64-bc22-4e54-bccf-c0685b57e74c	Nguyễn Ngọc An	01/04/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0333855032	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
10d10933-0a48-4e9c-a945-88dba5f2b8a3	Nguyễn Hoàng Anh	06/03/2008	Nam	Kinh	\N	t	\N	26/03/2023	0366927743	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
454af26b-b138-41d8-982d-0b06dbf6838e	Nguyễn Tuấn Anh	13/08/2008	Nam	Kinh	\N	t	\N	14/01/2024	0984802579	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Dơk- Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
f1e57505-5f65-4292-85b8-d4e86d7e6947	Nguyễn Trịnh Gia Bảo	26/08/2008	Nam	Kinh	\N	t	\N	22/04/2024	0869899621	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
22e3b339-bae9-4d8e-ae2f-754c3168756e	Nguyễn Quang Thành Công	04/09/2008	Nam	Kinh	\N	t	\N	30/11/2025	0349995067	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân- Xã Ia Krêl- Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
2e12f18b-729e-4569-af0f-371ec9faf5e6	Bùi Thùy Dương	04/01/2023	Nữ	Kinh	\N	t	\N	26/03/2023	 0346923157	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 1 - xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
960861c5-41c7-4f55-8491-08ad62d2d492	Dương Minh Đức	08/07/2008	Nam	Kinh	\N	t	\N	09/01/2025	0865646339	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
fbfa283f-e56c-4de9-9b9b-612da10e0a35	Hà Minh Đức	13/11/2008	Nam	Tày	\N	t	\N	18/01/2026	0373462577	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
7a28a3b6-f273-4187-9559-e942a26ccc9d	Lê Đức Giang	02/09/2008	Nam	Kinh	\N	t	\N	09/01/2025	0398171374	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 7 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
4a883c60-1f29-4329-96c0-9977c48a814c	Phạm Ngọc Gia Hân	12/10/2008	Nữ	Kinh	\N	t	\N	20/09/2023	0983029959	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
dece21d3-3ee9-4418-89a5-f521f3780379	Mai Văn Hoàng	23/01/2008	Nam	Kinh	\N	t	\N	26/03/2023	0375346667	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
2a41ab7a-5541-4150-895e-562ec8f87f40	Nguyễn Đức Hoàng	04/05/2008	Nam	Kinh	\N	t	\N	24/04/2025	0349315963	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 3 -Xã Đức Cơ -Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
36873ae8-cc3b-41dc-9bad-a9fd9ef160dd	Nguyễn Quang Huy	20/06/2008	Nam	Kinh	\N	t	\N	24/04/2025	0396036852	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
090e9b5f-6bd8-4928-a764-8311e6306eec	Nguyễn Trần Gia Huy	22/06/2008	Nam	Kinh	\N	t	\N	18/01/2026	0973227717	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 3 - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
89ec3e6c-9546-4216-b9b0-6a47c0fa9f32	Nguyễn Ngọc Giáng Hương	04/01/2008	Nữ	Kinh	\N	t	\N	20/09/2023	0377295803	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1- Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
54a592c1-4823-47d0-a519-be83880db6e3	Nguyễn Thị Diệu Linh	17/05/2008	Nữ	Kinh	\N	t	\N	20/09/2023	0328875445	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl - Xã Ia Krêl - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
7e30be34-1b9d-4f34-bc51-6c72547db751	Cao Thị Thanh Mai	13/03/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0328444459	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
d32f86ce-06f0-4c35-ab50-00bbc9916fc9	Đỗ Đình Mạnh	26/01/2008	Nam	Kinh	\N	t	\N	26/03/2023	0348607726	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
f766504b-0202-402f-9002-9b67d3b04a6f	Nguyễn Vũ Đức Minh	15/03/2008	Nam	Kinh	\N	t	\N	26/03/2023	0373807315	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
1c8b605f-002c-4048-94ed-973d68583ba1	Nguyễn Thị Bích Ngọc	27/02/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0362367022	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang - Xã Đức Cơ -Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
6e9f667f-db7c-48f9-a2ed-76c74dfafd81	Nguyễn Thành Nhân	22/01/2008	Nam	Kinh	\N	t	\N	09/01/2025	0383800177	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
70dc130a-cdc2-4f2e-960c-1076cb91d8db	Bùi Thị Tú Nhi	09/05/2008	Nữ	Kinh	\N	t	\N	09/01/2023	0385397067	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
97abcd3d-f0e8-4bac-89eb-d03422987749	Đinh Thị Yến Nhi	22/04/2008	Nữ	Kinh	\N	t	\N	05/12/2024	0354844896	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 3 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
0c974b27-a632-4afc-832c-1ed344cc6820	Nguyễn Thị Nguyệt Nhi	27/01/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0854427247	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
f677356f-8be2-433e-a867-35b4cc92e978	Phạm Lê Gia Nhi	28/10/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0977823975	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
331938b0-ea0a-4128-86e4-c710ce29ac52	Lê Tâm Như	09/10/2008	Nữ	Kinh	\N	t	\N	01/04/2025	0975046279	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm - Xã Ia Krêl - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
27c3cd6f-bd32-4f55-8f3a-e48fe052c049	Trịnh Tâm Như	14/08/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0789725567	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 6 - Xã Đức Cơ- Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
96f80e75-dc9e-4fa0-accc-fffcfe0973a4	Đỗ Hà Phi	06/01/2008	Nam	Kinh	\N	t	\N	16/10/2022	0382316601	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
73c45686-718c-473c-952e-c4179912dfd8	Hoàng Văn Phúc	14/01/2008	Nam	Kinh	\N	t	\N	26/03/2023	0376083663	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
f68374ec-97d4-413a-8ba9-0b03aa193330	Hồ Thị Bảo Phúc	29/01/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0386701578	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
7495eaf1-ee87-40f4-8f4c-805e8541b920	Đoàn Anh Quân	26/10/2008	Nam	Kinh	\N	t	\N	18/01/2026	0867942248	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
11d37ac1-ef43-4733-8ae7-88f327f1b603	Ngô Đức Sỹ	03/12/2008	Nam	Kinh	\N	t	\N	14/01/2024	0862246494	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
693fb770-8110-4f67-934f-66e57388e6e4	Đinh Hoàng Thu Thảo	26/03/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0794643167	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
611e1b11-00dd-461e-9916-b420a477cb97	Hoàng Thị Phương Thảo	29/10/2008	Nữ	Kinh	\N	t	\N	18/01/2026	0389905667	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
06a457b9-a104-45e3-916b-0f209197c445	Nguyễn Hương Thảo	30/09/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0347745938	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
0c8d451f-2c7c-43ca-864b-2502b867a811	Nguyễn Đức Thắng	09/09/2008	Nam	Kinh	\N	t	\N	01/04/2025	0839687889	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 7 - Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
1ef44547-07ea-4870-9f8a-459a42c5633c	Đinh Thị Thanh Thùy	25/11/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0833827587	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
f31ecdcd-3d9c-4e36-9a36-2fed61974bb8	Nguyễn Thị Trầm Thương	11/01/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0395372178	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
c804ca96-fd95-46fe-9856-5e529068e878	Đỗ Công Tuấn	06/02/2008	Nam	Kinh	\N	t	\N	22/04/2025	0987802574	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
8543c2da-e7d3-4763-8222-c4f1bdc7f3fa	Nguyễn Thị Minh Uyên	22/08/2008	Nữ	Kinh	\N	t	\N	09/01/2023	0355425605	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 1 -Xã Đức Cơ -Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
c1bf1cc7-d030-4e3e-bdee-728b623dbf87	Nguyễn Lê Vy	14/02/2008	Nữ	Kinh	\N	t	\N	18/01/2026	0356918059	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Mook Trang - Xã Ia Dom - Tỉnh Gia Lai	02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	2026-05-10 10:10:12.673721+00
1262dc00-8ce8-48d7-8ce0-61cc307134b8	Lê Quang An	12/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
278c07ce-25d1-455c-b099-ab2f36550aa0	Nguyễn Ngân Anh	20/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
08b90bcd-1b9b-4db1-83ac-a3a80d161200	Phan Ngọc Gia Bảo	19/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
2bcf65d2-4d7e-4e1a-b4b9-d2620eca9bd8	Nguyễn Thị Bình	02/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
c224c5fe-36b5-40f4-ad8f-e8342e718c81	Lê Thành Danh	19/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 7, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
1a2dbbb8-59ab-4cd0-a0d1-8241f5207771	Đoàn Thị Ngọc Diệp	26/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
cab670c2-5324-4eac-bc55-e12942be3694	Phan Văn Dũng	14/10/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
38368955-a039-4858-a702-329d6777aa80	Phạm Thành Đạt	11/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 6, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
6053d93d-93aa-437c-9c91-acfed89a10d1	Phan Tấn Đức	16/05/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
55bb7c95-ccd2-4cac-ab6e-6c22061f82da	Trần Thị Bích Hằng	13/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
98863bdf-9caf-4c19-bb1b-b3e9d7f2e5c2	Phạm Tuấn Hoàng	20/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
5663b591-4765-4d18-9c52-2a32c80dc1f0	Trần Lê Huy Hoàng	03/10/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
fcdccb11-7aa5-47e2-b382-0aa4caf926c6	Hồ Sỹ Huy	01/02/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
ec5ebcbb-40b2-4f65-ba14-3d96427c7b72	Hồ Sỹ Huy	27/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
3ca78ec9-c1de-4614-aeb0-6429ced27ea8	Trần Quang Huy	13/05/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Mook Trang, Xã Ia Dom, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
b268e8d2-ee5e-4834-af0c-59661f28d9c4	Hoàng Thị Thu Huyền	14/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
74db1cf9-f6d7-40d2-a4f7-cf49d6a81d5b	Đào Duy Hưởng	16/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Ia Krêl, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
ac0ebb15-1438-4c18-8b2a-acde84d007e9	Mai Thanh Lâm	23/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Chía, Xã Ia Nan, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
56ce8ac6-6acd-44e7-8c96-556ba9f86c3b	Phan Văn Long	11/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
f42fff47-4294-47c0-9441-c1812875e7d0	Lê Thị Mai	05/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
024034e5-d4d5-4fea-821f-32c9517640e4	Cao Thị Trà My	14/08/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
38d21942-a4ef-453a-b8aa-ce3089a4e0d8	Phạm Lê Hoài Nhi	01/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
4b8c5b98-5797-41e1-9e08-236afcb858f5	Dương Lê Thảo Phương	17/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
dfbdd7d4-b46a-40e1-a914-8836ca542e5f	Nguyễn Anh Phương	09/08/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
b1ec759b-3e72-4153-8388-7229076ee8c0	Nguyễn Chí Quốc	27/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
a03c70b2-2fd5-4e9d-a144-c513a70cfade	Nguyễn Thị Diễm Quỳnh	02/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	ThônThanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
9beba55b-34c5-44ad-bf3b-f18b99df14a7	Võ Duy Tài	10/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaLâm, Xã Ia Krêl, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
f189b1dd-d593-4a9d-8a52-5801c6aa1de4	Lê Hữu Thành	09/08/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
ea550a99-89d0-4b2c-91dd-d5f1ada38a3d	Lê Thị Xuân Thu	01/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
b9301d0e-cf81-405e-a4e3-b6ef05bb28f7	Đoàn Anh Thư	10/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	THÔN ĐOÀN KẾT, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
5c54810f-00d3-4bfc-97af-52b000e31346	Nguyễn Bùi Anh Thư	28/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
e113fe33-9e54-48c4-a2a1-b7c36869443f	Võ Hoài Thương	06/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
240ddb67-cceb-4723-a3d8-143db9537691	Nguyễn Thị Ngọc Trâm	20/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
d10dd044-2e69-447e-929e-cb771ee07b42	Trịnh Lâm Trí	28/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bi, Xã Ia Dom,Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
8fca5249-e6f7-4365-ac72-d5cefbf170c8	Nguyễn Đình Văn	24/02/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
01e11cb8-a847-473d-b5cf-879e2a0ee3bd	Phạm Nguyên Việt	12/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
bb71d109-6f0f-4ad5-8717-ea42fb4127f8	Lê Thị Yến Vy	18/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
58d12e26-45fc-4cc4-89b8-e36ccedda559	Phan Thị Kiều Vy	03/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	692c1b86-a6f3-4cd3-95af-770211b5613f	2026-05-10 10:10:12.673721+00
0b528d18-3afa-4950-8939-0fe9999a2690	Lê Đình Nam Anh	23/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
1ee580f3-6959-40ef-92c4-75296f77b63f	Lý Trâm Anh	31/10/2008	Nữ	Nùng	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
27c70622-9c5d-4964-bfaf-e8f3c8d361ab	Nguyễn Hà Anh	22/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
4ae6fecc-d96b-4345-bdc1-449f5cd4450b	Trần Gia Bảo	28/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
68172dfb-989d-421e-a6cb-ddcfdaf32299	Trịnh Phan Kim Chi	23/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
78bab781-bc14-4344-9399-44a27abf133c	Nguyễn Trọng Cảnh Duy	28/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tốk, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
d77aa743-bc44-49a0-b512-dc642a2cc5f4	Lê Văn Đạt	22/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
dd4711a5-aa01-494f-9c61-7a1addf87edc	Nguyễn Thành Đạt	29/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	 Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
92226c7f-666c-4328-ab6f-fd4268864438	Nguyễn Tiến Đạt	27/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
91508566-87b6-4d3c-9b61-d3a4579a57a0	Vũ Đình Đạt	26/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
c5a388ba-8a47-4211-8a82-1001d9610837	Hồ Văn Đức	06/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
fc17109d-9afc-420d-bb04-663318844ea4	Vũ Thị Thanh Giang	01/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
54764eb0-cbd6-42a4-8e89-f5ba40ac7f59	Lê Nguyễn Hồng Hà	06/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
730a2585-f132-47eb-ad1f-a04949a7e15e	Nguyễn Gia Hân	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
1cbf52e6-76be-49d8-91ad-1391f668f218	Nguyễn Khắc Hùng	22/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
732297ec-15be-4af8-9312-6329c9344c62	Dương Công Huy	24/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
2b35ea12-106e-483f-88b9-ca5bea1e8b67	Trần Thị Lan Hương	10/03/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
78f76a93-c9a5-406f-9702-7248ce9078a6	Lương Nguyễn Anh Kiệt	29/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
e095f0ba-6f01-40c7-a090-e2492983fb8c	Nguyễn Việt Linh	16/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
cdc6f956-be8f-4ecd-a43c-cf1a5403e90d	Nguyễn Trần Khánh Lợi	30/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
8e722d3f-c2ac-4c12-80dd-abf00e9e6758	Nguyễn Thị Bảo Ly	27/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
44be94c8-942b-47bf-a9f8-469541eac20d	Nguyễn Nhật Minh	16/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
09c3a075-db4b-4c1e-968b-1f53aa3b1426	Lê Diệu My	21/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
8463484c-76ee-4cca-ae8e-d59c1948fdae	Lê Võ Thanh Nguyên	20/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
5201dae6-df79-4675-8364-7725b43b0f75	Nguyễn Thị Ánh Nguyệt	04/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
6663b4a9-1bcf-4860-b6be-e9ce79604c7f	Cao Thị Yến Nhi	11/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
0a0c10eb-e821-472a-8531-172491ce50f0	Nguyễn Ngọc Phương Như	17/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Nú, Xã Ia Nan, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
9593b6c3-1718-4922-be70-83a9ea83141c	Nguyễn Văn Quyền	29/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
9bcf4b35-bd78-449d-8240-a2bd05717f93	Trần Thị Mỹ Tâm	28/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
8f1c2db0-635c-49b8-bb12-08598b3392a2	Trần Thị Lệ Thanh	29/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
59ea1f79-986b-437c-9f54-decb23f1727e	Nguyễn Thị Anh Thư	25/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
1051a528-25a4-4e1e-8a1a-b57469d782b7	Trần Minh Thư	16/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
f5f8f751-7321-4ae2-8cdd-d81df27eab98	Đoàn Huỳnh Mạnh Tiến	07/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
5cfc80fe-7d2d-4d2c-9bab-6b5edef1624a	Phạm Thị Huyền Trang	16/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
bf60e170-98a1-49ff-9c52-b37aa60885b1	Trần Cao Thùy Trang	25/11/2007	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
befe5a1f-fc19-4352-917b-f875039edfa2	Lương Thanh Trúc	10/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
1c9362bc-7b26-4c1e-aa30-54f09308502e	Hoàng Khương Kiên Trung	19/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 6, Phường Thống Nhất, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
481ca1f0-d7ef-4e60-b04f-781f3942a6c0	Từ Thị Ngọc Tuyên	28/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
47b54946-07e6-4bf5-bc47-94d7b1e95f25	Phạm Minh Vũ	24/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
f574c22d-f5d4-429a-a8af-5b5508b9b88e	Hoàng Uyên Vy	12/05/2008	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	8a09a494-de6c-4222-a716-51c456b8333d	2026-05-10 10:10:12.673721+00
82803986-02a9-4d6c-af2e-29df0c2cc5cc	Đỗ Võ Tuấn Anh	17/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
77c6e565-d5e4-42dd-a488-e1c4cce713a6	Hoàng Thị Kim Ánh	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
e4fbef68-ab59-4e78-a8a2-16908f01e0cf	Phan Thị Ngọc Anh	29/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
18801154-0bae-4067-9081-ead3e464e965	Phan Tùng Anh	03/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
bf7ff3be-6cb9-4420-a009-872b29fc750a	Nguyễn Thanh Bắc	17/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaLâm, xã Ia Krêl, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
fbc172cf-5b0a-4377-9b7f-5c995aa1e566	Hoàng Hải Bình	27/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
95c7f0bb-402d-4d57-8011-c29d04ec053b	Nguyễn Ngọc Chương	22/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, xã IaDơk, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
628d8e4d-f9e8-472a-820f-57f59da88101	Lê Tuấn Dũng	01/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
daa8d09a-292f-48ca-8f8d-32478710878c	Mai Tấn Dũng	20/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
d28c0555-becb-4e3a-aa2e-f4ad74a48f7e	Mai Tiến Dũng	20/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
81512613-035b-4bac-8af8-ffb9c3935a33	Hồ Thái Dương	20/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
c4b45ef2-ab16-474c-882b-b260b7adf25d	Hà Ngọc Hạnh	30/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2 , xã IaDơk, tỉnh Gia Lai 	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
083ffc35-4d42-454b-8602-9e16c236617d	Lê Thị Thu Hiền	29/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
4ccd2d9c-a48e-4536-9cd1-450bd7890d3b	Vương Thị Hiền	28/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
39c2aad0-269a-4029-9ebb-ccad69fdd5ab	Đỗ Ngọc Hoàng	24/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
0f0786e7-1d42-432f-a0f0-460759df48a0	Nguyễn Thị Thu Huyền	01/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
1abdb75e-5bcc-4e6c-9787-2be3771d1f30	Đặng Thu Hường	06/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
7072d18e-5d79-4950-932c-6908aef42709	Đinh Thị Hương	16/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
fbcbc898-5d2f-46cd-af8b-bd7734111073	Ngô Đức Linh	31/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krê, xã Ia Krêl, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
884dc1c5-9cf3-4251-be44-0b19901a1997	Nguyễn Ngọc Hồng Linh	08/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
d95271ae-fea2-45d7-b504-345620bc28cb	Trần An Lợi	14/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
62ab1d00-b091-4391-a8c9-40d1f14efdb0	Phan Vũ Thành Luân	25/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
7621bb3f-a187-4046-ba92-4a26220533e1	Trần Hải Ly	11/03/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
463f3c96-a68d-4bf6-b123-a0c08a68e508	Đàm Cảnh Minh	04/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
be0586bf-2920-4ce4-906b-fe4107f5960e	Võ Hoàng Minh	23/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
41fdb23e-d5cc-483d-8630-bc436134a0b7	Hà Thị Trà My	19/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2, xã IaDơk, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
73d5128f-e1c1-4f5d-8302-936fe853bd5c	Tăng Ngọc Nam	11/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
db4cb003-c9ed-4552-9c2e-d58b39be38b8	Nguyễn Thị Quỳnh Nga	21/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
5ece0038-4ad6-4657-8392-75c1bdb47306	Chu Nguyễn Bảo Ngọc	18/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
028aaea9-615a-4ce4-8a91-02b0c601a063	Mai Thị Yến Nhi	27/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
2698aaef-2492-496c-9041-eec131c84777	Lê Thị Mai Phương	25/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
1cb52ccf-9fc5-4772-a60c-f5294d3d348f	Nguyễn Thị Phương	09/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
0d7fedb5-300b-4140-ade7-dcb09ec4026f	Trần Minh Quang	01/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
9acff5ee-8147-4328-8b9a-951aa09b0263	Trần Khánh Quân	10/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
3d81158e-378f-427b-a5cf-39ad264d225b	Trần Minh Quân	21/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
c1210cb2-2427-49cd-85ce-6e610b59ac23	Nguyễn Cảnh Tân	01/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
0866b5b6-ec0e-4947-801a-83f580a34306	Nguyễn Hữu Thắng	12/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
e5d4000d-c6f8-47de-8f26-cbbba8ef5abc	Phạm Anh Thư	14/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
55216ca4-32f6-4e92-9636-626b9acc0842	Nguyễn Thị Thùy Trang	13/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
ec065ac6-4a68-467b-9ab1-df336b4dceb7	Nguyễn Xuân Việt	15/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
96bca4c0-869a-43f2-aa53-7d72c3c67136	Phan Hoàn Vũ	26/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	52995469-d22c-4b64-9fc0-18c64f146fc7	2026-05-10 10:10:12.673721+00
9a4bb193-c3d4-49ed-a4dd-9c7ba48bfa84	Đinh Hoàng Anh	14/10/2008	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang - Ia Dơk - Gia Lai (cũ)	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
514dc7fe-a2c4-4613-8487-b4bc014a2013	Hoàng Việt Anh	07/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Đức Cơ- Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
f527b1ac-aae6-42b4-937d-c83270a412fe	Lê Công Ngọc Anh	25/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - Đức Cơ  - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
d30c3070-dca1-4827-af94-57e61f0d90c8	Nguyễn Hoàng Anh	29/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
db6b9f4b-b678-4ae9-81bb-4f7eec64238f	Trần Đinh Hoàng Anh	18/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP1 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
25262c8e-7f25-4996-95d9-3f8b7a820714	Rơ Lan H' Bích	10/01/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le Kắt - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
01e38891-c7bc-4a19-add0-005338ff3234	Hoàng Thị Quỳnh Chi	11/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3  - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
0a3a7714-38dd-4bf0-9569-fb8d19cf5af7	Hồ Ngọc Quế Chi	26/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
3cee3e13-4e24-4095-a852-5d7caa5a1f9c	R Lan H' Diệp	19/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Lê Kắt - Ia Dơk- Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
a787fcf2-3f01-42d4-81e6-3e94ec773745	Lương Quốc Chiến Dương	25/02/2008	Nam	Tày	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
3e22adba-bb94-4968-8656-7665b92896ba	Lê Viết Đạt	03/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl - Ia Krêl  - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
64760071-dad5-456e-a35c-d3c05fe9824a	Mạc Phạm Hải Đăng	09/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
e5705b83-2e7b-412b-9699-02c386db7872	Trần Thị Vân Giang	23/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
700e5f12-06c9-49eb-a5ce-cc1f79709e1d	Lê Thị Thanh Hằng	29/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lâm Tốk - Ia Krêl - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
dce0e731-4c30-443b-ac34-6887fc2f2d83	Lý Gia Hân	30/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo - Ia Krêl  - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
f54cc085-f3b1-45a8-8115-ec3947f17ab0	Vương Tiến Hùng	29/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krêl - Ia Krêl - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
d4231934-eaa1-4366-b3fa-8b9e273cfcac	Lương Trung Huy	18/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
eb44c22d-095a-4fc0-81c8-34c39b5b4bab	Nguyễn Trần Minh Khôi	09/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
66fc981c-da30-4b4b-b73a-3abb148e4590	Hồ Lê Phương Linh	27/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP1 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
5b5ec88a-200e-41e3-a57c-7e0e0215e2cd	Đỗ Thị Tuyết Ngân	23/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm - xã Ia Krêl - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
95ead1d4-6d19-40d8-b2b1-58947c89670a	Nguyễn Thị Hồng Ngọc	12/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ II - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
5b955d67-6e02-4150-9472-5776fece35eb	Tào Trần Bảo Ngọc	26/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - Đức cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
852a9ad7-2d9f-4d38-b379-95da5da83fa6	Trần Thị Thanh Nhàn	15/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
17254d7a-16f6-4cf9-b98e-d854912ee0a4	Đinh Trọng Nhân	09/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông - Ia Kriêng - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
bb4f8cd1-f00d-4b69-87f2-685d9d7ed2b2	Nguyễn Thị Linh Nhi	10/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Ia Krêl· - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
ef88093a-cea1-4b86-883c-43177da00053	Nguyễn Thị Hồng Nhung	21/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Giáo - Đức Cơ -Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
9774e2f5-3b39-4c35-8148-bce6545d5de0	Rơ Mah Phiên	13/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè - Ia Dơk  - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
da7a75fd-09ab-4f3f-9fff-6046926f6390	Phí Mạnh Phúc	25/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 2 - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
67ad4a27-7ecb-4fa2-97d2-a02cc9ea4f63	Đậu Tiến Quân	03/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết- Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
08b844bc-1fa1-4955-8b00-96fde1d105f1	Trần Ngọc Quốc	19/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Giáo - Iakrêl - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
daf1a5e0-249c-414f-a5d9-1e8c477fbc0f	Kpuih H' Si	20/01/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang  - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
1ea22b96-5b7b-4c4a-857d-0fd2450845dd	Kpuih H' Soa	06/08/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua - Ia Pnôn  -Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
45ff376d-5ea0-4fcd-85e7-02f8e4af4357	Hồ Thanh Thanh	18/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 -  Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
9b91933e-8499-4638-b75d-e4ee7ad8d873	Phan Chí Thành	02/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
e10040f8-9476-415e-b9de-e559054ae12b	Phan Thị Phương Thảo	27/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Giáo, Iakrel, Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
34d9a043-3616-44bc-a6b9-dff23d7d64ac	Hồ Phúc Thịnh	02/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP4 , Đức Cơ ,Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
33c5827c-be78-4d33-8713-59e35dbb1471	Vũ Hồ Anh Thư	11/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6, Đức Cơ , Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
8218cafc-bac0-4f40-a112-8439d7bd7ee3	Lê Xuân Tiến	25/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
b4f443a0-fbd2-44e7-b73c-ce8b4e492186	Hồ Thị Tình	24/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết - Ia Dơk  - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
28a3b024-b9d3-4c91-a3ba-10fb1a9ce4c8	Lê Thị Ngọc Trang	04/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
38e9a5e5-de8c-4be6-a148-359d50e4bb90	Phạm Thị Huyền Trang	25/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1  - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
d6d24251-1a68-451a-8eb9-048e4f32b90f	Rơ Lan H' Thuỳ Trang	11/01/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
164704cc-da8d-47de-b35b-83fdaa228333	Dương Quỳnh Trâm	17/06/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
248bee28-a165-4528-8325-4663bf2908fd	Nguyễn Thị Trâm	14/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang - Ia Dơk  - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
384f87a7-b8ad-43e0-aabf-e9bd7ca04bd1	Rơ Mah Trân	28/08/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - Đức Cơ - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
fdc1536f-f271-4b0a-8346-e78609bd541c	Lê Văn Anh Tuấn	03/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm - Ia Krêl -Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
e99d9f60-9630-47c9-a2c7-3a0be60a5a55	Rơ Mah Tuấn	07/02/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
fa2acb48-8794-4819-bf3f-2f6f93c8993b	Rơ Mah H' Tuệ	12/12/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pong - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
56e8ce9a-20b2-438c-a9c5-d3bd396cdcb1	Rơ Mah H' Út	30/09/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông, Đức Cơ ,Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
31a5ee66-64c9-4bc7-a201-3d20b101f2fc	Ksor H' Uyên	21/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Le Tung - Ia Dơk - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
e92696ba-fc80-47c5-832b-c3e43fa18117	Nguyễn Thị Hải Yến	13/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Tân - Ia Krêl - Gia Lai	3b39cf16-56a8-4915-a043-216715c380ab	2026-05-10 10:10:12.673721+00
2ce7393d-0b66-4121-b46c-eb7558315bbf	KSOR H' HOÀNG ANH	07/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - Xã Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
990f7cf4-d3aa-4cd9-87b0-c33b169abedb	PHẠM THỊ VÂN ANH	14/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Lâm Tôk - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
870347cd-09ec-473b-9dd2-d9bee5680788	LỤC VÕ THÁI BÌNH	09/11/2008	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
d695f28e-2243-4a30-ab09-75a63de6f01b	NGUYỄN HỮU CHỨC	22/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP6 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
91cdf95d-f545-47d3-9551-3cca865252b4	RLAN H' DIỆU	28/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Le Kắt - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
cdf24097-3b8b-4885-9c9a-383f1100e017	Hồ Thị Thùy Dung	05/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2,TT Chư Ty, Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
ab98ae0a-1fe8-4afe-beaa-64ff02f9cf9c	NGUYỄN THỊ DUYÊN	10/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP7 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
9a10cdba-0eef-4db6-bd6c-52cd473eba2f	NGUYỄN THẾ ĐẠT	03/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 -Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
f1f4d744-4d4f-42ba-b466-82178e4fa917	LÊ THỊ ÁNH ĐỨC	18/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
1665859f-52fd-49b5-8612-c8b929d14c5a	TRẦN LÊ THU HÀ	19/12/2008	Nữ	Kinh	\N	t	\N	09/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đoàn Kết - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
00e28151-cfbe-4018-97c2-adae41acb6aa	KPUIH H' HAO	21/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
bd64996e-04b3-4a50-a2c2-e9368ae208e9	NGUYỄN HÀO	07/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
6ae929a6-1fea-4aa1-b8ff-4ccc6a7ae0f7	HOÀNG THỊ THÚY HẰNG	14/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
d26e0ab7-c724-4212-a7fa-1ace7fbc05ff	LƯƠNG THỊ THU HẰNG	18/09/2008	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Ia Kriêng - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
d3dd0f1c-2fe4-4ca8-93c5-0320ea930d42	NGUYỄN NGỌC BẢO HÂN	28/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
4689f56a-f99e-402e-9b62-7ebecb407f53	TRẦN MINH HIẾU	08/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
db32e5e0-4506-4422-bf96-669c284f5ae7	KPUIH H' HÚI	23/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
727a5d8c-4235-4b6c-9b49-417356a0a332	RƠ MAH HÚY	10/12/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
c9e7920e-e623-4b70-8e0f-b0a9869586d7	NGUYỄN THỊ KHÁNH HUYỀN	01/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Lâm Tốk - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
d7216f9b-17ba-4ccb-959a-7a3b2dc8b713	LÊ NGỌC KIÊN	27/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
3578b148-2373-4531-9c05-e94349bc12d3	LÊ THỊ THÙY LINH	18/03/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
17869143-235f-4486-80d5-b49e540ab56f	NGUYỄN THỊ PHƯƠNG LINH	17/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đoàn Kết - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
4f941a6f-4734-49fd-a887-e88e04aa3682	Hồ Hữu Lộc	05/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1,TT Chư Ty, Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
b239bc66-e41a-4f16-91d6-8e114ab12b96	NGUYỄN HOÀNG HỮU LƯỢNG	09/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 4 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
44ca085d-c2b1-454c-ad14-de64ebb32ae6	RƠ LAN H' MƯNH	06/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Kép - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
00d61fec-bee9-4f72-b755-97f7ce13d4f6	LÊ THỊ MỸ	26/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
8dbebf13-1163-407d-a6dd-2e7e6b965f7e	NGUYỄN THỊ HỒNG NGỌC	29/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đội 12 - Ia Chía - Ia Grai - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
64be41cc-e9e6-4219-8137-20c40bf4bdf5	NGUYỄN PHƯƠNG THẢO NGUYÊN	09/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
7e1941b4-0586-4f16-807e-1ddcbd307301	PUIH H' NHE	02/12/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
91d041bf-31d3-4b68-8ab7-c7d8fd19ac76	ĐẶNG THỊ YẾN NHI	18/06/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
da4dcee3-d7f8-4260-93f0-2e5a4302f01d	TRẦN BẢO NHI	28/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
eaf09a02-6d12-4022-adee-e1a4f4146562	TRƯƠNG THỊ HỒNG NHUNG	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Tang - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
269aabb2-11a1-47b0-9f34-be76e3681e14	NGUYỄN THANH PHƯƠNG	24/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
284113b7-7ab7-4cd9-9840-d8d7cd15ded2	PUIH PLÝ	06/02/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
680b90c0-ef41-4bfd-804d-b8013138b675	Hoàng Long Quyền	18/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
43fc98e5-f68e-418d-a6d3-22fefcd7c02c	RMAH H' LY SA	01/05/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Le Kắt - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
6f9b580a-101a-44f2-bc79-336322d16341	SIU LI SA	26/03/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
b095790c-8115-4fee-b275-61573aa8f14b	ĐÀO THỊ THANH THẢO	11/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Chư Ty - Đức Cơ - Gia lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
6bc2373e-b659-4a66-9823-186acbacf20d	NGUYỄN THỊ DIỆU THẢO	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
e22f66f2-f1ab-4a0d-a3ec-703a47ec7f9c	KSOR THEO	01/01/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
b29cd0d8-37ee-428e-9d66-7a869f47b3ef	QUÁCH ĐỨC THỊNH	06/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krol - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
9478a3cf-004c-4f7b-b3cc-9e46a4ab3c82	NGUYỄN THỊ BÍCH THỦY	02/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
c12f148a-ca31-4abf-9ac3-6be721849ee0	TRƯƠNG THỊ THANH THỦY	20/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
11b7628c-4b70-4c81-8b21-902d45ac2b85	NGUYỄN BÙI ANH THƯ	09/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
fe6c831c-8bfd-418e-b749-391361592b8a	NGUYỄN LÊ HOÀI THƯƠNG	29/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
8df0e589-15e0-441c-be9c-7c5a2b5e2380	TRƯƠNG ÁI MỸ TIÊN	29/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
e18b972c-3284-4162-b8ee-356475d09135	LÊ THỊ HUYỀN TRANG	04/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
4c9cacfd-ca34-49fa-bfa3-42038d343086	KHUẤT ANH TÚ	30/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
145124d7-3f1a-41e6-8fc8-e5cd953a2295	PHAN ANH TÚ	06/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
bb365224-cc47-4a15-af33-7aa24d5baddf	RƠ LAN H' TUỆ	27/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung - Ia Kla - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
7b480bf4-f1f0-4e57-8717-d6722dac0216	SIU VIÊN	04/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai	3990d292-e5e7-4897-864d-efd183724253	2026-05-10 10:10:12.673721+00
49f6b9c7-99dd-49c4-a9e8-f73589207ef6	Lương Hà Anh	09/07/2008	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Đức Cơ - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
a5fb6db6-6d0f-4e62-b827-b407a5a72527	Nguyễn Thị Ngọc Anh	29/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3- xã Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
7ca7da02-fc97-4c0d-98d0-7e708f92c286	Dương Văn Bảo	18/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Đức Cơ – Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
2795d53d-43aa-4c07-8f4e-289889fc6775	Rah Lan H' Ru Bi	28/11/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le kăt, Xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
6d8193ab-f217-4839-ac6e-00cc0bd759b5	Kpuih H' Chúc	15/09/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông -  xã Đức Cơ - Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
6646e015-0b9f-4717-a7f8-cdfcb6af15db	Nguyễn Sỹ Dũng	01/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Đức Cơ- Tỉnh Gia lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
bfbaeda3-1671-488e-8b73-a52b894e5f9b	Nguyễn Thị Thùy Dung	13/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia tang, Xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
56126567-f0f9-4c3c-b5c9-44489712f760	Phạm Thị Thùy Dung	26/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6-xã Đức Cơ-Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
e03ce750-0dff-472f-86d2-f19798b3243b	Nguyễn Thị Duyên	31/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
c0a5bbff-49a1-4c13-b8af-6377d2c5906e	Rơ Mah H' Điệp	01/08/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung, Ia Dơk, Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
55880c58-cd44-402d-a391-14afa4ec9293	Lê Đình Đức	13/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6- Đức Cơ – Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
e3d32ac2-163b-4e40-ab24-4592821de9d4	Nguyễn Hồng Hạnh	05/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bua, xã Ia Pnôn, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
3261dc35-8529-4872-bbe9-bf22ca467dc8	Rơ Mah H' Hát	19/10/2007	Nữ	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung -Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
a52d6a26-ff2a-48e6-8d68-648098a8c7d3	Nguyễn Thị Hiền	12/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
2b00220e-526a-415b-b869-5111b4a6b2a6	Nguyễn Thị Thu Hiền	14/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2,  Đức Cơ, Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
19149592-0e9f-4a01-9439-73372c08bfb1	Vũ Hoàng Diệu Hiền	11/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6-  Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
42952016-6038-4619-9872-f390127bacea	Lê Thị Hoài	06/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
a82c3793-cd93-4525-abbf-6d29741211e7	Phạm Đình Hùng	02/02/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4, xã Đức Cơ, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
8488d69b-d345-46aa-8195-5b496a7ed48b	Hà Thị Lan Hương	25/08/2008	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krái, Xã Đức Cơ, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
072323ea-1b8a-4038-b095-6c83a57a39b5	Lê Văn Khánh	10/05/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7- xã Đức Cơ-Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
38332134-4509-4042-9488-b2429f7da5bb	Trần Lê Ngọc Khánh	01/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn kết, Xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
09f953ed-3346-4010-b0c3-57a58c7fbf6e	Kpuih Khoa	11/12/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung le tung, Xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
c611ba9e-589b-48f7-85fd-6b78601563da	Rơ Mah H' Lan	16/06/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang -xã Đức Cơ - Tỉnh  Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
927cf030-53bc-43f8-af50-f28553cee0d6	Nguyễn Hải Lâm	01/12/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn ia lam- xã Iakrêl - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
bf7dc58d-4843-4057-ae46-83476cf3da96	Rơ Châm H' Lệ	23/10/2008	Nữ	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	làng dơk ngol ,xã ia dơk , tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
69d303f8-bd62-4170-9749-06145e54db09	Hồ Nguyễn Khánh Ly	21/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn kết, Xã Ia Dơk,  Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
28c9ff09-b566-4437-b29b-ef99bb2fe0ba	Vũ Thu Ly	25/05/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
aac80961-7155-419d-a78d-edf0f4a5a182	Hoàng Thị Diệu My	09/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Đường Tăng Bạt Hổ, Tổ dân phố 9,  Đức Cơ, Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
b1e07668-2abb-4593-8c40-eb4c57961ba2	Hồ Hoài Ngân	04/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ II - Ia Dơk - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
0ba4f24f-28e7-4d63-a571-17858b42833d	Đinh Thái Nghĩa	28/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 -  Đức Cơ - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
06da4b1f-10d1-4f31-9041-a8a4045ef828	Đỗ Khánh Ngọc	04/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk-  Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
b6467574-0c4a-4782-8861-00854ff45f34	Nguyễn Thị Khánh Ngọc	31/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - xã Đức Cơ – Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
d1e406c1-0df1-4f95-ace9-ccbc0ba99336	Vũ Phương Yến Ngọc	14/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung tung - Xã Iadơk- Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
74357861-208c-4b25-9003-51d33ef1db44	Rơ Lan Nhung	28/09/2007	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung- xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
11995ef9-91a1-4fb0-a8ea-68c399a72a49	Kpuih H' Như	20/04/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông-  Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
84054541-f386-4d43-9b28-e810a151b46f	Kpuih H' Nhưng	10/11/2008	Nữ	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk- Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
d17cea4e-e0de-4e6c-8289-69bb693c8448	Nguyễn Thị Hồng Phương	14/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lâm Tôk- Xã Ia Dơk -Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
806f2e46-eefe-49ee-a4f5-828fe71cce8a	Nguyễn Thị Ngọc Phượng	05/04/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
a9d78447-40ac-41cf-b769-6e7682114831	Nguyễn Mạnh Quân	28/10/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 – Đức Cơ – Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
a7a52d0b-bd16-4bb5-9170-5fc49deb5865	Lê Nam Thiên	24/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ 2, xã  Đức Cơ, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
53bfca12-a146-4659-92a2-e5be0073afd8	Lê Trường Thịnh	17/07/2007	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ , Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
1caea613-90af-42cb-99e7-8daf8e8dbab2	Nguyễn Đình Tiến	06/01/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ DP 6 -  Đức Cơ - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
3edd165e-5839-4b98-8c6e-f7c495777cd6	Rơ Lan Tiếp	08/07/2008	Nam	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Đo, xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
6868e23c-5120-4f8f-9e0a-c7f37a4916f8	Quyền Đình Trọng	12/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
1d19ff52-e008-4e97-b284-7fe7a5007c17	Rơ Mah H' Trúc	28/11/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Le - Ia Dơk-  Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
70a67951-5894-41fd-a3e4-f06841622060	Rơ Mah Hà Trúc	09/08/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kắt - xã Ia Dơk - Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
fc62d3d2-5881-4b91-8217-853223104d48	Rơ Mah H' Vân	19/12/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le - xã Ia Dơk - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
ddd9ed32-4afc-4cf7-b7d2-69c9afc4242f	Rơ Mah H' Vị	17/06/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép - xã Ia Dơk- Tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
ab150de3-3b90-46a2-90ec-2c7c9ad3a536	Nguyễn Ngọc Vũ	25/04/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9- Đức Cơ- Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
389a422e-37ea-4e33-89e7-e5a0b8e76e33	Rơ Mah H' Y-Su-In	16/05/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Kép - IaDơk - Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
aa563348-7320-4f0f-8dde-dc904f67bf99	Hồ Thị Ngọc Yến	27/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tdp9 , Đức cơ , tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
1baaa070-9bf2-46a6-bdce-fec2548a1b7a	Nguyễn Thị Ngọc Yến	06/05/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn krel ,xã ia krel , tỉnh Gia Lai	ed01c317-ee64-4d47-abf2-c2bb06d4987d	2026-05-10 10:10:12.673721+00
c7e21be6-ef01-4e67-915b-1cbcd1b20dc9	Phan Đình Hoàng Anh	24/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
d26f5b54-21d8-48bf-bce8-d6dfa56c22b3	Đặng Gia Bảo	20/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
b9478d73-20cf-4f8d-9b3a-2aa85a49f8a9	Hoàng Gia Bảo	18/10/2008	Nam	Sán Dìu	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
91bb0891-0aee-4322-852a-68e978389f8f	Nguyễn Trần Nhật Đang	16/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
94415e7e-a63f-4ae9-93c6-3fbf7ccecf2e	Nguyễn Văn Định	27/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Kăm - Xã Ia Krêl - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
42a7dfb2-f358-4156-afcb-34bd2f1f82fd	Lê Đại Đồng	15/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Xã Ia Krêl  - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
b8062965-4da6-4b97-993b-edec25c1963e	Nguyễn Hoàng Gia	18/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
c1246aeb-14aa-4f9b-a740-02ed568cd22a	Rơ Mah H' Hà	10/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Kắt - Xã Iadơk- Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
80cb17c3-cfc7-41d1-bbb3-1e06c23f4b2b	Nguyễn Thu Hiền	22/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2 -Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
8870fa10-09df-497f-a24b-05e86915908f	Rơ Lan H Khâm	06/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le Tung - Xã Iadơk- Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
49de0734-f20b-42b2-bd11-6259faa8d36d	Đỗ Đình Lâm	29/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lang - Ia Dơk - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
0c8c0fad-cc7c-4ee4-ba29-03c4dce61067	Đinh Quang Lộc	01/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
31df2f18-fa68-4760-8345-c0eedcc4fe7d	Nguyễn Ngọc Mai	10/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
85b207c1-5d45-4eaa-af58-dba2e6394b97	Lê Thị Trà My	06/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
e8338221-4c47-459c-bb02-817093f33cac	Nguyễn Hà Thảo My	05/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
73a360d0-cfa9-44bb-84db-a92aec237d26	Trương Thị Thu Na	04/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
f30f28fe-25c5-4bb1-bdda-f15d15607871	Hồ Thị Thúy Nga	09/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
18c5b642-144b-4da6-93db-dad6840cfd90	Kpuih Ngân	17/03/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol - Ia Dơk  - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
69ce7ac2-04a3-466a-833b-4d3e063e6e69	Đào Trần Gia Như	08/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã Đức Cơ - GiaLai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
869c8021-eb58-4682-a607-9b5370904a3b	Lê Hoàng Hạ Phương	10/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm - Ia Krêl - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
a72055c0-757d-411d-8afc-1dfbc1bcb798	Cao Thục Quyên	28/06/2008	Nữ	Kinh	\N	f	\N	-	0333481577	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
0aabe7ad-8fc2-4a61-9f20-1a2ec7fb6556	Rơ Mah H' Quỳnh	04/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp - Ia Krêl  - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
d9def323-e1e0-4626-bc1f-93662bf9c614	Nguyễn Văn Sỹ	06/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Giáo - Ia Krêl - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
a529814d-3c37-4147-9f70-f626253761e9	Mai Văn Tâm	17/11/2007	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Xã Đức Cơ- Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
b83610b9-c5c4-4100-ad02-d5d14457eb17	Trần Thị Thảo	12/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
81c2407b-86e2-4049-9673-c1cae62c236d	Đặng Nguyễn Thu Thủy	02/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
fd8b3bea-f23b-41ca-9eda-bbcb72ffbdc5	Hồ Ngọc Anh Thư	11/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
f554f506-1d38-49bc-b638-4ab35796c28f	Nguyễn Xuân Tiến	05/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
1010926a-2b44-4ed6-9ae6-2807215e3fca	Luyện Tiến Tình	23/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
f66d3867-be70-4d40-9c65-ce7f28c5bc43	Rơ Mah H’ Trang	21/01/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krai - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
f2b3153a-fa2d-44ae-b98f-69dd3a410e5a	Hoàng Thị Quế Trân	02/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
4a471d99-43bd-46e2-a870-2bd961e9295b	Lê Khả Tuấn Tú	06/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
2fd48a46-cacf-403f-8fc9-0b6cad68fc64	Nguyễn Quốc Tuấn	19/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1 - Xã  Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
3b48dfd0-06c4-4580-8fe8-c6a9cd3e4074	Đặng Thị Khánh Uyên	30/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - Chư Ty - Đức Cơ - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
23d1c554-cfbf-48a9-83e1-554134ea53c1	Thái Hoàng Mỹ Uyên	20/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Lâm - Ia Krêl  - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
76ae53dd-b2b8-4b0f-a935-6ad613eabf47	Nguyễn Trương Anh Vũ	01/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang - Ia Dơk  - Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
e5be8db0-b43c-4843-abc7-ffd01a081423	Lê Nguyễn Thảo Vy	21/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Xã IaDơk- Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
af82b86e-d550-45ec-bceb-96bca8c9b3a9	Rơ Mah H' Yumi	20/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Sung Le Kăt - Xã IaDơk- Gia Lai	25501d0e-9ea8-43bd-a64d-72f7a170ac35	2026-05-10 10:10:12.673721+00
ee70a795-15bd-4da4-9dd5-3882bbeded37	Hồ Hữu An	19/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố1 - xã- Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
db1c91df-3d94-4af2-9082-70fa616dbf6c	Hồ Văn An	18/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Lung Prông- xã Đức Cơ- Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
12a8d8ae-685c-4593-9053-850294f98604	Đinh Thị Ngọc Anh	13/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Klăh, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
d4c5304e-6d62-4a6f-a18d-139284c7880b	Nông Hoàng Diệp Bình	07/07/2008	Nữ	Tày	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Chư Bồ 1, Xã Ia Dơk,Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
434962cc-8c25-44f5-9a1e-5fbc926e81e7	Rơ Mah Bom	19/01/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
0c6cc5f9-a623-444f-978a-80e5a38c84a5	Lê Khả Cơ	16/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Đoàn Kết, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
b300bffc-d4cf-4526-b4f3-d9318266edb9	Nguyễn Văn Cường	26/10/2007	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Dơk Klăh, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
018bbfc1-081c-431a-9446-32e97aa2e005	Rơ Mah Dấu	14/11/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
ee852dff-dd2a-4a29-aadf-dd7f87042849	Ksor H' Diệp	24/06/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Kép, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
01fd1b17-8bf0-4a9a-8335-dd308abf6902	Phạm Khánh Duy	30/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP2 - xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
333a38c1-abf1-45b2-8dec-f53b479bb3f2	Hồ Vĩnh Hạnh	02/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
f1dfcd11-d3a5-4c3c-adcd-8e59b1b99fcd	Lê Thị Hiền	22/05/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố I, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
e18238b6-ade7-4cfd-8219-56e96c76c4f6	Châu Thanh Hoàng	06/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Kom Ngó, Ia Chia, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
f939bbdd-7daf-4055-854c-dd71ff9697c8	Trần Gia Hưng	23/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim, Xã Ia Dơk ,Tỉnh Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
4b4c48ea-4b17-495a-83a0-6ccdf7aefc44	Võ Duy Hưng	28/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 9 - xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
400365ea-4ac7-48c9-8dee-63eaa459e5f2	Đinh Thị Trúc Linh	09/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP3, xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
12be17f0-b702-4cbe-8841-754ea56f6281	Nguyễn Lê Diệu Linh	03/06/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP1, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
2ff0d9d6-f908-48c6-9240-c41abac45fb9	Rơ Mah Luy	29/04/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Hrang, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
1fd960f1-7749-4eee-b08d-925d65f10d62	Hoàng Thị Mai	05/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
bc75c172-ad35-428d-83db-0fdf43ca9782	Trương Anh Ngọc	04/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
e8213c4c-b627-42cc-b560-b1ea8a626878	Bùi Lê Trung Nguyên	01/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
f94e13f8-1fec-456e-b21b-30a349f1cc2d	Kpuih Nhan	06/09/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Dơk Ngol, xã Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
9c3357ae-1916-4800-b6b5-659452661df5	Y Linh Nhi	20/06/2008	Nữ	Xơ-Đăng	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ghè,xã Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
3075b7c3-06ad-4512-a887-f754f6c7bd3f	Lê Thị Hồng Nhung	15/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp, xã Ia Krêl, Gia Lai.	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
137d7c3e-054b-4033-befb-bbc8eb77f563	Đỗ Quỳnh Tố Như	23/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thanh Bình, xã Bàu Cạn, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
cd58e121-1bbf-4bb0-bfad-c143e07eb5be	Lê Văn Phụng	26/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Chư bồ II - Ia Dơk - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
02f406cf-6604-42d7-9af8-2f7904288fb2	Mai Văn Sơn	08/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
ee25012d-991c-4a5d-8db2-b3960f6b0018	Bùi Đức Tài	13/01/2007	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
4490d7a0-56a6-446f-8098-27f5787f8c1e	Trần Đức Tài	13/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 6 - xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
5043bc4d-799e-4c74-90e8-58ec4978e0cd	Ngô Sỹ Thêm	17/08/2006	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Lâm Tốk, xã Ia Krêl, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
1efbfda3-d278-4652-8cc4-b1a4796720ac	Nguyễn Thị Kim Thu	11/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 2, xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
5237fc54-9299-4edd-8b3b-280a5e3f85ef	Lê Thị Minh Thư	29/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng H'rang,, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
705bf4a7-f210-4d15-80de-564e4f78ed6d	Lương Thị Thủy Tiên	10/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Lệ Kim, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
ff60eb7f-25dd-4cdf-a2e5-7b49bc83c6f2	Nguyễn Thành Tín	08/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
a6b00776-7b4a-418e-9a97-d9ca39a9883c	Hoàng Thị Bảo Trâm	11/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lệ Kim, Ia Dơk, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
6eb4b71c-a50e-4a89-aff3-6e856ef9045a	Phan Bảo Trâm	12/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3 - xã Đức Cơ - Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
4a86f3b0-54a1-461e-8009-74aaff45297e	Thái Tú Trinh	30/08/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Tiên Sơn 1, xã Biển Hồ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
4f0d95e9-3922-447e-b12b-d38fd6b9d734	Trương Minh Vũ	11/11/2007	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
706fa9fd-cb28-447d-a502-237575c6e5e4	Nguyễn Thị Hải Yến	04/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 1, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
66ed38ae-e673-421e-9bc9-0e17d1c3891e	Trần Thị Hải Yến	03/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Tổ dân phố 3, xã Đức Cơ, Gia Lai	93e919f0-82a4-4d57-84bd-41e9e946f66b	2026-05-10 10:10:12.673721+00
c946d4fb-c6f1-4ea0-9d7a-a9d5d6be3a91	Dương Như Hoàng Anh	03/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Xã Đức cơ- Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
7556999d-267f-4604-82c5-e2bb68842527	Đậu Tuấn Anh	31/12/2008	Nam	Kinh	Học sinh	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Xã Đức cơ- Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
8c8b3a76-b91a-4a5a-b979-2145eb897fb1	Đinh Hải Anh	19/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
e5dbcd54-3d8c-4060-8d35-6b3764789efc	Trần Ngọc Ánh	12/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
f4c7c26f-853f-4a65-a11d-c56082598b95	Rơ Mah H' AYưng	24/01/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Khóp - Xã Ia Krêl - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
068c32b9-ff08-4e69-9378-b22c6f8f424a	Trần Nguyễn Gia Bảo	10/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
7efca695-9063-4e0b-a2d1-f060d4f0b195	Lê Thái Châu	22/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
c5bee871-8958-4101-891d-41caea5c679b	Nguyễn Công Chiến	15/09/2006	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
6a835508-4422-48df-bd57-e8c126ab0997	Trần Thị Chính	26/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
f4e3a76a-529f-4df0-ad77-21cb3f19bf27	Lê Tiến Công	12/05/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
a876cdc1-efbb-4605-8fa4-748117b58cec	Kpuih H' Diệu	23/03/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Ấp - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
1ab797cf-1879-49e4-83ab-2b4b9c23e916	Rơ Mah H' Diệu	23/01/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Dơk Ngol- Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
73bc3379-72fa-40eb-9435-bc4ad7543be5	Lê Thị Anh Đào	30/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
b903168f-7e40-443d-9417-f7aa61b65c2a	Ksor Ngọc Hân	26/07/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Đo - Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
1d340efb-0bbf-4f10-9e46-621ee1d84ab7	Lương Gia Hân	29/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
eaac84ff-219c-41c9-a417-74fba7f6022b	Nguyễn Công Hiếu	31/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang, Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
a961b106-665a-41e9-8f53-7c0fe5441fd0	Nguyễn Huy Hoàng	21/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
02c20afd-8e48-4398-8fe8-706ddfe91071	Nguyễn Ngọc Hùng	17/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
8c6b95bc-badf-4ac1-8db1-16cb6bb1937e	Lê Khanh	26/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 6 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
6321fadb-1bee-4d20-bc06-60687715c7fb	Ksor Khởi	24/05/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Sung Le - Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
4c47715a-4fda-4836-bd9a-236dae5c3017	Lê Thị Thúy Kiều	24/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
e44ba36a-c47d-4484-a951-78b6384f2e9f	Hoàng Thị Khánh Linh	25/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
c8e35b68-5100-470c-9d36-91b1ade85d1b	Trịnh Hoàng Long	09/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
65603207-5b5f-495e-a10b-641b7eadc3d5	Rơ Lan Hoa Mai	22/11/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Poong - Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
12dbfecb-f6fe-4c5d-b40a-f5ff55f67557	Nguyễn Văn Mạnh	10/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
d4891464-1bb4-4b25-a040-2277c155ab24	Rơ Châm Trung Nguyên	03/07/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Bi - Xã Ia Dom - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
3fc6d296-c819-4721-a706-c5bca13c2d6c	Kpuih H' Nhàn	31/01/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
8b176c36-7ddc-4116-b747-fe0fb0f8517e	Văn Đức Hoàng Phúc	30/09/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
6a31a614-144d-43d2-a94c-1168fb918630	Vũ Văn Quân	29/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
77cbf5f5-9a36-4dba-91ad-7ce07be2b4a5	Nguyễn Từ Tài	16/09/2007	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
340f0af1-fe4a-493c-997c-fc3cb099b8b7	Đoàn Thị Mỹ Tâm	06/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
584ea3ba-f63e-43e5-a137-76e6468649d7	Lưu Thị Phương Thảo	18/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Lâm Tôk - Xã Ia Krêl - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
71e2d90e-f630-48b3-95f9-4b89eac87764	Mai Thị Thảo	07/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
1dc44adf-4155-43da-a3d8-6a291677ed25	Vũ Thị Thu Thảo	24/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
826cbcaf-b89d-4111-8eaa-6cc17276c552	Ksor Thịnh	08/07/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	Làng Krol - Xã Ia Krêl - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
e51036e6-25a4-44d2-aead-b6183f6cfcca	Nguyễn Thị Cẩm Tú	05/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
5453ab7d-8c95-4784-868d-1fae4279645b	Hồ Đức Việt	23/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
581247ec-fffb-4c3a-b33e-7f8313d9f34c	Nguyễn Quốc Việt	20/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-10 10:10:12.673721+00	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	eb5e81b1-4422-49fc-81bb-74ca45502ad5	2026-05-10 10:10:12.673721+00
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
1b671eeb-04c9-417a-8bd7-b1aba8f07518	29	2026-04-29 13:45:42.476892+00	2026-05-10 03:15:08.557405+00	2026-05-10 10:11:15.100334+00
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
default	hohuuthe/SAOLUU_CSDL_QL_THIDUA_CHUANCSDL	main	supabase-backup.yml	supabase-restore.yml	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	2026-05-02 09:35:07.76+00	Admin	2026-05-10 03:14:45.814898+00	2026-05-10 03:17:45.987101+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "isdefault", "islocked", "updatedat", "createdat") FROM stdin;
4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2025-2026	f	f	2026-05-10 02:48:58.536+00	2026-05-10 03:09:12.540608+00
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "quyen_chi_doan_phu_trach", "ngay_cap_nhat", "nam_hoc", "quyen_xem_tat_ca_chi_doan", "createdat", "updatedat") FROM stdin;
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat") FROM stdin;
e32bc02a-8fe4-4b79-88dd-eb3020f764cd	10A1	Chiều	TN	11	Nguyễn Khánh Linh	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
71aecc43-796f-4f77-8113-57663aa7ba79	10A2	Chiều	TN	10	Lê Hồ Hoài An	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
0486a847-676e-4993-90d5-c90ff8debed2	10A3	Chiều	TN	9	Nguyễn Thị Trâm Anh	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
7cbf7380-c57c-430c-a810-957d07ae3b31	10A4	Chiều	TN	8	Phạm Hà Anh	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
44b2b336-e1d1-46bb-86f8-49d92bfc4ed4	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
1a7fa50d-808c-4664-b089-da58329a9210	10A6	Chiều	XH	1	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
b9ec8215-b493-4870-8316-34a4fad30aec	10A7	Chiều	XH	2	Phạm Khánh Chi	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
1803c151-2cf9-4bc4-9963-7fa7c1591ee4	10A8	Chiều	XH	3	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
d711c8db-37c2-4444-8b55-68c90e3e1522	10A9	Chiều	XH	4	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
e4722370-a8ce-4512-8a49-3288b7618899	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
391e11c8-13ff-4f6a-bfab-f00158b3a5b3	10A11	Chiều	XH	6	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
05e16768-764d-4f10-92d9-192fa5e1c673	11C1	Chiều	TN	12	Lê Minh Phương	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
302f5070-e9c3-4687-b8f5-5be8c273ee6b	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
9c191843-0cd9-43b9-b8e3-e2bad8bdd7c6	11C3	Chiều	TN	14	Phạm Minh Anh	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
5b462911-8d6c-4fe1-acfc-8164ecd0d90c	11C4	Chiều	TN	15	Cù Hoàng Gia An	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
57291d4a-4e9f-4c47-9597-8ca205bb54fd	11C5	Chiều	TN	16	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
59276cb1-56e1-49c7-9187-129615738e24	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
a263fb21-00df-476a-893e-c645216eec6c	11C7	Sáng	XH	2	nguyễn hồng lai	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
1a8c4e5a-7fb0-49f4-b6a0-cf9e7101090d	11C8	Sáng	XH	3	Nguyễn Trung Hiếu	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
76434353-26ae-431a-b933-3b520076a8eb	11C9	Sáng	XH	4	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
b901c879-d714-4743-b6da-7f39748743c3	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
a8eaa04d-04fd-460d-9894-4219bd41e2c3	11C11	Sáng	XH	6	Bùi Thị Tường Vy	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
e362306b-fa85-4fd5-8caf-a05c20b49cc1	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
02cf6cf2-c29b-4d6e-8e84-ecbaaee7781e	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
692c1b86-a6f3-4cd3-95af-770211b5613f	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
8a09a494-de6c-4222-a716-51c456b8333d	12B3	Sáng	TN	10	Nguyễn Gia Hân	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
52995469-d22c-4b64-9fc0-18c64f146fc7	12B4	Sáng	TN	11	\N	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
3b39cf16-56a8-4915-a043-216715c380ab	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
3990d292-e5e7-4897-864d-efd183724253	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
ed01c317-ee64-4d47-abf2-c2bb06d4987d	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
25501d0e-9ea8-43bd-a64d-72f7a170ac35	12B8	Sáng	XH	15	Quế Trân	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
93e919f0-82a4-4d57-84bd-41e9e946f66b	12B9	Sáng	XH	16	Thành Tín	\N	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
eb5e81b1-4422-49fc-81bb-74ca45502ad5	12B10	Sáng	XH	17	Lê Tiến Công	Đoàn Thị Minh Hương	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 09:40:05.558832+00	2026-05-10 09:40:05.558832+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat") FROM stdin;
682c241a-fce8-4726-988f-bcf60ca265ac	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT Lê Hoàn1	300			100			Tất cả			21:00	10	Lỗi không nộp phiếu chấm điểm tuần	f	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n[C][B]Độc lập - Tự do - Hạnh phúc	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][I]Đức Cơ, {{FULL_DATE}}\n[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n[C][B][U]Độc lập - Tự do - Hạnh phúc\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]{{HOTEN}}	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	2026-05-10 03:42:37.761765+00	2026-05-10 04:46:30.278944+00
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat") FROM stdin;
e53e265f-5ccd-443f-ac69-3b584e15b835	Admin	$argon2id$v=19$m=65536,t=3,p=4$72TKLZSr/rHbaoUyipV9iQ$eKmDYt6MHzo45CV+i8k33nfuSHugs8T0cHO0bry1vME	HHT-Admin	Admin	2026-05-10 03:34:02.030928+00	\N	2026-05-10 03:34:02.030928+00
0e0584f9-3832-4d51-b3a0-c454b2eab7cb	hohuuthe	$argon2id$v=19$m=65536,t=3,p=4$PUDXJllthdBNREj7Jd2KTw$blk3GJ2W6Jk/+OxXqPO9quBJtU9mjQqcHb6rYNmBxjM	Quản trị	Admin	2026-05-10 08:16:51.526988+00	\N	2026-05-10 08:16:35.124027+00
a183028d-91ec-4df6-8618-c3ff3317eb57	Quet	$argon2id$v=19$m=65536,t=3,p=4$uTdDfKZp6aZSh6hcx1e5gA$Lh29TBwBBJCh9Q0aBEVHYxW5hBrqxBNWFWfKCaPRqyU	Ksor H Quet	BTV	2026-04-01 01:21:20.059+00	\N	2026-05-10 03:12:23.35086+00
edfbd9cb-15c5-42f8-b51a-e6d90f02fb0b	Letrungthanhbtv	$argon2id$v=19$m=65536,t=3,p=4$7aDAvPslz8ibeTD/gb9zjg$bQfwrr3EqOBNqZoxgyF77g2nIZNcM5T7qm3gjWtbbIg	Lê Trung Thành -Bí thư ĐT	BTV	2026-03-26 07:42:27.886+00	\N	2026-05-10 03:12:23.35086+00
a9bad279-3cdc-4762-9b5f-cd6d5c1a2608	Leminhphuongbtv	$argon2id$v=19$m=65536,t=3,p=4$Y5lYDc9Had+EJM/PWm5qJg$c8+0lKGVEPdXzzpdycZ0PxEtEIEL7ZARyIXE2HljcBo	Lê Minh Phương BTV	BTV	2026-03-28 22:36:04.141+00	\N	2026-05-10 03:12:23.35086+00
fe1ed425-96ce-49db-96b5-57f36b7acd91	Tranthithuytam	$argon2id$v=19$m=65536,t=3,p=4$bkPCIo+4RA3SG6cN1PFGKQ$sXwdHUWz4LBsxqAaQa54NQsVQeTOrhv1HGejsiXVwMM	Trần Thị Thủy Tâm - Phó BT ĐT	BTV	2026-03-26 07:42:51.396+00	\N	2026-05-10 03:12:23.35086+00
faf551e3-c757-4078-a239-fa5823211ee0	Nguyengiahanbtv	$argon2id$v=19$m=65536,t=3,p=4$w+X6XyZlE1xqKRaCOb3V2g$oe7AMmeni3pBDapc1WuMe+DhgZPCSTKD10TS7whA+7o	Nguyễn Gia Hân (BTV)	BTV	2026-03-29 07:58:50.656+00	\N	2026-05-10 03:12:23.35086+00
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
280d29e9-3083-4483-9783-f90fb3d77ba1	4e9c9dc4-e7e0-4316-b533-f5aa3131ce53	HK1	1			f	f	2026-05-10 02:49:46.724+00		2026-05-10 03:10:49.511196+00
\.


--
-- Data for Name: messages_2026_05_07; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_07" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_08; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_08" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_09; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_09" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_10; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_10" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_11; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_11" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_12; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_12" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_13; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_13" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-03-29 11:07:20
20211116045059	2026-03-29 11:07:20
20211116050929	2026-03-29 11:07:20
20211116051442	2026-03-29 11:07:20
20211116212300	2026-03-29 11:07:20
20211116213355	2026-03-29 11:07:20
20211116213934	2026-03-29 11:07:20
20211116214523	2026-03-29 11:07:20
20211122062447	2026-03-29 11:07:20
20211124070109	2026-03-29 11:07:20
20211202204204	2026-03-29 11:07:20
20211202204605	2026-03-29 11:07:20
20211210212804	2026-03-29 11:07:20
20211228014915	2026-03-29 11:07:20
20220107221237	2026-03-29 11:07:20
20220228202821	2026-03-29 11:07:20
20220312004840	2026-03-29 11:07:20
20220603231003	2026-03-29 11:07:20
20220603232444	2026-03-29 11:07:20
20220615214548	2026-03-29 11:07:20
20220712093339	2026-03-29 11:07:20
20220908172859	2026-03-29 11:07:20
20220916233421	2026-03-29 11:07:20
20230119133233	2026-03-29 11:07:20
20230128025114	2026-03-29 11:07:20
20230128025212	2026-03-29 11:07:20
20230227211149	2026-03-29 11:07:21
20230228184745	2026-03-29 11:07:21
20230308225145	2026-03-29 11:07:21
20230328144023	2026-03-29 11:07:21
20231018144023	2026-03-29 11:07:21
20231204144023	2026-03-29 11:07:21
20231204144024	2026-03-29 11:07:21
20231204144025	2026-03-29 11:07:21
20240108234812	2026-03-29 11:07:21
20240109165339	2026-03-29 11:07:21
20240227174441	2026-03-29 11:07:21
20240311171622	2026-03-29 12:35:40
20240321100241	2026-03-29 12:35:41
20240401105812	2026-03-29 12:35:41
20240418121054	2026-03-29 12:35:41
20240523004032	2026-03-29 12:35:41
20240618124746	2026-03-29 12:35:41
20240801235015	2026-03-29 12:35:41
20240805133720	2026-03-29 12:35:41
20240827160934	2026-03-29 12:35:41
20240919163303	2026-03-29 12:35:41
20240919163305	2026-03-29 12:35:41
20241019105805	2026-03-29 12:35:41
20241030150047	2026-03-29 12:35:41
20241108114728	2026-03-29 12:35:41
20241121104152	2026-03-29 12:35:41
20241130184212	2026-03-29 12:35:41
20241220035512	2026-03-29 12:35:41
20241220123912	2026-03-29 12:35:41
20241224161212	2026-03-29 12:35:41
20250107150512	2026-03-29 12:35:41
20250110162412	2026-03-29 12:35:41
20250123174212	2026-03-29 12:35:41
20250128220012	2026-03-29 12:35:41
20250506224012	2026-03-29 12:35:41
20250523164012	2026-03-29 12:35:41
20250714121412	2026-03-29 12:35:41
20250905041441	2026-03-29 12:35:41
20251103001201	2026-03-29 12:35:41
20251120212548	2026-03-29 12:35:41
20251120215549	2026-03-29 12:35:41
20260218120000	2026-03-29 12:35:41
20260326120000	2026-05-03 11:13:24
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter") FROM stdin;
87106	ad7fa608-4c58-11f1-8598-0a58a9feac02	"public"."chamdiem"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:22.596379	*
87096	6fd288de-4c58-11f1-a446-0a58a9feac02	"public"."settings"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:24.277441	*
87095	6fd1d498-4c58-11f1-97ae-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:22.565128	*
87102	6fd6e6cc-4c58-11f1-a163-0a58a9feac02	"public"."phancong"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:22.455804	*
87101	6fd6723c-4c58-11f1-9958-0a58a9feac02	"public"."tieuchitd"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:22.928256	*
87099	6fd42568-4c58-11f1-b56b-0a58a9feac02	"public"."qlchidoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:23.391313	*
87098	6fd3a48a-4c58-11f1-8bc9-0a58a9feac02	"public"."dotptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:23.486321	*
87104	70a35608-4c58-11f1-b2fe-0a58a9feac02	"public"."doanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:23.570681	*
87097	6fd32672-4c58-11f1-831c-0a58a9feac02	"public"."tuanhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:24.268299	*
87055	fbdcda7e-4c57-11f1-90ce-0a58a9feac02	"public"."phanquyen"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:23.405237	*
87056	fbdd8c4e-4c57-11f1-928e-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778390763}], "aud": "authenticated", "exp": 1778411541, "iat": 1778407941, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "e5cad0cd-81be-43c2-b2dd-8be48aae28eb", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-10 10:12:22.348103	*
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-03-29 11:07:19.986384
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-03-29 11:07:20.013179
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-03-29 11:07:20.017897
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-03-29 11:07:20.097159
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-03-29 11:07:20.622223
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-03-29 11:07:20.630588
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-03-29 11:07:20.641979
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-03-29 11:07:20.647677
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-03-29 11:07:20.652654
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-03-29 11:07:20.660073
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-03-29 11:07:20.673859
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-03-29 11:07:20.692666
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-03-29 11:07:20.757269
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-03-29 11:07:20.762235
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-03-29 11:07:20.767263
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-03-29 11:07:20.944514
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-03-29 11:07:20.955467
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-03-29 11:07:20.965666
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-03-29 11:07:20.971212
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-03-29 11:07:20.981453
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-03-29 11:07:20.9865
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-03-29 11:07:20.993933
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-03-29 11:07:21.028096
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-03-29 11:07:21.044403
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-03-29 11:07:21.049974
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-03-29 11:07:21.058404
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-03-29 11:07:21.064792
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-03-29 11:07:21.069209
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-03-29 11:07:21.074012
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-03-29 11:07:21.078587
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-03-29 11:07:21.083136
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-03-29 11:07:21.088878
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-03-29 11:07:21.096871
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-03-29 11:07:21.102499
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-03-29 11:07:21.108148
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-03-29 11:07:21.114418
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-03-29 11:07:21.119708
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-03-29 11:07:21.124114
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-03-29 11:07:21.135386
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-03-29 11:07:21.157554
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-03-29 11:07:21.162121
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-03-29 11:07:21.166646
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-03-29 11:07:21.17123
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-03-29 11:07:21.176242
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-03-29 11:07:21.181547
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-03-29 11:07:21.187118
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-03-29 11:07:21.227439
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-03-29 11:07:21.232766
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-03-29 11:07:21.237486
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-03-29 11:07:21.2672
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-03-29 11:07:21.27285
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-03-29 11:07:25.087069
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-03-29 11:07:25.089842
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-03-29 11:07:25.114783
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-03-29 11:07:25.117684
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-03-29 11:07:25.11957
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-05-03 11:13:12.452636
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-05-03 11:13:12.469465
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-03-29 11:07:25.159066
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-06 01:59:36.853256
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-06 01:59:36.863371
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 340, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 3543, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 87128, true);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_07 messages_2026_05_07_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_07"
    ADD CONSTRAINT "messages_2026_05_07_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_08 messages_2026_05_08_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_08"
    ADD CONSTRAINT "messages_2026_05_08_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_09 messages_2026_05_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_09"
    ADD CONSTRAINT "messages_2026_05_09_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_10 messages_2026_05_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_10"
    ADD CONSTRAINT "messages_2026_05_10_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_11 messages_2026_05_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_11"
    ADD CONSTRAINT "messages_2026_05_11_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_12 messages_2026_05_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_12"
    ADD CONSTRAINT "messages_2026_05_12_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_13 messages_2026_05_13_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_13"
    ADD CONSTRAINT "messages_2026_05_13_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_namhoc" ON "public"."chamdiem" USING "btree" ("namhoc");


--
-- Name: idx_chamdiem_thoigian_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thoigian_context" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_doanvien_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_id" ON "public"."doanvien" USING "btree" ("chidoan_id");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_dotptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_namhoc" ON "public"."dotptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phancong_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_namhoc" ON "public"."phancong" USING "btree" ("namhoc");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_qlchidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_chidoan" ON "public"."taikhoan" USING "btree" ("chidoan_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tieuchitd_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_namhoc" ON "public"."tieuchitd" USING "btree" ("namhoc");


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_namhoc" ON "public"."tuanhoc" USING "btree" ("namhoc");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_07_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_07_inserted_at_topic_idx" ON "realtime"."messages_2026_05_07" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_08_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_08_inserted_at_topic_idx" ON "realtime"."messages_2026_05_08" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_09_inserted_at_topic_idx" ON "realtime"."messages_2026_05_09" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_10_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_10_inserted_at_topic_idx" ON "realtime"."messages_2026_05_10" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_11_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_11_inserted_at_topic_idx" ON "realtime"."messages_2026_05_11" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_12_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_12_inserted_at_topic_idx" ON "realtime"."messages_2026_05_12" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_13_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_13_inserted_at_topic_idx" ON "realtime"."messages_2026_05_13" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_key" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter");


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_05_07_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_07_inserted_at_topic_idx";


--
-- Name: messages_2026_05_07_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_07_pkey";


--
-- Name: messages_2026_05_08_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_08_inserted_at_topic_idx";


--
-- Name: messages_2026_05_08_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_08_pkey";


--
-- Name: messages_2026_05_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_09_inserted_at_topic_idx";


--
-- Name: messages_2026_05_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_09_pkey";


--
-- Name: messages_2026_05_10_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_10_inserted_at_topic_idx";


--
-- Name: messages_2026_05_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_10_pkey";


--
-- Name: messages_2026_05_11_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_11_inserted_at_topic_idx";


--
-- Name: messages_2026_05_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_11_pkey";


--
-- Name: messages_2026_05_12_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_12_inserted_at_topic_idx";


--
-- Name: messages_2026_05_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_12_pkey";


--
-- Name: messages_2026_05_13_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_13_inserted_at_topic_idx";


--
-- Name: messages_2026_05_13_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_13_pkey";


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Admins can view all activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all activity logs" ON "public"."activity_logs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: activity_logs Authenticated users can insert activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users can insert activity logs" ON "public"."activity_logs" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: chamdiem Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."chamdiem" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: doanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."doanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: dotptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."dotptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: namhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."namhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phancong Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phancong" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phanquyen Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phanquyen" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: ptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."ptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: qlchidoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."qlchidoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: settings Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."settings" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: taikhoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."taikhoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tieuchitd Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tieuchitd" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tuanhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tuanhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: github_settings Cho phép Admin quản lý cấu hình github; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: github_settings Cho phép người dùng đã đăng nhập thao tác github_se; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: taikhoan Enable read access for all users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable read access for all users" ON "public"."taikhoan" FOR SELECT USING (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "postgres";

--
-- Name: supabase_realtime chamdiem; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chamdiem";


--
-- Name: supabase_realtime doanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."doanvien";


--
-- Name: supabase_realtime dotptdoanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."dotptdoanvien";


--
-- Name: supabase_realtime namhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."namhoc";


--
-- Name: supabase_realtime phancong; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phancong";


--
-- Name: supabase_realtime phanquyen; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phanquyen";


--
-- Name: supabase_realtime qlchidoan; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."qlchidoan";


--
-- Name: supabase_realtime settings; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."settings";


--
-- Name: supabase_realtime tieuchitd; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tieuchitd";


--
-- Name: supabase_realtime tuanhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tuanhoc";


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "vault" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "supabase_realtime_admin";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_05_07"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_07" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_07" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_08"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_08" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_08" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_09"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_09" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_09" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_10"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_10" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_10" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_11"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_11" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_11" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_12"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_12" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_12" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_13"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_13" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_13" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "anon";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "service_role";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "supabase_realtime_admin";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";
GRANT ALL ON TABLE "realtime"."subscription" TO "supabase_realtime_admin";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "supabase_realtime_admin";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict 3TLQ8p4wI6izf3fCr4OeYviLoI5XdHktW9MuJKZUXGiV37qB8PdHLQIzLV7Vf3m

