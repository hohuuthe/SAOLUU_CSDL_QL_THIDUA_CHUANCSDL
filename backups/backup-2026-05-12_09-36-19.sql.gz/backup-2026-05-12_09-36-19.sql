--
-- PostgreSQL database dump
--

\restrict wZoGDSbaXqXkLq8Xlgflk4ibGZBchhyfvTKeWobu2FDOAriCa5Uiyyaha4gXKZm

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Enable read access for all users" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings";
DROP POLICY IF EXISTS "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."settings";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."ptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phanquyen";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."phancong";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."namhoc";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."dotptdoanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."doanvien";
DROP POLICY IF EXISTS "Authenticated users only" ON "public"."chamdiem";
DROP POLICY IF EXISTS "Authenticated users can insert activity logs" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Admins can view all activity logs" ON "public"."activity_logs";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "fk_tuanhoc_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "fk_tieuchitd_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "fk_settings_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "fk_qlchidoan_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "fk_ptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "fk_phanquyen_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "fk_phancong_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "fk_dotptdoanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "fk_doanvien_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "fk_chamdiem_namhoc";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_lopcham_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_doanvienid_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chidoan_id_fkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_chamlop_fkey";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_namhoc_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_dotdangki_fkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "Ngay_3_5_ptdoanvien_doanvien_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP TRIGGER IF EXISTS "update_tuanhoc_modtime" ON "public"."tuanhoc";
DROP TRIGGER IF EXISTS "update_tieuchitd_modtime" ON "public"."tieuchitd";
DROP TRIGGER IF EXISTS "update_taikhoan_modtime" ON "public"."taikhoan";
DROP TRIGGER IF EXISTS "update_settings_modtime" ON "public"."settings";
DROP TRIGGER IF EXISTS "update_qlchidoan_modtime" ON "public"."qlchidoan";
DROP TRIGGER IF EXISTS "update_ptdoanvien_modtime" ON "public"."ptdoanvien";
DROP TRIGGER IF EXISTS "update_phanquyen_modtime" ON "public"."phanquyen";
DROP TRIGGER IF EXISTS "update_phancong_modtime" ON "public"."phancong";
DROP TRIGGER IF EXISTS "update_namhoc_modtime" ON "public"."namhoc";
DROP TRIGGER IF EXISTS "update_github_settings_modtime" ON "public"."github_settings";
DROP TRIGGER IF EXISTS "update_duytricsdl_modtime" ON "public"."duytricsdl";
DROP TRIGGER IF EXISTS "update_dotptdoanvien_modtime" ON "public"."dotptdoanvien";
DROP TRIGGER IF EXISTS "update_doanvien_modtime" ON "public"."doanvien";
DROP TRIGGER IF EXISTS "update_chamdiem_modtime" ON "public"."chamdiem";
DROP TRIGGER IF EXISTS "trigger_chi_doan_deletion" ON "public"."qlchidoan";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_key";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_dotdangki";
DROP INDEX IF EXISTS "public"."ngay_3_5_idx_ptdoanvien_doanvien_id";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_namhoc";
DROP INDEX IF EXISTS "public"."idx_tuanhoc_context";
DROP INDEX IF EXISTS "public"."idx_tuan_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_namhoc";
DROP INDEX IF EXISTS "public"."idx_tieuchitd_context";
DROP INDEX IF EXISTS "public"."idx_taikhoan_chidoan";
DROP INDEX IF EXISTS "public"."idx_settings_namhoc";
DROP INDEX IF EXISTS "public"."idx_qlchidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_dot";
DROP INDEX IF EXISTS "public"."idx_ptdoanvien_doanvien";
DROP INDEX IF EXISTS "public"."idx_phanquyen_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_namhoc";
DROP INDEX IF EXISTS "public"."idx_phancong_lopcham";
DROP INDEX IF EXISTS "public"."idx_phancong_context";
DROP INDEX IF EXISTS "public"."idx_phancong_chamlop";
DROP INDEX IF EXISTS "public"."idx_namhoc_isdefault_true";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_dotptdoanvien_nam_hk";
DROP INDEX IF EXISTS "public"."idx_doanvien_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_hoten";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_namhoc";
DROP INDEX IF EXISTS "public"."idx_doanvien_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_chamdiem_thoigian_context";
DROP INDEX IF EXISTS "public"."idx_chamdiem_namhoc";
DROP INDEX IF EXISTS "public"."idx_chamdiem_loaitieuchi";
DROP INDEX IF EXISTS "public"."idx_chamdiem_doanvienid";
DROP INDEX IF EXISTS "public"."idx_chamdiem_chidoan_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_15" DROP CONSTRAINT IF EXISTS "messages_2026_05_15_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_14" DROP CONSTRAINT IF EXISTS "messages_2026_05_14_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_13" DROP CONSTRAINT IF EXISTS "messages_2026_05_13_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_12" DROP CONSTRAINT IF EXISTS "messages_2026_05_12_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_11" DROP CONSTRAINT IF EXISTS "messages_2026_05_11_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_10" DROP CONSTRAINT IF EXISTS "messages_2026_05_10_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_05_09" DROP CONSTRAINT IF EXISTS "messages_2026_05_09_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "unique_namhoc_tenchidoan";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "unique_chamdiem_record";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_ten_nam_unique";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."ptdoanvien" DROP CONSTRAINT IF EXISTS "ptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."github_settings" DROP CONSTRAINT IF EXISTS "github_settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."duytricsdl" DROP CONSTRAINT IF EXISTS "duytricsdl_pkey";
ALTER TABLE IF EXISTS ONLY "public"."dotptdoanvien" DROP CONSTRAINT IF EXISTS "dotptdoanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_15";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_14";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_13";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_12";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_11";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_10";
DROP TABLE IF EXISTS "realtime"."messages_2026_05_09";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."ptdoanvien";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."github_settings";
DROP TABLE IF EXISTS "public"."duytricsdl";
DROP TABLE IF EXISTS "public"."dotptdoanvien";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "storage"."allow_only_operation"("expected_operation" "text");
DROP FUNCTION IF EXISTS "storage"."allow_any_operation"("expected_operations" "text"[]);
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "public"."update_modified_column"();
DROP FUNCTION IF EXISTS "public"."update_likes_count"();
DROP FUNCTION IF EXISTS "public"."rpc_get_user_by_username"("p_username" "text");
DROP TABLE IF EXISTS "public"."taikhoan";
DROP FUNCTION IF EXISTS "public"."handle_update_likes_count"();
DROP FUNCTION IF EXISTS "public"."handle_post_like"();
DROP FUNCTION IF EXISTS "public"."handle_chi_doan_deletion"();
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: handle_chi_doan_deletion(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_chi_doan_deletion"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Sửa "chiDoan" thành chidoan (viết thường, không cần ngoặc kép)
    DELETE FROM "doanvien" 
    WHERE chidoan = OLD.tenchidoan;
    
    RETURN OLD;
END;
$$;


ALTER FUNCTION "public"."handle_chi_doan_deletion"() OWNER TO "postgres";

--
-- Name: handle_post_like(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_post_like"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_post_like"() OWNER TO "postgres";

--
-- Name: handle_update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."handle_update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."handle_update_likes_count"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullname" "text" NOT NULL,
    "role" "text" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: rpc_get_user_by_username("text"); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") RETURNS SETOF "public"."taikhoan"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT * FROM taikhoan WHERE username = p_username OR username = lower(p_username) LIMIT 1;
$$;


ALTER FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") OWNER TO "postgres";

--
-- Name: update_likes_count(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_likes_count"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE nhat_ky_doan SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
  END IF;
  RETURN NULL;
END;
$$;


ALTER FUNCTION "public"."update_likes_count"() OWNER TO "postgres";

--
-- Name: update_modified_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION "public"."update_modified_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updatedat = now();
    RETURN NEW;
END;
$$;


ALTER FUNCTION "public"."update_modified_column"() OWNER TO "postgres";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_
        -- Filter by action early - only get subscriptions interested in this action
        -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
        and (subs.action_filter = '*' or subs.action_filter = action::text);

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS TABLE("wal" "jsonb", "is_rls_enabled" boolean, "subscription_ids" "uuid"[], "errors" "text"[], "slot_changes_count" bigint)
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
  WITH pub AS (
    SELECT
      concat_ws(
        ',',
        CASE WHEN bool_or(pubinsert) THEN 'insert' ELSE NULL END,
        CASE WHEN bool_or(pubupdate) THEN 'update' ELSE NULL END,
        CASE WHEN bool_or(pubdelete) THEN 'delete' ELSE NULL END
      ) AS w2j_actions,
      coalesce(
        string_agg(
          realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
          ','
        ) filter (WHERE ppt.tablename IS NOT NULL AND ppt.tablename NOT LIKE '% %'),
        ''
      ) AS w2j_add_tables
    FROM pg_publication pp
    LEFT JOIN pg_publication_tables ppt ON pp.pubname = ppt.pubname
    WHERE pp.pubname = publication
    GROUP BY pp.pubname
    LIMIT 1
  ),
  -- MATERIALIZED ensures pg_logical_slot_get_changes is called exactly once
  w2j AS MATERIALIZED (
    SELECT x.*, pub.w2j_add_tables
    FROM pub,
         pg_logical_slot_get_changes(
           slot_name, null, max_changes,
           'include-pk', 'true',
           'include-transaction', 'false',
           'include-timestamp', 'true',
           'include-type-oids', 'true',
           'format-version', '2',
           'actions', pub.w2j_actions,
           'add-tables', pub.w2j_add_tables
         ) x
  ),
  -- Count raw slot entries before apply_rls/subscription filter
  slot_count AS (
    SELECT count(*)::bigint AS cnt
    FROM w2j
    WHERE w2j.w2j_add_tables <> ''
  ),
  -- Apply RLS and filter as before
  rls_filtered AS (
    SELECT xyz.wal, xyz.is_rls_enabled, xyz.subscription_ids, xyz.errors
    FROM w2j,
         realtime.apply_rls(
           wal := w2j.data::jsonb,
           max_record_bytes := max_record_bytes
         ) xyz(wal, is_rls_enabled, subscription_ids, errors)
    WHERE w2j.w2j_add_tables <> ''
      AND xyz.subscription_ids[1] IS NOT NULL
  )
  -- Real rows with slot count attached
  SELECT rf.wal, rf.is_rls_enabled, rf.subscription_ids, rf.errors, sc.cnt
  FROM rls_filtered rf, slot_count sc

  UNION ALL

  -- Sentinel row: always returned when no real rows exist so Elixir can
  -- always read slot_changes_count. Identified by wal IS NULL.
  SELECT null, null, null, null, sc.cnt
  FROM slot_count sc
  WHERE NOT EXISTS (SELECT 1 FROM rls_filtered)
$$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: allow_any_operation("text"[]); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT CASE
      WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
      ELSE raw_operation
    END AS current_operation
    FROM current_operation
  )
  SELECT EXISTS (
    SELECT 1
    FROM normalized n
    CROSS JOIN LATERAL unnest(expected_operations) AS expected_operation
    WHERE expected_operation IS NOT NULL
      AND expected_operation <> ''
      AND n.current_operation = CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END
  );
$$;


ALTER FUNCTION "storage"."allow_any_operation"("expected_operations" "text"[]) OWNER TO "supabase_storage_admin";

--
-- Name: allow_only_operation("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."allow_only_operation"("expected_operation" "text") RETURNS boolean
    LANGUAGE "sql" STABLE
    AS $$
  WITH current_operation AS (
    SELECT storage.operation() AS raw_operation
  ),
  normalized AS (
    SELECT
      CASE
        WHEN raw_operation LIKE 'storage.%' THEN substr(raw_operation, 9)
        ELSE raw_operation
      END AS current_operation,
      CASE
        WHEN expected_operation LIKE 'storage.%' THEN substr(expected_operation, 9)
        ELSE expected_operation
      END AS requested_operation
    FROM current_operation
  )
  SELECT CASE
    WHEN requested_operation IS NULL OR requested_operation = '' THEN FALSE
    ELSE COALESCE(current_operation = requested_operation, FALSE)
  END
  FROM normalized;
$$;


ALTER FUNCTION "storage"."allow_only_operation"("expected_operation" "text") OWNER TO "supabase_storage_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Get the last path segment (the actual filename)
    SELECT _parts[array_length(_parts, 1)] INTO _filename;
    -- Extract extension: reverse, split on '.', then reverse again
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint)::bigint as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid"
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "uuid",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "uuid",
    "chamlop" "uuid",
    "doanvienid" "uuid",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoten" "text" NOT NULL,
    "ngaysinh" "text",
    "gioitinh" "text",
    "dantoc" "text",
    "doituong" "text",
    "doanvien" boolean DEFAULT false,
    "chidoan" "text",
    "ngayvaodoan" "text",
    "sdt" "text",
    "thongtinthem" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "diachi" "text",
    "chidoan_id" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: dotptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."dotptdoanvien" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tendot" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."dotptdoanvien" OWNER TO "postgres";

--
-- Name: duytricsdl; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."duytricsdl" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "so" bigint DEFAULT 0,
    "thoigian" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."duytricsdl" OWNER TO "postgres";

--
-- Name: github_settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."github_settings" (
    "id" "text" NOT NULL,
    "github_repo_path" "text",
    "github_branch" "text" DEFAULT 'main'::"text",
    "github_workflow_file" "text" DEFAULT 'supabase-backup.yml'::"text",
    "github_restore_workflow_file" "text" DEFAULT 'supabase-restore.yml'::"text",
    "github_token" "text",
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "updated_by" "text",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."github_settings" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tennamhoc" "text" NOT NULL,
    "islocked" boolean DEFAULT false,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"(),
    "isdefault" boolean DEFAULT false
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopcham" "uuid" NOT NULL,
    "chamlop" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "quyen_chi_doan_phu_trach" boolean DEFAULT false,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "uuid",
    "quyen_xem_tat_ca_chi_doan" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: COLUMN "phanquyen"."quyen_chi_doan_phu_trach"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."quyen_chi_doan_phu_trach" IS 'Giới hạn phạm vi dữ liệu chỉ trong chi đoàn của user';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: ptdoanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."ptdoanvien" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "doanvien_id" "uuid",
    "dotdangki" "uuid",
    "thongkerenluyen" "text",
    "diemrenluyen" integer DEFAULT 0,
    "pheduyet" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "namhoc" "uuid",
    "soquyetdinh" "text",
    "ngayquyetdinh" "date"
);


ALTER TABLE "public"."ptdoanvien" OWNER TO "postgres";

--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoihoc" "text" NOT NULL,
    "ban" "text",
    "phonghoc" "text",
    "bithu" "text",
    "gvcn" "text",
    "namhoc" "uuid" NOT NULL,
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemsan" numeric,
    "aiprompttemplate" "text",
    "geminiapikey" "text",
    "diemsanhocky" numeric DEFAULT 0,
    "aiassistantprompt" "text",
    "thongbaochamdiem" "text",
    "doituongthongbao" "text",
    "noidungthongbao" "text",
    "thongbaodoanvien" "text",
    "autopenaltytime" "text" DEFAULT '23:55'::"text",
    "autopenaltypoints" integer DEFAULT 30,
    "autopenaltycriteria" "text" DEFAULT 'Lỗi không báo cáo điểm tuần'::"text",
    "autopenaltyenabled" boolean DEFAULT false,
    "autopenaltyreporter" "text" DEFAULT 'Hệ thống tự động'::"text",
    "autopenaltyday" integer DEFAULT 0,
    "thongbaophattriendoan" "text" DEFAULT ''::"text",
    "excel_header_left" "text",
    "excel_header_right" "text",
    "excel_footer_left" "text",
    "excel_footer_right" "text",
    "word_header_left" "text",
    "word_header_right" "text",
    "word_footer_left" "text",
    "word_footer_right" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"(),
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: COLUMN "settings"."autopenaltytime"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltytime" IS 'Giờ kiểm tra xử phạt tự động vào Chủ Nhật';


--
-- Name: COLUMN "settings"."autopenaltypoints"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltypoints" IS 'Số điểm trừ khi vi phạm lỗi không nhập điểm';


--
-- Name: COLUMN "settings"."autopenaltycriteria"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltycriteria" IS 'Tên tiêu chí hiển thị khi xử phạt';


--
-- Name: COLUMN "settings"."autopenaltyenabled"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyenabled" IS 'Trạng thái bật/tắt chức năng xử phạt tự động';


--
-- Name: COLUMN "settings"."autopenaltyreporter"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."settings"."autopenaltyreporter" IS 'Tên người chấm hiển thị trong bảng điểm';


--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "matieuchi" "text" NOT NULL,
    "tentieuchi" "text" NOT NULL,
    "mota" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"(),
    "hocky" "text",
    "namhoc" "uuid",
    "createdat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namhoc" "uuid" NOT NULL,
    "hocky" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tungay" "text",
    "denngay" "text",
    "isdefault" boolean DEFAULT false,
    "islocked" boolean DEFAULT false,
    "createdat" timestamp with time zone DEFAULT "now"(),
    "ghichu" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_05_09; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_09" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_09" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_10; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_10" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_10" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_11; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_11" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_11" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_12; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_12" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_12" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_13; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_13" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_13" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_14; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_14" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_14" OWNER TO "supabase_admin";

--
-- Name: messages_2026_05_15; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_05_15" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_05_15" OWNER TO "supabase_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb",
    "metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_05_09; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_09" FOR VALUES FROM ('2026-05-09 00:00:00') TO ('2026-05-10 00:00:00');


--
-- Name: messages_2026_05_10; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_10" FOR VALUES FROM ('2026-05-10 00:00:00') TO ('2026-05-11 00:00:00');


--
-- Name: messages_2026_05_11; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_11" FOR VALUES FROM ('2026-05-11 00:00:00') TO ('2026-05-12 00:00:00');


--
-- Name: messages_2026_05_12; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_12" FOR VALUES FROM ('2026-05-12 00:00:00') TO ('2026-05-13 00:00:00');


--
-- Name: messages_2026_05_13; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_13" FOR VALUES FROM ('2026-05-13 00:00:00') TO ('2026-05-14 00:00:00');


--
-- Name: messages_2026_05_14; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_14" FOR VALUES FROM ('2026-05-14 00:00:00') TO ('2026-05-15 00:00:00');


--
-- Name: messages_2026_05_15; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_05_15" FOR VALUES FROM ('2026-05-15 00:00:00') TO ('2026-05-16 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
c869d8ce-23e0-47e9-b7b8-7678ddd70597	c869d8ce-23e0-47e9-b7b8-7678ddd70597	{"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": false, "phone_verified": false}	email	2026-05-10 05:19:49.313863+00	2026-05-10 05:19:49.314312+00	2026-05-10 05:19:49.314312+00	265cf928-6816-4b56-9c4e-e63d7c9c6723
39c8bd8e-417e-4f88-bf13-f8800858bdbe	39c8bd8e-417e-4f88-bf13-f8800858bdbe	{"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": false, "phone_verified": false}	email	2026-05-10 05:26:03.226927+00	2026-05-10 05:26:03.226975+00	2026-05-10 05:26:03.226975+00	ac6cd08d-29cf-40db-bc4c-dea5392613da
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
5b72536a-9b8e-4162-a0e1-c01a979a8acd	2026-05-10 05:19:49.519185+00	2026-05-10 05:19:49.519185+00	password	aac2f87b-7a9d-4d50-b4a5-8f643b5019db
6f5146a2-99a0-404f-89cd-e13e5ef546ed	2026-05-10 09:33:32.583129+00	2026-05-10 09:33:32.583129+00	password	d9a949ac-9bd2-4249-9c76-c485935714d1
94e29cdf-8ffa-449b-9b56-7d495208405a	2026-05-10 13:41:19.532268+00	2026-05-10 13:41:19.532268+00	password	ac2f8de4-6378-4be2-adcf-4944c70a0be6
bdf7c1fe-7102-4680-9daf-e789d3f07f74	2026-05-10 23:35:47.021375+00	2026-05-10 23:35:47.021375+00	password	0eaaf4d6-3646-408e-9aa1-4a552f8c7928
a283844b-9ad9-4697-b973-d2a954a09721	2026-05-11 00:11:51.775974+00	2026-05-11 00:11:51.775974+00	password	d30bfd72-30d2-461e-9a64-450ce6085db4
f333624d-97ef-46a4-ac61-1614ef8614e0	2026-05-11 00:54:01.194282+00	2026-05-11 00:54:01.194282+00	password	ca22747b-a58f-4336-821d-e4f3421f4b5a
0c60a456-a718-432e-8763-3806172c2eff	2026-05-11 04:30:41.808373+00	2026-05-11 04:30:41.808373+00	password	92f60325-17ea-4e19-a408-8b6fdbd95b8d
a73136e3-6fed-4e14-9e47-876c0127fd70	2026-05-11 06:08:52.970792+00	2026-05-11 06:08:52.970792+00	password	8b305da6-66d2-4c95-9322-88c3aa4cffb4
ef60474c-2102-4f89-8ce9-3f1056c154f3	2026-05-11 09:40:12.360567+00	2026-05-11 09:40:12.360567+00	password	eafb7201-ea2c-48de-8e7d-9d2827ea6b0a
6a63958d-1dc5-49de-985b-3200b29f6bef	2026-05-11 11:47:19.884009+00	2026-05-11 11:47:19.884009+00	password	4087a361-2330-45f6-857a-22f49bdc63eb
f5ee7e24-febc-4ae4-8df8-0ef327d84484	2026-05-11 22:26:59.235331+00	2026-05-11 22:26:59.235331+00	password	3804c3dd-f660-42c9-b7cf-f64eb9d9f44d
7a969d00-653b-4d6d-9393-e930fee972f1	2026-05-12 00:08:16.816881+00	2026-05-12 00:08:16.816881+00	password	bed52d8d-e1fd-48ea-a4e1-596d39d49259
783deb18-7bf3-40eb-a947-a89bf6ed8d04	2026-05-12 01:28:12.538012+00	2026-05-12 01:28:12.538012+00	password	79dc8ee9-4f06-4bb6-9805-081fbea655e3
283da001-da7d-4519-b2d0-9c07b0db51a0	2026-05-12 08:17:45.618921+00	2026-05-12 08:17:45.618921+00	password	041c16ef-c864-48b8-ba01-5bacae540472
58ae6835-dd81-4b77-bab0-3027b818eae8	2026-05-12 08:30:06.885948+00	2026-05-12 08:30:06.885948+00	password	5831e1d8-6e20-4ed0-ab3b-f1f122b462f2
e5cad0cd-81be-43c2-b2dd-8be48aae28eb	2026-05-10 05:26:03.318739+00	2026-05-10 05:26:03.318739+00	password	cec6872c-6b84-4fb3-a6be-0630dd5d4340
467cb318-b9d9-4f73-8470-c0658c966c81	2026-05-10 12:34:32.647183+00	2026-05-10 12:34:32.647183+00	password	550b3abe-59f2-4692-88e6-3aefc0476b4c
b9346b4b-83eb-4a2f-b5f4-9dd56ea0326d	2026-05-10 22:16:50.889742+00	2026-05-10 22:16:50.889742+00	password	519f3fef-2ee0-4dd3-a388-907e59e180b3
7da5088e-29b9-450a-8010-cab3b693f20c	2026-05-11 00:06:18.569969+00	2026-05-11 00:06:18.569969+00	password	d86154ed-14d8-48fd-b911-5a47b7019a35
024d0d42-2ef3-424f-975e-ed0d73ef0c04	2026-05-11 00:16:47.823501+00	2026-05-11 00:16:47.823501+00	password	70f0b62f-1ac0-4b6d-8b0f-53a4c0918c17
d527d8a9-1685-43cb-8b23-09773488438f	2026-05-11 00:16:54.863245+00	2026-05-11 00:16:54.863245+00	password	08c315f7-4879-409e-aee7-2a0d280e859a
af2256a6-ac64-4525-a246-91fd340b9bb2	2026-05-11 04:18:09.955349+00	2026-05-11 04:18:09.955349+00	password	bbbbba52-5d7c-4f55-a969-34881dce719c
8d2d163a-beb6-4b16-94e2-a9f82f5199cb	2026-05-11 04:51:04.621032+00	2026-05-11 04:51:04.621032+00	password	97aa9d4d-01d3-4a20-bc28-27dc68c6ffd8
2298d10d-b478-4977-91f6-07fe0380c824	2026-05-11 06:39:50.83993+00	2026-05-11 06:39:50.83993+00	password	55f5f39b-f2f1-4bb3-95e6-e09b12ba2ca0
a9b88a62-771d-457b-9f21-1ee41305f1c5	2026-05-11 06:39:59.370698+00	2026-05-11 06:39:59.370698+00	password	931f170c-a3a2-4504-afa9-c9a62cddb428
306bfcd6-dc55-4fae-9c6b-af76eaac301f	2026-05-11 09:48:22.098242+00	2026-05-11 09:48:22.098242+00	password	8e4e7bc7-f581-49ee-9b9b-bc0292631e02
eee22d67-0b56-4fed-af68-cf8598edfcc4	2026-05-11 13:02:10.85508+00	2026-05-11 13:02:10.85508+00	password	46b65e92-5f39-4817-916e-c605632bbc73
27a795f9-87e3-479c-b32c-8aee8f8bb33c	2026-05-11 23:54:54.371682+00	2026-05-11 23:54:54.371682+00	password	7de049f5-2137-4d2b-b648-2930a5fd3f1b
66810336-8c4a-48fc-99f4-182f70fa405a	2026-05-12 00:36:11.060855+00	2026-05-12 00:36:11.060855+00	password	7237c58c-5148-4e0a-b8c1-e5ffea94fc64
befbaa49-fed1-40d3-88fa-7c43bd870983	2026-05-12 03:33:50.175749+00	2026-05-12 03:33:50.175749+00	password	6af7d392-e749-420e-bb61-9d370f41f971
a029bea8-34bd-4e33-b6dd-6893bedbab30	2026-05-12 08:23:44.858388+00	2026-05-12 08:23:44.858388+00	password	74dcec8e-f96f-44fa-96cb-378e5586e0a5
24af1d8d-05ef-498b-b41b-4e9d1c7967f4	2026-05-12 09:02:56.444181+00	2026-05-12 09:02:56.444181+00	password	059bb2d0-2845-4886-901c-c3ae7374940f
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	332	ka3b5frw6pa6	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-10 05:19:49.50707+00	2026-05-10 06:19:59.518231+00	\N	5b72536a-9b8e-4162-a0e1-c01a979a8acd
00000000-0000-0000-0000-000000000000	337	s7g7h3yrjqmc	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-10 09:10:01.022838+00	2026-05-10 09:10:01.022838+00	say47mw2rymm	5b72536a-9b8e-4162-a0e1-c01a979a8acd
00000000-0000-0000-0000-000000000000	342	u2kt7wx3chny	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 12:34:32.614471+00	2026-05-10 15:00:48.220632+00	\N	467cb318-b9d9-4f73-8470-c0658c966c81
00000000-0000-0000-0000-000000000000	349	fwm2fe2ep72r	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-10 23:35:44.553769+00	2026-05-10 23:35:44.553769+00	wnmb4clq63zk	94e29cdf-8ffa-449b-9b56-7d495208405a
00000000-0000-0000-0000-000000000000	350	ql56aogrt46e	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 23:35:47.018687+00	2026-05-11 01:18:27.499786+00	\N	bdf7c1fe-7102-4680-9daf-e789d3f07f74
00000000-0000-0000-0000-000000000000	357	r4d6xphlsvrr	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 01:18:27.526301+00	2026-05-11 02:17:37.166982+00	ql56aogrt46e	bdf7c1fe-7102-4680-9daf-e789d3f07f74
00000000-0000-0000-0000-000000000000	362	4rmqlhvswv4m	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 04:30:41.037418+00	2026-05-11 04:30:41.037418+00	\N	0c60a456-a718-432e-8763-3806172c2eff
00000000-0000-0000-0000-000000000000	369	cn4ifcgtks3v	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 07:39:43.775229+00	2026-05-11 07:39:43.775229+00	6ze4wjodzj4n	bdf7c1fe-7102-4680-9daf-e789d3f07f74
00000000-0000-0000-0000-000000000000	374	eainds2i63e7	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 09:48:22.078122+00	2026-05-11 10:46:53.81077+00	\N	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	379	5zixbuzdnqxk	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 12:44:08.328074+00	2026-05-11 13:42:37.834551+00	5pobhloawhpu	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	384	42b2schxqk7w	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 14:20:34.596091+00	2026-05-11 22:25:54.665111+00	h7royib5u43x	eee22d67-0b56-4fed-af68-cf8598edfcc4
00000000-0000-0000-0000-000000000000	389	amw7qm3qbub7	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 22:26:59.217168+00	2026-05-11 23:25:38.251755+00	\N	f5ee7e24-febc-4ae4-8df8-0ef327d84484
00000000-0000-0000-0000-000000000000	394	irxf2vxwvxkf	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 01:18:02.93437+00	2026-05-12 02:18:12.64019+00	beca2ppbgovu	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	395	jdkt4ucmwu3t	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 01:19:02.644719+00	2026-05-12 02:49:27.677004+00	ikswkw6as2x6	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	400	abuc3ju3ns3h	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 03:27:39.70119+00	2026-05-12 04:26:55.341073+00	a7qhpkpedrph	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	405	qdyoxvo57wjz	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 05:49:05.245497+00	2026-05-12 06:48:23.930244+00	w6mfwu4mgaj7	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	406	jwxcvqwihdwy	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-12 05:49:12.905886+00	2026-05-12 06:49:22.723467+00	mve43guo5kws	befbaa49-fed1-40d3-88fa-7c43bd870983
00000000-0000-0000-0000-000000000000	413	mpb2wf7ui5ay	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-12 08:17:45.594607+00	2026-05-12 08:17:45.594607+00	\N	283da001-da7d-4519-b2d0-9c07b0db51a0
00000000-0000-0000-0000-000000000000	333	tlsxwleljedb	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 05:26:03.2933+00	2026-05-10 06:26:13.630216+00	\N	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	338	rlzl5zdixrm3	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 09:13:17.797041+00	2026-05-10 10:12:21.053497+00	xv5brkl5wa77	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	343	ah5yllmibvp3	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-10 13:41:13.471488+00	2026-05-10 13:41:13.471488+00	thwrnlgefvj6	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	344	z64sra77e7rz	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 13:41:19.512926+00	2026-05-10 14:39:45.49819+00	\N	94e29cdf-8ffa-449b-9b56-7d495208405a
00000000-0000-0000-0000-000000000000	351	ze36v3drne6q	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 00:06:10.910742+00	2026-05-11 00:06:10.910742+00	piay3b2mtrfh	b9346b4b-83eb-4a2f-b5f4-9dd56ea0326d
00000000-0000-0000-0000-000000000000	352	ktidcgxp4eil	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 00:06:18.564437+00	2026-05-11 00:06:18.564437+00	\N	7da5088e-29b9-450a-8010-cab3b693f20c
00000000-0000-0000-0000-000000000000	358	xmlfnkapanlb	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 02:17:37.180578+00	2026-05-11 03:16:02.498347+00	r4d6xphlsvrr	bdf7c1fe-7102-4680-9daf-e789d3f07f74
00000000-0000-0000-0000-000000000000	363	w4okgezf4nle	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 04:51:04.384388+00	2026-05-11 06:08:47.305353+00	\N	8d2d163a-beb6-4b16-94e2-a9f82f5199cb
00000000-0000-0000-0000-000000000000	370	lc65bimjrs4x	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 08:09:03.934423+00	2026-05-11 09:09:13.444377+00	aypp5kkmmns4	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	380	ywghjd2ow2mg	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 12:45:27.029723+00	2026-05-11 12:45:27.029723+00	nuqvx6wep3cs	6a63958d-1dc5-49de-985b-3200b29f6bef
00000000-0000-0000-0000-000000000000	375	o4sxsabnmtur	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 10:09:23.453184+00	2026-05-11 14:03:50.792952+00	vpetp5hnc7xu	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	385	yhywlxw5ajjc	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 14:41:39.744383+00	2026-05-11 15:40:28.151071+00	utvepl5kxoaz	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	390	qkky7qoj64p6	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 23:25:38.266273+00	2026-05-11 23:25:38.266273+00	amw7qm3qbub7	f5ee7e24-febc-4ae4-8df8-0ef327d84484
00000000-0000-0000-0000-000000000000	396	amyrtfjvuuh2	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 01:28:12.505646+00	2026-05-12 02:28:22.453092+00	\N	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	401	mrl2yya5svrk	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-12 03:33:50.137776+00	2026-05-12 04:32:23.773712+00	\N	befbaa49-fed1-40d3-88fa-7c43bd870983
00000000-0000-0000-0000-000000000000	407	ma4mnuydgrd6	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 05:53:19.218436+00	2026-05-12 06:54:32.815571+00	mrgyhp73njfl	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	414	6brpu7kuzkqn	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-12 08:23:44.835438+00	2026-05-12 08:23:44.835438+00	\N	a029bea8-34bd-4e33-b6dd-6893bedbab30
00000000-0000-0000-0000-000000000000	334	say47mw2rymm	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-10 06:19:59.536193+00	2026-05-10 09:10:01.011519+00	ka3b5frw6pa6	5b72536a-9b8e-4162-a0e1-c01a979a8acd
00000000-0000-0000-0000-000000000000	339	3ylhgcfvxaxs	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-10 09:33:32.559501+00	2026-05-10 09:33:32.559501+00	\N	6f5146a2-99a0-404f-89cd-e13e5ef546ed
00000000-0000-0000-0000-000000000000	345	wnmb4clq63zk	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 14:39:45.521615+00	2026-05-10 23:35:44.552901+00	z64sra77e7rz	94e29cdf-8ffa-449b-9b56-7d495208405a
00000000-0000-0000-0000-000000000000	353	3hgqhkxlv3qz	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 00:11:51.754172+00	2026-05-11 00:11:51.754172+00	\N	a283844b-9ad9-4697-b973-d2a954a09721
00000000-0000-0000-0000-000000000000	359	mykfrlrpabrz	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 03:16:02.511099+00	2026-05-11 04:16:11.87249+00	xmlfnkapanlb	bdf7c1fe-7102-4680-9daf-e789d3f07f74
00000000-0000-0000-0000-000000000000	364	zngrs2r624o6	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 06:08:47.327314+00	2026-05-11 06:08:47.327314+00	w4okgezf4nle	8d2d163a-beb6-4b16-94e2-a9f82f5199cb
00000000-0000-0000-0000-000000000000	365	pauz2pevsjeh	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 06:08:52.965365+00	2026-05-11 06:08:52.965365+00	\N	a73136e3-6fed-4e14-9e47-876c0127fd70
00000000-0000-0000-0000-000000000000	371	vpetp5hnc7xu	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 09:09:13.460773+00	2026-05-11 10:09:23.433572+00	lc65bimjrs4x	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	376	lifl2iolzkmw	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 10:46:53.831314+00	2026-05-11 11:45:38.272569+00	eainds2i63e7	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	381	h7royib5u43x	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 13:02:10.831319+00	2026-05-11 14:20:34.576404+00	\N	eee22d67-0b56-4fed-af68-cf8598edfcc4
00000000-0000-0000-0000-000000000000	391	q5ljru5kfem5	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 23:54:54.336503+00	2026-05-11 23:54:54.336503+00	\N	27a795f9-87e3-479c-b32c-8aee8f8bb33c
00000000-0000-0000-0000-000000000000	386	ikswkw6as2x6	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 15:10:37.474213+00	2026-05-12 01:19:02.630132+00	xj7yzz7qflww	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	397	dqksc62att46	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-12 02:18:12.656603+00	2026-05-12 02:18:12.656603+00	irxf2vxwvxkf	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	402	mrgyhp73njfl	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 03:58:18.25261+00	2026-05-12 05:53:19.189004+00	5on7ybjmgfai	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	408	tzbxi6elzrcm	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 06:48:23.945355+00	2026-05-12 07:48:32.998493+00	qdyoxvo57wjz	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	409	nb3qyukt74pq	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-12 06:49:22.740123+00	2026-05-12 07:49:31.736701+00	jwxcvqwihdwy	befbaa49-fed1-40d3-88fa-7c43bd870983
00000000-0000-0000-0000-000000000000	415	z6ychwccqqu6	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-12 08:30:06.86196+00	2026-05-12 08:30:06.86196+00	\N	58ae6835-dd81-4b77-bab0-3027b818eae8
00000000-0000-0000-0000-000000000000	335	mlsqa4wg3lqc	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 06:26:13.644504+00	2026-05-10 08:14:21.398618+00	tlsxwleljedb	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	340	4bk5ll3rmryq	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 10:12:21.067697+00	2026-05-10 11:10:42.388238+00	rlzl5zdixrm3	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	346	ha5jbg5asdah	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 15:00:48.239979+00	2026-05-10 22:16:49.107568+00	u2kt7wx3chny	467cb318-b9d9-4f73-8470-c0658c966c81
00000000-0000-0000-0000-000000000000	354	smrw6zqz7m2l	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 00:16:47.784107+00	2026-05-11 00:16:47.784107+00	\N	024d0d42-2ef3-424f-975e-ed0d73ef0c04
00000000-0000-0000-0000-000000000000	355	faxt3lryod7e	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 00:16:54.841366+00	2026-05-11 00:16:54.841366+00	\N	d527d8a9-1685-43cb-8b23-09773488438f
00000000-0000-0000-0000-000000000000	366	kp6uuxa7me6u	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 06:39:50.819294+00	2026-05-11 06:39:50.819294+00	\N	2298d10d-b478-4977-91f6-07fe0380c824
00000000-0000-0000-0000-000000000000	360	6ze4wjodzj4n	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 04:16:11.886587+00	2026-05-11 07:39:43.757904+00	mykfrlrpabrz	bdf7c1fe-7102-4680-9daf-e789d3f07f74
00000000-0000-0000-0000-000000000000	367	mkiiqtz3r2y5	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 06:39:59.369457+00	2026-05-11 09:17:56.283625+00	\N	a9b88a62-771d-457b-9f21-1ee41305f1c5
00000000-0000-0000-0000-000000000000	372	q6auas2t2k3b	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 09:17:56.322744+00	2026-05-11 09:17:56.322744+00	mkiiqtz3r2y5	a9b88a62-771d-457b-9f21-1ee41305f1c5
00000000-0000-0000-0000-000000000000	377	5pobhloawhpu	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 11:45:38.292028+00	2026-05-11 12:44:08.312916+00	lifl2iolzkmw	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	382	utvepl5kxoaz	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 13:42:37.850265+00	2026-05-11 14:41:39.720503+00	5zixbuzdnqxk	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	392	yj5cwpossynr	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-12 00:08:16.765912+00	2026-05-12 00:08:16.765912+00	\N	7a969d00-653b-4d6d-9393-e930fee972f1
00000000-0000-0000-0000-000000000000	387	beca2ppbgovu	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 15:40:28.16158+00	2026-05-12 01:18:02.922293+00	yhywlxw5ajjc	306bfcd6-dc55-4fae-9c6b-af76eaac301f
00000000-0000-0000-0000-000000000000	398	a7qhpkpedrph	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 02:28:22.471512+00	2026-05-12 03:27:39.525335+00	amyrtfjvuuh2	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	403	w6mfwu4mgaj7	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 04:26:55.35864+00	2026-05-12 05:49:05.228992+00	abuc3ju3ns3h	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	410	qhbpgn3ugapa	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-12 06:54:32.848856+00	2026-05-12 06:54:32.848856+00	ma4mnuydgrd6	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	416	je7widgyuwlw	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-12 09:02:56.409369+00	2026-05-12 09:02:56.409369+00	\N	24af1d8d-05ef-498b-b41b-4e9d1c7967f4
00000000-0000-0000-0000-000000000000	336	xv5brkl5wa77	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 08:14:21.415583+00	2026-05-10 09:13:17.781867+00	mlsqa4wg3lqc	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	341	thwrnlgefvj6	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 11:10:42.423582+00	2026-05-10 13:41:13.457742+00	4bk5ll3rmryq	e5cad0cd-81be-43c2-b2dd-8be48aae28eb
00000000-0000-0000-0000-000000000000	347	ntdkxntrum7r	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-10 22:16:49.126525+00	2026-05-10 22:16:49.126525+00	ha5jbg5asdah	467cb318-b9d9-4f73-8470-c0658c966c81
00000000-0000-0000-0000-000000000000	348	piay3b2mtrfh	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-10 22:16:50.887906+00	2026-05-11 00:06:10.898189+00	\N	b9346b4b-83eb-4a2f-b5f4-9dd56ea0326d
00000000-0000-0000-0000-000000000000	356	a5kl6vgz3sz4	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 00:54:01.169108+00	2026-05-11 00:54:01.169108+00	\N	f333624d-97ef-46a4-ac61-1614ef8614e0
00000000-0000-0000-0000-000000000000	361	cfdwdo66ckbx	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 04:18:09.934089+00	2026-05-11 07:10:12.153362+00	\N	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	368	aypp5kkmmns4	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 07:10:12.178387+00	2026-05-11 08:09:03.919378+00	cfdwdo66ckbx	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	373	cugrs3o77jtp	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 09:40:12.339899+00	2026-05-11 09:40:12.339899+00	\N	ef60474c-2102-4f89-8ce9-3f1056c154f3
00000000-0000-0000-0000-000000000000	378	nuqvx6wep3cs	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 11:47:19.859027+00	2026-05-11 12:45:27.019347+00	\N	6a63958d-1dc5-49de-985b-3200b29f6bef
00000000-0000-0000-0000-000000000000	383	xj7yzz7qflww	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-11 14:03:50.878465+00	2026-05-11 15:10:37.46113+00	o4sxsabnmtur	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	388	ez7lct6rwrvv	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-11 22:25:54.685484+00	2026-05-11 22:25:54.685484+00	42b2schxqk7w	eee22d67-0b56-4fed-af68-cf8598edfcc4
00000000-0000-0000-0000-000000000000	393	melmh5m4ez3p	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-12 00:36:11.036721+00	2026-05-12 00:36:11.036721+00	\N	66810336-8c4a-48fc-99f4-182f70fa405a
00000000-0000-0000-0000-000000000000	399	5on7ybjmgfai	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 02:49:27.699592+00	2026-05-12 03:58:18.228392+00	jdkt4ucmwu3t	af2256a6-ac64-4525-a246-91fd340b9bb2
00000000-0000-0000-0000-000000000000	404	mve43guo5kws	c869d8ce-23e0-47e9-b7b8-7678ddd70597	t	2026-05-12 04:32:23.791029+00	2026-05-12 05:49:12.748928+00	mrl2yya5svrk	befbaa49-fed1-40d3-88fa-7c43bd870983
00000000-0000-0000-0000-000000000000	412	dkzmu4bij3l2	c869d8ce-23e0-47e9-b7b8-7678ddd70597	f	2026-05-12 07:49:31.745868+00	2026-05-12 07:49:31.745868+00	nb3qyukt74pq	befbaa49-fed1-40d3-88fa-7c43bd870983
00000000-0000-0000-0000-000000000000	411	nayjkm72lruz	39c8bd8e-417e-4f88-bf13-f8800858bdbe	t	2026-05-12 07:48:33.015695+00	2026-05-12 09:05:01.477973+00	tzbxi6elzrcm	783deb18-7bf3-40eb-a947-a89bf6ed8d04
00000000-0000-0000-0000-000000000000	417	pmtnuekqiwwn	39c8bd8e-417e-4f88-bf13-f8800858bdbe	f	2026-05-12 09:05:01.501473+00	2026-05-12 09:05:01.501473+00	nayjkm72lruz	783deb18-7bf3-40eb-a947-a89bf6ed8d04
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
5b72536a-9b8e-4162-a0e1-c01a979a8acd	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-10 05:19:49.500233+00	2026-05-10 09:10:01.038338+00	\N	aal1	\N	2026-05-10 09:10:01.038234	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
94e29cdf-8ffa-449b-9b56-7d495208405a	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 13:41:19.483644+00	2026-05-10 23:35:44.56694+00	\N	aal1	\N	2026-05-10 23:35:44.566826	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
a283844b-9ad9-4697-b973-d2a954a09721	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 00:11:51.728445+00	2026-05-11 00:11:51.728445+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
0c60a456-a718-432e-8763-3806172c2eff	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 04:30:40.114156+00	2026-05-11 04:30:40.114156+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
ef60474c-2102-4f89-8ce9-3f1056c154f3	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 09:40:12.307502+00	2026-05-11 09:40:12.307502+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
f5ee7e24-febc-4ae4-8df8-0ef327d84484	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 22:26:59.183659+00	2026-05-11 23:25:38.284309+00	\N	aal1	\N	2026-05-11 23:25:38.283475	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
58ae6835-dd81-4b77-bab0-3027b818eae8	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-12 08:30:06.831559+00	2026-05-12 08:30:06.831559+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.233.245.100	\N	\N	\N	\N	\N
783deb18-7bf3-40eb-a947-a89bf6ed8d04	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-12 01:28:12.475635+00	2026-05-12 09:05:01.525011+00	\N	aal1	\N	2026-05-12 09:05:01.524436	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
e5cad0cd-81be-43c2-b2dd-8be48aae28eb	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 05:26:03.264427+00	2026-05-10 13:41:13.485612+00	\N	aal1	\N	2026-05-10 13:41:13.485521	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
b9346b4b-83eb-4a2f-b5f4-9dd56ea0326d	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 22:16:50.875237+00	2026-05-11 00:06:10.924323+00	\N	aal1	\N	2026-05-11 00:06:10.923893	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
024d0d42-2ef3-424f-975e-ed0d73ef0c04	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 00:16:47.752344+00	2026-05-11 00:16:47.752344+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
d527d8a9-1685-43cb-8b23-09773488438f	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 00:16:54.826544+00	2026-05-11 00:16:54.826544+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
8d2d163a-beb6-4b16-94e2-a9f82f5199cb	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 04:51:04.20338+00	2026-05-11 06:08:47.342862+00	\N	aal1	\N	2026-05-11 06:08:47.342771	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
27a795f9-87e3-479c-b32c-8aee8f8bb33c	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 23:54:54.252609+00	2026-05-11 23:54:54.252609+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
306bfcd6-dc55-4fae-9c6b-af76eaac301f	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 09:48:22.046595+00	2026-05-12 02:18:12.688186+00	\N	aal1	\N	2026-05-12 02:18:12.684297	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
befbaa49-fed1-40d3-88fa-7c43bd870983	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-12 03:33:50.097492+00	2026-05-12 07:49:31.759537+00	\N	aal1	\N	2026-05-12 07:49:31.759436	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.233.245.100	\N	\N	\N	\N	\N
24af1d8d-05ef-498b-b41b-4e9d1c7967f4	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-12 09:02:56.365197+00	2026-05-12 09:02:56.365197+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6f5146a2-99a0-404f-89cd-e13e5ef546ed	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 09:33:32.526805+00	2026-05-10 09:33:32.526805+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
f333624d-97ef-46a4-ac61-1614ef8614e0	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 00:54:01.139518+00	2026-05-11 00:54:01.139518+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
a73136e3-6fed-4e14-9e47-876c0127fd70	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 06:08:52.950349+00	2026-05-11 06:08:52.950349+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
bdf7c1fe-7102-4680-9daf-e789d3f07f74	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 23:35:47.007071+00	2026-05-11 07:39:43.798318+00	\N	aal1	\N	2026-05-11 07:39:43.796818	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
6a63958d-1dc5-49de-985b-3200b29f6bef	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 11:47:19.827487+00	2026-05-11 12:45:27.044447+00	\N	aal1	\N	2026-05-11 12:45:27.043962	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
7a969d00-653b-4d6d-9393-e930fee972f1	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-12 00:08:16.724517+00	2026-05-12 00:08:16.724517+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
283da001-da7d-4519-b2d0-9c07b0db51a0	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-12 08:17:45.566771+00	2026-05-12 08:17:45.566771+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.233.245.100	\N	\N	\N	\N	\N
467cb318-b9d9-4f73-8470-c0658c966c81	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-10 12:34:32.575731+00	2026-05-10 22:16:49.143806+00	\N	aal1	\N	2026-05-10 22:16:49.142918	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
7da5088e-29b9-450a-8010-cab3b693f20c	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 00:06:18.549281+00	2026-05-11 00:06:18.549281+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
2298d10d-b478-4977-91f6-07fe0380c824	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 06:39:50.792133+00	2026-05-11 06:39:50.792133+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
a9b88a62-771d-457b-9f21-1ee41305f1c5	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 06:39:59.36435+00	2026-05-11 09:17:56.336704+00	\N	aal1	\N	2026-05-11 09:17:56.335616	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.150.170	\N	\N	\N	\N	\N
eee22d67-0b56-4fed-af68-cf8598edfcc4	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 13:02:10.791184+00	2026-05-11 22:25:54.701587+00	\N	aal1	\N	2026-05-11 22:25:54.70115	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
66810336-8c4a-48fc-99f4-182f70fa405a	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-12 00:36:11.004155+00	2026-05-12 00:36:11.004155+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	171.255.155.137	\N	\N	\N	\N	\N
af2256a6-ac64-4525-a246-91fd340b9bb2	39c8bd8e-417e-4f88-bf13-f8800858bdbe	2026-05-11 04:18:09.906865+00	2026-05-12 06:54:32.899986+00	\N	aal1	\N	2026-05-12 06:54:32.899507	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	171.251.239.39	\N	\N	\N	\N	\N
a029bea8-34bd-4e33-b6dd-6893bedbab30	c869d8ce-23e0-47e9-b7b8-7678ddd70597	2026-05-12 08:23:44.799971+00	2026-05-12 08:23:44.799971+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	14.233.245.100	\N	\N	\N	\N	\N
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	c869d8ce-23e0-47e9-b7b8-7678ddd70597	authenticated	authenticated	admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com	$2a$10$yICCU7VKh.xcTxEgXsA12eTwe4J8vVjXQhn0twACSa47wWF8/uXz2	2026-05-10 05:19:49.477261+00	\N		\N		\N			\N	2026-05-12 09:02:56.363807+00	{"provider": "email", "providers": ["email"]}	{"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}	\N	2026-05-10 05:19:49.273939+00	2026-05-12 09:02:56.440659+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	39c8bd8e-417e-4f88-bf13-f8800858bdbe	authenticated	authenticated	admin@gioithieu.com	$2a$10$MVYZSibwWIE9ePWAoyBziOMl53MeSct2CMnIVMGrdO9UKjpFOHG1q	2026-05-10 05:26:03.249173+00	\N		\N		\N			\N	2026-05-12 01:28:12.472964+00	{"provider": "email", "providers": ["email"]}	{"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}	\N	2026-05-10 05:26:03.202812+00	2026-05-12 09:05:01.513701+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at", "namhoc") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat", "chidoan_id", "createdat") FROM stdin;
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoten", "ngaysinh", "gioitinh", "dantoc", "doituong", "doanvien", "chidoan", "ngayvaodoan", "sdt", "thongtinthem", "updatedat", "namhoc", "diachi", "chidoan_id", "createdat") FROM stdin;
ff274fde-e036-45d3-ac00-aff15ed9dece	Phạm Dương Anh	01/02/2010	Nữ	Kinh	\N	t	\N	17/01/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai.	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
5bd84857-9f16-4a7b-9912-b9ceee882f88	Phạm Văn Bé	04/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4,xã Đức Cơ,Tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
08d657a8-2d18-4fed-8cf8-ad27b923a7d1	Lương Thanh Bình	05/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Đo,xã Ia Dơk,tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
66a985bd-c92a-4ffe-ba56-72f86bbcadfd	Bùi Ngọc Đạt	08/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân, IaKrêl, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
1d6aac1b-bc8b-42b4-811c-a5ebd7d64b61	TRẦN KHÁNH HÀ	02/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Đoàn kết, xã iakla, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
ebf46acb-22e6-4e0a-895b-f5a5d28a4093	Nguyễn Công Hậu	25/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
bda4ef04-9f4b-4e34-ad37-840f3420d90b	Nguyễn Đức Hiếu	21/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
d6810a04-750e-4a5a-a37b-d4d5c9177df1	Nguyễn Văn Hiếu	13/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
c6c29a73-19bc-450e-9c60-83b971a5f5b2	Lê Thị Thúy Hoài	09/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
dd6e7e72-0efc-4184-86a5-bf75ff821c61	Đinh Ngọc Khánh Huyền	11/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
7abf1c46-e632-416c-a236-77b735cad37a	Phạm Quốc Hưng	25/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
2dcc7033-77eb-44be-b603-e96fe34d03da	Đào Viết Khánh	29/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
a3add910-2421-4306-85ee-79586d984b44	Nguyễn Quang Kiên	07/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Thanh giáo, xã ia Krêl, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
94dd7549-b924-4ad9-b4b9-9ad66be90117	Nguyễn Khánh Linh	14/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
28fdc614-e3bb-4ca0-aa7f-a23fe0e24fed	Nguyễn Phi Long	02/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn chư bồ,xã Ia Dơk, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
3887a79b-a272-4c75-95fb-6f9c4276b719	Trần Đức Lương	20/06/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngo Rông , xã Iakrêl , tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
24ee73f0-abab-4340-b895-0d0b407ea519	Hồ Thị Khánh Ly	01/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
6a8cc4d6-2d9b-4d50-a147-8e84f0d8d693	Nguyễn Hoàng Bảo Minh	25/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
a3908f0a-4617-42d0-ba98-d701f7f9b832	Hồ Thu Nga	13/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
79279359-c6b2-4bc0-bfa7-82c8befff0af	Trịnh Thị Hằng Nga	28/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Ia Krêl, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
24acf2af-5e90-4ea0-af02-fa8d087d3f17	Nguyễn Lục Ngạn	26/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
ff78d8b8-9a51-4d02-bb4e-6b8cafbabd34	Lê Hoàng Mỹ Ngọc	01/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
21f1a3d1-c453-46c9-98d4-006229bb71f0	Lê Thị Bảo Ngọc	29/04/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
6070d770-1a62-4423-987b-9b6b04d6731a	Cao Anh Nhân	24/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
bdd0b563-4d04-4ce4-858b-473243286656	Lê Võ Thanh Nhật	01/12/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
1f23ead5-8bad-40ea-b50b-4889ae25b951	Đặng Thị Thu Phương	04/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua - IaPnôn -Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
56661cbe-689f-4dba-abac-7b8ff530bd3e	Đỗ Bảo Quang	07/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
08a186ff-0a6b-4d48-86eb-cb046837c5d6	Hồ Hữu Quang	07/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
b28ca061-2a06-4af1-9c59-6bc5bebbbd27	Hô Khắc Anh Quân	21/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Thanh giáo, Xã Ia Krêl, Tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
44e5fafc-b092-497d-842a-887023171093	Hồ Sỹ Quân	22/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Đức Cơ, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
c7a307e4-bd40-44e2-87df-fa6c5c4e5773	Phạm Vũ Như Quỳnh	03/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
af188f23-4b87-4667-9a8b-ecdbd184e25a	Nguyễn Ngọc Lan Thanh	07/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
eeac0126-540c-486c-9d60-1611981fbced	Võ Hạnh Thảo	26/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
b28f2b79-eb81-4eb6-9679-ef6f6ea48d6c	Trần Hồng Thế	24/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân ,xã Ia Krêl, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
b77fb88a-0c2b-457f-ae8d-5b788929c376	Dương Đức Thịnh	07/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
0a69b601-9e46-4b4d-98b8-e4ae7705d3fb	Phan Ngọc Thịnh	02/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, Đức Cơ, Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
bbb92e37-e04e-4e29-a560-f8b6eee8f7d2	Bùi Thị Lý Thu	05/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua - Xã Ia Pnôn - Tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
1003b661-914c-48cb-8b6d-588eae1bcf71	Hồ Nguyễn Khánh Trang	09/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
62317796-c74f-44b4-8d26-4368945c4dc8	Hồ Thị Thùy Trang	22/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
282f61d3-20be-4cbc-ad08-05f63ba2bf37	Lê Thị Thùy Trang	25/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1,xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
ab602b7d-fdf9-4b59-9b50-5484f04b906a	Nguyễn Thị Huyền Trang	11/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
ecec11e9-ee98-4d41-abe6-4ec37d0293ab	Nguyễn Trần Huyền Trang	10/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lâm Tôk , xã Ia Krêl, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
49e2207e-1f84-4aa0-b3f6-41c8f1792516	Nguyễn Quốc Trọng	11/05/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1,xã Đức Cơ, tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
cbca41d2-93bd-44ea-bcab-7bf151c5f4ea	Đoàn Tường Vy	11/04/2010	Nữ	Kinh	\N	t	\N	24/03/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngo le 1 - xã Iakrêl - tỉnh Gia Lai	35e180f6-6d54-4a30-a1ac-a55760d259f7	2026-05-12 09:22:24.602551+00
ce7324ab-acdc-42a9-8b05-d349fb66efae	Lê Hồ Hoài An	28/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ  3, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
6542fe07-7ba0-419f-8f5e-b17509f6dcb0	Lê Thị Hoài Anh	29/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
cff0343f-9d26-4300-b6b5-a7e09da815b9	Lê Thị Thanh Ánh	04/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua, xã Ia Pnôn, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
47998900-83a7-4437-af1b-4f17bb6127fc	Nguyễn Quang Ánh	11/02/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
cbef4a34-b744-497d-8936-99335e9204c1	Nguyễn Tuấn Anh	17/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
d1b50b67-e43f-4477-8cfa-7e40ecc7ef28	Trần Quỳnh Anh	26/04/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
70bd7942-cd99-4e77-9485-95ff0aefd818	Phạm Lê Gia Bảo	27/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
d2c702fd-afd6-46c8-93d0-1c6d61f0f18d	Lường Thị Ngọc Bích	19/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thống Nhất, xã Ia Krêl, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
39a24dc8-fe07-4fd4-bab1-18fe09a90c67	Đặng Bảo Châu	19/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Xã Ia Dơk, Tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
a4af014f-5629-4ddc-b4be-bd5cc37ce178	Nguyễn Thị Kim Cúc	10/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
cc61ec45-be8a-49e8-bc13-47b4a30f57a7	Bùi Thị Thùy Dung	23/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
42fba978-7df5-46d5-ba9e-37c348e7a1e3	Hoàng Lê Trung Dũng	30/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
c8580b04-a0c9-4b6b-8238-a5ef21c51bf4	Nguyễn Hoàng Đức Duy	26/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaTang, xã ia Dơk, tỉnh Gia lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
4b51d8ec-1215-46e7-9b8e-3eabdc2c6320	Nguyễn Ngọc Quỳnh Dương	14/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
69b0f0d2-0a6c-4b32-8914-0ca91980f35b	Lê Đức Đạt	05/11/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
7e59287c-1598-44a2-8d87-85d12e12b8fe	Hồ Việt Đức	13/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
4a79b0fc-9158-47c0-b1df-effd2ddc30dd	Vũ Ngọc Trường Giang	18/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
8a8e18c9-ca1f-4430-b61b-dd49f6336c4f	Nguyễn Hồ Thanh Hà	10/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
adc04080-6534-4b04-ba46-91179306c0b6	Đào Ngọc Hân	24/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
55085754-735d-49f4-8b84-27f4add4e44b	Lê Minh Hiếu	02/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
6d484de2-d5b9-4135-81cf-f20ce76b6b6e	Hà Thị Kim Huệ	01/09/2010	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
30f1c828-5fb9-4f3e-b2aa-42e27486a978	Nguyễn Văn Quốc Hùng	02/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
1b25d696-c919-4e3f-bdaa-04ecca77ef3a	Đinh Thị Nhã Hương	08/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
6bedb820-abe5-4d07-87c8-161f911b3ab1	Phạm Lê Gia Linh	09/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua, xã Ia pnôn, tỉnh Gia lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
f7eb59c9-010c-4132-ba47-ef1864f9a7e7	Bùi Thanh Luân	14/02/2010	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
2dbeca21-6fd6-4061-857e-bb8143207f0a	Lê Ngọc Hoàng Minh	23/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
4244ce90-edcd-45d8-baec-3f27bcbc1e56	Đoàn Thị Trà My	09/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn đoàn kết, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
46c6ae55-1174-487d-abe7-97cddd2ac1ac	Đỗ Như Nguyệt	01/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
386bb254-ce55-4327-85a2-f662d3511d18	Hồ Thị Như	04/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
9866bb78-ff22-4ec5-9668-1861d9aa73f4	Lê Quang Phú	07/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk , Gia lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
bbed558c-c0d3-420e-a951-7a635ee06ad3	Võ Hồ Thanh Phúc	06/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
e6d151e6-c467-4b8f-8464-181f7feb26e5	Đinh Hồng Quy	22/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
8b4261bd-a3e4-4079-b534-39a763c890cc	Lê Dương Nhất Tâm	01/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
6df15387-293f-4b0b-bf9a-119e978ee732	Lê Đức Thành	05/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
a8ccbd6c-ede1-41e0-9797-b0811435e41f	Võ Văn Thành	19/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
bfd1c9eb-6014-49e7-8862-831beed74e91	Hồ Diên Thuận	24/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
da1da17d-9238-4672-bcb0-6835b119a0e1	Nguyễn Hoàng Anh Thư	26/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
c6b94ceb-e9a0-4a1b-8387-829ac6953ce7	Nguyễn Sỹ Nguyên	16/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	\N	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
a51a0e23-c9c5-4ba9-811e-3b3d974844dc	Võ Anh Thư	18/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Bình, xã Bàu Cạn , tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
2cc86fce-e84c-46fb-a720-ff91827daaec	Đặng Việt Tiến	31/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
98832356-5a0a-4000-8457-6274418c5abd	Nguyễn Minh Trí	11/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
42fe7bae-38cf-48a0-a64c-ff8d5c2f53bf	Đỗ An Triều	01/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
3822d599-79bd-49d5-bb6e-db8b2dd42b46	Phạm Đức Trung	13/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
b64b3c87-34a9-4d33-9e3b-924f13d7d751	Nguyễn Đình Tuân	21/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
4cf307b4-7c64-4e39-b69c-ffa9208286ba	Nguyễn Hoàng Vi	11/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	2ad031fd-d814-44c0-a31a-144fd9b75bce	2026-05-12 09:22:24.602551+00
78cf5341-236a-4331-a9ab-13c093ceee77	Hồ Xuân An	26/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
4046a1dd-a672-41e1-b66c-f9ef10091378	Nguyễn Trường An	05/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
5106f21e-f23c-4d46-b73f-8fe6c411f4fc	Huỳnh Thị Ngọc Anh	13/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
3442ad72-65fb-4887-8d69-be886f371376	Nguyễn Thị Trâm Anh	14/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
bd77240b-087c-4919-ba77-94408cfce292	Hồ Nguyễn Khánh Băng	17/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
4e1f7a60-1fa4-4196-841d-276a726a341a	Kpuih Bân	09/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Klăh, xã Ia Dơk, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
f1375c14-18da-4c43-b08e-d122c92be28e	Vũ Thị Ánh Dương	15/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
984013bd-d610-4047-a2db-9b0ef0d8826b	Lê Anh Đức	27/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
ccce2496-0188-4fbd-8dcc-9e831f285336	Phan Anh Đức	10/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
1cb3dbd2-3fa0-476b-ab80-62b259b8c95c	Lê Hương Giang	07/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
27ead699-eb29-4996-a228-1d0e8466c3bd	Hồ Ngọc Hậu	21/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
68e802ba-862a-4851-9dce-7c584134f854	Bùi Việt Hoàng	18/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
99b7abda-1a5d-4277-9318-f576117568be	Mai Văn Nguyên Hoàng	23/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
f83fd902-7f8b-4457-b526-0e787d8888ac	Võ Đại Hùng	02/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
5d9a1fe0-438d-4ef5-8e97-5e12e90ca90d	Lê Thu Huyền	26/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
d342c432-0055-4766-936c-d8a159a727b1	Nguyễn Ngọc Lan	02/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
71c99a4c-5eb5-45a9-ac4c-eb7ca206f26e	Lữ Thị Mỹ Linh	20/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
efce81dc-f77d-441f-8e38-780fa852b883	Lương Võ Hà Linh	14/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaTang, xã Ia Dơk, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
1b543aa3-3404-4962-b51e-c5ac9a011431	Trần Thị Thùy Linh	03/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
3ddacce5-5f87-4047-9d7f-1cb0b623d6bc	Võ Đại Mạnh	02/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
17de2b42-2a2b-4512-b0e5-a9def0862a8f	Nguyễn Thảo Minh	02/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
cd3710f0-8797-49c0-ba39-b120169ee0b6	Nguyễn Thị Kim Ngân	30/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
292851ea-17ea-4f7d-9dbc-8e82562a0f81	Trương Nữ Kiều Ngân	08/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
35b8a8fd-c99a-45fd-8eb9-2aa0d567fec7	Hồ Đại Nghĩa	30/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
7a5782bf-42fd-4da1-9d2d-fa0bdda1f927	Lê Nguyễn Hồng Ngọc	29/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
26495189-74ca-4ae8-9f72-6ba093c5dfdf	Hồ Trần Gia Như	15/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
f1e2b953-8cce-49ce-9443-7364be75b7d2	Lê Thị Uyên Phương	29/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
3a23d066-9882-46b0-9ebd-6e1640b810a3	Nguyễn Ngọc Anh Quân	10/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
62bde065-6e37-4842-8be1-4619c8ee269e	Trương Đình Cảm Thái	07/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
3f0cbbe9-2424-4e4f-9ae7-d744c1cbbd56	Huỳnh Nguyễn Phương Thảo	10/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã Ia Dom, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
47d69220-7f26-4994-b729-f1294b729f7f	Võ Thị Anh Thơ	09/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
a037b4b5-af05-4080-bd22-908a8e84844a	Phạm Thị Anh Thư	11/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn 3, xã Ia Krăi, Ia Grai, Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
caa4d937-d2e0-4d45-9fdb-ce97b22e72c0	Trần Thị Thu Trang	03/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
cdc8b65b-135a-4b1c-b037-22125f27abfa	Võ Ngọc Minh Trâm	14/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
6b11af12-8e94-41e0-9095-107d7ce79c70	Nguyễn Minh Trí	04/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
640a0ead-edba-4b83-8313-72aa319e16f8	Võ Huỳnh Trung	09/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
3dfb6c40-704f-440e-9522-01263b71b0e7	Nguyễn Khắc Anh Tuấn	19/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã Ia Krêl, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
5c92a257-77ab-4ee7-bcd8-ac24f829761f	Hồ Nguyễn Thục Uyên	16/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
302ba95f-1a48-4198-bcb8-ba8ad8597f3f	Thiều Quang Vinh	20/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
ce1aef30-e999-404e-aafd-742f9ba192e6	Nguyễn Quách Uy Vũ	23/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
4b88c92d-0085-4d9e-884e-9429a13b95cd	Bùi Thị Tường Vy	15/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	4c6892d9-08b6-40c7-90fb-357745b185c6	2026-05-12 09:22:24.602551+00
3770af4a-40ab-412b-b7d6-aa7a7cc2ca7f	Hồ Ngọc Trâm Anh	22/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
033bdf93-bfca-459c-a974-1b53aaa69cfd	Phạm Hà Anh	23/01/2010	Nữ	Kinh	\N	t	\N	25/04/2025	0901910680	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
29b8e6a6-00de-4eb5-b094-f0f146d90f63	Vũ Thị Hà Anh	17/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
5e3d1f9c-0aa5-47a1-84d1-3ed949768a31	Lê Thị Khánh Băng	16/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
51325b1c-ccb7-4212-9a2e-10d75dcaa753	Hồ Anh Dũng	17/07/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
1ea43a95-822f-49f7-b16b-c1b7290bc6de	Lê Quang Dũng	24/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
a5bc8a37-76a2-4718-b18f-19e692ccbb90	Đỗ Viết Đạt	16/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
695d4755-f9eb-44b5-a6ae-e9988cd39feb	Hà Tiến Đạt	04/07/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
693f3dd0-7c39-48ff-b6c6-0e74ee97a3bb	Đào Gia Đức	10/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Ia Krel tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
2e8df8f5-3e5a-4ec4-88b4-8626dc1e4702	Bạch Thị Ngọc Hà	08/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
b6928476-8645-4b88-ba17-40d9e8a5f6bc	Hồ Ngọc Hải	29/09/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
987f6b98-fe8a-4bcb-b381-eb28e57e9a34	Nguyễn Đăng Hoàng	10/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
80820fd9-aa77-41b8-82a6-0f25a4f35089	Nguyễn Đăng Huy	12/10/2010	Nam	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
086f7026-ebe0-487b-9f3d-f2698074e86b	Nguyễn Văn Huy	29/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
1fc10c29-1346-4e21-a2bb-b16178575ca0	Võ Đình Huy	17/05/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	tổ dân phố 7, xác Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
1d276776-69cd-4122-9098-46b5a2f3a0b3	Nguyễn Phùng Tuấn Hưng	09/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đội 12, xã Ia Chía, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
a7898610-7f6e-416d-94f8-a61404e4f3b3	Trần Đăng Khoa	28/12/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
c4db0e53-e5ce-4938-8eba-39bb74072abc	Lê Đình Lâm	02/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
761d6326-21f2-4b14-a872-588ebcc1c463	Quách Thùy Linh	21/02/2010	Nữ	Kinh	\N	t	\N	25/04/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
2f73bdfa-6c22-404d-9a47-d56c0d6a93a0	Nguyễn Bảo Ngọc	03/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
3dba9c13-7f5b-4c77-a60a-44387e3869dc	Võ Trần Bảo Ngọc	03/10/2010	Nữ	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
c4250538-6154-4791-b7e8-67364a78313c	Trần Đức Nguyên	25/02/2010	Nam	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
96b4dcb5-0ab2-4605-a622-a3bb1882e9b9	Hoàng Mai Nhi	19/09/2010	Nữ	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
7a83b07d-4a9f-4bd9-a6e2-673ec616cbb3	Hồ Thị Yến Nhi	20/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng ấp, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
f7682a7e-6a91-4279-9c71-3646b7f0526a	Hoàng Lâm Phú	10/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bi, xã Ia Dom, huyện Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
90e8df97-07a8-4689-89df-6b0332dd5384	Lại Minh Quang	12/12/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
9b2b7816-d23f-4ccd-b628-2db572537781	Dương Thị Hồng Quyên	29/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
dd7f78f9-7241-4b07-abb9-6e3885415eea	Nguyễn Thị Như Quỳnh	14/02/2010	Nữ	Kinh	\N	t	\N	20/04/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
93993241-08c6-41e0-b8a6-a996038bad34	Hồ Văn Tài	22/02/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
3c0a152f-db92-43a4-810f-87795c0667e3	Trần Thị Tuệ Tâm	03/05/2010	Nữ	Kinh	\N	t	\N	26/03/2024	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai.	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
fa7cf0ca-1a74-40d3-a712-e0dbefafab13	Võ Lê Thanh Thảo	02/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
cafabd3d-8d00-4423-8e98-85a49b521bed	Hồ Diên Thiện	30/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, xã Iakrel, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
e726b445-d083-4834-bc03-76eb531a9e27	Võ Hoàng Ngọc Thiên	07/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ấp chợ, Xã Thống Nhất, Tỉnh Đồng Nai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
92b90568-bd5c-4c48-ab14-e2c35021eeb1	Võ Huỳnh Thiên Thư	04/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
b00b4b14-30fc-4e95-9b8d-43f0606c2e2a	Trần Trọng Tiến	11/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
64d8c58b-15c5-4b6d-a1d5-10674fd9b176	Võ Văn Tiến	01/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
6a83edcf-d538-4658-a90b-6c19c7d0aa9a	Nguyễn Thị Thảo Trang	22/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
db5136ad-357a-467f-8ea7-c92017be042b	Nguyễn Thị Thùy Trang	17/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
8e3877cc-6947-40b5-9c06-9f141a9878bc	Nguyễn Ngọc Quỳnh Trân	25/08/2010	Nữ	Kinh	\N	t	\N	07/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
248fe49a-ff61-4804-b3c7-baa779053991	Phan Văn Trọng	28/04/2010	Nam	Kinh	\N	t	\N	25/04/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
3718c699-bf5d-4ffd-8d2e-89769f3e395d	Trần Văn Trọng	09/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
dd4ae0bb-8278-4b19-bb90-434a1f04b9f4	Nguyễn Huỳnh Như Trúc	27/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
b6a0ffed-c4cf-4222-8d48-5f47a28c31f4	Trần Đỗ Uy Vũ	23/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	d310f4db-72b5-4ec3-9200-ae53af36051f	2026-05-12 09:22:24.602551+00
988e81eb-67f3-4b1b-93bc-55c4cdde709d	Mã Quỳnh Anh	29/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
45b33a56-0884-4edb-b33c-6dbc27351bab	Nguyễn Thị Mai Anh	24/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
a988e04b-df77-47e7-b4b5-ec16ee7f0fae	Nguyễn Ngọc Bảo Châu	10/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
af3e12bf-2905-4294-951e-d5a672ccf70f	Rơ Lan Chun	31/10/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le Kắt, xã Ia Dơk, tỉnh Gia La	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
50970b93-1320-4763-b9fd-fc171f6575dd	Kpuih H' Han	10/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
abbea730-c907-4312-9783-3718f324ae37	Nguyễn Thị Minh Hằng	01/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
3ddac27b-eb57-4a6d-a5c7-09e1fe7b9656	Phạm Công Hậu	02/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo. xã Ia Krêl, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
70742ede-2847-4e56-bca1-fdd32c1bcfef	Võ Xuân Hiền	09/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
544ca036-3bcf-4b15-85e3-7ac49f9068d1	Hoàng Thị Thu Hoài	02/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
ac8b3a0f-2956-447c-a7bd-780e68dce399	Lê Đình Huy	24/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
97cc2805-b64b-4595-bdc0-8cd26e721251	Trần Thị Khánh Huyền	07/12/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
2d47cf02-db32-4e17-8363-cc563b7ee0ce	Lưu Thị Phương Khanh	22/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
a8e0183f-50bb-4138-bf53-6a07f94a5dc3	Phạm Ngọc Cao Kiệt	20/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lâm Tôk, xã IaDơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
144cdf63-121f-404e-8856-5db2c810ec1e	Kpuih H' Lăk	10/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, xã IaDơk, tỉnh GIa Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
1c196a91-23a8-49f1-a59d-98efff2eb077	Rơ Mah H' Liên	07/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong, xã IaDơk, tỉnh GIa Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
7e449983-409d-40f2-bda7-95f952b9dfea	Bùi Thị Khánh Linh	09/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
455ff833-2a16-4c88-be1e-f2535ed9e4f0	Đào Thị Thùy Linh	20/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
9d68c7da-458b-43d1-9246-e9071e61e286	Hồ Thị Mỹ Linh	07/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
87bb611c-4181-4904-b051-1bb40fa512c3	Lê Hoàng Kiều My	07/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
4e3f06d3-89a1-4c7a-be90-36815be9e2d3	Nguyễn Hà Thảo My	02/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
e670eaae-23e4-4444-a530-4ea7e4d18826	Rơ Mah H’ An ne	12/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le Tung, Xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
29657be6-97e9-48b9-8db8-1ca9f913a90d	Nguyễn Thị Tố Nga	01/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Grôn,  xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
8e0cfc5a-ca84-4707-a106-5d5072f3e1dc	Hàn Thị Hồng Nguyên	15/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
f97fb41f-9a93-4c15-8e07-61d671543026	Dương Thị Như Nguyệt	14/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
3d9b3fe7-4e6e-4276-a6b6-8781dc793c39	Nguyễn Thị Quỳnh Như	11/06/2010	Nữ	Mường	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
63e7935e-dc82-4af4-92ff-df61d6f1099f	Ksor H' Za Ni	21/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, xã Ia Dơk tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
9fc7690a-7830-40b9-ad29-47bafa0a992f	Phạm Thị Oanh	18/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
8bf3d889-661b-451e-a11b-cbd923d19940	Mai Tiến Quân	19/04/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai,xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
853d66ef-983a-4ccf-80e5-78b64216fd45	Rơ Lan A Sở	05/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
e27e5e28-4294-4a27-9181-60f24dbd0324	Trần Văn Thái	25/08/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
5da545b8-d1ce-4858-a4cc-83674befdcc7	Hồ Thu Thảo	12/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
4dad7332-3fa9-497d-97e6-482d82a3df05	Rơ Lan H' Thiết	27/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Đo, xã Ia Dơk , tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
4dafaaf0-22e7-4faa-bf1f-e1f7876f48e4	Rơ Mah H' Thủy	26/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kắt, Xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
90dd398b-f9cc-4f89-99ed-c1c4b10a5aad	Trần Vũ Anh Thư	16/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
bf6653e0-501b-4265-aeec-5729218ceefc	Rơ Măh Thương	11/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
8432b299-a487-45b2-95c3-b66fad63798e	Đinh Thị Thùy Trang	24/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
43fd01d1-b10f-4016-990d-bb58417d6472	Hồ Thị Huyền Trang	26/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
318dca3c-8259-482f-9cb4-b2cc8b2d5fe8	Hồ Thị Ngọc Trang	20/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
b2f9572e-3605-4188-912c-9e6192fd2dda	Kpuih H' Trinh	26/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Đo, xã Ia Dơk, tỉnh Gia Laỉ	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
2f88c302-43cf-45a8-8098-44fc23829381	Rơ Mah H' Trinh	19/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
6e1fb9c7-34de-4500-881c-63843c9c7289	Nguyễn Ngọc Trung	21/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
91a4ced8-cd5b-444b-9271-282d886444ac	Hàn Quốc Tuấn	11/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ , xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
d965e923-f8a4-43d2-a786-c691581e2a97	Kpuih H' Yên	06/08/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
f17bc8be-23f7-4c2b-98d0-1580db060dfc	Trần Thị Bảo Yến	27/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
8ed4d399-55f4-41e1-8dee-753dc95e855b	Trương Thị Hồng Yến	27/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai	4dec191f-67f7-40e1-ae29-1f402c50c046	2026-05-12 09:22:24.602551+00
7cc09867-2f43-4917-b0f2-64f28f29b890	Lê Hồ Lan Anh	22/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - xã Iakrêl - Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
985cbe70-438c-44a2-9c65-97808ba6d8e0	Lê Thị Mai Anh	08/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl,tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
8777af17-331b-41cf-835f-6f46ad15d899	Lương Thị Hà Anh	25/12/2010	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
67b8e22c-a770-4b90-b099-8cbf5d914b18	Rơ Lan Anh	12/02/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè- IaDơk,Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
60083740-918e-45f0-8c81-669620adf508	Rơ Lan H' Bích	20/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le, Xã Ia Dơk, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
8dbb3bbd-ea0f-42a4-bcce-d4984fb9bf79	Nguyễn Hoàng Hân Di	22/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7,Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
196ec54e-e569-494b-81d6-8ace3f87ff4b	Đàm Thị Thanh Hà	04/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
c61872de-8502-46f5-ab87-2f892a1d95ea	Lê Minh Hoàng	18/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
8f6162ea-dd4a-4ce6-a2f5-57e9b0e1531b	Nguyễn Việt Hoàng	18/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
af5e3c70-d409-4c27-9c72-827cbb7e155d	Nguyễn Thị Hồng	21/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
a72be406-ada7-4fb7-a529-02865535844b	Hồ Viết Tường Huy	18/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaMang, xã IaDơk, tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
7f0ab335-8f4d-4386-9410-6099a74179e9	Hoàng Thị Thanh Thanh Huyền	24/03/2010	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Đức Cơ, tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
ec3b3af3-edfe-49de-9e55-02c0eda87e0e	Rơ Châm H' Huyền	19/03/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang, Ia Dơk, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
21b23535-b5ed-4678-93e9-b4035c4345f2	Hoàng Thị Cúc Hương	08/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
a52a65e3-f3c5-4273-a076-fabf4ddbdedc	Lê Đình Khánh	30/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
6a8a339d-7bda-4477-a895-9b460a64c1a1	Nguyễn Duy Khánh	06/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl, IaKrêl, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
4e649c6f-dc4b-47eb-ad88-8b1046d13678	Ksor H' Khuê	10/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krol, xã Ia Krêl, tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
be6f5cea-25af-4542-8f03-3597ceb2387d	Nguyễn Văn Quốc Kiệt	10/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
d889be37-24a4-4ab5-bbd7-7136066d6eb2	Bùi Thị Mỹ Linh	05/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
f51085d9-101e-48d1-9386-b8d2f18d85a2	Rơ Mah Thị Thanh Mai	14/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, Xã Ia Dơk , Tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
1086fb01-358f-4db3-93f2-0cb25ce325a5	Rơ Châm H' Mẫn	20/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong, IaDơk, GIa Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
2aaae138-a851-4f85-86b3-614133092228	Nguyễn Hoài Diễm My	24/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Đức Cơ , Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
f1713204-3fca-4d0a-ba83-468f6fa0b130	Nguyễn Phan Trà My	06/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố , Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
c4bf6e9d-d24e-4f0e-8b79-1ac7bd034731	Nguyễn Thị Thanh Ngân	31/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngole, xã Ia Krêl, Tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
387db265-531c-435c-89c4-de16fb0469ca	Hà Như Ngọc	12/01/2010	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đội 8, xã Ia Púch,tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
55b95b00-2ad7-4e55-b121-fb15fc474e1f	Nguyễn Thị Thanh Ngọc	28/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân, IaKrêl, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
331fba06-bc0a-4478-927d-97af148cd181	Kpuih H' Nhanh	24/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk - Đức Cơ - Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
a9a99e7b-db82-47c2-8f8e-0b782d617078	Nguyễn Ngọc Bảo Như	11/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
83a312df-0c37-4917-ae7b-9ce31769b53a	Đinh Nhương	26/11/2010	Nữ	Ba na	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, xã Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
be6143d7-cd70-44fd-b440-640d72881d84	Nguyễn Thị Như Quỳnh	22/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iamang, IaDơk, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
22427eec-167a-40e1-b1ad-cd3ed5036989	Rơ Mah Y H’ RiLa	28/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung le - Ia Dơk- Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
ecb2ce3d-0355-47ba-a3c9-8f245bbb545d	Rơ Lan H’ Sương	20/12/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Le 2, Ia Dơk, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
e5492937-6d7d-40b1-ba6e-fa349b693fbc	Nguyễn Phùng Thành	18/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
57baa509-7a10-4ce7-8ed4-6a327352e2a9	Lục Phương Thảo	18/01/2010	Nữ	Sán Dìu	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Iadơk, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
8e92074d-01a5-49d8-bcd3-05b84337ddee	Đậu Thị Anh Thư	02/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm, Ia Krêl, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
6d999e8b-351a-4dac-ab28-31c44bacfd42	Lê Thị Anh Thư	28/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, Đức Cơ, tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
058b558e-3098-4148-8575-3edcc36137f5	Rơ Lan H' Thư	17/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
3a485438-28a0-484c-b363-eae908161c53	Trần Anh Thư	24/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Đức Cơ, tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
3658fa38-89a8-42e5-885f-95812eda0a05	Rơ Lan H' Thương	27/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung Le - Ia Dơk, GIa Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
bcf20fc4-a306-43c0-8da4-32bdf6b5fad1	Ksor Nguyễn Tráng	29/04/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Mới, Xã Ia Dơk , Tỉnh Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
0d011413-2cf5-498d-9e55-8ed25c6038a6	Rơ Châm Vũ Bảo Trang	17/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngo Le 1 - Ia Krêl - Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
7e4b5eaa-107f-49c4-9bff-94b460959955	Kpuih H' Trâm	22/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
f1fd34d9-bba9-418d-a1b9-967ec913d3e5	Hà Bùi Cẩm Tú	17/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, Xã Đức Cơ, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
16f86616-114a-47e2-9fc5-26b901dd037f	Vũ Hoàng Minh Tuấn	16/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim, Ia Dơk, Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
50c6bd91-2223-43bd-bd22-acc0ef4efaa3	Lê Thị Hạ Vy	11/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Hợp Nhất - Ia Hrung - Gia Lai	515ff95e-a824-473a-82ee-0aa2f9cd1bd4	2026-05-12 09:22:24.602551+00
d10bdfc9-6782-4b18-b5d9-d4dfd3b311ee	Ksor H’ Lê A	23/08/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le kắt, xã Ia Dớt , Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
9bbda695-6303-444b-9613-4611142be747	Đoàn Thị Ngọc An	05/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang, Ia Kla, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
3255096a-bc56-4b9e-953a-caebce5f1b7e	Bùi Gia Bảo	17/09/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
d638691c-3299-4c1d-9ea3-f2c7813485a3	Siu H' Xim Bi	13/03/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung kép , Xã Ia Dơk, Gia lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
5378f951-15be-4d04-a5cf-9376f872cbfe	Phạm Khánh Chi	19/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
1a07fe5b-4917-4134-9f95-869d7dee1a7e	Ksor H' Giang	23/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, Xã Đức Cơ, GIa lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
1474bf2a-e56b-418d-9b81-dc7a0a1a416e	Nguyễn Thị Trà Giang	13/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
85848f6c-d077-47df-85f9-1aad756a834b	Rơ Mah H’ Grinh	05/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung le - Ia kla - Đức Cơ-Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
07e6c463-42c6-415e-aa34-48fb9bb77c9d	Hàn Quốc Hải	13/02/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
99e2283a-cb93-4222-b309-521dd5ef15c3	Dương Bảo Hân	12/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
26c3029e-9bac-42cd-ba36-b70440504943	Nguyễn Phi Hậu	20/08/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
aea50791-4a88-441b-bdf5-27e40e891917	Trần Thị Ngọc Huyền	04/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
0ce2543e-f291-4033-98b7-bc42dd675a4b	Lê Thị Thu Hương	24/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl - xã Iakrêl - Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
2363ef1c-c1ce-46d1-82c0-0961a0ad8c36	Lê Hữu Khang	13/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
e47d9c6b-b5e3-41ea-b8fa-c3b92f108f71	Trần Văn Khánh	29/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
8e8abb1e-ba3d-4d61-bdd0-92903fa4e6a4	Mã Văn Kiệt	12/11/2010	Nam	Tày	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Grôn, xã Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
b3217c8e-ad84-4c4a-87e1-67ef893918c2	Kpuih H' Lin	02/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Ia Dơk, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
c84437f2-7feb-4e37-a26a-24da7827336c	Chu Thị Thanh Linh	07/12/2010	Nữ	Tày	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl, xã Ia Krêl, Tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
920f47cd-894e-4654-9015-bc12022958d3	Lê Thị Thùy Linh	04/03/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
e0bf5ac4-2158-4faf-b519-5c4b2cdcb527	Nguyễn Thị Thùy Linh	28/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
97540f25-983d-41e8-a627-db21879f480d	Trần Thị Khánh Ly	09/02/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ I, Ia Dơk, Gia lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
6082aaa2-7da4-4ad5-82e4-5e4058bf7aec	Lê Thị Trà My	21/09/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
84099f46-c99a-44c1-ac3d-591e9f5a4048	Nguyễn Minh Nguyệt	14/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
bd584a02-fe58-45ea-9399-18e3550c2768	Kpuih H' Nhuy	11/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
58b40148-cdec-44c4-911f-a3b25dbd821f	Siu En Ny	28/02/2010	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, xã Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
5c6de4c3-b569-43e9-ad28-aa49a6d0bfba	Rơ Mah H' Quỳnh	22/04/2010	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
254b6e63-4560-4b66-8583-69f17520d5a8	Kpuih Sữa	06/05/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, IaKriêng, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
1c833f4c-31df-4d2b-ac08-1170d1e639c5	Rơ Lan Lê Thành	16/08/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, xã Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
b71c993b-a00f-4b83-af53-25f28a0b0939	Bùi Thị Thảo	12/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 , Đức Cơ, Gia lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
bd3bfca7-5cbf-4410-9bcd-e37335fbd499	Hoàng Bá Thiên	21/06/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl- xã Krêl, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
70c8ec7a-78b1-4281-9be6-1b6d6d259fff	Dương Thị Thanh Thúy	29/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
a8e8c93e-e646-44c8-86af-6735087abb15	Trần Thị Thu Thủy	27/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim , xã Ia Dơk, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
7b66bd69-e557-423a-a102-249ac42a8c69	Nguyễn Lê Bảo Thư	26/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, xã Ia Dơk, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
ff17482d-aa30-4191-b2d9-12110d47a8bc	Nguyễn Ngọc Anh Thư	29/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
96a8f44b-4f5e-4206-a853-4e99e13c06ca	Kpuih Y Lan Tina	02/05/2010	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, Ia Dơk, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
26e05025-f1eb-41b0-9dd2-e97ec10c7885	Lê Viết Tình	24/01/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl, xã Ia Krêl, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
b2a37b1e-f54a-4b63-8a45-352699659b9b	Nguyễn Bảo Trân	04/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
8d0e4a4f-1fc6-4e39-96a1-b55e0898989d	Lê Đình Anh Tuấn	22/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, xã Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
06720488-3095-405e-bd6f-68ae5616ae26	Rơ Mah H' Ury	01/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung Kắt - Ia Dơk -Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
26182b05-306f-4e3e-8ec5-c8b9a208d95e	Lê Thị Phương Uyên	04/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
9d8da41a-711b-442b-83ae-2e1cc2cc3339	Đặng Thị Thảo Vy	14/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Triêl- Xã Ia Pnôn - Tỉnh Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
be226389-dd69-4d33-8f98-2e7c0aed8c0e	Rơ Châm Zaka	04/11/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, Đức Cơ, Gia Lai	3e472426-2282-4407-82c2-331bf418fc7f	2026-05-12 09:22:24.602551+00
1536f0af-e763-4ad1-80ab-6f096d5153d4	Vũ Ngọc Bảo Anh	09/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
88c0068f-1551-41e9-aebf-3db3e72c83c7	Nguyễn Sỹ Thế Bảo	17/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
5eb2d140-7d98-415b-a438-16521dca0444	Nguyễn Thị Diệu	22/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
87fbcc0c-2001-474c-99ae-0fa71c71474a	Rơ Mah H' Đa	15/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
32c5d1ce-915f-43ea-937b-7e1de224c6a2	Ksor H' Đuin	23/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
fab0dc2a-016d-4144-9fef-18e6a94154bd	Nguyễn Thị Thanh Hà	11/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
56fac642-7c00-4f2d-8db7-caab855635c4	Rơ Mah H' Hạ	18/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
4ccebfac-4fcf-45bd-87ce-ef87e42d6eac	Nguyễn Dương Thanh Hằng	24/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
2003c9d6-0653-4c43-aa5e-16bc496d5b73	Phan Thị Thu Hằng	17/05/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
416975ee-9880-4794-9307-c4d44714491b	Nguyễn Nữ Bảo Hân	15/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
3edfe857-4b54-4a3b-9ba8-89abddde7251	Nguyễn Đình Hiếu	09/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
0bfe2417-aa98-44ab-923c-5462064a4329	Trương Văn Hiếu	05/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
c6ad3dac-4421-42da-8fc9-79955ea4901c	Trần Đức Hoàng	08/06/2010	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
53d4d430-2fc5-4de5-8c26-6b41ed0615a3	Nguyễn Lê Thu Huyền	13/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
1c1fa600-f051-4ee0-a6a7-3017f8522a7b	Trần Ngọc Huyền	02/06/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
5c508455-22f4-4fcd-942e-c93e9c07e19f	Nguyễn Thị Hương	24/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
bcb25a5c-5345-40c6-85d2-856382c79b90	Rơ Mah H' Jin	26/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
e4e03c8d-2aa5-4290-9121-a01aeb4bc9a2	Nguyễn Nhật Kha	01/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
c40c4aac-14b3-408f-9c86-73db6a36fd89	Rơ Lan H' Khuyên	30/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
d7d11a32-81f0-4406-ab55-c927a71c28ba	Trần Doãn Kiên	20/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
415d5fee-8d16-41c8-bdc0-6714946c30fc	Ngô Thị Kim Luân	08/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
5992a189-e95a-4a3e-8da4-d30ea313cf98	Nguyễn Thị Ly Ly	12/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
2f1d3437-fa25-449c-9147-ea0c015777da	Lê Khánh Hằng	09/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
41d25d5e-72f1-4552-8c23-4be97247cb51	Phạm Gia Minh	23/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
bc950e23-45fb-4801-b314-19f0ca290fb1	Đoàn Văn Nam	22/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
47f96e7d-3989-45e7-8ce2-81fdcc8e1386	Trần Văn Bảo Nam	22/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
2801581c-5c07-4db1-8cce-1675ad246ef9	Kpuih H' Ngon	17/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
615fc402-16f7-4565-9143-de9e1412fac9	Đỗ Bảo Nhi	13/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
5dfa19b1-1f22-4302-80fa-03242f227fc1	Ksor Hà Nhi	01/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
38522085-017f-4aa3-954d-439d022f596c	Vũ Thị Tuyết Như	07/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
20ff87c2-a279-4cb8-9232-bb2e3c976fb5	Lường Thị Kiều Oanh	03/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
a7bb5ce6-d483-4f6a-976a-abb4d25b99f0	Rơ Lan H’ Rubin	08/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
cac464c7-ac3b-4607-8f41-48b36de2ef7d	Kpuih Sái	11/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
6ea92cbb-718d-406d-b4b7-855fa4675aa6	Kpuih H' Sen	28/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
95482c20-929d-45f2-a527-b6385cb9e08b	Rơ Lan H' Siu	13/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
a1f93475-2874-49cb-ad9a-1e87886bde1d	Rơ Mah H’ Sôri	12/06/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
43704178-1782-4079-b01e-18e50f9105b3	Đặng Phương Thảo	30/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
9cea3254-5ab6-4309-8cf4-f0d6ff113d53	Phan Thị Phương Thảo	21/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
2c061d43-98bf-4917-9c0b-58d9da215980	Hồ Hữu Thắng	16/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
d7797cef-7dc9-492e-8a30-27e30490c797	Kpuih Thuy	02/09/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
e86f618c-8cac-46cd-b809-777dda95f4d6	Rơ Mah Phạm Thị Thương	21/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
b8d327f2-74f5-4ab1-aa81-ae3bcf74b56d	Nguyễn Duy Tiến	25/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
5a745555-8823-45cc-bb06-b53cb5cdf5b2	Đặng Thị Huyền Trang	17/04/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
4c1ee37d-777f-4205-a551-7bbec9153483	Mai Giang Tuyết	11/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
c85932fe-f832-4a08-a2a1-dc55e03ab95e	Kpuih H' Uyên	29/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
1add4a5b-1059-4f71-bb57-46ddca25de20	Nguyễn Thị Hải Yến	24/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	0752aefe-02d6-410a-84a7-40260303f0a3	2026-05-12 09:22:24.602551+00
3b111d2d-d83a-4e3f-9745-95f42c66fd33	Rơ Lan Kim A	04/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép -Xã Iadơk- Tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
ac983687-6bbb-4c95-b3c4-972ded15efb7	Dương Bình An	02/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ dân phố 7, xã Đức Cơ, Tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
75f6573b-e115-44b5-8136-f5824c8117a5	Lê Hoàng Anh	21/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
0f1c690a-89b9-4e00-9afb-37c285de8e74	Lê Khả Tuấn Anh	26/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
f67aee46-487b-4f54-85e0-2ed3012c40b5	Lương Thị Ngọc Ánh	09/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
47c568f9-ac8a-41cb-a1cc-4d985eed5c3c	Nguyễn Xuân Anh	21/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
070b2283-87b0-421d-a1f5-d4075c72a5d2	Rơ Lan Anh	04/04/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, Ia Kiêng, Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
1c6a0f73-d928-496a-9d8a-0220c9b4525c	Mai Thị Anh Đào	14/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
5bf9d24a-d6bf-48d0-aaf2-8f16bef49d57	Kpuih Hải	04/02/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, Iakriêng, Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
a8336f7e-da51-45b3-8a82-191e518a8c97	Đinh Thị Hằng	26/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
1d2530cc-93a2-4e5d-ba57-3217606d49d3	Ksor Hân	19/01/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krol, Xã IaKrêl, Đức Cơ, GIa lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
4f015b52-98d6-42a5-8980-92dcc1998bbf	Võ Hữu Hoàng	28/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
d414b036-8ffb-457f-ab16-661c1f70d3e5	Phan Lê Quốc Huy	03/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
2259ae5b-47a6-4007-95c3-390a46a405af	Rơ Lan Khiếp	02/04/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông xã Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
10665337-9d6b-4c17-9d97-5dde9fa3c424	Khuất Anh Khoa	05/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
eb2598ab-70d4-429d-b3b6-eb5ea9df126c	Nguyễn Trọng Khoa	07/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
e70bc683-913d-4224-811a-cdd8042099bc	Bùi Hữu Kiên	19/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
4038283d-17bc-46a6-b00b-edf0cc563000	Nguyễn Tuấn Kiệt	07/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
199f1fcd-da1d-4ed1-95fa-736524b62cc9	Đặng Hồ Phương Linh	30/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
48a448b0-b8a8-43b2-a53d-37bca775140e	Nguyễn Thành Long	07/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
0fe670a9-ff69-4709-9493-9750a600e5e6	Trần Thị Ngọc Mai	10/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
bdc72c80-38e0-4398-9624-9a04d05a2ccd	Trần Văn Mạnh	10/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
9b7bd640-2bff-46ea-90d7-db4560681fc7	PHẠM TRỌNG BẢO NAM	11/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đội 15, Xã IA Púch, huyện Chư Prông	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
42429f58-c7c3-4735-b070-86cbdd3efaad	Rơ Lan H’ Nasi	10/10/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le - Xã Ia Kla - Đức Cơ - Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
45fa500c-fed9-4c6a-a5d7-d14e590f1ae1	Rơ Mah H' Ngiêt	17/03/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Ia krêl, Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
b74bc9cc-adde-42c5-96e7-b2f088b5c374	Kpuih Nguyên	19/01/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Trolđeng, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
4955ba8b-8cc9-4c1e-9501-d865f60c6432	Hồ Trọng Nhật	18/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
e3c240dd-3871-40ab-8792-dc8628b0c8cd	Mai Võ Yến Nhi	23/08/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
d4147eef-a05f-4649-aad0-01143090a32f	Nguyễn Đình Phong	15/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
c05e96ad-1353-4f6c-bfba-8e7269c6d91e	Lương Hữu Phương	13/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iatang, Ia Dơk tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
7e3009b4-a593-4ef3-bd5e-227f32eabac6	Trần Anh Quân	21/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
cd8119ee-3465-43fc-a5ce-d442b5289490	Rơ Mah H' Sarina	25/05/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung le -Iakla- Đức cơ - Tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
94295cc6-1a66-485e-a5be-d20e90e0205b	Hà Ngọc Thành	13/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
b29f0f3f-aed4-4563-b916-4f0b39f42a5c	Nguyễn Thị Thảo	04/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
2ce05468-64a3-44ff-af8e-f24ee01f4b30	Vũ Thu Thảo	28/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
2158b45a-2cd0-494a-a246-8e7d4b90012b	Bùi Sỹ Thắng	05/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
91e2ecdc-6843-4ede-8c30-9f3fc666e160	Rơ Lan H' Thư	10/12/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
2e7b9807-bf0c-42f4-b909-a4df3381520d	Đào Nguyễn Lâm Tiên	29/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
18c4f0dc-715a-45bf-a859-40ae7857a04e	Nguyễn Song Toàn	07/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
cee78827-251e-40cc-9a9a-876c48bb894c	Võ Thị Kiều Trinh	25/11/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
2567f776-57ed-47ff-84cd-7670a229df01	Lê Trần Anh Trung	20/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk , Tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
f254ed1d-3de5-402e-9059-442400c3c1e2	Nguyễn Thị Cẩm Tú	03/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
a4f75a93-ed31-4434-999d-78d1bc443c2e	Phan Đình Tùng	21/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Chư Ty, Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
29dc6ea5-d562-406f-aa56-f09f551b2aad	Kpuih Lan Văn	24/12/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, IaKriêng, Đức Cơ, Gia Lai	8eddec37-5c16-40a8-83af-5c94fd6ac02e	2026-05-12 09:22:24.602551+00
0c36fc85-1599-4fb4-8f1d-193bb1e1699c	Nguyễn Hồng An	20/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ I, IaKLa, Đức Cơ, Gia lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
a6a9770a-1354-483e-a654-646d8afaaeb1	Siu H' Beo	19/02/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, Iakriêng, Đức Cơ	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
9d256af4-baaa-450a-b0cb-06056e99ccbe	Nguyễn Đinh Ngọc Duy	26/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Păng tul - Ia Dơk - Đức Cơ Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
d8fe6116-a0f5-46df-a83b-1c1d603dfcf0	Đoàn Hà Giang	16/11/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
eb0053ef-43e9-4de1-aad9-5fbec388d037	Nguyễn Thị Thu Hiền	06/01/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
5e6ebc83-a542-407e-86b5-e259388c6b40	Cầm Trung Hiệp	14/11/2010	Nam	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
b5fe8793-1947-4948-86ca-1ed21bd2b1e7	Nguyễn Khánh Hoà	08/10/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, xã Ia Krêl, huyện Đức cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
395e9faa-1a50-4b90-aed4-1b6ac56c2498	Trần Bá Hoàng	09/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
a8633dc0-7854-42bf-a8cc-1a3ef95310f9	Rơ Lan H' Hường	27/04/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Tung, xã IaKla, huyện Đức Cơ, Tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
3677ab88-0463-4a43-98b0-740bad01bd16	Võ Trần Gia Khánh	31/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
35ab5e85-aefe-4197-99ee-b4e21f306951	Nguyễn Vũ Tuấn Kiểm	01/06/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
db4f7afd-5793-4716-8a62-2912a934840b	Kpuih Kiệt	26/02/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Grôn, IaKriêng, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
57852f28-4f88-4d0d-bda3-170731befe6b	Rơ Mah Kiệt	09/12/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
068f776e-a9e9-4967-98fe-f35cc175c08c	Hà Thanh Lâm	25/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
ddc3798c-bff4-4dbf-993d-1bedc822c640	Vi Thị Phương Linh	17/11/2010	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaTang - IaKla - Đức Cơ - Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
0b98c2fc-a90e-4d74-9a23-bb345ec408e9	Phạm Sỹ Hoàng Long	08/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
f1f6a8ea-56d9-41e5-8c2d-5e549f422d32	Rơ Châm Thảo My	10/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
4978e671-65dc-4b92-a421-84f7834aefa5	Lê Bảo Nam	10/01/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Iadơk, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
4a2787f6-415e-4735-b243-12a03afa21d0	Phạm Quang Nam	01/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
fa449d71-a5d5-45e8-9a48-41846467bc1a	Nguyễn Hoàng Bảo Ngọc	17/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
2c54cca6-8785-484f-aa4a-b1555d522887	Nguyễn Thị Bích Ngọc	09/08/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã Ia Kla, Huyện Đức Cơ, Tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
a4513f16-0ad6-4a09-8237-dc9b17c7b7f0	Phạm Thị Như Ngọc	09/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
c573f950-dad2-4c94-9a14-d747c2509bcd	Hồ Thanh Nguyên	15/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
aea7c787-9db9-4b21-ac10-98e66ec1b54d	Rơ Mah H' Niê	27/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, Xã Ia Dơk , Huyện Đức Cơ , Tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
e591d917-989a-45b1-ba2c-6e429e85c322	Nguyễn Thị Diễm Phương	09/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 5,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
73d40895-9be0-46ea-b62c-040b096e7858	Ngô Trí Quân	13/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Kom Ngó, Ia Chía, Ia Grai, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
82168ae3-33ea-4ad4-8d4b-ab8960628c64	Trần Đức Quân	19/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	\N	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
c08aca49-d8b9-4735-a7cd-1f1cdc504580	Kpuih H' Quế	28/11/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Trol Đeng, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
d0a20bd2-8cab-400a-b896-205093f794ac	Lê Đình Tài	23/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 1 Chư Ty , Đức Cơ , Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
ca6bb420-d339-44b6-8d35-86a284046e31	Nguyễn Thị Hồng Thắm	08/07/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã ia chía, Huyện Ia grai,Tỉnh gia lai.	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
5fdbda45-d9b0-4d91-b58e-90b0ca2ec1a9	Nguyễn Xuân Thắng	06/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
2e6a1156-31ef-4747-9453-e6431cda7761	Nguyễn Hiền Thu	10/05/2010	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
9c7dcedf-2b1d-480e-9a4d-8dbd8120a55a	Hồ Thị Ngọc Trâm	11/12/2010	Nữ	Kinh	\N	t	\N	07/09/2025	0343400608	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
e26bf423-9a2a-4349-b1ca-2dbb1b99ed25	Lương Quốc Trọng	16/11/2010	Nam	Tày	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, IaKriêng, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
797bc0ce-61ae-497b-8516-d1c5bec84f33	Kpuih Trực	15/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung Tung - Ia kla - Đức Cơ -Gia La	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
557d2ff8-3f63-4751-a33c-12f8f50854c8	Hoàng Anh Tú	07/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaMang -Iakla - Đức Cơ Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
d60dfcfe-786a-4f73-8adf-864efb816e45	Lê Văn Tuấn Tú	19/03/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iakăm, xã Ia Krêl, huyện Đức Cơ, tỉnh Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
bcf0a304-2093-4e66-a245-1301c2e16242	Rơ Mah H' Viên	02/06/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong, Ia Dơk, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
a4a470e0-a2fc-4583-9177-a28629793fe1	Phan Quốc Vương	03/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
c25c9381-6352-4f5f-a97a-b1574eb9f1a4	Rơ Mah Xâm	28/09/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung kép 1 - Iakla -Đức cơ -Gia Lai	bf3de950-ced7-4bb1-b8a2-4433a53e4e29	2026-05-12 09:22:24.602551+00
41f4803d-f123-4c82-9383-7233f1430912	Hồ Thị Nguyệt Ánh	30/10/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
27b6423a-3108-4375-881b-d733c5df44ac	Lê Thị Mai Anh	19/12/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
b604c599-5328-417c-bd51-baddf4c31632	Rơ Lan H' Bạch	14/07/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
1c09e056-1e28-49f6-a1a6-1ad12db92f98	Cao Trần Gia Bảo	21/09/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
b742a60b-fe83-4245-b72d-94e9a9c76b9a	Hà Phạm Gia Bảo	28/10/2010	Nam	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
348f8c38-25c4-4502-848f-deb17ca11ecb	Rơ Mah H' Chúc	28/01/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
af65c9b0-71bb-48cf-906b-b09679669e8a	Nhữ Thị Kim Dung	27/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
be8004c9-f10d-4c3f-ac16-0e68c2f3be6e	Kpuih H' Dương	18/08/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
4f83935a-0206-4f0d-9d0f-57a9ea5d2803	Rơ Lan Điệp	14/06/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
f0e8f1c1-ba09-4b7c-9084-db3d20967677	Ksor Đinh Đức	24/08/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 8, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
6f1707e3-33d4-403b-be78-06f54444ce16	Nguyễn Thị Khánh Hà	09/02/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
78fc2a12-0373-4f51-9f89-61ec61ec7030	Nguyễn Diệp Hân	13/03/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
8d30e858-2636-4b9d-bec9-f97d1b4951c5	Hồ Thị Như Hoa	21/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
e2adcb75-7505-49a5-b02a-0c3ea4760eb3	Hồ Huy Hoàng	30/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
4fb5921d-3647-4b89-a3d0-c4de6d1b17d4	Lương Hoàng Huy	18/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
26718dc3-70e5-4450-a21c-1af508bbe152	Nguyễn Hữu Huy	06/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
456ec1cc-2462-4fe7-8d8a-c20959e52adf	Lê Thị Lưu Huyền	28/06/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
f58ed678-68eb-40ed-ad93-4e5967fb07ae	Rơ Lan Khàng	02/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
1afbedbc-99fc-40b1-8598-280546995dcc	Rơ Lan A Khiển	07/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
df85cbd5-b104-429e-806f-398639ee884d	Kpuih Khruin	20/11/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
0976930f-3beb-409b-9102-b8198aa93466	Cao Thục Khuê	14/07/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
6c73205f-229a-46e5-a302-531ca861789a	Hoàng Tùng Lâm	12/11/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
233586a8-001a-47a1-aa1b-48a195792c58	Phạm Nguyễn Nhật Linh	30/01/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
5cfcc85c-7657-4682-bf71-7b09c05f479d	Siu Phương Linh	31/12/2010	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
55b011a1-28a4-41c6-a431-4c24afd07265	Nguyễn Hoàng Minh	11/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
b1985f85-618b-450b-ac2d-b3d3caa1e45c	Trần Nhật Minh	29/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
ab6b1654-9248-423f-8f3b-dbe7b03547a2	Nguyễn Văn Bảo Nam	24/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
d9ffad51-04a1-40a8-a55d-5b49283aa9e0	Rơ Mah Nguyên	17/12/2010	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, xã Ia Dơk, tỉnh Gia lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
377bdee2-d646-4b88-ab6f-2f88e76274c5	Võ Phước Nguyên	20/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
173b3b8b-6640-4791-ad36-c63250586058	Ngô Quang Nhật	09/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
163ebbcf-2889-4f02-b06d-22097c876558	Hồ Hữu Minh Phong	05/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
f33934a5-ff5a-4f5b-9912-6392431cbfd3	Hoàng Minh Quân	18/10/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
498a0221-658b-46e6-91b6-2dd0c6822426	Lê Thế Quý	02/12/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
7b699630-9444-414d-bf28-6a697cd61c98	Hồ Viết Sỹ	01/02/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
5f39931b-4695-4814-8a7d-4e2b51644f80	Bùi Sinh Thái	01/08/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn 9, Xã Chư Prông, Tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
d3b464a6-2511-472f-be95-c1001e653b55	Mai Thị Thắm	11/09/2010	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
89460439-42b7-4c55-afa2-b168d9331a45	Kpă Tiếu	08/05/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
d662ce66-3de3-4243-9d97-7343228fc9d1	Nguyễn Vĩnh Triều	12/04/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
3bc679c6-a310-45d1-b1ea-0b692216d75b	Hồ Sỹ Tuấn	06/07/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
951f7269-8d28-4f0e-9847-c3e44f9e71bb	Tống Minh Tùng	20/05/2010	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	7ba87a2c-261e-454b-8c9d-bb35fd06eed7	2026-05-12 09:22:24.602551+00
b322d678-a34b-4b10-831d-53664da8e6f5	Hồ Thị Lan Anh	29/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP6- Đức Cơ- Gia Lai.	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
3ca49bfa-bc78-4d01-adba-9d4f594f1b07	Nguyễn Mai Công Anh	22/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2- Ia Dơk- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
42cfd728-de7f-4a19-bd65-cf5484bb9a18	Nguyễn Thị Hoài Ân	20/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
d472a23b-3050-4df6-aca8-0db285e7e860	Nguyễn Đình Gia Bảo	08/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ialâm - Iakrêl - Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
6d2fabed-dfb0-4320-9fe5-2aacea41f20b	Phạm Ngọc Chính	14/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung kép - Ia Dơk- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
6a6520c9-e3f6-41ec-81e2-5ee3aaf46be4	Phan Minh Cường	24/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
a3e066a3-4b09-4d9f-aa01-94bb111670a1	Đào Tuấn Duy	29/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
645616af-1f01-44b1-a71d-cf6c65210436	Nguyễn Nhật Duy	08/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
9b80ebc9-7891-4163-a902-a59c205ebfbb	Bùi Thị Thùy Duyên	01/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP6-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
ecb2aafa-aaf4-4b6d-8c10-65d668eb8dbd	Nguyễn Tấn Đạt	26/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP4-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
70ff6eaf-0f04-4474-ba2c-f672cff3190e	Nguyễn Hải Đăng	29/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
c858e9bb-6a52-4cb3-b0a4-adbc97d9f08a	Vũ Minh Đức	02/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung kép - Ia Dơk- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
4472acc6-98cc-4645-8af7-06c79bb1974d	Nguyễn Thu Hà	23/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
8a52684f-1e2e-48ab-ab5e-8bbd4316d658	Diêu Gia Hân	01/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP9-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
0bc89b03-d1e8-4e09-b196-ba6d692feb75	Nguyễn Thanh Hiền	05/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
d8cf2f0d-cd7e-485f-8887-21fe89102c2d	Lê Phạm Công Hiếu	08/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
edeb5516-574a-4c44-97b0-1a1b46e94e5d	Lê Thị Ánh Hồng	08/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
811f9739-6a59-4ee7-b736-b01cfe66428a	Lê Quang Khải	25/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 6, Đức Cơ, Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
fe8bb37a-4cdc-4001-9fd3-5fcb7bc22a65	Nguyễn Đức Nhật Khánh	09/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP6- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
5961ebcc-3c9c-4dbf-a8e2-ed8a9118f974	Nguyễn Phạm Phương Linh	02/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
50ed6d0c-b53e-4daf-8f4a-4ed284d52d17	Bùi Văn Lộc	27/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm - Ia Krêl  - Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
a38040af-9504-4273-a868-1b834773f0b5	Văn Tiến Mạnh	12/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
d77f65db-ba56-410b-a1cc-c19424887851	Đào Quang Minh	19/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
9f35f3bc-9848-4018-8eec-a3f1cf82648a	Phạm Thanh Bảo Ngọc	11/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP6-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
36433711-b08c-4aa1-9513-cd8242f4e9c6	Phan Bảo Ngọc	21/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang- Ia Dơk- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
53e35a9f-802b-449f-9795-57b575d8ce07	Trần Bảo Ngọc	11/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
48eed849-6063-40e8-8398-e73b860e6d46	Phan Trần Gia Nhi	02/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Giáo- Ia Krêl- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
624d3b03-06c8-4a15-adba-4952a0992e3f	Bùi Nữ Vy Oanh	16/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP4-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
91b6b3f4-e796-4aac-9fa2-9b6852300626	Nguyễn Tấn Phát	29/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP6- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
027ac83e-f89a-442a-88ea-f344389b3134	Lê Minh Phương	05/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP7- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
142e90d6-961f-44da-b1c2-809269337a6b	Nguyễn Ngọc Nhã Phương	28/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Chư Bồ 1- Ia Dơk- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
49a5cfe8-3828-48ce-bb7d-4e45f789a05a	Cao Nhữ Hoàng Quân	13/09/2009	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp -  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
716c80be-269b-4ab7-9cdd-6dee7b94601d	Hoàng Thủy Tần	16/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP7-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
46932a19-0553-41cf-b5f5-b709bc823a18	Cù Lê Gia Thanh	04/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Lâm- Ia Krêl- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
3c2f3e6b-b433-4bd0-9ea5-b244a4c26cc2	Lê Thị Ngọc Thư	06/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol- Ia Dơk - Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
3720af6b-9ef7-48eb-a278-ce1cb84e18b9	Nguyễn Thị Minh Thư	17/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP6-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
bd2272bb-76d5-4bc0-a45f-9ded18fe485d	Đặng Đình Tiến	17/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua- Ia Pnôn- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
c1e869aa-2550-4e27-985b-347bb869deef	Nguyễn Huỳnh Yến Trang	06/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP3-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
e1bfcaf2-75c0-4a92-9eb8-3033c3afdc1d	Nguyễn Hoàng Bảo Trâm	03/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
aa17c818-23ba-4315-bf24-d03e5f622fba	Võ Hồ Yến Vi	25/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP1-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
c33ff6e5-9f3b-4594-9aec-059661e41535	Châu Ngọc Như Ý	18/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2- Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
0079a635-7163-4f5e-bbde-55ce2e825a27	Nguyễn Ngọc Như Ý	28/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
b4409e0b-38e2-43b4-aca2-576dadc8793b	Phan Thị Yến	20/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP2-  Đức Cơ- Gia Lai	29ad20ee-673d-4c83-8589-7bb0dee8d6d1	2026-05-12 09:22:24.602551+00
d1367a6c-f49d-4b86-8698-7c95c6561a9c	Lương Kim Anh	18/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
b5efe70a-ea83-4c50-9138-69db5e87e8a0	Nguyễn Hồ Quỳnh Anh	14/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 7 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
a8b7e2e6-0d53-4b7b-b1b9-ee49b10e8967	Nguyễn Thị Ngọc Anh	05/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
5e454678-f987-45a1-b035-f5e09a9dda5d	Bùi Công Gia Bảo	21/09/2009	Nam	Kinh	\N	f	\N	19/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
265b6698-4f14-4ecc-b692-b7aa660d0645	Mai Nguyễn Quốc Cường	08/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lâm Tốc, Iakrêl, Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
4eb22862-b80a-46fb-8f44-0e4334110274	Hồ Ngọc Diễn	17/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 7 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
b31ce48c-f7ae-4d37-b038-451afff068eb	Hồ Nghĩa Dũng	12/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 9 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
4cda2098-5a25-42c9-bccd-7b05206405a6	Nguyễn Thị Hồng Duyên	21/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
d50f66a9-45b3-481f-8be5-2f959d80928c	Nguyễn Quang Dương	24/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Ia Dơk- Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
9dd88cff-9120-49a8-989c-92c7393355cd	Nguyễn Việt Đức	27/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
ad38f989-c718-4896-80e7-f5c84305b99c	Lê Thị Việt Hà	22/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
5c433a3b-1e79-40f5-aed6-cbd247856d04	Nguyễn Hoàng Thu Hiền	22/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 1 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
c520a0ae-52ca-4dce-b0f4-15cc196af851	Hoàng Văn Hiếu	13/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
e86b0e0a-9ae9-4203-9050-9c9fbc5726e7	Phan Nguyên Khang	08/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 3 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
7ba23bdc-5661-476b-88d5-2bbaec9119c5	Phạm Đình Khánh	02/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 2 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
85530ec1-72ed-421a-bdb0-17c998e88731	Trần Thiên Khánh	16/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 9 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
868fb449-ef70-4e20-8834-a945186b3327	Nguyễn Anh Kỳ	28/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - xã Ia Dơk - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
be204408-7175-4e7b-9487-eeeae2381368	Phan Ngọc Lâm	03/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 1 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
e1682b4b-fece-4edf-94b6-d3cb00729c24	Thủy Ngọc Lĩnh	14/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
22258954-41f8-4e65-8fb0-b912b507a2f8	Phan Minh Bảo Long	07/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	681 Quang Trung - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
1bbb14a3-1ab0-4a10-b604-d09276734dab	Trần Lê Xuân Mai	25/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
6448da15-4984-4b92-88f4-5d62619b6efa	Hoàng Văn Nam	17/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
fa7a5323-28b0-4530-b057-cbacaaadd6fe	Hồ Minh Nguyệt	29/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
0ab59b3b-e16d-433b-a3e1-c7e89a1b11e7	Phan Thanh Nhân	15/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 1 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
595b0bcc-2ff9-4f9a-af55-ad3060e8816a	Nguyễn Thị Yến Nhi	27/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 7 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
b0885701-9093-48d0-9074-fd3ef0a35d14	Nguyễn Yến Nhi	03/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
b2810ca3-be58-47c1-9d4a-b7c674128569	Ngô Thị Tuyết Nhung	06/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
3a642a96-917b-4f6c-a1c4-07361b966eef	Trần Gia Như	03/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 4 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
3cf5dcb7-d417-4dc8-b237-adcd2cbc87c9	Nguyễn Thị Kim Oanh	15/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - xã Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
56bca380-9d16-4308-aff3-9ed6ce673a56	Trần Gia Phát	26/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 1 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
de377ea6-1401-4eb5-aa2b-9816a3071edf	Nguyễn Thị Diễm Quỳnh	21/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Ia Dơk - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
ff354f7c-aa72-41e0-8a46-e7b46d774757	Nguyễn Xuân Sang	30/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
95bd9eaf-7b3e-4f3a-b4f2-9bade4f94177	Lê Ngọc Thái	05/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 7 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
49f77a14-8498-4cf1-be8a-54b54e0a706c	Bùi Thị Anh Thơ	23/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
16c4f9b5-da68-4b47-8f05-0c7b95bc56b6	Trịnh Tâm Thư	11/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 6 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
e62a2722-9677-44cb-bf9f-6b07b1651c54	Vũ Thị Thùy Trang	09/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - xã Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
496abf0e-c31f-4d29-8fa4-908ddbd7d149	Võ Hoài Bảo Trâm	01/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 1 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
7e3ae6b3-09c5-45eb-b245-0e696724011b	Nguyễn Phan Bảo Trân	25/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân  - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
917a0ecb-d43f-4086-bcdb-e385859ed600	Nguyễn Phạm Đức Trí	04/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Ia Dơk - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
537d2b67-2dc1-4fe1-986a-d262754b8128	Lê Hồng Trúc	11/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Ia Dơk - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
12308b0a-a293-4289-b3c7-4797b4a57ac5	Lữ Thành Tú	30/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - xã Ia Krêl - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
c3e62d48-81bc-40c8-956f-da50a985682e	Lê Anh Tuấn	27/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 4 - Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
f5aef1ae-7146-4aae-8bf2-29098fa483fd	Trần Nguyên Tuấn	14/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - xã Đức Cơ - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
07dc2728-75cb-408c-81dd-588e26019a20	Cao Đăng Quang Tùng	06/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết  -Xã Ia Dơk- Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
9cc22d19-db46-4b57-b97c-649420b20de7	Vũ Sơn Tùng	10/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Klăh - xã Ia Dơk - Gia Lai	1868a20c-490f-4db2-bc22-d85f4f69b497	2026-05-12 09:22:24.602551+00
c792fb6f-cdfc-4d71-8423-e96c5ba02004	Đàm Quỳnh Anh	01/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
dce4ba53-2d94-4f6a-98db-980b61fc64bb	Phạm Minh Anh	17/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2 - Xã Đức Cơ-Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
1651a7d4-6ff3-4860-a79a-15bc98469d2e	Trần Gia Bảo	13/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
9bb504d7-40c8-47aa-98c1-61494178bf83	Hồ Ngọc Bích	02/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
fcdc90b9-da93-4648-ad26-9ee9f556798a	Lê Nguyễn Giáng Châu	11/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
1b4787da-1cfa-4180-8eaa-4a527693852d	Nguyễn Đình Dũng	15/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Iakrêl, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
87d3e9d0-1ec4-42f7-88a6-2d8ff49ce0f7	Lê Đình Đại	30/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, Xã Đức Cơ, GiaLai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
122f3026-442f-4711-a002-ef61f1eb207e	Trần Trịnh Nhất Gia	15/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 -  Xã Đức Cơ - Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
d685863b-a57e-4b60-83d3-eb0831cee18b	Nguyễn Hoàng Bảo Hân	25/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
1bf24490-4daa-4d94-87e4-3ce2ae1706fa	Siu Đỗ Tuấn Hùng	03/09/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Trol Đen, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
d54d8b26-e2f5-4747-98e1-1c1ac0dd1358	Nguyễn Văn Huy	09/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh giáo -  Xã Ia Krêl  -  Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
e3aea581-0f26-468a-b937-8465a341e122	Nguyễn Thanh Huyền	30/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
71cd0728-9cad-4712-a537-87fd57195adf	Nguyễn Thị Lan Hương	19/03/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng gron -  Xã Đức Cơ - Tỉnh gia lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
eec59353-592e-4be8-bb42-40ca4bb5ee40	Nguyễn Thế Khang	03/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
c326d026-f202-4986-812b-2f4adf8625d5	Trần Anh Khoa	05/01/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dấn phố 7, Chư Ty, Đức Cơ,Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
ea2789e4-b39d-452e-98ca-0a55cdb33f99	Đồng Gia Khôi	02/04/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
717e9f9c-6e94-48d1-8d93-5a77be43140f	Nguyễn Trần Thùy Linh	21/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4- Xã Đức Cơ- Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
d7d3af22-9326-4857-a1d2-ca2e54219185	Nguyễn Quang Long	02/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Xã Đức Cơ- Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
3883499c-ab8b-4f2b-8f27-96201b5e2248	Trương Gia Long	24/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, Xã Ia Dơk, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
818f202b-6519-4114-88ef-75859b2a6a0e	Nguyễn Thị Mai Ly	25/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, Xã Ia Dơk, Tỉnh gia lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
cfa14e2e-6c50-4a0c-8d50-f039a06b416d	Cầm Thị Quỳnh Mai	30/08/2009	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
6efbd8f2-34c1-471a-af1c-425d47a48228	Đỗ Thị Ngọc Mai	05/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dấn phố 1 - Xã Đức Cơ -  Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
3261f2df-b03d-48f2-84d1-c5c9752f3a66	Phan Trần Yến Minh	14/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Kpă Klong, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
ef671265-b940-47f0-8d97-55b3d2b1d3ea	Huỳnh Nguyễn Trà My	20/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mút - Ia Dom - Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
10d137f2-47eb-4805-83a0-9ac2d47865a3	Hoàng Lê Ngọc Nam	26/05/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
cb48f903-1fe2-4011-806e-d7fd9b245e32	Lê Thị Hồng Ngọc	17/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP7, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
8a38bb11-e6b6-46a5-a510-00c61d2a3f2d	Nguyễn Công Ngọc	21/06/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn ia Mang, Xã Ia Dơk ,Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
df321690-cf05-477f-8456-ca52afc5c575	Trịnh Thị Bích Ngọc	19/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ia Mút, Xã IaDom,  Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
341f0bf4-c879-4e5e-a14b-1e66443d6d6d	Bùi Thị Yến Nhi	02/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp2, Xã Đức Cơ, Tỉnh Gia Lai.	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
cea15ab3-d0e7-4adf-845f-4b1cc92c0775	Nguyễn Thị Quỳnh Nhi	04/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang- Xã Đức Cơ - Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
c0d14ab7-8ad3-45d4-ad23-50d3657192f5	Trần Gia Như	05/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP2 , Xã Đức Cơ, Tỉnh gia lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
d3e1c2a0-0ced-4057-8952-3db16cc083dd	Hoàng Thị Kim Oanh	21/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp7, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
e19ed776-1831-4873-8ab8-7b65350aced0	Huỳnh Văn Phúc	14/02/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh giáo-Xã Ia Krêl-Huyện Đức Cơ Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
882bba96-7f33-44a6-865c-2470b313fae1	Hồ Thanh Tâm	01/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
0184c6e3-8d54-42d9-977d-3a17c2024d1f	Nguyễn Nhật Tân	24/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
4e04c8ab-f7d8-4bf3-8f33-a33babe64745	Hoàng Thị Kim Thoa	16/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4- Xã Đức Cơ- Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
8967649c-577f-4ea2-a0b8-c3c57ae204c5	Hồ Thị Anh Thơ	11/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP2- Xã  Đức Cơ-Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
793fe79b-01d3-4336-8590-00e6f74a11a4	Nguyễn Thị Ái Thuận	24/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP1- Xã Đức Cơ-Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
3ac379cf-ab50-4454-ba48-747e287ca2b0	Phạm Hoàng Anh Thư	22/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
5cf3ddfd-b6de-4a22-a868-5e78b9d65d45	Vũ Đức Tiến	22/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
885d5924-7bc2-493e-abed-75473ac0188f	Bùi Ngọc Tĩnh	19/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
01697a70-ec5d-47b4-afae-1b5df811d7db	Vũ Thùy Trang	15/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
3357c216-2945-4ba9-8b4b-8dee9ab6afb9	Thiều Thanh Trúc	16/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
8a1a3ac2-0250-4fe8-a6d0-9517ab5345a2	Lê Hoàng Tuấn	20/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ I, Xã Ia Dơk, Tỉnh Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
dd305fb9-bd15-4562-9eaf-ba023f583fef	Nguyễn Trí Vĩ	23/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đường Quang Trung, TDP 2, Xã Đức Cơ, Gia Lai	3ab3bcb4-3575-43c6-95ae-73f824b28ef3	2026-05-12 09:22:24.602551+00
160decc6-f5ee-4fc4-b98a-a633d22be782	Cù Hoàng Gia An	03/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
cab311f9-802b-496d-bc79-c1405346f515	Đào Lê Minh Anh	20/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
343d693d-c94f-4de1-83ed-46c99c56d1e3	Nguyễn Khắc Việt Anh	02/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
d1dc6e5a-c4fa-4d70-9ef9-3796f63faf71	Phạm Đình Ánh	15/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
8c4a5eb1-e42b-4458-ab6d-0f366a50a0c6	Huỳnh Ngọc Bảo	02/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
01791ae0-f19b-4a7f-9341-63af4149d0f4	Hoàng Hoài Băng	26/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk - Xã Ia Krêl - Tỉnh Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
b336bfe7-b732-4c3c-a5e3-09cdc5d6d3d1	Hoàng Gia Bình	15/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
3b1455cb-8677-4386-ac3c-13bef0767711	Nguyễn Trọng Bình	19/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - xã Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
52e51c8f-fd14-4812-a31d-df8a1ac78331	Phạm Hồng Diễm	25/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
d0aea946-dcd3-4c8c-9878-a21d13cfed20	Lê Anh Dũng	24/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
fb8e53c2-28a4-4836-8675-a160a83fd097	Nguyễn Anh Dũng	04/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
381bec6f-5a5e-41d6-b68c-5cc3ae4cf287	Vũ Hải Hà	20/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
22ceafdb-2577-4b4a-a162-ec57d8263f6a	Phạm Nguyễn Bảo Hân	24/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
124eb075-1e2a-46c5-af16-c4e2cf642f92	Nguyễn Trung Hiếu	15/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 -Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
b5215e83-616d-48bf-aa51-cb6bfa4f5fd8	Nguyễn Hoàng	01/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Grôn - Ia Kriêng - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
3f4d182b-27f8-4748-9c6d-422864c52666	Nguyễn Hồ Khải Hoàng	29/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
19d76731-0b4a-4cfa-974c-5aeafb0f860a	Võ Văn Huân	18/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
3d4fea63-3b8e-4764-b9f6-4d671a0bbf7d	Lương Phi Long	06/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tôk - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
628f4dfc-bfb5-4d94-9b6b-f52f7568af52	Mai Xuân Long	20/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
992e2942-c6c5-4323-9796-ad2e02e1ec15	Vũ Tiến Long	25/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
f52d71d1-09a5-406f-8467-3717dc759cc0	Nguyễn Tấn Lợi	10/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
2ad20ab1-2314-45c3-9dc6-21c95efedd67	Lê Phương Thảo My	02/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
79b6b0b6-66f9-4124-902a-0d3eda30a698	Hà Nhật Nam	06/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
b3e9a3f2-7e0d-48b2-80b1-64353005f073	Lê Thị Bảo Ngọc	29/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Sung Le Tung - Ia Dơk -  Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
b6877ad0-3e5e-49a4-9679-b1e2ed50f005	Nguyễn Thị Bảo Ngọc	22/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Chư Bồ 1- Ia Dơk - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
53ca7b47-cb9b-43bb-82bf-c59e0d9360c6	Hồ Bảo Yến Nhi	28/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
56af5b28-e542-4da7-8f60-5c3b7250ccbb	Nông Lê Yến Nhi	26/08/2009	Nữ	Tày	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
845412fe-e3bb-4a6f-919f-fe5d41cc6e78	Trương Nguyễn Quỳnh Như	18/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
e1040787-9056-453d-9fa4-6182c28c6e11	Nguyễn Văn Phúc	05/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Lâm - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
8f9962c4-78d7-487b-b7ff-f7cf09ca71a4	Phạm Văn Quân	06/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
1f58ae7f-ee03-4b34-998c-6b412846382a	Rơ Lan Ai Quyết	13/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
0e68991a-e5bc-4394-a251-27455991903e	Hoàng Thị Thanh Sáng	20/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 -  Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
8d883102-9186-47e5-913d-e15fdd48d78a	Nguyễn Khánh Sương	19/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Lâm - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
d1e9746a-cab6-4776-a9f4-4d05161f36cc	Lê Phú Thành	04/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Lâm - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
3a198517-6f0a-4ced-842d-4b8bd20fadcd	Hồ Thị Anh Thư	24/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
f9a1215d-55e7-48dc-a20e-77de04659b99	Nguyễn Thị Thương	17/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang - Ia Dơk- Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
78de2c44-2a3b-41d4-a798-a6645a9c3671	Hồ Vĩnh Tiến	09/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Ia Dơk - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
69ab5b68-077d-4d28-887a-d366de23d06f	Nguyễn Thị Thùy Trang	10/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1- Ia Dơk - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
80354fdb-8611-48db-a35c-955ca3cd595b	Trần Thị Thùy Trâm	13/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
24c8c27c-4256-4f52-8aba-9e3cc01a9f81	Trà Minh Trí	27/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Giáo - Ia Krêl - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
62b0ea88-c3d5-407f-9ab8-9b8949926956	Nguyễn Thị Diệu Trinh	13/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
1ee4955c-9865-44cc-844a-d9a882522d70	Trương Phương Trinh	16/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - xã Ia Dơk - Gia Lai\r\n	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
c317acbc-4fbb-40e2-8a47-b7028c39627c	Trương Vũ Cẩm Tú	25/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
e37091b0-0fb5-407b-92b2-109ae41d8f2b	Lê Thị Hồng Tuyết	14/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
0db2b7b6-6be0-47ec-8969-28087d963cce	Nguyễn Ngọc Như Ý	13/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Đức Cơ - Gia Lai	b810e758-01b0-43f5-aa70-8a9088efa2fd	2026-05-12 09:22:24.602551+00
0e0f13e5-6e20-456e-837f-322e2148ccae	Đào Duy Anh	18/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 1, xã Đức Cơ, Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
43419abb-7c06-47be-b95a-bc53b1d88118	Hà Vĩnh Hoàng Anh	02/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 4, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
ea86bccf-6267-43cb-bba1-d964fbfec5a3	Hồ Quỳnh Anh	27/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
702333ee-3b7d-4009-b953-b521c1f244e1	Phạm Nguyễn Việt Anh	27/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 6, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
824e7f62-4eb7-4904-b244-403416f4a72b	Lê Thị Thanh Bình	01/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
2a6be401-e398-4b95-a46d-94b09b4c4625	Phạm Thị Kim Chi	27/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
455b3c8f-b899-4901-a082-a979e189151f	Nguyễn Thành Công	16/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
e4103a19-cc74-4991-a8d8-072dec11df8e	Giang Hải Đăng	30/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
05f1d0b0-3489-479f-90ef-812db2217b9d	Nguyễn Hữu Đức	12/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
d153fa2e-abe1-4c02-a8d5-b50add58d716	Võ Hương Giang	11/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
8648f0c7-be7c-41ac-8209-e73cda71443b	Nguyễn Thanh Hà	11/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
295a5e22-404c-492d-a997-cab4d461b0a1	Nguyễn Văn Hào	22/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
ca7173c4-419c-43b3-b2d8-79ad8e88a042	Nguyễn Thị Minh Hoàng	08/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
1e7efdb6-546f-4f03-8a18-6237ee8b0d0e	Lường Quốc Huy	23/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
3b65ad82-ea40-489b-a65d-09587d9d6c21	Phan Tấn Huy	18/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Nuk, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
fd818198-4e94-40aa-beed-56a18198b369	Hồ Hoàng Hưởng	11/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
1f9b2e3c-9e47-41ef-b499-bd9c0952e012	Nguyễn Hoàng Gia Khánh	10/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 7, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
c1c36e1c-e5d2-485d-95ff-d4a89216fc66	Phạm Thùy Linh	20/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang , xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
e487bc5b-979a-4b95-84e4-30c4b660c957	Tăng Văn Hải Long	01/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
27788458-b4f2-4def-83ad-df4a2fe80829	Lê Bùi Xuân Mai	04/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
07ee2533-3a03-4d6e-9f2d-214155c703fd	Nguyễn Lê Quỳnh Mai	14/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
0de87972-ba89-4132-9ea4-35ba59f9e0ab	Phạm Sao Mai	22/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 8, phường Hội Phú, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
b82533ed-3c42-445c-ac38-85a7bc792669	Nguyễn Lê Mạnh	14/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã Ia Dơk , tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
ad74df83-3ff7-4d10-bdf4-a2a9fee0fe4e	Bùi Phan Bảo Ngọc	18/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
e7fda187-a8bf-4c52-9f83-4f1c648ec8ea	Đinh Thị Bảo Ngọc	19/07/2009	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang ,Ia Dok ,Đức Cơ,Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
032ed47d-3357-46e5-b2d2-63dd7c20b9bd	Bùi Văn Hoàng Nguyên	23/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
4268f67f-7427-44f3-bb4f-c09c94535ce8	Nguyễn Lê Yến Nhi	23/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
46cecf71-759b-42e5-b5c1-406b822deac2	Lê Thị Thu Phương	29/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
86bf248f-daa4-4094-a918-a6af06bd384e	Nguyễn Thị Linh Phương	31/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
ea631d20-7679-443a-afb6-dbe779b7aff5	Bùi Minh Quân	27/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Chư Ty, Đức Cơ, Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
3e62fd90-206f-4043-b6f8-4291b5c14d93	Khiếu Thị Như Quỳnh	30/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
1f31bef6-3e43-40a0-9d73-a8b3cb50bf4c	Hồ Vĩnh Duy Tài	17/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 1, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
2ab9514c-2ecb-4a66-a056-cc1124ab4451	Nguyễn Xuân Thành	11/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
976afb59-5063-4d94-a232-04025fe673bc	Đặng Anh Thư	16/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
57c4e438-0f2f-437d-8ea4-abe4085b39f4	Phạm Anh Thư	20/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
e369a7b7-f30c-4602-9137-3dab48d3407a	Dương Thị Thùy Trang	14/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
459bf3ea-a2a4-4371-a841-d3c9e256f5b1	Trần Minh Trí	17/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
90c9c4be-0c74-4282-9dae-71f38c9fbba5	Nguyễn Hữu Trung	20/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
e4322ce8-9220-431e-b5d2-f7ddac7240a3	Trần Xuân Tú	26/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
2b256d49-9479-4de7-8ed4-3d295c4e720b	Phan Trọng Tuấn	25/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
544a7395-0e1d-4f97-8db2-d22947a15310	Trịnh Đình Tuấn	01/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Ia Krêl, Gia Lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
a22aa873-1845-4014-84b2-ddc987bada94	Lã Thị Tố Uyên	11/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia lai	f603988f-cb60-4443-940a-d3c0116c784c	2026-05-12 09:22:24.602551+00
adf3ca9d-9987-464a-910d-71919a9de1b6	Đinh Đức Anh	09/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
bd669fd4-a037-4e97-9446-1c85f45ace13	Đỗ Hạ Nguyên Anh	17/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP6, Xã Đức Cơ, tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
51e60f8b-cf0e-4534-99c5-cfa78bb501fb	Đỗ Đình Bảo	26/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
abff38df-150a-4dc1-8b4b-9f9e9b440b35	Rơ Lan H' Sa Bét	27/11/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
111017b9-1757-4364-a5aa-b91eaded1c2f	Khuất Duy Công	16/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 , Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
0918a358-9534-49ec-9848-7a80b365c1fe	Nguyễn Công Dân	03/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
edfed9ce-bb62-4b12-9c7e-9adba9225190	Vũ Thị Duyên	30/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp 4, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
3b04f218-290c-4f60-94e9-eaa4f481742e	Ksor Dứ	10/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
3ae6a702-e611-494f-9009-2b11431068bb	Cao Chấn Đông	13/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Grôn, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
28f2de89-2cc8-4ffc-8699-56078be50cb2	Hồ Thị Ngọc Hà	23/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP2, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
d30ece2c-45fd-4098-b83f-2ae8af425475	Đinh Thị Thuý Hiền	13/07/2009	Nữ	Tày	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP9, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
a5343b1a-c626-4bc7-aa6a-6976e93358e5	Nguyễn Thị Thanh Hoài	06/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
919ee2e8-7978-4daf-a8c3-f32df7c19d2c	Nguyễn Thị Thu Hoài	14/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7, Xã Đức Cơ ,Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
0fc692b9-4422-43eb-b747-7ac51ecbd220	Rơ Lan H' Hoài	31/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
b3c867bd-edfe-4f23-98e1-4b6714344fa1	Nguyễn Minh Hoàng	17/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
e467c825-1576-4085-9b72-464645021596	Phan Công Hoàng	01/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
66cd70ea-56d3-48cb-9368-7bddff31d935	Phan Ngọc Khánh Huyền	02/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
4ccebb03-98b7-4d19-9a64-aa28b981a986	Trần Khánh Huyền	12/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 , Xã Đức Cơ , Tĩnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
9c2d3d43-35d3-4f94-8189-4c4de2b8d586	RMah H' Jin	31/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
0dd5d5a4-6787-41d3-9827-d0480d96b198	Nguyễn Đăng Khoa	10/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
1d4b662d-7bf6-4346-8d60-9a694f1490be	Kpuih Khuyên	07/10/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
bfd97138-b59a-4cef-aab6-7e17d6499942	Đào Quách Hạ Lan	01/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang , Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
48f3fa73-ea9d-4d41-af35-25fac6b7d904	Vũ Đỗ Thùy Lâm	12/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
65e32c86-d313-4873-a321-ece05f173f06	Rơ Mah Liêm	09/06/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
337536a5-d35e-401f-a60f-20006a4cdc08	Đặng Thị Hà Linh	17/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Triêl, Xã Ia Pnôn, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
4a0acf2c-77b4-493c-9289-8c1fb96ec855	Nguyễn Thị Ngọc Linh	25/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
608e57b6-c85b-4fa2-a6ac-276dc4fdf27e	Đinh Mai Loan	13/03/2009	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl, Xã Iakrêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
42906d89-d532-4af0-926d-d50c90e0ec22	Trần Văn Long	14/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
eb3cc030-cb9e-44f3-94df-1a6261a06507	Phạm Gia Bảo Lộc	28/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
e1811b70-7c5e-4548-b641-d8dd2cad63ab	Nguyễn Thị Lượng	01/10/2007	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
8006b4fd-e78e-457b-847f-b414041f599a	Phan Thị Thúy Ly	17/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
aa760c89-d88a-45d6-a4cc-034178e2d002	Phan Đình Minh	06/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP6, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
4ecd46ec-6c82-418e-8b66-e292831b2f6b	Ksor H' Mlan	03/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
b89cbf03-fa7b-4919-b5bf-3d5c0fe7ceae	Đỗ Thị Hải My	22/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
f56ad239-4c67-4339-b97a-a8e6fd6910fa	Lưu Thị Thảo Nguyên	24/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP7 , Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
b4284b35-9572-47ea-b49e-0945ec4cd7dd	Hồ Thị Nguyệt	29/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ , Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
05d54bc5-68da-470e-ad40-3a269b592f83	Nguyễn Thị Gia Nhi	05/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân , Xã Iakrêl , Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
5491a758-bc47-487d-8c3b-bb56b6c23f2d	Nguyễn Thị Quỳnh Nhi	20/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
a1c198aa-06c7-415a-b1a1-65be3bf13247	Trần Linh Nhi	22/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
4b194e53-d84a-4e95-8bea-79217a5396f9	Nguyễn Tài Phát	23/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
764d9ee3-4c2b-4d6e-8737-06e4c720c275	Trần Trung Quân	10/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
897b23f9-47a3-44e4-b838-7c2342e031dc	Rơ Lan H' Rêny	03/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
252df8b5-5f59-4d7a-8d3b-14d612fe1906	Siu Run	12/04/2007	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
58c7cfdf-b226-44ac-a490-88308e06e553	Rơ Lan H' Tâm	21/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
25490c10-d106-439b-926d-9813b605d0a5	Trịnh Thủy Tiên	14/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
c4f59d00-ebaf-4671-bde1-00efd8fe30ba	Lê Ngọc Bảo Trâm	28/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, xã Ia Dơk, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
2d81f286-1077-4f35-8dd6-1d70484c63b2	Hồ Thị Mai Trinh	17/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
0e1d22d6-d357-4c36-9aec-ccb1829a24fd	Hoàng Nguyễn Thành Trung	01/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Iakrêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
ca258ced-928f-4b36-a888-95311ecc39d7	Ngô Thảo Vy	15/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ngo Le 2, Xã Ia Krêl, Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
f0957a0e-fb48-405c-abd6-b885dba7255e	Rơ Mah H' Xari	03/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, Xã Ia Dơk , Tỉnh Gia Lai	49482452-f8a6-4345-a1e6-0506a641cd2f	2026-05-12 09:22:24.602551+00
db3818fa-6b72-455b-9013-58203987ca58	Đỗ Nguyễn Thiên Ái	12/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Chư bồ 1- Ia Dơk- Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
068704dd-a4bf-47f6-a4d9-a10af95b5e3a	Nguyễn Thị Vân Anh	27/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krel- Iakrêl- Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
77d590bf-6a18-4073-82c3-74a6399845cc	Lê Trần Gia Bảo	01/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Phường Pleiku, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
0ebd3c7e-3e6e-41cd-8da7-663a83c09a8f	Phan Khanh Hoà Bình	25/11/2009	Nam	Kinh	\N	t	\N	18/09/2024	0328348334	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Chư bồ 1, Ia Dơk, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
f8982620-c3e2-4e57-b838-2a037b8baa91	Võ Đặng Ngọc Châm	15/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 9, Đức Cơ, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
1b6d2e57-a49f-42c3-890c-b306875da3b6	Rơ Mah H' Dulen	12/02/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt, Ia Dơk , Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
7d38d546-613d-4d9f-88c2-161fbec304af	Ksor Dũng	23/02/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung le kép,Ia Dơk , Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
20a97f06-3335-4bbf-b72b-861b8dff9139	Nguyễn Quang Dũng	25/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Iakrêl, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
7e598c43-914f-4175-9e64-62e1439a5b98	Nguyễn Hữu Duy	21/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang,Ia Dơk, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
154f5188-80ba-416e-8cda-c897e47c7dd2	Nguyễn Thị Mỹ Duyên	10/11/2009	Nữ	Kinh	\N	f	\N	-	0868220435	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 9, Chư Ty, Đức Cơ, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
98c2750c-6a30-4795-96e2-fb5e0c969998	Hồ Hữu Đại	15/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã Đức Cơ - Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
9dac3cc5-c78f-47c9-9452-f1f49c72da80	Nguyễn Phùng Đạt	30/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
882939cf-4528-4c8a-b565-d2cb1ce35b69	Nguyễn Thị Thanh Hằng	29/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Đức Cơ, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
b5c1f927-c058-45ad-b2be-a9cacfda31e2	Rơ Mah Hân	26/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang Pong, Xã Iadơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
164174da-42a4-4683-bee1-f06b89075b33	Nguyễn Xuân Hiệp	20/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Kom Ngó, Xã Iachia, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
e827a767-0a0f-4e89-983f-2ccf2276bae3	Hoàng Thị Hợp	28/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
0ddb9e53-0585-4e75-b428-a56ef57043ed	Nguyễn Quang Huy	08/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaTang - Xã Ia Dơk - Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
915c4f8a-4644-4124-8501-1d24ce651f2c	Mai Nguyễn Tuấn Hưng	29/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, Xã  Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
8e8f86ca-9b43-4345-9641-426cc345beda	Nguyễn Hồng Lai	17/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
ce4cc531-7925-4a55-9105-0d6ac457833c	Đỗ Hà Lan	28/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krel, Xã Đức Cơ, Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
3a14d14c-9646-4d90-9e39-816045752b75	Rơ Mah H' Lang	06/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang Hrang, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
d5981b06-bf93-4059-8137-3ab35f61333d	Đoàn Thị Mỹ Lệ	13/09/2009	Nữ	Kinh	\N	t	\N	20/11/2023	0387058713	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
df637113-08d1-433a-b3e6-0c9b4b2ef68b	Siu H' Li-ya	04/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
d9c5a7a1-ee6a-4edf-b656-7bd460ab253f	Hoàng Ngọc Bảo Long	06/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iatang, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
499646c8-0756-4620-aecf-99db7d10212e	Hứa Thị Lưu Luyến	18/10/2009	Nữ	Nùng	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
5a7da352-2241-4083-9a5f-fdc7f4801e39	Rơ Lan H' Lyna	03/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
aeca1c38-a866-42e0-b934-515a67c0ef2f	Lê Nguyễn Trà My	16/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
879b7598-765e-44fc-91dc-dc3f131b864a	Hồ Thị Nguyên	03/07/2009	Nữ	Kinh	\N	t	\N	06/05/2024	0369569267	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
bef5f5b5-06b8-446b-acb3-f7facb501187	Ngô Thị Thảo Nguyên	19/08/2009	Nữ	Kinh	\N	f	\N	-	0358280046	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krel, Xã Ia krêl, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
20a4299d-0b23-4bd0-82ef-adbeb9742d7a	Hồ Tuyết Nhi	21/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 3, Xã Đức Cơ, Tinh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
7e5832b9-7fb3-4184-bd03-f9e14ae8d673	Thiều Hoàng Yến Nhi	07/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 3, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
016fcda7-33cd-47f5-88ec-fe63156cc764	Hồ Thị Nhung	01/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
9f73e465-c6c3-4cff-ba25-c74382e3d301	Đinh Thị Quỳnh Như	16/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
12d810a4-a567-435c-87c4-e123eb50623e	Cù Ngọc Sáng	29/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
ef87745e-4f73-4961-8b83-8223c2a24f02	Rơ Mah H' Sơrka	02/02/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
a2da68e9-ee37-4d93-a55b-5bfe157f67d7	Đinh Đức Thắng	29/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Lang Krol, Xã Ia krêl, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
a4e1ce0f-0735-47d3-addc-c61259111a57	Nguyễn Ngọc Thông	01/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn chư bồ 2, xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
e8047ea7-af12-4fa6-a0c1-548bd215531a	Văn Võ Anh Thơ	02/07/2009	Nữ	Kinh	\N	t	\N	19/01/2026	03354213	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
2bb5c1c9-8b3f-4933-bad8-d774f62be774	Rơ Lan H' Thư	29/03/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
1bdfbaf2-709a-49e8-b910-f549452576c7	Nguyễn Vũ Trúc Thy	01/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
2fa0f8a5-21ee-4072-815c-86aae3da9bd9	Nguyễn Như Tình	01/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
efdeca8f-4598-4d73-b3e2-d25bed5f9abe	Trịnh Ngọc Khánh Trang	31/05/2009	Nữ	Kinh	\N	t	\N	18/09/2024	0345181657	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
d1225c80-1588-4aeb-abfe-acabca9e5ddc	Hoàng Anh Tuấn	18/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
5b25eaf4-e79d-41a0-a567-bda6f5dff239	Mai Thị Ánh Tuyết	06/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
20951c02-d002-47b1-8272-03f5e05fbd89	Nguyễn Thị Kim Tuyết	17/06/2009	Nữ	Kinh	\N	f	\N	-	0349738669	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Đo, Xã Iadơk, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
31241b2c-5b38-48c7-9906-3382865892e7	Nguyễn Khắc Tường	22/05/2009	Nam	Kinh	\N	t	\N	21/10/2024	0344580369	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn 2, Xã Phú Riềng, Tỉnh Đồng Nai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
d13b311b-48e1-4f31-bd4f-3e3e15d90ae4	Ksor H' Vệ	07/08/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, Xã Iakrêl, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
b2b58368-0d56-40c8-8402-9fa082c55247	Ksor Kỳ Vọng	22/07/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le tung, Xã Ia Dơk,  Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
18376e81-bf4e-4eaa-a98d-9d9278f70907	Ksor Long Vũ	22/07/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung, Xã Ia Dơk,  Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
84ac01c6-7ead-449f-9635-a090caeb953d	Hoàng Thị Hải Yến	27/09/2006	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
f1449187-e44c-42d0-b01f-d74bd058701e	Phạm Ngô Hoàng Yến	06/07/2009	Nữ	Kinh	\N	t	\N	21/04/2024	0344307611	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 6, Xã Đức Cơ, Tỉnh Gia Lai	0372fedc-3ce9-4484-823e-d7587838ca34	2026-05-12 09:22:24.602551+00
4171ecda-0051-46b1-9bbb-d2b27aa6f5bf	Lương Thị Linh An	24/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
9c954f32-88b7-4459-b060-32b110873cb3	Rơ Mah H' Bạch	20/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
a6f20d15-d8b1-405f-9707-780f9d4f0d56	Trịnh Thị Hồng Bích	26/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm - xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
231b7606-c253-4158-95d5-e4f7d754ac74	Phạm Đức Bin	04/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
10a082ed-6e06-43e3-9968-b3cb42055be0	Rơ Mah H' Chi	11/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
4dc6e812-a823-44a4-acde-062dd01c9f63	Trần Thị Khánh Chi	08/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
7de4b697-fa6c-4550-8859-5af7a0e4f2bc	Nguyễn Công Danh	28/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
fdc577ff-600e-41f9-87e3-9204ede5bbb3	Lương Thị Mỹ Duyên	17/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iatang, Ia Kla, Đức Cơ, Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
88fbab06-fa76-4f96-bd95-af27a4297af9	Phan Trần Thành Đạt	27/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
85f964e9-72be-4001-aba2-f968c3fb3a21	Rơ Mah Điềm	20/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Lớn - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
5f454cd3-c6e4-4825-8940-8941611469a4	Rơ Mah H'phương	23/01/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
82ce1046-56ba-4e7b-a55c-d13114cda495	Trần Thị Mỹ Hạ	29/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
ced05ed5-677b-454a-979c-289aad217eed	Hà Gia Hân	16/01/2009	Nam	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Grôn - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
6d49b398-fb8d-456c-9f74-1c1f5c682ca6	Lê Minh Hiệp	20/02/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
1719aae9-326f-4aed-87af-cba2f5c32cdd	Rơ Mah H' Hiệp	14/06/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
28f062af-57d7-466e-9f6e-f6e53d3c7b7f	Nguyễn Trung Hiếu	01/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
fe641a3f-da32-4cca-9ecb-3cc60901dd6a	Hồ Thị Thu Hoài	16/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
a407d82b-046e-4ee3-ab1b-6fea8e709374	Nguyễn Ngọc Hưng	10/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
12bf8d27-b2c9-433a-8ac4-772d7a3fe4f8	Nguyễn Thị Mai Lan	16/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Trol Đeng - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
22e9679c-ec3e-4e96-9d29-8b5d8dab9db4	Rơ Lan Lâm	26/08/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
485bbdff-46b7-47b6-b019-334416927dc9	Đặng Thùy Linh	25/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
a5376caa-7a79-4700-90cb-5257550db68e	Đinh Thị Thùy Linh	21/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
fad5c17b-9bea-4170-a6bc-cd6ad7b226c2	Ksor Mai Linh	28/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
c1581581-3c9d-467f-9796-c4eb485b411c	Nguyễn Đức Mạnh	10/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
51957864-1b5e-4991-8bfa-7a6f0c6486ae	Ksor Net	08/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
4f21b133-fcb7-4f51-bdbb-9dede77bad88	Rơ Mah H' Ngâm	18/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
64cc3a36-c184-40ae-bbec-7dae9084b028	Lê Diễm Quỳnh Ngân	31/07/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
11d5eac1-7bed-40d2-91db-d8ff16ef146c	Phạm Thảo Nguyên	11/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
516aa41a-2bae-4cc3-a387-6c4262afb79a	Hồ Diên Nhật	24/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
7b3fd63d-abed-4997-b5f4-83034cbcc4df	Vũ Quang Nhật	27/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ II - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
124eb6ce-ef79-41c0-96ba-37efc9181ab1	Nguyễn Hoài Bảo Như	31/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
405f0c82-a9f1-4fd2-a743-1cec7d87954f	Rơ Châm H' Plil	19/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
37b39c53-fbca-44eb-94b4-624c513c62d3	R Mah H' Yu Ri	10/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
22bdf7bf-c012-4756-8fbd-66356986d9bf	Nguyễn Thị Mỹ Tâm	07/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
3466fe42-5990-49c6-8a59-dd07f7802128	Phạm Thị Bích Thuận	11/02/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
df60ea81-d81c-4611-bc41-02187bee27b8	Trương Thị Hoài Thương	05/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
5cee3bd2-9e4c-408e-8300-dcd1dd51903f	Lê Đoàn Thị Thủy Tiên	30/01/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
aff783d7-b70b-428d-ae48-6a8ce5e97094	Lê Thị Thủy Tiên	30/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Chư Ty, Đức Cơ, Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
e8336450-4e77-4f97-b99c-4268f8ffc9ef	Đỗ Thị Huyền Trang	31/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ I - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
f4e8d6d4-402c-432f-af9c-a25a866d461f	Kpuih Trí	17/09/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
77a37200-3a57-4f93-a8c1-e11fa10d7f0a	Mai Trung Tuyển	10/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
baeaf9a5-abc9-45b5-9816-829428513c7f	Trần Tố Uyên	28/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
a13c76da-7e1f-4058-94ce-0a0c5b9d4590	Hồ Thị Thanh Vân	07/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
0bda491c-2572-4db3-88c1-d3c1641a6bb7	Nguyễn Thị Bích Vân	20/04/2009	Nữ	Thổ	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
dddbc2df-c68a-472f-b67e-78dd0a4abf3b	Lường Viết Việt	09/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
364d04de-57be-44de-871f-a19c5de36521	Lê Thảo Vy	10/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
dffb7d75-b041-4f89-95a9-ec2543a0a0ff	Bùi Thanh Xuân	14/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
b83d8ad5-bb6a-47ea-9504-d696f679c918	Rơ Mah H' Xuân	17/11/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai	473ec1ae-2792-4f8f-a2dd-f5803b44186a	2026-05-12 09:22:24.602551+00
d522b80c-06b3-496f-bab9-9df58bbfb520	Trần Lê Ngọc Anh	23/06/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
fea23173-d484-4115-8c83-1ace6fb03456	Trần Nguyễn Mai Anh	28/07/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
a180f736-9ec3-4788-804a-91f514202b49	Nguyễn Gia Ân	08/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Krêl - Tỉnh Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
a2220bf9-6563-4f34-98f7-199098779ef0	Rơ Mah H' Bdít	10/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong - Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
ea563867-418d-471d-8371-c96eb50908d1	Mai Văn Tuấn Đạt	14/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
c0800fde-822d-4018-bc6f-3b2b38c618fe	Trần Tiến Đạt	04/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
59e77189-12e7-4d5d-8682-b67dbebc6523	Rơ Lan Điệp	26/07/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Klăh - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
06c1dd12-0497-43ae-b2a1-294e7fb502e7	Lê Duy Đức	13/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
e96514d6-9a09-439a-82ba-244a542bfc84	Rơ Mah H' Hần	13/09/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
cbffd09b-07f6-4540-ba4b-479207830a5d	Mai Đức Hiếu	27/02/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
8d0f1451-3684-4a00-82c4-a824a484e421	Nguyễn Ngọc Hiếu	10/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
8bc760d6-7b95-47f2-8341-c997851d1d54	Bùi Mai Hoa	18/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl - Ia Krêl - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
c42e1cfb-45da-42e5-9dd0-c933905c4811	Ksor Hòa	04/01/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
cd02e001-9736-4b5c-abe0-4bba148ae499	Nguyễn Sỹ Hoàng	12/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Ia Krêl - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
c96b67bf-076b-4826-9e81-c765ff229bdb	Cầm Thị Hường	19/03/2009	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
2b320ded-0d8b-4de5-b871-5150fee6198b	R' Mah Hy-lia	14/02/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - Xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
13839ff8-8010-4a9c-b222-07f248f345e7	Hồ Thị Thúy Kiều	14/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP2 - Xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
240213aa-f9ef-4cfe-a400-4137f8552435	Trần Thị Ngọc Lan	30/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
dca420d7-f9ec-4e9c-b9d8-616756f3dc82	Rơ Mah H' Lệ	16/12/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ia Dơk Ngol - Xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
460d0238-a5cb-49a6-92c3-d32802a68480	Ngô Phạm Thùy Linh	24/07/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng TrolĐeng - xã Đức Cơ - tỉnh Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
6eede258-9f20-4c28-a0b8-8244338a6581	Ngô Thị Khánh Ly	14/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
9d098572-36e2-45bb-b349-fdd7d94ddbaf	Rơ Lan H' Lysa	01/12/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Kắt - Xã Ia Dơk - Gia lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
c3a83c1a-9f4a-40bf-9dc6-d6db7277fea8	Tăng Văn Mạnh	01/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Lâm - xã Ia Krêl - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
c36f91ab-f2b5-44e9-b85e-cf310f9edee3	Hoàng Yến My	04/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1 - Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
b5edd834-65a3-4442-b7e5-030ff772f4d2	Lê Thị Trà My	15/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
bb8f13f0-9672-4103-a534-3d0e07b4cb99	Nguyễn Lệ Trà My	13/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
049dec42-035a-4e03-9f21-f5d7e19ca167	Phan Thanh Trà My	16/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
f5434775-c29e-4a73-ad4f-9228e8c6fdab	Nguyễn Thị Thanh Ngân	17/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
a0bca5c2-3201-4a9b-af36-ecf458a39e75	Lê Quỳnh Như	25/03/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - xã Đức cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
1a1bf061-6b69-4f51-9a9b-53f39a7f29bd	Siu Quyết	30/07/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
e7b39ec2-5501-441e-9102-d5501bc49d38	Đỗ Thị Thanh Thảo	03/03/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
175ced7f-6819-402f-ac38-a2b0a6448f88	Lường Viết Thuận	23/08/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Lệ Kim - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
a545f3c9-0429-4c42-8b8f-a8f509172026	Nguyễn Anh Thư	18/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
e207f36a-f87a-4e56-9978-cd9643052548	Hoàng Ngọc Huyền Trang	28/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang - xã Iadok - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
b90b929d-4076-457d-b125-24070ecc9c98	Hoàng Thị Cao Trang	24/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
66a4375b-e355-4233-b939-8c0a34f489ca	Lương Thị Đoan Trang	13/01/2009	Nữ	Mường	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
b609ecd7-cdef-4f7d-8d44-aa154b709b98	Lưu Thị Thu Trang	02/01/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Dơk - tỉnh Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
459b8304-154c-47a7-829e-82effe6992f4	Nguyễn Thị Quỳnh Trang	19/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
d726059c-dd72-447a-af22-b70022137f8e	Lê Tây Hùng Trường	21/12/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
0809bd17-269d-4543-b4d4-d1b74b85ea5b	Trần Đình Tú	03/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
4952d689-e0d3-4f06-b753-1d50ffeab671	Phan Nguyễn Anh Tuấn	08/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
b49b4e54-2ff4-43b8-8802-06c3b0877362	Kpuih H' Tuyết	04/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
a4fc625d-81c5-43dc-aac4-2ab52b5459ea	Lê Bảo Uyên	21/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
c85722f2-fe6d-4abe-b0af-48a22b6b08e6	Rơ Mah H' Uyên	28/11/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Tung - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
661b83f4-9322-480d-a94d-9ce0b4b25de6	Rơ Mah Vũ	13/09/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung - xã Ia Dơk - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
1232e1aa-9e70-4ef9-9d60-49d3de01042d	Trần Thị Kiều Vy	22/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - xã Đức Cơ - Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
01ca37d7-fa07-4802-9c47-0247ab1056d5	Đặng Hải Yến	17/08/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - xã Đức Cơ - Tỉnh Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
087b8e3c-b308-4585-a9b2-9ba53d3dd18a	Nguyễn Thị Yến	22/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7- xã Đức Cơ - Tỉnh Gia Lai	70924dff-ae3f-4737-bc36-34503d81d2f0	2026-05-12 09:22:24.602551+00
9bf70b46-f0d5-437a-b5fb-8994c6d2e688	Nguyễn Vũ Hải Anh	09/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
46ae0281-a82c-491f-a3cc-d90722d8142f	Phạm Ngọc Khánh Băng	11/04/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
7d7474e1-5708-4f31-a5aa-f21b834ccc71	Lê Đình Dụng	17/03/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng ấp, xã Ia Kriêng, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
34405602-43e1-456d-83fa-6424068ac31a	Nguyễn Trương Đắc Đạt	04/08/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iamang, xã IaDơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
2c6cfdeb-2418-4aba-bcb9-b039517e2203	Bùi Lương Hải Đăng	08/12/2009	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ dân phố 3, Chư Ty, Đức CƠ, Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
92919e23-3492-4e64-b48e-45c315b5cd0f	Nguyễn Xuân Hà	22/01/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
991aa00e-6608-45ec-b274-abf3bd1d3c02	Rơ Châm H' Hà	12/09/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Ia Kiêng, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
68ea99a7-a08e-4a9b-8a3d-eae4ba87895e	Nguyễn Quang Huy	25/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
890bf806-af69-47a3-825b-e0c2d6f865cd	Vũ Quốc Huy	06/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
58e6ce36-0341-43a9-a081-5d91df667b71	Lê Thị Lan Hương	12/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
e5d93d55-0dd5-4d80-a840-66a1f9906aff	Đỗ Quang Hữu	05/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
c1ca240b-0b36-4ef3-adaf-38ebd76e7e25	Rơ Mah H' Hyưng	01/05/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
e7e5831f-dea5-4508-aeb5-7dd607943d21	Siu Châm Khang	11/09/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
705b1224-c77e-49c1-8b6b-a5874a51c212	Nguyễn Thị Mai Linh	15/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Iakrêl, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
a709f5da-3151-46d3-941a-61dc733751c5	Hoàng Nguyễn Bảo Long	10/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
9d11fb16-6882-4867-bf4c-1e0a8dc8da28	Phùng Chí Long	28/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
a4b579c6-3dfc-41d7-9197-5e4c2abd0c9f	Dương Hữu Lộc	16/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
0dd5586e-111d-4681-99e2-55b242a3c6a9	Rơ Mah Si Mô	30/11/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le , Ia Dơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
4a4267c5-d83d-4d24-bf7e-b50534839e21	Lê Thị Nga	10/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
466d7d49-2da8-4729-ab8f-683040ca70cd	Lê Thị Bích Ngọc	09/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
b80e2ae1-16a9-4d25-a95a-58629df55aaa	Nguyễn Ngọc Tiên Nhi	26/02/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốc, xã Ia Krêl, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
5372d49c-e34f-4707-8001-a9d0c0ad230f	Mai Hoàng Phi	07/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
3dc3dc37-605e-4703-aaac-7e7100227449	Hoàng Quang Hải Quân	01/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
718e11e2-5c7d-40b4-942f-cb12b4ed31cc	Trịnh Quốc Quân	30/08/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
ca800246-1ef0-4217-8fc8-7ea41bf6891c	Kiều Tuấn Sang	10/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	xã Ia Kriêng, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
00af2afe-36d8-4783-ae1c-6de702d429fb	Nguyễn Văn Sang	13/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
b48795b3-ce84-47b7-a75c-c8d2ba830a8b	Nguyễn Văn Tài	10/06/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
efa15d89-bb35-4fa0-ac36-511588007097	Nguyễn Trọng Tâm	04/05/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
e4979085-bc3c-4c9a-802c-5a0386dd6a66	Rơ Lan H' Thoại	08/11/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
a6aa9ab5-0e97-42ab-b335-d3171b5cb4ef	Đoàn Trần Anh Thư	15/04/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
fb04df61-62ba-4c1e-8fc1-9f717a68100d	Hồ Anh Thư	13/11/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
9786165b-70a7-4105-b1cf-be6a633a8b04	Lê Văn Tiến	30/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
30b209d2-1a2d-4b1e-9a55-5d6bbed9cb8d	Kpuih H' Tinh	02/07/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Trol Đeng, xã Đức Cơ, Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
ae4bb0c0-a69f-4ca6-b5ce-35a5e08dff0d	Mai Thị Huyền Trang	26/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức cơ, tỉnh Gia lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
b5d65995-e4fc-4a37-89bf-47fde23a9fb8	Nguyễn Tiến Vinh	11/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai	008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	2026-05-12 09:22:24.602551+00
9c822dce-8a5f-4a82-87b0-f1cd0761eb18	Lê Đức Bảo	31/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Iatang- Iadok- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
089b0d74-1055-49cc-b878-634ba53f504a	Bùi Quang Dương	02/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9- Chư Ty- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
67115ebc-0200-4fae-86c6-dcac5562d96f	Nguyễn Thế Thành Đại	17/06/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1- Chư Ty- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
8b6277d5-66ea-4522-bd20-3adfbbd0b4fd	Trần Văn Đạt	29/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3- Chư Ty- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
797f9727-7d70-4b61-a744-9d49fa7736cb	Đậu Quang Thỏa Hiệp	13/03/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm tốc- Iakrel- - Gia lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
8e67de40-518b-4006-ac73-0a999204ca54	Hoàng Trung Hiếu	06/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Iatang- Iakla- Đức cơ- Gia lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
2ce2c459-5ef8-424d-99a8-f16c52daa001	Ngô Đức Hiếu	24/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4- Chư Ty- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
76af8ade-9667-4a97-a6b3-b514816d1d8d	Trần Minh Hiếu	21/01/2009	Nam	Kinh	\N	t	\N	09/01/2025	0327889830	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
d5787c36-f7e2-44cd-84c9-8fb1ef0d2263	Nguyễn Văn Nguyên Hoàng	20/04/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang- Đức Cơ - Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
ed5b2061-fb20-45d0-a527-15c3c2ac390c	Nguyễn Văn Lâm	18/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn chư bồ 1- Iakla- Đức cơ - Gia lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
cc06fcc8-ba5c-41d5-a21a-59a4c48e6355	KSOR H' LIA	04/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung - Iatuk - Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
d5b3874d-d9f6-4bce-9f90-6dc33edb3957	Phạm Nguyễn Hoàng Linh	05/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4-Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
c98316c6-525d-4592-ad9c-b885ba02e8c9	Đoàn Ngô Vũ Luân	10/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng DơkKiah- Ia Dơk- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
86b91e3f-669b-44df-ae38-5bac6b245bc8	Lê Thị Xuân Mai	21/10/2009	Nữ	Kinh	\N	t	\N	19/09/2024	0344040341	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
a600423f-a815-46ed-81e6-c555dacc31a2	Nguyễn Văn Mạnh	17/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
7164eb9f-9267-4fa5-a935-cb72722fb4cb	Lê Anh Minh	14/12/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
69deb51c-bfdd-488a-a37b-9f7016d5945a	Huỳnh Thị Diễm My	18/01/2009	Nữ	Kinh	\N	t	\N	28/12/2024	033 6850730	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
d053195f-521e-4dfd-b5ae-b83b05cc75fb	Đặng Bảo Nam	08/04/2009	Nam	Kinh	\N	t	\N	09/01/2025	0398869302	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
2d45b825-69aa-4cee-9dca-dcea32c35c64	Kpuih H' Ngát	08/10/2009	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Xã Iakrieng- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
ea5d70c5-d68d-4d97-bb6d-0a268f3f38c4	Bạch Thị Bảo Ngọc	16/07/2008	Nữ	Kinh	\N	t	\N	14/09/2025	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
dc2b4b14-ab06-4df4-8ab1-065fee7eff09	Lương Thị Yến Nhi	19/03/2009	Nữ	Kinh	\N	t	\N	-	038 4626009	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
a7610fb9-7c77-40a5-8cef-74dc5f108468	Vũ Minh Phương	21/09/2009	Nữ	Kinh	\N	t	\N	14/09/2025	0375374792	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2 - Iadok - Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
99114c0d-1437-418d-846e-670a742789b0	Chu Thị Quỳnh	10/12/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
de99ab3f-8958-4849-8b93-33be1e251328	Trần Thị Diễm Quỳnh	25/10/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
16eb6fb6-60da-4f0e-be14-f589dae58e15	Kpuih Sen	26/10/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
f5af8131-cdfc-4650-b795-a14868a58c6b	Cao Thái Sơn	26/05/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
e5556d32-35b3-462a-b38f-8a7ec0804716	Nguyễn Khắc Tân	23/10/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
5a025a4c-cffe-4d3f-ad7a-dbd077e9f20e	Rơ Mah A Thanh	10/12/2009	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng sung Le Tung- ladok - Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
9d5f2367-90fc-48e0-a99b-5594bfab4a2f	Nguyễn Anh Thịnh	30/04/2009	Nam	Kinh	\N	t	\N	09/01/2024	0372442289	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Đức cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
3608f20c-fe42-46a6-8469-80f65e2233cd	Hoàng Thị Thanh Thúy	18/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Đức cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
3cf15d49-0f36-46e3-9b1d-619f0f271eba	Trần Hồ Anh Thư	10/09/2009	Nữ	Kinh	\N	t	\N	09/01/2024	0967874123	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
58003fde-a76e-4528-ac3e-33ab42738b0a	Phạm Lê Hoài Thương	11/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
d23a2df0-d85b-4067-9041-6444ebfa5a22	Lê Thị Quỳnh Trang	29/08/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư BồI, Iadok, Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
74ef88e7-08dc-4792-a57b-639bb3485a08	Nguyễn Ngọc Bảo Trâm	17/11/2009	Nữ	Kinh	\N	t	\N	14/09/2024	0706131033	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
831f6968-d575-44b4-b84a-ddca316ccd97	Lê Thị Huyền Trân	04/03/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
a83c9e41-5fa7-4735-8fba-c47bd3917362	Nguyễn Văn Tuấn	16/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2- Đức Cơ- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
8ad53fe8-31e6-4c15-9821-2f7281a2e600	Mã Thị Kim Tuyến	16/01/2009	Nữ	Kinh	\N	t	\N	14/09/2024	0392466042	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn chư bồ 1-iadok- Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
7f0f53d6-8801-4839-b42c-f3ad510fb85a	Bùi Thị Tường Vy	03/10/2009	Nữ	Kinh	\N	t	\N	14/09/2025	0345685398	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn chư bồ 1- Iadok-Gia Lai	a9b2b57f-b578-4799-a790-c951def81dc4	2026-05-12 09:22:24.602551+00
5631fd3d-8321-4317-82cd-b6f1b881e50f	Trần Thành An	12/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Chia, Xã Ia Nan, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
bb7857c9-9bb9-4f0a-aed0-470f6b56c286	Siu H' Dịu	22/01/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
304792c1-e138-4b55-8f81-237163f903c1	Nguyễn Đức Dương	24/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
246438eb-e486-4c99-a7bf-7bda8928ffdb	Trương Đắc Dương	07/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 4, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
48c0f1ee-db79-4e31-a30f-428caa106d5d	Đặng Quang Thành Đạt	29/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
7bdee69f-f7fc-4981-8ca0-df8e84d24a7c	Tống Thành Đạt	25/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
bb0fadb3-9d33-4683-84c7-6502e61fafc1	Doãn Thị Hồng Hạnh	20/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
26c87d51-5e03-4c8f-8320-cfa9bb32db29	Lại Hoàng Bảo Hân	29/05/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Phường Pleiku, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
07966004-846f-4957-9092-4d30b8b68601	Nguyễn Thị Ngọc Hân	06/09/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tôk, Xã Ia Krêl, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
6a85c6c4-6234-47f6-a0c3-1967b963b278	Lê Quang Hiếu	04/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
bbe10ab8-2355-4937-9a71-57bf5e625fee	Phạm Khánh Hoà	08/01/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
ab9e0d30-1610-42f5-bf31-7e024bb499b0	Phan Công Hùng	03/10/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
3a72b54b-41c7-4388-a47c-52bf6c39e87d	Nguyễn Hoàng Gia Huy	18/07/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
65572bd6-3675-4553-8223-7aeafce859d7	Nguyễn Hồ Nhật Hưng	27/11/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm, Xã Ia Krêl, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
77162036-bf36-4a11-ac1c-a841f54bdde9	Vũ Nguyễn An Khang	01/07/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 2, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
829a508b-0873-4ffa-b8aa-e5a9e62c011d	Mai Xuân Khánh	29/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
78757a88-d8dd-4954-8eb1-6fef1ea61eac	Nguyễn Phùng Khánh	02/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
a2f606f5-e113-4203-a1f9-82d0aa4e47e7	Nguyễn Thị Thùy Linh	19/05/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
2d44c692-096a-4414-84ee-08414a915ce2	Kim Ngọc Long	16/09/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
976a580c-4e49-441f-924e-9674149f8395	Hồ Hữu Mạnh	29/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
88de484f-ad63-4d9a-8371-70cf01cbb08a	Kpă Mathê	17/04/2009	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
5398896d-5485-432d-9d91-3dc1f617a959	Hồ Thúy Nga	21/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
29794cf4-3590-491f-8c2d-c37ea3d37c7c	Hoàng Bảo Ngân	07/11/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Kom Ngó, Xã Ia Chia, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
69387012-da09-4066-8934-7fda2a0159cd	Mai Thanh Nguyên	28/10/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
10a7ae34-30ba-488b-a555-c1e6ab5af31f	Trần Đăng Phong	23/09/2009	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
987a77dd-e9db-4e5a-a07a-8b6d0d451724	Chu Đặng Nhật Phương	07/06/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
8f59ecbc-9a0b-4dc7-96cd-eee60b0cb23c	Đoàn Ngọc Nam Phương	27/12/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
2f3b2d74-ecdf-4a57-b8ab-3f031ad9ff62	Đặng Duy Quốc Quân	09/04/2009	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
14d42945-483f-4539-8913-16b810a6613a	Vũ Diệu Thảo	26/09/2009	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
7326dcac-20d9-4590-8e2f-5f87692d34b6	Kpuih H' Thứ	26/09/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Trol Đeng, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
ae9848ab-49a4-42ab-868f-87c015f35337	Phạm Trần Anh Thư	29/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
b4e03a35-9005-49b0-bfcf-759f4ea4cd0c	Trần Thị Anh Thư	29/10/2009	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
df7a8be6-e046-4772-8917-96c6e6734c83	Kpuih Trần	18/12/2009	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai	d9432471-04ff-4bae-b307-ca83ee8907c2	2026-05-12 09:22:24.602551+00
a58b7c11-93ec-46a2-90db-11c13127e205	Nguyễn Ngọc An	01/04/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0333855032	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
0f0b1a55-9c15-4635-bedb-e62523a6f12d	Nguyễn Hoàng Anh	06/03/2008	Nam	Kinh	\N	t	\N	26/03/2023	0366927743	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
da3cd7a6-c98f-4440-8e80-107b869fdc06	Nguyễn Tuấn Anh	13/08/2008	Nam	Kinh	\N	t	\N	14/01/2024	0984802579	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Dơk- Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
f15af0b7-f86b-4be2-96b7-0e6b5fbcb300	Nguyễn Trịnh Gia Bảo	26/08/2008	Nam	Kinh	\N	t	\N	22/04/2024	0869899621	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
6d81090a-8433-432e-8d90-7ec18a663845	Nguyễn Quang Thành Công	04/09/2008	Nam	Kinh	\N	t	\N	30/11/2025	0349995067	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân- Xã Ia Krêl- Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
478730b9-d4e5-4eda-aeaf-b9a0e5a7ae40	Bùi Thùy Dương	04/01/2023	Nữ	Kinh	\N	t	\N	26/03/2023	 0346923157	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 1 - xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
1bfbd098-427c-4357-aa31-a72590e52bf4	Dương Minh Đức	08/07/2008	Nam	Kinh	\N	t	\N	09/01/2025	0865646339	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
12693533-1ae4-4768-b78f-9cb1bcf1499a	Hà Minh Đức	13/11/2008	Nam	Tày	\N	t	\N	18/01/2026	0373462577	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
518e5675-7bd2-4748-9e29-85306148fe57	Lê Đức Giang	02/09/2008	Nam	Kinh	\N	t	\N	09/01/2025	0398171374	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 7 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
61c549d2-a164-4aad-afe1-6493e8c1d86b	Phạm Ngọc Gia Hân	12/10/2008	Nữ	Kinh	\N	t	\N	20/09/2023	0983029959	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
44d1f91c-8bd3-49a4-9a2e-429191ef4284	Mai Văn Hoàng	23/01/2008	Nam	Kinh	\N	t	\N	26/03/2023	0375346667	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
d58459c4-7848-4988-b034-e78887714997	Nguyễn Đức Hoàng	04/05/2008	Nam	Kinh	\N	t	\N	24/04/2025	0349315963	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 3 -Xã Đức Cơ -Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
244d99e9-fec9-428d-9efb-3e26842b0109	Nguyễn Quang Huy	20/06/2008	Nam	Kinh	\N	t	\N	24/04/2025	0396036852	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
07e157b9-d0c1-417f-9272-ce73a3750bf2	Nguyễn Trần Gia Huy	22/06/2008	Nam	Kinh	\N	t	\N	18/01/2026	0973227717	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 3 - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
6b6067dd-eabe-407f-bf3c-2afbf3098658	Nguyễn Ngọc Giáng Hương	04/01/2008	Nữ	Kinh	\N	t	\N	20/09/2023	0377295803	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1- Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
8a828ea8-55a4-4fb2-a417-ae5ea9691b19	Nguyễn Thị Diệu Linh	17/05/2008	Nữ	Kinh	\N	t	\N	20/09/2023	0328875445	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl - Xã Ia Krêl - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
e3b336c0-4adf-4d0e-9b1d-af5b8fda9275	Cao Thị Thanh Mai	13/03/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0328444459	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
e61e798e-d89b-44e9-b963-fd45399cf275	Đỗ Đình Mạnh	26/01/2008	Nam	Kinh	\N	t	\N	26/03/2023	0348607726	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
482c0b56-7fe9-412e-bf38-2214adc78a93	Nguyễn Vũ Đức Minh	15/03/2008	Nam	Kinh	\N	t	\N	26/03/2023	0373807315	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
aa4877d6-5713-4054-9d92-7a1a1e8b5f60	Nguyễn Thị Bích Ngọc	27/02/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0362367022	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang - Xã Đức Cơ -Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
c3b1f0e1-24a0-4092-aef8-7e47198afda6	Nguyễn Thành Nhân	22/01/2008	Nam	Kinh	\N	t	\N	09/01/2025	0383800177	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
f0f05adc-0462-4e79-a543-a179c005b1c3	Bùi Thị Tú Nhi	09/05/2008	Nữ	Kinh	\N	t	\N	09/01/2023	0385397067	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
1772dd7d-42be-4d39-a4a9-4cec4d6a5313	Đinh Thị Yến Nhi	22/04/2008	Nữ	Kinh	\N	t	\N	05/12/2024	0354844896	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 3 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
53d68343-baa8-4c70-90e5-69e183f5c688	Nguyễn Thị Nguyệt Nhi	27/01/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0854427247	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
0663cee6-6363-4f25-94fa-e2f74b35aaf1	Phạm Lê Gia Nhi	28/10/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0977823975	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
b1656e22-9948-4729-8d00-c8e66e02ecb3	Lê Tâm Như	09/10/2008	Nữ	Kinh	\N	t	\N	01/04/2025	0975046279	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm - Xã Ia Krêl - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
2c3ec82c-efb2-4ab7-82f1-e05183f17d0a	Trịnh Tâm Như	14/08/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0789725567	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 6 - Xã Đức Cơ- Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
4d16cf90-9ecd-4423-98cf-2e77a9272f6c	Đỗ Hà Phi	06/01/2008	Nam	Kinh	\N	t	\N	16/10/2022	0382316601	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
e56505ec-4fe8-4c68-b8bb-bfadb7c9aba5	Hoàng Văn Phúc	14/01/2008	Nam	Kinh	\N	t	\N	26/03/2023	0376083663	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
ef7af40c-db08-40ed-b736-36baee18c0c9	Hồ Thị Bảo Phúc	29/01/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0386701578	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
169da06d-e6a6-4600-b55b-0a52982984d6	Đoàn Anh Quân	26/10/2008	Nam	Kinh	\N	t	\N	18/01/2026	0867942248	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
6649b360-45ad-4e50-8d00-f54ada203aae	Ngô Đức Sỹ	03/12/2008	Nam	Kinh	\N	t	\N	14/01/2024	0862246494	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
10a17aff-cbf8-45ed-b937-010c404b021d	Đinh Hoàng Thu Thảo	26/03/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0794643167	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
d622e2ac-9d83-4a7d-8b30-5fb4efb11d30	Hoàng Thị Phương Thảo	29/10/2008	Nữ	Kinh	\N	t	\N	18/01/2026	0389905667	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
0d995bf5-a30d-40aa-b5fc-9d888951c735	Nguyễn Hương Thảo	30/09/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0347745938	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
346c8c87-4002-499e-a483-5ce0bae091df	Nguyễn Đức Thắng	09/09/2008	Nam	Kinh	\N	t	\N	01/04/2025	0839687889	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 7 - Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
8b39c009-9a24-492a-b6ba-3d5bf2ad1617	Đinh Thị Thanh Thùy	25/11/2008	Nữ	Kinh	\N	t	\N	09/01/2025	0833827587	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
58eaed2d-34a1-4633-a887-39b8d9162f5a	Nguyễn Thị Trầm Thương	11/01/2008	Nữ	Kinh	\N	t	\N	26/03/2023	0395372178	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
a51fce29-b6db-47af-a595-2d9d40024e22	Đỗ Công Tuấn	06/02/2008	Nam	Kinh	\N	t	\N	22/04/2025	0987802574	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
9d5472c6-1c62-4cac-bdf9-3897c47498f7	Nguyễn Thị Minh Uyên	22/08/2008	Nữ	Kinh	\N	t	\N	09/01/2023	0355425605	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 1 -Xã Đức Cơ -Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
7f80ddef-2251-400f-b060-503f4f5d23ef	Nguyễn Lê Vy	14/02/2008	Nữ	Kinh	\N	t	\N	18/01/2026	0356918059	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Mook Trang - Xã Ia Dom - Tỉnh Gia Lai	954194a1-bde4-41fc-8fc2-196f4f77c43c	2026-05-12 09:22:24.602551+00
11e6875f-31d6-43a9-abb4-936a11656fc5	Lê Quang An	12/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
eb6e9468-6322-47e2-abbe-61d1cc85518b	Nguyễn Ngân Anh	20/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
da7d3180-4c83-48fa-bb2a-0e232670da65	Phan Ngọc Gia Bảo	19/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
f889dda8-565f-4d5c-b872-ea184e5ca498	Nguyễn Thị Bình	02/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
61d41d02-79f4-476c-b4a3-7442caee968d	Lê Thành Danh	19/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 7, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
3e7d3530-badd-45f2-a063-f7f8b8b3e8f9	Đoàn Thị Ngọc Diệp	26/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
28518122-686e-44d1-80e8-f9155f65967e	Phan Văn Dũng	14/10/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
b5746f94-34f6-4045-b921-5939b3cfd2aa	Phạm Thành Đạt	11/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 6, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
aa7a1fb9-4897-47d0-9345-549458dde9bd	Phan Tấn Đức	16/05/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
3d19b533-ac17-4c0c-a6c2-d4bd91583af3	Trần Thị Bích Hằng	13/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
aca681de-df3d-4d44-8165-dcb9d85fb1b2	Phạm Tuấn Hoàng	20/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
35234be3-4d3d-4b8c-988f-2f5d706a2b1a	Trần Lê Huy Hoàng	03/10/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
c3443743-ca48-48c8-9d89-e460e6f2d23b	Hồ Sỹ Huy	01/02/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
89886d3f-3348-415e-bf13-0535e010467f	Hồ Sỹ Huy	27/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
fc1d41fe-3554-40c2-b131-d3462c2b617b	Trần Quang Huy	13/05/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Mook Trang, Xã Ia Dom, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
5c42da03-5197-495d-87d2-0b4237ebeccc	Hoàng Thị Thu Huyền	14/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
a362dad4-4757-44bf-85b7-3d49cefc50d1	Đào Duy Hưởng	16/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Ia Krêl, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
bb34c9b9-9e60-4b0d-bead-ad151c005709	Mai Thanh Lâm	23/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Chía, Xã Ia Nan, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
a21a7b29-fd10-4a72-a458-0d1fccb2f791	Phan Văn Long	11/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
be0e45d6-83ec-4f71-b6cc-c30d71bc060e	Lê Thị Mai	05/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
27a181b9-2e4b-4090-9a2e-eeaf2c1fc523	Cao Thị Trà My	14/08/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
28168597-5903-4249-ac36-ac5585c41fa1	Phạm Lê Hoài Nhi	01/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
e4a3c658-33d8-4801-a8f7-698ed5eb90b7	Dương Lê Thảo Phương	17/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
19f030f8-1318-4abe-ae2d-189cc272cbcc	Nguyễn Anh Phương	09/08/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
6f59f906-9fb9-4623-8be3-f310ab6bd16c	Nguyễn Chí Quốc	27/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
8c5d094e-6360-4d46-a82f-14443f7ab5c0	Nguyễn Thị Diễm Quỳnh	02/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	ThônThanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
e5bb2e6e-f8a7-4fa7-aa93-f5e05e7591e3	Võ Duy Tài	10/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaLâm, Xã Ia Krêl, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
f293d389-d23e-439c-9820-350dcdcd6ec3	Lê Hữu Thành	09/08/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
feb821a9-ed28-4c43-888f-5ab71701f16a	Lê Thị Xuân Thu	01/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
341ac8db-d9e6-4751-98e5-eec8529c2be5	Đoàn Anh Thư	10/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	THÔN ĐOÀN KẾT, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
55ab3afb-2a5c-4e4e-9eaf-bb4b6ab5319f	Nguyễn Bùi Anh Thư	28/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
90555ccc-3df0-46a0-9750-1599d6407de2	Võ Hoài Thương	06/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
ddfab9f6-76df-47aa-a7d1-a2e64b3e2731	Nguyễn Thị Ngọc Trâm	20/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
7d183ee1-8117-4e38-828e-84ddf095a9aa	Trịnh Lâm Trí	28/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bi, Xã Ia Dom,Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
85c73b3c-2775-46f3-b879-8d86b71ee071	Nguyễn Đình Văn	24/02/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
35b33d7f-3aec-45a7-9964-586e5fc535b8	Phạm Nguyên Việt	12/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
3fd1a11a-92d9-4a15-8569-e1920b2f1e7a	Lê Thị Yến Vy	18/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
ed72e5e4-3342-4c1d-a6d2-b640861638b7	Phan Thị Kiều Vy	03/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai	0759f20d-917b-497c-a424-c1c80b3a9eee	2026-05-12 09:22:24.602551+00
a44cd7ef-4e0d-4a8c-88fa-35b28fb52007	Lê Đình Nam Anh	23/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
51675953-b647-4f97-a517-001257f8258c	Lý Trâm Anh	31/10/2008	Nữ	Nùng	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
9d652ea6-3b3f-44c6-b414-0c8d4500a0f5	Nguyễn Hà Anh	22/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
26e0ca58-a315-4433-9f79-a7d8e673afff	Trần Gia Bảo	28/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
715fbec9-32cf-464e-8991-10d6c9894a60	Trịnh Phan Kim Chi	23/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
cbaa3b0a-8196-492a-a282-7908d0c4ff77	Nguyễn Trọng Cảnh Duy	28/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tốk, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
39b33de7-6880-4f7b-b29e-6fe46efbf411	Lê Văn Đạt	22/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
6e13cdbc-aac2-45cb-a2bd-7941cc932426	Nguyễn Thành Đạt	29/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	 Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
ceb2ea01-8a76-4834-a2d8-316451ac8e7d	Nguyễn Tiến Đạt	27/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
5d22d3ef-3c19-4ed6-a245-6a9a68dc0aa8	Vũ Đình Đạt	26/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
f3b79598-2d13-40a7-8ccb-c300b4afd316	Hồ Văn Đức	06/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
f28dee30-c35e-4a31-becb-7725ed32a4e0	Vũ Thị Thanh Giang	01/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
ccfcdd03-4ba2-4c85-b8ba-6034b2ec4de3	Lê Nguyễn Hồng Hà	06/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
6a53fd7e-d9ee-497e-8802-722c434ae570	Nguyễn Gia Hân	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
eedfac4c-dac0-48f1-9605-5c61f7282640	Nguyễn Khắc Hùng	22/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
35f5ae81-c739-4833-ae93-18ee426fc04b	Dương Công Huy	24/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
3c650820-6160-4c3d-b8d5-10df03bd64de	Trần Thị Lan Hương	10/03/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
f246cd5e-ed52-49de-8408-f47ab458a041	Lương Nguyễn Anh Kiệt	29/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
74d507c8-40b7-451c-a096-807cb0e0910a	Nguyễn Việt Linh	16/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
e02be7d8-0ba0-46e7-bd39-ca3ec627637f	Nguyễn Trần Khánh Lợi	30/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
b3a27fbf-2ebc-4a33-b81d-83d0bac042ed	Nguyễn Thị Bảo Ly	27/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
37d99b5e-3f0d-45fa-9e56-060112ac979a	Nguyễn Nhật Minh	16/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
7e4963f3-d4e5-4e51-8724-d7b0bb348253	Lê Diệu My	21/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
448a4655-f35b-4873-93d1-7d53362ed744	Lê Võ Thanh Nguyên	20/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
195a015e-c39b-48dc-9130-ac6aaaf4ecc8	Nguyễn Thị Ánh Nguyệt	04/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
f6286bf7-0bfb-40c5-9e3d-d4387f5bd567	Cao Thị Yến Nhi	11/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
c89fb46d-bce7-42f4-a218-631a10fcab88	Nguyễn Ngọc Phương Như	17/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Nú, Xã Ia Nan, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
afed2ce4-7a76-4f23-802a-f8bf5257d06c	Nguyễn Văn Quyền	29/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
50f8db5b-35a5-4f2b-a1be-22614c464318	Trần Thị Mỹ Tâm	28/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
e015d6a7-46d3-446e-8989-aa6457727beb	Trần Thị Lệ Thanh	29/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
c3107189-f5f6-4f2e-8ed2-abc08aa18d35	Nguyễn Thị Anh Thư	25/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
ea7b100b-2c7d-4388-be09-1f2c6ba71f62	Trần Minh Thư	16/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
4761fb8d-df79-4065-b967-04bab6804975	Đoàn Huỳnh Mạnh Tiến	07/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
676f529a-7fd3-496e-8536-0a0cf6483724	Phạm Thị Huyền Trang	16/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
6c3857a7-0069-41a0-9e63-6dc63ba2ff6d	Trần Cao Thùy Trang	25/11/2007	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
26dfe311-c7fb-4619-843f-6fb2eb4b3c11	Lương Thanh Trúc	10/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
a61e2b78-50da-4bd2-a32f-01372d94c962	Hoàng Khương Kiên Trung	19/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 6, Phường Thống Nhất, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
2cf8bab3-639c-46ba-8e8a-afab507da79b	Từ Thị Ngọc Tuyên	28/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
bb547317-f3d7-43ef-a9ae-f0a924974ed2	Phạm Minh Vũ	24/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
db59dbc0-4617-444f-808e-c4f92778a11c	Hoàng Uyên Vy	12/05/2008	Nữ	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	4f330808-8e49-4958-a90d-945234bd6d66	2026-05-12 09:22:24.602551+00
4bfb2f42-2762-4171-8e53-8c2ddc8e2b1d	Đỗ Võ Tuấn Anh	17/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
74727a78-0a94-4083-b67c-2300092e7a9f	Hoàng Thị Kim Ánh	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
bc372711-dc07-4573-a6dc-69bed6d2b32c	Phan Thị Ngọc Anh	29/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
50afc5ce-a95e-4c5f-aa13-be2ab974ced9	Phan Tùng Anh	03/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
2244a9fd-37f6-4277-b890-adc10924c8da	Nguyễn Thanh Bắc	17/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaLâm, xã Ia Krêl, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
05d2accc-274a-4df5-82c0-d9cbf7233df4	Hoàng Hải Bình	27/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
a4ae0159-ecd5-4053-b431-c5daf360e882	Nguyễn Ngọc Chương	22/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, xã IaDơk, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
ac2ab540-52b9-4a39-a4a8-a89a0f373c7c	Lê Tuấn Dũng	01/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
858ea3c6-0d7b-4602-9fa5-6f42b95e3a82	Mai Tấn Dũng	20/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
f79ea3bd-8d84-4808-b463-786484b02bdb	Mai Tiến Dũng	20/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
5c0556ec-ad75-4783-bf9d-7b3c7b933672	Hồ Thái Dương	20/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
305aa0b8-31da-4211-a744-1a9bd1c2d2b5	Hà Ngọc Hạnh	30/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2 , xã IaDơk, tỉnh Gia Lai 	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
3327006d-72b8-47f1-82a9-c1d072681bd3	Lê Thị Thu Hiền	29/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
2a89f097-7584-4a56-8ae5-59687c2f90d6	Vương Thị Hiền	28/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
47a40bcf-5a00-4bb0-ad84-1ef42974838f	Đỗ Ngọc Hoàng	24/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
51e57d0e-dc6d-4821-b299-0cdb856950a9	Nguyễn Thị Thu Huyền	01/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
3cb435b4-87f0-4aa6-b75c-2ce31a8112f6	Đặng Thu Hường	06/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
a9448908-9871-4065-9c5a-28f8f50787c0	Đinh Thị Hương	16/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
f293b1d9-9a72-4140-8879-7f1f3c5a4828	Ngô Đức Linh	31/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krê, xã Ia Krêl, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
20ff4626-5892-43f8-9c79-2694d71e4ff5	Nguyễn Ngọc Hồng Linh	08/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
f09ed25e-c78f-447d-be27-626fdfef30fb	Trần An Lợi	14/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
636f317d-12a9-430e-a92d-02cbf3bff3f3	Phan Vũ Thành Luân	25/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
071bcaa9-de0b-428b-bdc6-33049424e090	Trần Hải Ly	11/03/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
121a4bc5-cda8-4cf2-85a3-7d25fcd8eb69	Đàm Cảnh Minh	04/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
53fe14b0-0745-4f51-a852-6c639b989e46	Võ Hoàng Minh	23/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
28b988c3-c40c-4a17-9108-938ae28f2a01	Hà Thị Trà My	19/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2, xã IaDơk, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
99704ae9-d794-435f-b0cf-56377fe1cac9	Tăng Ngọc Nam	11/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
fd2fad1f-d167-4277-9f68-70795f074656	Nguyễn Thị Quỳnh Nga	21/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
1031a390-5a1b-4dfa-bae2-d57a1e026ce7	Chu Nguyễn Bảo Ngọc	18/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
5098b148-a824-4f21-8010-c15431d27f49	Mai Thị Yến Nhi	27/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
081b4053-ade0-4bc7-92e5-4bdde54d563b	Lê Thị Mai Phương	25/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
b8af13e2-e94a-4305-a199-77221f841fad	Nguyễn Thị Phương	09/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
70f63d8c-6af6-4f2a-ac2c-b742f84e3e91	Trần Minh Quang	01/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
0dcaf75b-5045-4c08-831e-7cf74ac8acb1	Trần Khánh Quân	10/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
7137a827-e0d9-41bf-995d-0e42b57b68af	Trần Minh Quân	21/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
401bab13-113c-4ded-8b74-b8e88be4a256	Nguyễn Cảnh Tân	01/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
a702560f-6db3-407c-b64c-b3db522acff3	Nguyễn Hữu Thắng	12/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
7f2048df-232b-4b10-be81-29d93b4317de	Phạm Anh Thư	14/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
0a88c8ba-8fa0-4de7-90f5-0db0e5ceb569	Nguyễn Thị Thùy Trang	13/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
89674339-627c-4f6b-b632-5637685a6ada	Nguyễn Xuân Việt	15/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
b7da90c2-a1be-42cd-9c8e-ceed9959a307	Phan Hoàn Vũ	26/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai	362d1fb7-681a-4425-a1d9-7b5cbe3243b5	2026-05-12 09:22:24.602551+00
72ef2d4d-0c2e-44ff-ab55-9e8f01ed501d	Đinh Hoàng Anh	14/10/2008	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang - Ia Dơk - Gia Lai (cũ)	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
0d206d88-ebdb-4864-973d-b797ffa43d14	Hoàng Việt Anh	07/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Đức Cơ- Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
c28ec368-1000-4b4b-81bd-48f38cef6fea	Lê Công Ngọc Anh	25/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - Đức Cơ  - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
1e1030d2-4c3d-43e3-a43e-37643e881382	Nguyễn Hoàng Anh	29/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
9768e9ee-b174-46fa-81b7-5208839e5944	Trần Đinh Hoàng Anh	18/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP1 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
c67e8b53-6d9d-4cff-a2d4-6e5413f28017	Rơ Lan H' Bích	10/01/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le Kắt - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
c472838d-b367-4462-81be-f0f18873510a	Hoàng Thị Quỳnh Chi	11/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3  - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
39668dd2-781e-4135-93cc-f70fa44ce005	Hồ Ngọc Quế Chi	26/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
91c53f91-d99e-4ba1-83e7-2d5248173816	R Lan H' Diệp	19/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Lê Kắt - Ia Dơk- Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
adf30c92-0ead-4deb-859f-0a58ccdc161b	Lương Quốc Chiến Dương	25/02/2008	Nam	Tày	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
23ba87f4-7b0c-4d77-babe-6e80eef4a4d5	Lê Viết Đạt	03/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl - Ia Krêl  - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
0795e431-615b-4686-a281-29b7dcd830fc	Mạc Phạm Hải Đăng	09/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
c0a77a52-44b8-444a-a09b-b8ab90f43461	Trần Thị Vân Giang	23/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
c222e4ab-7608-4e04-81e1-0183c3be38dd	Lê Thị Thanh Hằng	29/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lâm Tốk - Ia Krêl - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
4ea359d2-13bb-42b9-90be-237316767e38	Lý Gia Hân	30/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo - Ia Krêl  - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
9d89ed18-2f7a-428b-b1ad-c451683f6c26	Vương Tiến Hùng	29/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krêl - Ia Krêl - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
5d91e65b-4703-4954-99ad-9712319c6f94	Lương Trung Huy	18/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
d590a533-798a-431c-8cfa-fd3af820528d	Nguyễn Trần Minh Khôi	09/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
f3ec6844-e009-4f0b-a219-caa0b04a7086	Hồ Lê Phương Linh	27/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP1 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
bcca8779-c9bc-4472-9bd7-6646a15d12eb	Đỗ Thị Tuyết Ngân	23/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm - xã Ia Krêl - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
a3174162-a49b-4c6b-b6ff-c481f3775504	Nguyễn Thị Hồng Ngọc	12/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ II - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
0f6675cd-fe4e-4c3a-8e37-e6c05bdbe287	Tào Trần Bảo Ngọc	26/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - Đức cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
8211937d-d592-4b1b-9c17-03a50f7c8c29	Trần Thị Thanh Nhàn	15/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
5557bfbb-f5b6-405c-bda0-342dfcf89d21	Đinh Trọng Nhân	09/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông - Ia Kriêng - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
adf8db89-9e09-4e55-9d7b-929a724e0cc1	Nguyễn Thị Linh Nhi	10/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Ia Krêl· - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
0ff24325-9e9f-4c8b-a3f7-08b208a13a8d	Nguyễn Thị Hồng Nhung	21/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Giáo - Đức Cơ -Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
730b66cf-febe-443b-8a40-7af0b90f3b1f	Rơ Mah Phiên	13/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè - Ia Dơk  - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
ac6c3e8b-49dd-4b09-bab5-5333c478b8da	Phí Mạnh Phúc	25/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 2 - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
91324c5f-f58a-49f3-8dff-3957a77d53d7	Đậu Tiến Quân	03/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết- Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
1b9f6d8d-d2e9-4f7c-9261-f26508651526	Trần Ngọc Quốc	19/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Giáo - Iakrêl - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
6381f6d1-2b6b-4964-858b-21a36b107480	Kpuih H' Si	20/01/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang  - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
0c4b362d-d1e1-4fc5-9542-a2d3aae67925	Kpuih H' Soa	06/08/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua - Ia Pnôn  -Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
2c4de948-e4dc-473b-998a-6f767177c468	Hồ Thanh Thanh	18/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 -  Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
bede917d-4a52-4d2e-be0f-31b5d7b2e7db	Phan Chí Thành	02/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
2927fda3-1d26-47fc-bda1-7a75e155b79a	Phan Thị Phương Thảo	27/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Giáo, Iakrel, Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
c4477834-0b2c-431f-992c-faced8442da3	Hồ Phúc Thịnh	02/07/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP4 , Đức Cơ ,Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
94fad007-29e0-47e8-a84b-92dd14586a3f	Vũ Hồ Anh Thư	11/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6, Đức Cơ , Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
b4a25066-2c52-4424-b8bc-ba49abe6869e	Lê Xuân Tiến	25/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
450a9c37-e533-4ad2-8e09-080e2b0ab2c1	Hồ Thị Tình	24/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết - Ia Dơk  - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
27422029-96af-42a1-b848-5bedfaed5a7d	Lê Thị Ngọc Trang	04/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
e83870de-82ee-47e2-8e63-87cae04e4845	Phạm Thị Huyền Trang	25/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1  - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
6183c6fa-0c84-48c4-b23c-ba2debd1c500	Rơ Lan H' Thuỳ Trang	11/01/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
7113bd20-acc4-4f98-bd74-86c2d0653447	Dương Quỳnh Trâm	17/06/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
a4534595-bcde-441e-88f8-8603b54f9d10	Nguyễn Thị Trâm	14/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang - Ia Dơk  - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
5caca084-8b5b-4d28-8dbe-a52d00854a0f	Rơ Mah Trân	28/08/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - Đức Cơ - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
5cac5542-9514-4aed-866f-17f8fb5b4c69	Lê Văn Anh Tuấn	03/02/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm - Ia Krêl -Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
09404e29-ab33-41fd-b34b-c4acc4132049	Rơ Mah Tuấn	07/02/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
0b76e640-f90a-45eb-abd8-f2789e15f6a0	Rơ Mah H' Tuệ	12/12/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pong - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
5da3474d-b83b-475e-98bd-06b9444480d1	Rơ Mah H' Út	30/09/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông, Đức Cơ ,Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
fcfefa83-b3aa-476a-8e9d-74467d90a666	Ksor H' Uyên	21/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Le Tung - Ia Dơk - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
bd4c4ed4-069f-4be7-82a1-c725ba80c581	Nguyễn Thị Hải Yến	13/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Tân - Ia Krêl - Gia Lai	f9353b84-a3a8-49bf-b97f-e1fd07619c34	2026-05-12 09:22:24.602551+00
933c5da7-f0c8-45fc-89bb-b94ac827abbe	KSOR H' HOÀNG ANH	07/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - Xã Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
5b315147-aef7-4f62-a38a-b6c87de5840d	PHẠM THỊ VÂN ANH	14/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Lâm Tôk - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
011e4ef7-69d7-4055-8cbc-ae50e9d63564	LỤC VÕ THÁI BÌNH	09/11/2008	Nam	Mường	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
3381a8b9-905f-4308-8314-8db5cef68ae4	NGUYỄN HỮU CHỨC	22/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP6 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
ef33967f-dcb0-4267-ad1d-bdf4ebfa77ba	RLAN H' DIỆU	28/10/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Le Kắt - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
c7302294-b151-45f2-8c43-50853c120b84	Hồ Thị Thùy Dung	05/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2,TT Chư Ty, Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
4d7dd818-9056-46ef-be33-6a002f454795	NGUYỄN THỊ DUYÊN	10/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP7 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
4dc88cc0-0ffe-4fbd-bc83-bcbc26751319	NGUYỄN THẾ ĐẠT	03/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 -Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
dd63af4c-61e4-4043-9977-cb0d0b469716	LÊ THỊ ÁNH ĐỨC	18/08/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
3ae00e89-b52e-458a-9ca7-430257b3d4d1	TRẦN LÊ THU HÀ	19/12/2008	Nữ	Kinh	\N	t	\N	09/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đoàn Kết - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
65d7306c-f3bc-4f45-8dfc-e449f88f6220	KPUIH H' HAO	21/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
150d0809-9e61-4bc7-8d71-9785b5b92d4c	NGUYỄN HÀO	07/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
de96b2cd-4e7f-46cd-b34c-8cdd34032aed	HOÀNG THỊ THÚY HẰNG	14/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
dab510d8-9715-4319-ba5b-c157a042e3e0	LƯƠNG THỊ THU HẰNG	18/09/2008	Nữ	Thái	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Ia Kriêng - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
355cdc78-838a-4972-9a55-2f3d336aa162	NGUYỄN NGỌC BẢO HÂN	28/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
368091ab-0d6b-48f0-bbfe-b523a8325f59	TRẦN MINH HIẾU	08/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
dd9c8667-a12c-473c-a7e2-d0a5d03abd19	KPUIH H' HÚI	23/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
ba6fded9-5d05-495c-9bf4-9d2e556195d8	RƠ MAH HÚY	10/12/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
1b8024c7-7049-45c9-95b8-277b18bfa4b8	NGUYỄN THỊ KHÁNH HUYỀN	01/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Lâm Tốk - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
95a9b20e-f91c-408b-8d76-700685dadf02	LÊ NGỌC KIÊN	27/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
3bf8017b-ff41-4e57-8926-dc0989e92c30	LÊ THỊ THÙY LINH	18/03/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
c2eac573-c154-4b13-b2cf-8e001a764276	NGUYỄN THỊ PHƯƠNG LINH	17/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đoàn Kết - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
8cbbe11a-12dc-4f96-98b2-38c648f5eb32	Hồ Hữu Lộc	05/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1,TT Chư Ty, Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
173db6ee-f554-4cb5-a4ab-e9291a1435ba	NGUYỄN HOÀNG HỮU LƯỢNG	09/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 4 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
1be95151-fc20-4561-bcff-e786fed42cfa	RƠ LAN H' MƯNH	06/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Kép - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
a8f7f07c-0162-473e-b894-11c427904180	LÊ THỊ MỸ	26/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
10fdc2c3-1bf3-41a9-8a05-afda30cd4b51	NGUYỄN THỊ HỒNG NGỌC	29/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đội 12 - Ia Chía - Ia Grai - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
23fbb046-fc8a-4082-9e15-b407425e972c	NGUYỄN PHƯƠNG THẢO NGUYÊN	09/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
cb659782-7088-4bac-b880-ef2cad8e20d6	PUIH H' NHE	02/12/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
6454c094-cff9-46be-9dba-5d93c5c33a60	ĐẶNG THỊ YẾN NHI	18/06/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
16ccbf07-3038-431e-a25e-230859e53953	TRẦN BẢO NHI	28/12/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
80a7ae35-ab13-47cb-9e00-f33b337ef8b0	TRƯƠNG THỊ HỒNG NHUNG	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Tang - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
f81ffda2-f94a-4202-839b-3ede6f8f5843	NGUYỄN THANH PHƯƠNG	24/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
70dcfe37-d913-45d0-8d8d-b66dffdecfc5	PUIH PLÝ	06/02/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
951bcc14-9900-49ad-a20e-1310ef135cef	Hoàng Long Quyền	18/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
f8d5e01b-879f-41de-9926-2ad877c1a741	RMAH H' LY SA	01/05/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Le Kắt - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
3a3ee946-b781-4b8b-9de5-0e594c2c2c70	SIU LI SA	26/03/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
a1ea49bb-d185-40f6-8e43-292efd3c94ed	ĐÀO THỊ THANH THẢO	11/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Chư Ty - Đức Cơ - Gia lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
8fc82845-aff2-4682-ab44-690e39ceb01f	NGUYỄN THỊ DIỆU THẢO	02/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
4d593e7e-8ba9-45b7-aa36-b835e1137482	KSOR THEO	01/01/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
3766315e-3811-4300-a35f-d2001ef40e3f	QUÁCH ĐỨC THỊNH	06/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krol - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
fb5d4481-6bc0-4b3d-a0e0-6b52ee4d3250	NGUYỄN THỊ BÍCH THỦY	02/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
262d5322-8e2c-453a-9b0c-78fe614ddae6	TRƯƠNG THỊ THANH THỦY	20/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
52235e3c-3720-489a-970a-4649a1c3c654	NGUYỄN BÙI ANH THƯ	09/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
5325f526-430d-48c1-8d21-4788ae505d64	NGUYỄN LÊ HOÀI THƯƠNG	29/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
fc784374-4140-425a-8719-057d6263a650	TRƯƠNG ÁI MỸ TIÊN	29/01/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
a5704945-2e61-4e9a-a128-0c1d70b3d74e	LÊ THỊ HUYỀN TRANG	04/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
c6ce8453-4c63-4eed-a01c-65d9beacd96d	KHUẤT ANH TÚ	30/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
d7df1edf-e94f-424b-857a-18cccc858b1c	PHAN ANH TÚ	06/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Chư Ty - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
efeb59cd-7d06-4bfa-86e9-8b5090d5c881	RƠ LAN H' TUỆ	27/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung - Ia Kla - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
49b44b80-df83-42c7-94d1-9ab451b537ea	SIU VIÊN	04/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai	229ebe21-a1f4-4762-992e-525d59e56343	2026-05-12 09:22:24.602551+00
0976a2b2-df07-4a73-9946-412612424f1d	Lương Hà Anh	09/07/2008	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Đức Cơ - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
b2f6f704-d102-45dd-a0b5-26758f6e41ab	Nguyễn Thị Ngọc Anh	29/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3- xã Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
c77af04e-1242-456f-a514-6693fa024d89	Dương Văn Bảo	18/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Đức Cơ – Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
73450923-fc38-43d7-991b-5f3a647d16c8	Rah Lan H' Ru Bi	28/11/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le kăt, Xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
0a6d7f95-cc8d-4435-aa5a-36b39823896d	Kpuih H' Chúc	15/09/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông -  xã Đức Cơ - Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
574b63ff-eeb9-4786-98eb-241873f270e0	Nguyễn Sỹ Dũng	01/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Đức Cơ- Tỉnh Gia lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
77c23a2b-cd0a-44ee-a81a-a06b870cf4a3	Nguyễn Thị Thùy Dung	13/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia tang, Xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
290eaf84-3c23-4173-a78c-cd2d3cb6492f	Phạm Thị Thùy Dung	26/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6-xã Đức Cơ-Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
599bfe8e-7006-4b3f-b21a-87bd00b1c182	Nguyễn Thị Duyên	31/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
62285d9c-38cb-4af8-a324-94534f513eb1	Rơ Mah H' Điệp	01/08/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung, Ia Dơk, Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
80f79419-2fc5-4820-a421-f9154e19445d	Lê Đình Đức	13/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6- Đức Cơ – Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
fc275262-430d-4da7-a23c-022ab63c277b	Nguyễn Hồng Hạnh	05/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bua, xã Ia Pnôn, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
8b667bf1-371f-47d4-b2ae-0a0d8b47479d	Rơ Mah H' Hát	19/10/2007	Nữ	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung -Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
b52a5778-e49f-44f9-8b43-b725f0de46f3	Nguyễn Thị Hiền	12/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
7308445a-da1f-482f-8709-01c1c2ffe457	Nguyễn Thị Thu Hiền	14/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2,  Đức Cơ, Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
eebfeb02-2514-490c-a7f6-0ab56cda1fac	Vũ Hoàng Diệu Hiền	11/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6-  Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
fa564e91-5098-4cc1-b8c7-01a3f86bc3a1	Lê Thị Hoài	06/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
834dfe34-514e-4e5c-bf2e-acad85b05f0f	Phạm Đình Hùng	02/02/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4, xã Đức Cơ, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
704e82be-14aa-4c9e-b6e6-21221db0390d	Hà Thị Lan Hương	25/08/2008	Nữ	Thái	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krái, Xã Đức Cơ, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
d332c6a3-fd77-4d9b-b0ff-f48f2adbba2d	Lê Văn Khánh	10/05/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7- xã Đức Cơ-Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
710ff680-e390-4b05-b744-f0cf083f3b60	Trần Lê Ngọc Khánh	01/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn kết, Xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
4fb9f125-a131-4b66-a569-61fcdf12bc0f	Kpuih Khoa	11/12/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung le tung, Xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
13fc400b-75cd-4e2c-ae39-78a95473a6bb	Rơ Mah H' Lan	16/06/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang -xã Đức Cơ - Tỉnh  Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
68db9b44-4dfd-4246-9122-b26ddbb51682	Nguyễn Hải Lâm	01/12/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn ia lam- xã Iakrêl - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
7a21f75f-9069-42bd-92ef-4eccaf95279e	Rơ Châm H' Lệ	23/10/2008	Nữ	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	làng dơk ngol ,xã ia dơk , tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
6aa9bfa5-267e-42fc-a23f-48c899ca1713	Hồ Nguyễn Khánh Ly	21/07/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn kết, Xã Ia Dơk,  Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
fd8294ec-506f-459e-adcf-eb81949620e1	Vũ Thu Ly	25/05/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
c1acb526-3e8b-4c2e-848b-307afe569fbe	Hoàng Thị Diệu My	09/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Đường Tăng Bạt Hổ, Tổ dân phố 9,  Đức Cơ, Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
1eb55ad9-1670-497e-9be9-5e5721d59a35	Hồ Hoài Ngân	04/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ II - Ia Dơk - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
06fd8a1f-2d9c-4811-8b46-d9e9e5d4b715	Đinh Thái Nghĩa	28/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 -  Đức Cơ - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
947ecc0c-0c75-4d35-9c35-53376aeaf0c2	Đỗ Khánh Ngọc	04/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk-  Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
5ebb091d-4b72-4b51-a00f-f6e20ea3c3a3	Nguyễn Thị Khánh Ngọc	31/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - xã Đức Cơ – Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
619e6b07-57d6-42db-a9bc-67dba2fb8ad2	Vũ Phương Yến Ngọc	14/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung tung - Xã Iadơk- Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
1f9b0b48-425d-470f-9b7f-125a9cbc0387	Rơ Lan Nhung	28/09/2007	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung- xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
c7e449e4-bce0-4e84-a956-998dbd614b6c	Kpuih H' Như	20/04/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông-  Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
d8620b09-134e-4ba9-a771-8c9a4eb4122c	Kpuih H' Nhưng	10/11/2008	Nữ	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk- Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
8847dcd5-3c40-413c-a133-959eeb3a8f63	Nguyễn Thị Hồng Phương	14/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lâm Tôk- Xã Ia Dơk -Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
18ff09aa-e589-48dc-9b11-4820e56de3cd	Nguyễn Thị Ngọc Phượng	05/04/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
fb33b10d-c102-4621-a03a-17fa7ebb2c87	Nguyễn Mạnh Quân	28/10/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 – Đức Cơ – Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
7dc80fe6-879a-46d3-b591-28e0c855a09a	Lê Nam Thiên	24/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ 2, xã  Đức Cơ, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
a861e656-a41a-4e5a-a063-c086b7623e79	Lê Trường Thịnh	17/07/2007	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ , Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
7ea14206-1366-404c-be2e-3a0298234a81	Nguyễn Đình Tiến	06/01/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ DP 6 -  Đức Cơ - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
6fcfec44-bc0d-44cb-8ffc-374ead4f3c02	Rơ Lan Tiếp	08/07/2008	Nam	Gia-rai	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Đo, xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
7283e96c-1f59-4be0-a40d-ab706706cdd1	Quyền Đình Trọng	12/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
334489d1-089a-4f91-8f07-823040e87c5d	Rơ Mah H' Trúc	28/11/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Le - Ia Dơk-  Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
4916f32c-ad49-4de5-856c-5c3863e5c9c8	Rơ Mah Hà Trúc	09/08/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kắt - xã Ia Dơk - Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
e0edc71f-4062-481d-b33a-91c27b3352f3	Rơ Mah H' Vân	19/12/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le - xã Ia Dơk - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
19d342ec-1582-4b30-8b6e-663b1b43cdf6	Rơ Mah H' Vị	17/06/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép - xã Ia Dơk- Tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
682aeed5-50a8-4f7b-a5ee-e177c3574a74	Nguyễn Ngọc Vũ	25/04/2008	Nam	Kinh	\N	t	\N	22/04/2026	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9- Đức Cơ- Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
4fb0fd63-f0df-475f-a591-da49e0dde78e	Rơ Mah H' Y-Su-In	16/05/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Kép - IaDơk - Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
684c71ca-eba4-458c-ad36-103dc645c954	Hồ Thị Ngọc Yến	27/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tdp9 , Đức cơ , tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
fb8f6350-ffdc-45e3-9911-eeb52a9a5036	Nguyễn Thị Ngọc Yến	06/05/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn krel ,xã ia krel , tỉnh Gia Lai	e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	2026-05-12 09:22:24.602551+00
ed7e312a-7564-47a5-9b5a-a5dc783ff194	Phan Đình Hoàng Anh	24/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
c3ba3909-9292-4cd5-bd69-5c04924d20b7	Đặng Gia Bảo	20/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
95c89ce6-11a8-46c2-a7b4-32769ca279e2	Hoàng Gia Bảo	18/10/2008	Nam	Sán Dìu	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
b9dd1648-1a64-4d82-9f62-ee40fa59cd78	Nguyễn Trần Nhật Đang	16/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
3e09ffe2-3251-4410-bd8a-f756508da42b	Nguyễn Văn Định	27/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Kăm - Xã Ia Krêl - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
fc1f185b-65e4-4f9e-af81-b1226cb806f8	Lê Đại Đồng	15/03/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Xã Ia Krêl  - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
60ff55f3-0127-414c-ad7d-66fe55f45751	Nguyễn Hoàng Gia	18/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
9add7ffe-6fe1-4b4f-8bfa-e0eee6b4d8fa	Rơ Mah H' Hà	10/04/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Kắt - Xã Iadơk- Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
058616d3-c399-44e9-9364-375f37801ec9	Nguyễn Thu Hiền	22/07/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2 -Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
6e5665ef-6e11-4a3b-9c96-46ffd335bd9c	Rơ Lan H Khâm	06/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le Tung - Xã Iadơk- Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
5bf964c3-34f4-4a16-9dc2-4c28091194eb	Đỗ Đình Lâm	29/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lang - Ia Dơk - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
f57467ad-0414-43d9-96e8-e2a34f90fac5	Đinh Quang Lộc	01/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
8726ad8e-1d4a-4a82-99bb-2a1e97864936	Nguyễn Ngọc Mai	10/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
6456b219-8fe8-4807-af34-42510584655a	Lê Thị Trà My	06/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
baa61c14-72dd-4c7a-85ed-1cf0dcf1967d	Nguyễn Hà Thảo My	05/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
3d6d442b-ceaf-4f03-ab29-515f39170386	Trương Thị Thu Na	04/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
f58ab49f-7598-47e0-b396-e45828ccd392	Hồ Thị Thúy Nga	09/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
fd9a55fc-d15e-45c8-88c8-2f52323ad888	Kpuih Ngân	17/03/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol - Ia Dơk  - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
bc7a16d3-5999-4a49-8903-29b6600ea2af	Đào Trần Gia Như	08/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã Đức Cơ - GiaLai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
dc03343f-d05a-49f3-80a1-b9a456aaf6d9	Lê Hoàng Hạ Phương	10/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm - Ia Krêl - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
274732fe-9b2f-4c58-b2ea-e09557d16e17	Cao Thục Quyên	28/06/2008	Nữ	Kinh	\N	f	\N	-	0333481577	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
0ce477ff-000c-493e-8657-85ba696da77a	Rơ Mah H' Quỳnh	04/06/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp - Ia Krêl  - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
aa40083e-ac60-4437-a7cc-baf5bbddf312	Nguyễn Văn Sỹ	06/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Giáo - Ia Krêl - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
a30a0242-1aa9-4286-9b51-fb9ab2532af1	Mai Văn Tâm	17/11/2007	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Xã Đức Cơ- Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
cc69cfa1-b499-4450-8d13-077146e56618	Trần Thị Thảo	12/05/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
4aaec18d-29fe-41b7-93d6-4aea7184520f	Đặng Nguyễn Thu Thủy	02/11/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
1f866441-c18c-4146-95df-d3c3dff1a2b9	Hồ Ngọc Anh Thư	11/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
1b2cae98-51b2-4b57-9abe-fac72ae2f755	Nguyễn Xuân Tiến	05/04/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
7a72dafe-b4c8-4875-b64c-67ab8a92c061	Luyện Tiến Tình	23/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
55f5a8b9-7931-40c6-aa93-db70b2a3e5b0	Rơ Mah H’ Trang	21/01/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krai - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
8ea50331-9366-499f-aa0f-6162dc7225ba	Hoàng Thị Quế Trân	02/10/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
bc9b5d40-6f29-4146-b655-c990b138887b	Lê Khả Tuấn Tú	06/10/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
e30d2802-9808-45da-b94a-0facdabc5be7	Nguyễn Quốc Tuấn	19/08/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1 - Xã  Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
b5601210-e0b3-4595-9dba-9b5a16907dcd	Đặng Thị Khánh Uyên	30/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - Chư Ty - Đức Cơ - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
ea0d5399-ff21-45a9-8e71-37dfeaa8e0c2	Thái Hoàng Mỹ Uyên	20/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Lâm - Ia Krêl  - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
7e784915-6013-4638-b71e-1d98447779ad	Nguyễn Trương Anh Vũ	01/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang - Ia Dơk  - Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
d3f7f693-1e7e-4fec-8c1f-b692c2445cf7	Lê Nguyễn Thảo Vy	21/02/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Xã IaDơk- Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
f934e490-3b6d-423e-804f-a8b864e82361	Rơ Mah H' Yumi	20/11/2008	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Sung Le Kăt - Xã IaDơk- Gia Lai	df556f4e-09a0-4224-b29b-7d9912eef51c	2026-05-12 09:22:24.602551+00
14c33966-eb7f-4c8f-b68e-b6b0ad669a51	Hồ Hữu An	19/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố1 - xã- Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
150405df-6b9f-4350-9eed-4338258f1760	Hồ Văn An	18/11/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Lung Prông- xã Đức Cơ- Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
9c2649d4-56fe-4030-a29e-561cbcc14b95	Đinh Thị Ngọc Anh	13/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Klăh, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
c7e0ae11-c33f-41c5-9daf-a117d376b84b	Nông Hoàng Diệp Bình	07/07/2008	Nữ	Tày	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Chư Bồ 1, Xã Ia Dơk,Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
9c87607e-7ca6-472d-95be-5d69cd5f0d61	Rơ Mah Bom	19/01/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
2da050cb-837c-4ae2-908a-ada88b587c0f	Lê Khả Cơ	16/05/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Đoàn Kết, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
96f26a70-6f7c-4057-a6da-7b1ef6cfbe57	Nguyễn Văn Cường	26/10/2007	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Dơk Klăh, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
1b2edf02-23f1-4e13-ab7b-f85351a2e68f	Rơ Mah Dấu	14/11/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
008a5dbd-712f-4926-a81a-50bdf3ed0cac	Ksor H' Diệp	24/06/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Kép, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
d5be4bde-867a-4565-8921-8f31696d3a3e	Phạm Khánh Duy	30/12/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP2 - xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
a0fe15df-5c61-408e-86cf-549d5da8c43d	Hồ Vĩnh Hạnh	02/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
12fa9418-de6c-46ec-a964-e35ecb9edc9b	Lê Thị Hiền	22/05/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố I, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
0206e219-8a80-42d5-805d-bf01c85cbaf2	Châu Thanh Hoàng	06/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Kom Ngó, Ia Chia, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
1111bd8c-6237-421e-a367-65050a516027	Trần Gia Hưng	23/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim, Xã Ia Dơk ,Tỉnh Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
8fa7c4e8-6cca-46ea-a981-c5b675389b7a	Võ Duy Hưng	28/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 9 - xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
a850d326-cb83-478a-8102-f0d9f3dc4137	Đinh Thị Trúc Linh	09/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP3, xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
b363649a-ac7d-4ac8-8c24-b9c8d86aaab1	Nguyễn Lê Diệu Linh	03/06/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP1, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
e34c0db6-5029-4ba7-85e8-f4aae5253c31	Rơ Mah Luy	29/04/2008	Nam	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Hrang, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
374d5a3d-d752-4ab0-aee9-225e7a2d31d3	Hoàng Thị Mai	05/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
033cb953-7651-4760-a2fe-8f8107f64e56	Trương Anh Ngọc	04/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
bb00410e-aaa1-47a5-85a1-8d9fde8fc83e	Bùi Lê Trung Nguyên	01/01/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
d9b485a1-3425-4072-9f0a-742322637ecb	Kpuih Nhan	06/09/2007	Nữ	Gia-rai	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Dơk Ngol, xã Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
c6a6e459-cdaa-49d0-9984-2e00a5040fc0	Y Linh Nhi	20/06/2008	Nữ	Xơ-Đăng	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ghè,xã Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
3deeddee-7d78-4669-a0e2-d4faa7798f5b	Lê Thị Hồng Nhung	15/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp, xã Ia Krêl, Gia Lai.	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
51467f0e-4d5f-40a8-bf96-55508508c1ba	Đỗ Quỳnh Tố Như	23/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thanh Bình, xã Bàu Cạn, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
220a1f02-2531-45f8-b3d4-535fca700308	Lê Văn Phụng	26/06/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Chư bồ II - Ia Dơk - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
b80ab978-9f38-49a2-a332-6950aa80ea9c	Mai Văn Sơn	08/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
83a3d459-3160-4146-aa43-db710e4cbefa	Bùi Đức Tài	13/01/2007	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
72623726-80ae-486d-a92e-d460ceaa56a0	Trần Đức Tài	13/09/2008	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 6 - xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
bf195ab7-6ccd-4143-80c3-eda3acac3e26	Ngô Sỹ Thêm	17/08/2006	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Lâm Tốk, xã Ia Krêl, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
455ef4b7-a970-4741-aac9-e69853eb0834	Nguyễn Thị Kim Thu	11/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 2, xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
059eae2a-f1ba-4867-926d-bd16200e4314	Lê Thị Minh Thư	29/04/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng H'rang,, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
6403faa7-3680-4293-a35c-534336bb9d35	Lương Thị Thủy Tiên	10/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Lệ Kim, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
b365bd43-a0ee-4c15-87a8-a79bd2dfac39	Nguyễn Thành Tín	08/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
cd00b5fe-a754-4aeb-935f-3dbf242632ea	Hoàng Thị Bảo Trâm	11/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lệ Kim, Ia Dơk, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
52cfefb6-0c08-440c-86e3-c86da5b16b27	Phan Bảo Trâm	12/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3 - xã Đức Cơ - Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
7e7def31-180f-48ae-ac26-e1c2bfdb3122	Thái Tú Trinh	30/08/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Tiên Sơn 1, xã Biển Hồ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
6e70b5f4-dc64-4df6-8aea-5ab81448d66a	Trương Minh Vũ	11/11/2007	Nam	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
4c522fdc-89bd-4e89-a37e-a4936e4df026	Nguyễn Thị Hải Yến	04/06/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 1, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
d73c6488-a549-4b76-bd2f-03452c543c74	Trần Thị Hải Yến	03/09/2008	Nữ	Kinh	\N	f	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Tổ dân phố 3, xã Đức Cơ, Gia Lai	55ccbeef-a96a-4801-9bb9-c35f17e4b669	2026-05-12 09:22:24.602551+00
a2e6f727-2723-4a9a-a089-802abcd61cba	Dương Như Hoàng Anh	03/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Xã Đức cơ- Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
2bc71188-2e21-4ee3-be98-6e01407fbb6f	Đậu Tuấn Anh	31/12/2008	Nam	Kinh	Học sinh	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Xã Đức cơ- Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
5d18a729-2fda-43b1-830a-7ee0cec9d16c	Đinh Hải Anh	19/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
b76f868c-e8b2-4cc6-a298-99683cbc4c3e	Trần Ngọc Ánh	12/09/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
ae7a276f-457c-437f-a6b0-82ceb85963a0	Rơ Mah H' AYưng	24/01/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Khóp - Xã Ia Krêl - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
8c7a8e3c-8908-4883-906b-d321cc8b39ad	Trần Nguyễn Gia Bảo	10/03/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
255fe3e4-436d-4c19-a273-5df6d4653f02	Lê Thái Châu	22/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
07aa6a8b-086b-4d13-9ec3-913f94f56b48	Nguyễn Công Chiến	15/09/2006	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
fe7d8d12-ead5-4e9e-b3dc-f67b3cd98abf	Trần Thị Chính	26/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
c2dc43b6-b5a9-4a99-902c-49df6f766efb	Lê Tiến Công	12/05/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
5a399d98-5ded-4f87-b070-30f085c0a6ab	Kpuih H' Diệu	23/03/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Ấp - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
3e4602d7-2ad8-44a6-9312-335944b522f6	Rơ Mah H' Diệu	23/01/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Dơk Ngol- Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
e6adb3fb-4723-41cc-98f3-fdb59df02f6e	Lê Thị Anh Đào	30/01/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
4d626697-e13f-49e0-ae30-f4613d914a60	Ksor Ngọc Hân	26/07/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Đo - Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
c4927323-f9e3-4508-9481-29152c998750	Lương Gia Hân	29/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
aeaea097-7978-474c-8e22-f75e61edd9e3	Nguyễn Công Hiếu	31/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang, Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
17b9b051-0840-42d7-b24c-e5babecbffb9	Nguyễn Huy Hoàng	21/11/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
e44ffc63-2f34-4978-9ef0-7a24f4be7991	Nguyễn Ngọc Hùng	17/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
ad282049-b031-40c4-87db-baa62244e8ba	Lê Khanh	26/06/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 6 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
dc117896-565f-4b45-b30f-7537045b2650	Ksor Khởi	24/05/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Sung Le - Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
d79d9c09-06b7-433b-aa09-3b71ddfda971	Lê Thị Thúy Kiều	24/02/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
9ea458a8-3a8c-4a98-957b-b59b2dbb5774	Hoàng Thị Khánh Linh	25/11/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
d7591e81-decb-455d-8507-9dbcf86a2256	Trịnh Hoàng Long	09/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
573a97fe-cb1f-4ce2-b4b6-0c5850ab5781	Rơ Lan Hoa Mai	22/11/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Poong - Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
697f9a0f-771a-4543-9e8d-616a45c0de4c	Nguyễn Văn Mạnh	10/07/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
5d6fd2a8-c734-4633-873f-4e1cce2cfbb4	Rơ Châm Trung Nguyên	03/07/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Bi - Xã Ia Dom - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
f03afd70-d75a-4d71-b6fe-b967f3239f36	Kpuih H' Nhàn	31/01/2008	Nữ	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
d9cd1cf2-d3f9-4427-8695-663a992c6862	Văn Đức Hoàng Phúc	30/09/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
b5586f38-7c69-4030-98c8-67304731a692	Vũ Văn Quân	29/04/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
3c3569a3-5752-47c8-b0b3-d16069bdf7af	Nguyễn Từ Tài	16/09/2007	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
12744730-e4f9-4100-999c-e86e8c9253bd	Đoàn Thị Mỹ Tâm	06/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
42b8e56a-0d69-4ed8-95b4-9d045818df69	Lưu Thị Phương Thảo	18/03/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Lâm Tôk - Xã Ia Krêl - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
14465561-c187-4813-80e2-7b2caf940904	Mai Thị Thảo	07/04/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
a290b108-5918-45c1-9d34-191c7416b01f	Vũ Thị Thu Thảo	24/10/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
541fd2b0-73b3-4768-89e1-ddcf21f96b4a	Ksor Thịnh	08/07/2008	Nam	Gia-rai	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	Làng Krol - Xã Ia Krêl - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
673d72ba-07ac-4b62-84ba-6fe5b968eb4a	Nguyễn Thị Cẩm Tú	05/12/2008	Nữ	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
8f3ca421-78f8-44e3-9174-0f443197b06b	Hồ Đức Việt	23/01/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
a3fd24db-ea8a-4669-96bd-f8770811a1b2	Nguyễn Quốc Việt	20/12/2008	Nam	Kinh	\N	t	\N	-	\N	\N	2026-05-12 09:22:24.602551+00	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai	f9f7ba97-9aba-4cd0-bb64-74567c927c56	2026-05-12 09:22:24.602551+00
\.


--
-- Data for Name: dotptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."dotptdoanvien" ("id", "namhoc", "hocky", "tendot", "tungay", "denngay", "isdefault", "islocked", "ghichu", "updatedat", "createdat") FROM stdin;
\.


--
-- Data for Name: duytricsdl; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."duytricsdl" ("id", "so", "thoigian", "createdat", "updatedat") FROM stdin;
1b671eeb-04c9-417a-8bd7-b1aba8f07518	53	2026-04-29 13:45:42.476892+00	2026-05-10 03:15:08.557405+00	2026-05-12 09:34:31.215618+00
\.


--
-- Data for Name: github_settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."github_settings" ("id", "github_repo_path", "github_branch", "github_workflow_file", "github_restore_workflow_file", "github_token", "updated_at", "updated_by", "createdat", "updatedat") FROM stdin;
default	hohuuthe/SAOLUU_CSDL_QL_THIDUA_CHUANCSDL	main	supabase-backup.yml	supabase-restore.yml	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	2026-05-02 09:35:07.76+00	Admin	2026-05-10 03:14:45.814898+00	2026-05-10 03:17:45.987101+00
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tennamhoc", "islocked", "updatedat", "createdat", "isdefault") FROM stdin;
9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2025-2026	f	2026-05-12 09:15:26.299107+00	2026-05-12 09:15:01.271856+00	f
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocky", "tuan", "lopcham", "chamlop", "updatedat", "namhoc", "createdat") FROM stdin;
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "quyen_chi_doan_phu_trach", "ngay_cap_nhat", "nam_hoc", "quyen_xem_tat_ca_chi_doan", "createdat", "updatedat") FROM stdin;
\.


--
-- Data for Name: ptdoanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ptdoanvien" ("id", "doanvien_id", "dotdangki", "thongkerenluyen", "diemrenluyen", "pheduyet", "createdat", "updatedat", "namhoc", "soquyetdinh", "ngayquyetdinh") FROM stdin;
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoihoc", "ban", "phonghoc", "bithu", "gvcn", "namhoc", "updatedat", "createdat") FROM stdin;
35e180f6-6d54-4a30-a1ac-a55760d259f7	10A1	Chiều	TN	11	Nguyễn Khánh Linh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
2ad031fd-d814-44c0-a31a-144fd9b75bce	10A2	Chiều	TN	10	Lê Hồ Hoài An	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
4c6892d9-08b6-40c7-90fb-357745b185c6	10A3	Chiều	TN	9	Nguyễn Thị Trâm Anh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
d310f4db-72b5-4ec3-9200-ae53af36051f	10A4	Chiều	TN	8	Phạm Hà Anh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
4dec191f-67f7-40e1-ae29-1f402c50c046	10A5	Chiều	XH	7	Nguyễn Thị Minh Hằng	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
515ff95e-a824-473a-82ee-0aa2f9cd1bd4	10A6	Chiều	XH	1	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
3e472426-2282-4407-82c2-331bf418fc7f	10A7	Chiều	XH	2	Phạm Khánh Chi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
0752aefe-02d6-410a-84a7-40260303f0a3	10A8	Chiều	XH	3	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
8eddec37-5c16-40a8-83af-5c94fd6ac02e	10A9	Chiều	XH	4	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
bf3de950-ced7-4bb1-b8a2-4433a53e4e29	10A10	Chiều	XH	5	Hồ Thị Ngọc Trâm	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
7ba87a2c-261e-454b-8c9d-bb35fd06eed7	10A11	Chiều	XH	6	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
29ad20ee-673d-4c83-8589-7bb0dee8d6d1	11C1	Chiều	TN	12	Lê Minh Phương	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
1868a20c-490f-4db2-bc22-d85f4f69b497	11C2	Chiều	TN	13	Nguyễn Thị Yến Nhi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
3ab3bcb4-3575-43c6-95ae-73f824b28ef3	11C3	Chiều	TN	14	Phạm Minh Anh	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
b810e758-01b0-43f5-aa70-8a9088efa2fd	11C4	Chiều	TN	15	Cù Hoàng Gia An	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
f603988f-cb60-4443-940a-d3c0116c784c	11C5	Chiều	TN	16	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
49482452-f8a6-4345-a1e6-0506a641cd2f	11C6	Sáng	XH	1	Vũ Đỗ Thùy Lâm	Trần Thị Huệ	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
0372fedc-3ce9-4484-823e-d7587838ca34	11C7	Sáng	XH	2	nguyễn hồng lai	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
473ec1ae-2792-4f8f-a2dd-f5803b44186a	11C8	Sáng	XH	3	Nguyễn Trung Hiếu	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
70924dff-ae3f-4737-bc36-34503d81d2f0	11C9	Sáng	XH	4	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
008cbea1-c7e3-439d-b74b-b9cc5b4bd4d9	11C10	Sáng	XH	5	Nguyễn Ngọc Tiên Nhi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
a9b2b57f-b578-4799-a790-c951def81dc4	11C11	Sáng	XH	6	Bùi Thị Tường Vy	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
d9432471-04ff-4bae-b307-ca83ee8907c2	11C12	Sáng	XH	7	Nguyễn Thị Ngọc Hân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
954194a1-bde4-41fc-8fc2-196f4f77c43c	12B1	Sáng	TN	8	Phạm Ngọc Gia Hân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
0759f20d-917b-497c-a424-c1c80b3a9eee	12B2	Sáng	TN	9	Hoàng Thị Thu Huyền	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
4f330808-8e49-4958-a90d-945234bd6d66	12B3	Sáng	TN	10	Nguyễn Gia Hân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
362d1fb7-681a-4425-a1d9-7b5cbe3243b5	12B4	Sáng	TN	11	\N	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
f9353b84-a3a8-49bf-b97f-e1fd07619c34	12B5	Sáng	XH	12	Hoàng Thị Quỳnh Chi	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
229ebe21-a1f4-4762-992e-525d59e56343	12B6	Sáng	XH	13	Nguyễn Thanh Phương	Nguyễn Thị Thảo Trinh	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
e0afda5e-6ef5-495d-8ba7-9cfddff28e6a	12B7	Sáng	XH	14	Trần Lê Ngọc Khánh	Võ Thị Bình	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
df556f4e-09a0-4224-b29b-7d9912eef51c	12B8	Sáng	XH	15	Quế Trân	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
55ccbeef-a96a-4801-9bb9-c35f17e4b669	12B9	Sáng	XH	16	Thành Tín	\N	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
f9f7ba97-9aba-4cd0-bb64-74567c927c56	12B10	Sáng	XH	17	Lê Tiến Công	Đoàn Thị Minh Hương	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:21:22.021491+00	2026-05-12 09:21:22.021491+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemsan", "aiprompttemplate", "geminiapikey", "diemsanhocky", "aiassistantprompt", "thongbaochamdiem", "doituongthongbao", "noidungthongbao", "thongbaodoanvien", "autopenaltytime", "autopenaltypoints", "autopenaltycriteria", "autopenaltyenabled", "autopenaltyreporter", "autopenaltyday", "thongbaophattriendoan", "excel_header_left", "excel_header_right", "excel_footer_left", "excel_footer_right", "word_header_left", "word_header_right", "word_footer_left", "word_footer_right", "namhoc", "createdat", "updatedat") FROM stdin;
a951e84c-f203-4360-bf8a-be53d6e40e50	HỆ THỐNG QUẢN LÝ THI ĐUA	Đoàn trường THPT Lê Hoàn	300		AIzaSyCGNOkoySDC6TidMBGlVGYFzEbgg47xNjM	100		\N	\N	\N	\N	23:55	30	Lỗi không báo cáo điểm tuần	t	Hệ thống tự động	0		[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n[C][B]Độc lập - Tự do - Hạnh phúc	[C][B]NGƯỜI LẬP BIỂU\n[C][I](Ký và ghi rõ họ tên)\n\n\n\n[C]{{HOTEN}}	[C][I]Đức Cơ, {{FULL_DATE}}\n[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\nLê Trung Thành	[C]ĐOÀN XÃ ĐỨC CƠ\n[C][B]ĐOÀN TRƯỜNG THPT LÊ HOÀN\n[C]***\n[C]Số:        -BC/ĐTN	[C][B]ĐOÀN TNCS HỒ CHÍ MINH\n[C][B][U]Độc lập - Tự do - Hạnh phúc\n[C][I]Đức Cơ, {{FULL_DATE}}	[L][B]NƠI NHẬN:\n[L]- Như Điều 1;\n[L]- Lưu VT.	[C][B]TM. BAN CHẤP HÀNH\n[C][B]BÍ THƯ\n\n\n\n[C][B]Lê Trung Thành	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:17:29.603726+00	2026-05-12 09:17:29.603726+00
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullname", "role", "updatedat", "chidoan_id", "createdat") FROM stdin;
e53e265f-5ccd-443f-ac69-3b584e15b835	Admin	$argon2id$v=19$m=65536,t=3,p=4$72TKLZSr/rHbaoUyipV9iQ$eKmDYt6MHzo45CV+i8k33nfuSHugs8T0cHO0bry1vME	HHT-Admin	Admin	2026-05-10 03:34:02.030928+00	\N	2026-05-10 03:34:02.030928+00
0e0584f9-3832-4d51-b3a0-c454b2eab7cb	hohuuthe	$argon2id$v=19$m=65536,t=3,p=4$PUDXJllthdBNREj7Jd2KTw$blk3GJ2W6Jk/+OxXqPO9quBJtU9mjQqcHb6rYNmBxjM	Quản trị	BT	2026-05-11 13:56:17.96495+00	\N	2026-05-10 08:16:35.124027+00
a183028d-91ec-4df6-8618-c3ff3317eb57	Quet	$argon2id$v=19$m=65536,t=3,p=4$uTdDfKZp6aZSh6hcx1e5gA$Lh29TBwBBJCh9Q0aBEVHYxW5hBrqxBNWFWfKCaPRqyU	Ksor H Quet	BTV	2026-04-01 01:21:20.059+00	\N	2026-05-10 03:12:23.35086+00
edfbd9cb-15c5-42f8-b51a-e6d90f02fb0b	Letrungthanhbtv	$argon2id$v=19$m=65536,t=3,p=4$7aDAvPslz8ibeTD/gb9zjg$bQfwrr3EqOBNqZoxgyF77g2nIZNcM5T7qm3gjWtbbIg	Lê Trung Thành -Bí thư ĐT	BTV	2026-03-26 07:42:27.886+00	\N	2026-05-10 03:12:23.35086+00
a9bad279-3cdc-4762-9b5f-cd6d5c1a2608	Leminhphuongbtv	$argon2id$v=19$m=65536,t=3,p=4$Y5lYDc9Had+EJM/PWm5qJg$c8+0lKGVEPdXzzpdycZ0PxEtEIEL7ZARyIXE2HljcBo	Lê Minh Phương BTV	BTV	2026-03-28 22:36:04.141+00	\N	2026-05-10 03:12:23.35086+00
fe1ed425-96ce-49db-96b5-57f36b7acd91	Tranthithuytam	$argon2id$v=19$m=65536,t=3,p=4$bkPCIo+4RA3SG6cN1PFGKQ$sXwdHUWz4LBsxqAaQa54NQsVQeTOrhv1HGejsiXVwMM	Trần Thị Thủy Tâm - Phó BT ĐT	BTV	2026-03-26 07:42:51.396+00	\N	2026-05-10 03:12:23.35086+00
faf551e3-c757-4078-a239-fa5823211ee0	Nguyengiahanbtv	$argon2id$v=19$m=65536,t=3,p=4$w+X6XyZlE1xqKRaCOb3V2g$oe7AMmeni3pBDapc1WuMe+DhgZPCSTKD10TS7whA+7o	Nguyễn Gia Hân (BTV)	BTV	2026-03-29 07:58:50.656+00	\N	2026-05-10 03:12:23.35086+00
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "matieuchi", "tentieuchi", "mota", "loaitieuchi", "diemtru", "diemcong", "ghichu", "updatedat", "hocky", "namhoc", "createdat") FROM stdin;
85086f75-c692-49de-82d9-3104c4d3797c	TC01	Đi học muộn		Vi phạm	2	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
ff82ecc2-5093-445f-acc2-44cd74258bba	TC02	Cúp tiết		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
58769233-b7fb-4117-b0ba-0faf29891c71	TC03	Cúp chào cờ		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
faaba6cb-f3d3-4ab7-8aa5-085c3d01dda0	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
5d6ce834-e7f6-4d6c-a331-6bb87a13a8c5	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
7dc362e3-1be0-4bbe-b2c5-88a48730cae0	TC06	Không sơ vin		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
a7af4080-a6f3-4e77-9ec6-5379b2bab747	TC07	Không bảng tên		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
6c8fa5a3-0a8d-4f0f-b02f-243fce0b2403	TC08	Sai đồng phục		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
88501e36-b04b-43c8-a690-b2383f4736e0	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
dde810a8-09aa-4d48-bad8-2f80c9d51094	TC10	Không quai dép		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
4b0fc795-0635-4c2b-8cb3-491abb9cb707	TC11	Đi dép lê		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
0dae7eb5-4cfe-4925-a571-f04d9a70246d	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
0b4dac94-8f7e-4a4a-905f-0fcf447d79f1	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
ebf59696-6d9f-4fde-90c1-26240c06c0be	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
9edf1c48-df55-40e7-ab27-5610b6ffb47a	TC15	Sơn móng tay		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
cd174f50-3d22-4515-8e5e-c6ca2ba059a1	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
4ef97718-4bcf-40ba-a5a4-23f9e36fd77a	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
fde970b1-266e-484f-aaea-91d9d88a6fe7	TC18	chở quá số người qui định		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
b5028658-2aa3-46b1-955a-0e701f62a386	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
95f806d7-e6c9-4ae5-ba3b-6fd387a3c73c	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
42f82f39-85b8-460b-91e7-a2958c35af09	TC21	Hút thuốc lá		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
208693c8-b34e-45aa-b1df-56fadb900e32	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
c70e4dd0-9430-4627-a0c5-01e9a7c2dff2	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
35297fc2-611b-45e9-b775-db2d908802cb	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
e1ac81b0-cf9b-4911-a6c1-8355a612fe39	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
735a6aa3-f9be-45c4-8ae3-0a6da1e0a1af	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
365e7a00-16e3-44fb-8bee-28851f3c50bd	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
c04f671b-a783-474b-a4c1-700ca4a8b21c	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
23a36e86-940d-47ba-a27f-163dec49c593	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
9a2f3a89-80b6-4a19-aa74-2edbaf076768	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
5bd60e17-35d9-4bb0-8c79-f50ce248d3bc	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
b4fd4c52-b5f9-4dc2-aa20-7fc31787eb01	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
e927d0f1-05d5-44b7-b01b-04099655ea42	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
158da324-4d05-4f92-984d-06c7939656ed	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
905c648c-def7-4f19-9428-0278bb763856	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
0b95b56a-acfe-4338-8c91-359b0c119616	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
358fd96e-01cf-4190-8c54-623f67a48a50	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
59845a5a-7933-4dd4-b824-71080ce0ac2a	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
36ef315f-7740-4ae2-9de8-466cbfe21fc6	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
5bd709b6-266a-42cb-9592-d8c93b0ae60a	TC40	Đi chấm trễ		Vi phạm	2	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
13ea8b25-2ef5-423c-aeb5-d59debfdc6bb	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
72fbe252-f870-405d-9661-735651b0a17a	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
a2c9eb12-cf0d-439f-96fd-fa3905463490	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
da59237b-08e9-4580-b021-9ff74b56be52	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
f3cde0c7-2966-4520-8f0b-2a107896158a	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
80531733-8365-4894-9731-0d3d775e51c2	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
27b04794-2881-4411-80c8-974a3b0be4b0	TC47	Học sinh tham gia đăng bài có nội dung xuyên tạc nói xấu nhà nước, cơ quan chức năng, đơn vị, xúc phạm nhân phẩm danh dự người khác vi phạm pháp luật, gây mất đoàn kết (nếu có bằng chứng).		Vi phạm	50	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
1f103153-1ff8-42a3-9fbe-fd06c2576976	TC48	Vắng học trên 3 buổi		Vi phạm	0	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
188b4e24-df89-40fd-b848-16b2573c87d6	TC49	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
03b44675-5a43-4418-857e-c4e3915a1d83	TC50	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	mang đồ ăn/ nước uống (trừ sữa, nước lọc) hoặc ăn/ uống trong lớp.	Vi phạm	10	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
ab1e0d01-cc45-4e06-9895-d0a318b22d05	TC51	Lỗi không báo cáo điểm tuần		Vi phạm	30	0	Hệ thống tự trừ	2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
345f4704-61e4-4f62-8a29-6274d9756f76	TC52	Không đi chấm		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
dd379aae-f5c5-48e3-a10f-fa809568abc7	TC53	Trực cầu thang bẩn		Vi phạm	5	0		2026-05-12 09:25:39.370239+00	HK2	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:25:39.370239+00
59c3cd72-f3d1-49a7-ba42-bc934461b03a	TC01	Đi học muộn		Vi phạm	2	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
27c68d4d-2190-4d1c-a35a-e66d7c9618da	TC02	Cúp tiết		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
dbf45f2a-b8f4-4d72-9428-80b964fef01f	TC03	Cúp chào cờ		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
ba074f38-9128-481b-832c-ca23b6c5e6e0	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
a436564a-1e1e-4834-9076-a20418f1e493	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
6ce72e8a-b7b6-4547-9d01-d4706653a9ef	TC06	Không sơ vin		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
244e0392-e86e-437b-96f4-754de8de0ae7	TC07	Không bảng tên		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
e52ca63b-b1f6-4bda-83bd-d146b4f0a4d7	TC08	Sai đồng phục		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
9ea606f3-b6fb-45ef-8283-08fe18d3ac56	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
bba784cd-2eaf-441c-867d-587a64bf05e2	TC10	Không quai dép		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
1ec2b121-e2e4-4413-a3db-cd678b29eec5	TC11	Đi dép lê		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
d0103145-a0a0-41fa-abef-8ed5ec38acbe	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
2ea52001-20b9-4044-ac51-b7be08833927	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
4c02e28c-b8f8-4053-9a63-ff5dae698c84	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
bdbb815f-c47a-45bf-b356-b4b2658f4bfb	TC15	Sơn móng tay		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
c4f2c27c-a333-4136-a2a8-e892c1932fb5	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
56412ae7-ef00-45d5-a54e-ee6bb93bbf29	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
1b4bb06f-62fa-4e67-a04e-d9c3865f32af	TC18	chở quá số người qui định		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
e1c12b07-f820-4ebb-86d0-46ea0f8b919c	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
9d5bb2ce-0d37-415c-987d-7d0dec8db44b	TC20	Học sinh để xe không đúng quy định		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
6b216f7e-ef24-4323-bc03-93a7ef463dc2	TC21	Hút thuốc lá		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
bf5448df-8965-4ee1-9b43-d29c33f5ab3a	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
e8776f1b-9d3e-477a-81c7-760eb36c1791	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
4d93d3b2-3eb7-440d-aab0-65335f4c6e5b	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
ca372e37-abf3-4d6f-bb88-00fca5182565	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
1728601d-6800-494f-9b5a-ea09f11224ce	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
909c0a1a-6870-49bd-84f5-710e0e32ab07	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
9d669627-bd48-48b2-a094-d347a133fcb2	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
ed6a290e-e160-49d8-a14f-093cdd0846c8	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
e7c585ce-0db1-4fc2-a785-86aed3dda542	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
cb81e35d-179d-4156-a3b6-cd765e5be2ea	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
afd6a4b9-2c5b-4483-b24a-fd264697bd5a	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
450bb1cf-05e8-4a4f-86fb-4de5665081fa	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
938456d2-bc8f-4129-a6e2-33884b1dc209	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
2b43fe07-1558-464a-9f7c-54690c9e7c59	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
afd2b3ea-4bef-42dd-bb82-6522e09c741b	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
f10deeec-1834-44b5-97a8-44ed2be5abc8	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
2490830f-601d-477e-a321-027ee9ba4cc7	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
7d671d3a-8667-46d1-aef9-c2250ddaa0ba	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
e3605971-a9e0-4529-b09c-8443c4e3d17a	TC40	Đi chấm trễ		Vi phạm	2	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
959bd294-4aee-456d-8682-577d75f51472	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
5931cf31-997b-49c4-baba-b38b7c5e3f7a	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
386b9915-7d8f-4cf5-aeeb-8bbb5bcb0d13	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
9b93f085-5ee8-4833-b61f-3c2d53b94326	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
a02603c7-613b-4c4d-8e3e-9116994e4932	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
20f9e5cb-d1b4-4f53-a280-4d7946e396cd	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-05-12 09:32:33.09602+00	HK1	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	2026-05-12 09:32:33.09602+00
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namhoc", "hocky", "tuan", "tungay", "denngay", "isdefault", "islocked", "createdat", "ghichu", "updatedat") FROM stdin;
a439c914-a93e-45f4-82bc-3ca5d0f54afd	9a50c85c-29dd-4dbd-ac2d-1f2fb1b0b280	HK2	33	2026-05-04	2026-05-10	f	t	2026-05-12 09:18:53.018693+00		2026-05-12 09:18:54.60135+00
\.


--
-- Data for Name: messages_2026_05_09; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_09" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_10; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_10" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_11; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_11" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_12; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_12" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_13; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_13" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_14; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_14" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_05_15; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_05_15" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-03-29 11:07:20
20211116045059	2026-03-29 11:07:20
20211116050929	2026-03-29 11:07:20
20211116051442	2026-03-29 11:07:20
20211116212300	2026-03-29 11:07:20
20211116213355	2026-03-29 11:07:20
20211116213934	2026-03-29 11:07:20
20211116214523	2026-03-29 11:07:20
20211122062447	2026-03-29 11:07:20
20211124070109	2026-03-29 11:07:20
20211202204204	2026-03-29 11:07:20
20211202204605	2026-03-29 11:07:20
20211210212804	2026-03-29 11:07:20
20211228014915	2026-03-29 11:07:20
20220107221237	2026-03-29 11:07:20
20220228202821	2026-03-29 11:07:20
20220312004840	2026-03-29 11:07:20
20220603231003	2026-03-29 11:07:20
20220603232444	2026-03-29 11:07:20
20220615214548	2026-03-29 11:07:20
20220712093339	2026-03-29 11:07:20
20220908172859	2026-03-29 11:07:20
20220916233421	2026-03-29 11:07:20
20230119133233	2026-03-29 11:07:20
20230128025114	2026-03-29 11:07:20
20230128025212	2026-03-29 11:07:20
20230227211149	2026-03-29 11:07:21
20230228184745	2026-03-29 11:07:21
20230308225145	2026-03-29 11:07:21
20230328144023	2026-03-29 11:07:21
20231018144023	2026-03-29 11:07:21
20231204144023	2026-03-29 11:07:21
20231204144024	2026-03-29 11:07:21
20231204144025	2026-03-29 11:07:21
20240108234812	2026-03-29 11:07:21
20240109165339	2026-03-29 11:07:21
20240227174441	2026-03-29 11:07:21
20240311171622	2026-03-29 12:35:40
20240321100241	2026-03-29 12:35:41
20240401105812	2026-03-29 12:35:41
20240418121054	2026-03-29 12:35:41
20240523004032	2026-03-29 12:35:41
20240618124746	2026-03-29 12:35:41
20240801235015	2026-03-29 12:35:41
20240805133720	2026-03-29 12:35:41
20240827160934	2026-03-29 12:35:41
20240919163303	2026-03-29 12:35:41
20240919163305	2026-03-29 12:35:41
20241019105805	2026-03-29 12:35:41
20241030150047	2026-03-29 12:35:41
20241108114728	2026-03-29 12:35:41
20241121104152	2026-03-29 12:35:41
20241130184212	2026-03-29 12:35:41
20241220035512	2026-03-29 12:35:41
20241220123912	2026-03-29 12:35:41
20241224161212	2026-03-29 12:35:41
20250107150512	2026-03-29 12:35:41
20250110162412	2026-03-29 12:35:41
20250123174212	2026-03-29 12:35:41
20250128220012	2026-03-29 12:35:41
20250506224012	2026-03-29 12:35:41
20250523164012	2026-03-29 12:35:41
20250714121412	2026-03-29 12:35:41
20250905041441	2026-03-29 12:35:41
20251103001201	2026-03-29 12:35:41
20251120212548	2026-03-29 12:35:41
20251120215549	2026-03-29 12:35:41
20260218120000	2026-03-29 12:35:41
20260326120000	2026-05-03 11:13:24
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter") FROM stdin;
103190	ce903234-4de5-11f1-a374-0a58a9feac02	"public"."dotptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:43.404549	*
102580	bb9dd64e-4de1-11f1-9f6b-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:05:33.643342	*
102573	bb9d688a-4de1-11f1-936c-0a58a9feac02	"public"."phanquyen"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:05:33.632495	*
103191	ce90cbc2-4de5-11f1-a21b-0a58a9feac02	"public"."tieuchitd"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:43.408245	*
102926	9925c246-4de3-11f1-8b7b-0a58a9feac02	"public"."dotptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:18:54.798776	*
102582	be58ae9a-4de1-11f1-a279-0a58a9feac02	"public"."taikhoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:05:38.214717	*
103212	f299111e-4de5-11f1-af73-0a58a9feac02	"public"."phanquyen"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:43.86032	*
103214	f29a199c-4de5-11f1-9fdb-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:43.866877	*
103216	f29ae9c6-4de5-11f1-89c8-0a58a9feac02	"public"."settings"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:43.872393	*
102927	99265cce-4de3-11f1-a770-0a58a9feac02	"public"."tieuchitd"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:18:54.802738	*
102933	997da3a8-4de3-11f1-bf63-0a58a9feac02	"public"."phancong"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:18:55.374704	*
102845	66a5dfb8-4de3-11f1-8eea-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:17:30.076359	*
102847	66a6c13a-4de3-11f1-be1a-0a58a9feac02	"public"."settings"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:17:30.099533	*
102849	66a79254-4de3-11f1-9732-0a58a9feac02	"public"."taikhoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:17:30.105246	*
102934	997e0be0-4de3-11f1-bb11-0a58a9feac02	"public"."chamdiem"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:18:55.37792	*
103213	f2999f80-4de5-11f1-a012-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:43.863876	*
103215	f29a7e82-4de5-11f1-b842-0a58a9feac02	"public"."tuanhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:43.869548	*
102846	66a65812-4de3-11f1-a063-0a58a9feac02	"public"."tuanhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:17:30.078973	*
103223	f4d2ed2e-4de5-11f1-b516-0a58a9feac02	"public"."qlchidoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:47.594973	*
103164	bedde408-4de5-11f1-8721-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:17.071745	*
103166	bedfc9da-4de5-11f1-9437-0a58a9feac02	"public"."tuanhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:17.086158	*
103224	f4d3a430-4de5-11f1-ab18-0a58a9feac02	"public"."doanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:47.599552	*
103234	f92a9f34-4de5-11f1-a19f-0a58a9feac02	"public"."chamdiem"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:54.880739	*
103235	fb0a0fa6-4de5-11f1-aa27-0a58a9feac02	"public"."dotptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:58.022551	*
103163	bedc9ce2-4de5-11f1-91df-0a58a9feac02	"public"."phanquyen"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:17.064351	*
103165	bedf3600-4de5-11f1-86f2-0a58a9feac02	"public"."namhoc"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:17.083061	*
103225	f4d435c6-4de5-11f1-bed7-0a58a9feac02	"public"."ptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:47.604199	*
103229	f4f33b2e-4de5-11f1-b9a0-0a58a9feac02	"public"."taikhoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:47.807445	*
103167	bee05e68-4de5-11f1-bbb2-0a58a9feac02	"public"."settings"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:17.092908	*
103231	f4f4c908-4de5-11f1-904a-0a58a9feac02	"public"."phancong"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:47.81767	*
103233	f531849c-4de5-11f1-8e86-0a58a9feac02	"public"."taikhoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:48.214876	*
103236	fb0acc98-4de5-11f1-9f7c-0a58a9feac02	"public"."tieuchitd"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778549292}], "aud": "authenticated", "exp": 1778580301, "iat": 1778576701, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "role": "authenticated", "email": "admin@gioithieu.com", "phone": "", "session_id": "783deb18-7bf3-40eb-a947-a89bf6ed8d04", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "39c8bd8e-417e-4f88-bf13-f8800858bdbe", "email": "admin@gioithieu.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:35:58.028176	*
103175	c1276ba8-4de5-11f1-b53d-0a58a9feac02	"public"."doanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:20.90728	*
103182	c1578702-4de5-11f1-9753-0a58a9feac02	"public"."phancong"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:21.231082	*
103184	c1e96ffa-4de5-11f1-817e-0a58a9feac02	"public"."taikhoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:22.178936	*
103185	c609fe4c-4de5-11f1-9898-0a58a9feac02	"public"."chamdiem"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:29.103119	*
103174	c126d206-4de5-11f1-a364-0a58a9feac02	"public"."qlchidoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:20.9033	*
103176	c127fe1a-4de5-11f1-9fc8-0a58a9feac02	"public"."ptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:20.915275	*
103180	c1563668-4de5-11f1-9f68-0a58a9feac02	"public"."taikhoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:34:21.21397	*
102806	1d7f58f0-4de3-11f1-bb03-0a58a9feac02	"public"."doanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:15:27.350865	*
102805	1d7ef6c6-4de3-11f1-9bd6-0a58a9feac02	"public"."qlchidoan"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:15:27.349071	*
102807	1d7fa58a-4de3-11f1-89ed-0a58a9feac02	"public"."ptdoanvien"	{}	{"aal": "aal1", "amr": [{"method": "password", "timestamp": 1778576576}], "aud": "authenticated", "exp": 1778580176, "iat": 1778576576, "iss": "https://olxebyzmyddwtwxzhire.supabase.co/auth/v1", "sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "role": "authenticated", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "phone": "", "session_id": "24af1d8d-05ef-498b-b41b-4e9d1c7967f4", "app_metadata": {"provider": "email", "providers": ["email"]}, "is_anonymous": false, "user_metadata": {"sub": "c869d8ce-23e0-47e9-b7b8-7678ddd70597", "email": "admin@cbd5968c-0aa3-4b00-9b98-9fcfc7755304.com", "email_verified": true, "phone_verified": false}}	2026-05-12 09:15:27.354673	*
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-03-29 11:07:19.986384
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-03-29 11:07:20.013179
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-03-29 11:07:20.017897
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-03-29 11:07:20.097159
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-03-29 11:07:20.622223
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-03-29 11:07:20.630588
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-03-29 11:07:20.641979
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-03-29 11:07:20.647677
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-03-29 11:07:20.652654
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-03-29 11:07:20.660073
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-03-29 11:07:20.673859
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-03-29 11:07:20.692666
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-03-29 11:07:20.757269
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-03-29 11:07:20.762235
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-03-29 11:07:20.767263
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-03-29 11:07:20.944514
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-03-29 11:07:20.955467
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-03-29 11:07:20.965666
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-03-29 11:07:20.971212
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-03-29 11:07:20.981453
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-03-29 11:07:20.9865
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-03-29 11:07:20.993933
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-03-29 11:07:21.028096
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-03-29 11:07:21.044403
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-03-29 11:07:21.049974
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-03-29 11:07:21.058404
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-03-29 11:07:21.064792
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-03-29 11:07:21.069209
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-03-29 11:07:21.074012
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-03-29 11:07:21.078587
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-03-29 11:07:21.083136
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-03-29 11:07:21.088878
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-03-29 11:07:21.096871
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-03-29 11:07:21.102499
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-03-29 11:07:21.108148
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-03-29 11:07:21.114418
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-03-29 11:07:21.119708
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-03-29 11:07:21.124114
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-03-29 11:07:21.135386
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-03-29 11:07:21.157554
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-03-29 11:07:21.162121
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-03-29 11:07:21.166646
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-03-29 11:07:21.17123
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-03-29 11:07:21.176242
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-03-29 11:07:21.181547
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-03-29 11:07:21.187118
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-03-29 11:07:21.227439
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-03-29 11:07:21.232766
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-03-29 11:07:21.237486
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-03-29 11:07:21.2672
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-03-29 11:07:21.27285
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-03-29 11:07:25.087069
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-03-29 11:07:25.089842
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-03-29 11:07:25.114783
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-03-29 11:07:25.117684
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-03-29 11:07:25.11957
57	s3-multipart-uploads-metadata	f127886e00d1b374fadbc7c6b31e09336aad5287	2026-05-03 11:13:12.452636
58	operation-ergonomics	00ca5d483b3fe0d522133d9002ccc5df98365120	2026-05-03 11:13:12.469465
56	fix-optimized-search-function	b823ed1e418101032fa01374edc9a436e54e3ed4	2026-03-29 11:07:25.159066
59	drop-unused-functions	38456f13e39691c2bbb4b5151d0d1cdbabd4a8c4	2026-05-06 01:59:36.853256
60	optimize-existing-functions-again	db35e1c91a9201e59f4fef8d972c2f277d68b157	2026-05-06 01:59:36.863371
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 417, true);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 3564, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 103240, true);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: dotptdoanvien dotptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "dotptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: duytricsdl duytricsdl_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."duytricsdl"
    ADD CONSTRAINT "duytricsdl_pkey" PRIMARY KEY ("id");


--
-- Name: github_settings github_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."github_settings"
    ADD CONSTRAINT "github_settings_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: ptdoanvien ptdoanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "ptdoanvien_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_ten_nam_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_ten_nam_unique" UNIQUE ("tenchidoan", "namhoc");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("matieuchi", "namhoc", "hocky");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem unique_chamdiem_record; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "unique_chamdiem_record" UNIQUE ("namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "chidoan_id");


--
-- Name: qlchidoan unique_namhoc_tenchidoan; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "unique_namhoc_tenchidoan" UNIQUE ("namhoc", "tenchidoan");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_09 messages_2026_05_09_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_09"
    ADD CONSTRAINT "messages_2026_05_09_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_10 messages_2026_05_10_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_10"
    ADD CONSTRAINT "messages_2026_05_10_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_11 messages_2026_05_11_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_11"
    ADD CONSTRAINT "messages_2026_05_11_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_12 messages_2026_05_12_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_12"
    ADD CONSTRAINT "messages_2026_05_12_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_13 messages_2026_05_13_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_13"
    ADD CONSTRAINT "messages_2026_05_13_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_14 messages_2026_05_14_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_14"
    ADD CONSTRAINT "messages_2026_05_14_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_05_15 messages_2026_05_15_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_05_15"
    ADD CONSTRAINT "messages_2026_05_15_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: idx_chamdiem_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_chidoan_id" ON "public"."chamdiem" USING "btree" ("chidoan_id");


--
-- Name: idx_chamdiem_doanvienid; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_doanvienid" ON "public"."chamdiem" USING "btree" ("doanvienid");


--
-- Name: idx_chamdiem_loaitieuchi; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_loaitieuchi" ON "public"."chamdiem" USING "btree" ("loaitieuchi");


--
-- Name: idx_chamdiem_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_namhoc" ON "public"."chamdiem" USING "btree" ("namhoc");


--
-- Name: idx_chamdiem_thoigian_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_chamdiem_thoigian_context" ON "public"."chamdiem" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_doanvien_chidoan_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_id" ON "public"."doanvien" USING "btree" ("chidoan_id");


--
-- Name: idx_doanvien_chidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_chidoan_namhoc" ON "public"."doanvien" USING "btree" ("chidoan_id", "namhoc");


--
-- Name: idx_doanvien_hoten; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_hoten" ON "public"."doanvien" USING "btree" ("hoten");


--
-- Name: idx_doanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_doanvien_namhoc" ON "public"."doanvien" USING "btree" ("namhoc");


--
-- Name: idx_dotptdoanvien_nam_hk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_nam_hk" ON "public"."dotptdoanvien" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_dotptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_dotptdoanvien_namhoc" ON "public"."dotptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_namhoc_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_namhoc_isdefault_true" ON "public"."namhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_phancong_chamlop; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_chamlop" ON "public"."phancong" USING "btree" ("chamlop");


--
-- Name: idx_phancong_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_context" ON "public"."phancong" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_phancong_lopcham; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_lopcham" ON "public"."phancong" USING "btree" ("lopcham");


--
-- Name: idx_phancong_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phancong_namhoc" ON "public"."phancong" USING "btree" ("namhoc");


--
-- Name: idx_phanquyen_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_phanquyen_namhoc" ON "public"."phanquyen" USING "btree" ("nam_hoc");


--
-- Name: idx_ptdoanvien_doanvien; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_doanvien" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: idx_ptdoanvien_dot; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_dot" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: idx_ptdoanvien_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_ptdoanvien_namhoc" ON "public"."ptdoanvien" USING "btree" ("namhoc");


--
-- Name: idx_qlchidoan_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_qlchidoan_namhoc" ON "public"."qlchidoan" USING "btree" ("namhoc");


--
-- Name: idx_settings_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_settings_namhoc" ON "public"."settings" USING "btree" ("namhoc");


--
-- Name: idx_taikhoan_chidoan; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_taikhoan_chidoan" ON "public"."taikhoan" USING "btree" ("chidoan_id");


--
-- Name: idx_tieuchitd_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_context" ON "public"."tieuchitd" USING "btree" ("namhoc", "hocky");


--
-- Name: idx_tieuchitd_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tieuchitd_namhoc" ON "public"."tieuchitd" USING "btree" ("namhoc");


--
-- Name: idx_tuan_isdefault_true; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX "idx_tuan_isdefault_true" ON "public"."tuanhoc" USING "btree" ("isdefault") WHERE ("isdefault" = true);


--
-- Name: idx_tuanhoc_context; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_context" ON "public"."tuanhoc" USING "btree" ("namhoc", "hocky", "tuan");


--
-- Name: idx_tuanhoc_namhoc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_tuanhoc_namhoc" ON "public"."tuanhoc" USING "btree" ("namhoc");


--
-- Name: ngay_3_5_idx_ptdoanvien_doanvien_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_doanvien_id" ON "public"."ptdoanvien" USING "btree" ("doanvien_id");


--
-- Name: ngay_3_5_idx_ptdoanvien_dotdangki; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "ngay_3_5_idx_ptdoanvien_dotdangki" ON "public"."ptdoanvien" USING "btree" ("dotdangki");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_09_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_09_inserted_at_topic_idx" ON "realtime"."messages_2026_05_09" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_10_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_10_inserted_at_topic_idx" ON "realtime"."messages_2026_05_10" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_11_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_11_inserted_at_topic_idx" ON "realtime"."messages_2026_05_11" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_12_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_12_inserted_at_topic_idx" ON "realtime"."messages_2026_05_12" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_13_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_13_inserted_at_topic_idx" ON "realtime"."messages_2026_05_13" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_14_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_14_inserted_at_topic_idx" ON "realtime"."messages_2026_05_14" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_05_15_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_05_15_inserted_at_topic_idx" ON "realtime"."messages_2026_05_15" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_key" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter");


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_05_09_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_09_inserted_at_topic_idx";


--
-- Name: messages_2026_05_09_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_09_pkey";


--
-- Name: messages_2026_05_10_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_10_inserted_at_topic_idx";


--
-- Name: messages_2026_05_10_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_10_pkey";


--
-- Name: messages_2026_05_11_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_11_inserted_at_topic_idx";


--
-- Name: messages_2026_05_11_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_11_pkey";


--
-- Name: messages_2026_05_12_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_12_inserted_at_topic_idx";


--
-- Name: messages_2026_05_12_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_12_pkey";


--
-- Name: messages_2026_05_13_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_13_inserted_at_topic_idx";


--
-- Name: messages_2026_05_13_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_13_pkey";


--
-- Name: messages_2026_05_14_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_14_inserted_at_topic_idx";


--
-- Name: messages_2026_05_14_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_14_pkey";


--
-- Name: messages_2026_05_15_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_05_15_inserted_at_topic_idx";


--
-- Name: messages_2026_05_15_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_05_15_pkey";


--
-- Name: qlchidoan trigger_chi_doan_deletion; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "trigger_chi_doan_deletion" AFTER DELETE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."handle_chi_doan_deletion"();


--
-- Name: chamdiem update_chamdiem_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_chamdiem_modtime" BEFORE UPDATE ON "public"."chamdiem" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: doanvien update_doanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_doanvien_modtime" BEFORE UPDATE ON "public"."doanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: dotptdoanvien update_dotptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_dotptdoanvien_modtime" BEFORE UPDATE ON "public"."dotptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: duytricsdl update_duytricsdl_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_duytricsdl_modtime" BEFORE UPDATE ON "public"."duytricsdl" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: github_settings update_github_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_github_settings_modtime" BEFORE UPDATE ON "public"."github_settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: namhoc update_namhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_namhoc_modtime" BEFORE UPDATE ON "public"."namhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phancong update_phancong_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phancong_modtime" BEFORE UPDATE ON "public"."phancong" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: phanquyen update_phanquyen_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_phanquyen_modtime" BEFORE UPDATE ON "public"."phanquyen" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: ptdoanvien update_ptdoanvien_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_ptdoanvien_modtime" BEFORE UPDATE ON "public"."ptdoanvien" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: qlchidoan update_qlchidoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_qlchidoan_modtime" BEFORE UPDATE ON "public"."qlchidoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: settings update_settings_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_settings_modtime" BEFORE UPDATE ON "public"."settings" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: taikhoan update_taikhoan_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_taikhoan_modtime" BEFORE UPDATE ON "public"."taikhoan" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tieuchitd update_tieuchitd_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tieuchitd_modtime" BEFORE UPDATE ON "public"."tieuchitd" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: tuanhoc update_tuanhoc_modtime; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "update_tuanhoc_modtime" BEFORE UPDATE ON "public"."tuanhoc" FOR EACH ROW EXECUTE FUNCTION "public"."update_modified_column"();


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_doanvien_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_doanvien_id_fkey" FOREIGN KEY ("doanvien_id") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien Ngay_3_5_ptdoanvien_dotdangki_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "Ngay_3_5_ptdoanvien_dotdangki_fkey" FOREIGN KEY ("dotdangki") REFERENCES "public"."dotptdoanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: activity_logs activity_logs_namhoc_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_namhoc_fkey" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id");


--
-- Name: chamdiem chamdiem_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_doanvienid_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_doanvienid_fkey" FOREIGN KEY ("doanvienid") REFERENCES "public"."doanvien"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem chamdiem_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien doanvien_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: chamdiem fk_chamdiem_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "fk_chamdiem_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: doanvien fk_doanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "fk_doanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: dotptdoanvien fk_dotptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."dotptdoanvien"
    ADD CONSTRAINT "fk_dotptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong fk_phancong_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "fk_phancong_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phanquyen fk_phanquyen_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "fk_phanquyen_namhoc" FOREIGN KEY ("nam_hoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ptdoanvien fk_ptdoanvien_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."ptdoanvien"
    ADD CONSTRAINT "fk_ptdoanvien_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: qlchidoan fk_qlchidoan_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "fk_qlchidoan_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: settings fk_settings_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "fk_settings_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tieuchitd fk_tieuchitd_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "fk_tieuchitd_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tuanhoc fk_tuanhoc_namhoc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "fk_tuanhoc_namhoc" FOREIGN KEY ("namhoc") REFERENCES "public"."namhoc"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_chamlop_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_chamlop_fkey" FOREIGN KEY ("chamlop") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: phancong phancong_lopcham_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_lopcham_fkey" FOREIGN KEY ("lopcham") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: taikhoan taikhoan_chidoan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_chidoan_id_fkey" FOREIGN KEY ("chidoan_id") REFERENCES "public"."qlchidoan"("id") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Admins can view all activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all activity logs" ON "public"."activity_logs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: activity_logs Authenticated users can insert activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users can insert activity logs" ON "public"."activity_logs" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: chamdiem Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."chamdiem" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: doanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."doanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: dotptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."dotptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: namhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."namhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phancong Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phancong" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: phanquyen Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."phanquyen" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: ptdoanvien Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."ptdoanvien" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: qlchidoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."qlchidoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: settings Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."settings" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: taikhoan Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."taikhoan" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tieuchitd Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tieuchitd" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: tuanhoc Authenticated users only; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users only" ON "public"."tuanhoc" TO "authenticated" USING (("auth"."role"() = 'authenticated'::"text")) WITH CHECK (("auth"."role"() = 'authenticated'::"text"));


--
-- Name: github_settings Cho phép Admin quản lý cấu hình github; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép Admin quản lý cấu hình github" ON "public"."github_settings" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: github_settings Cho phép người dùng đã đăng nhập thao tác github_se; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Cho phép người dùng đã đăng nhập thao tác github_se" ON "public"."github_settings" TO "authenticated" USING (true) WITH CHECK (true);


--
-- Name: taikhoan Enable read access for all users; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Enable read access for all users" ON "public"."taikhoan" FOR SELECT USING (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: chamdiem; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."chamdiem" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: dotptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."dotptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: github_settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."github_settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: phanquyen; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ENABLE ROW LEVEL SECURITY;

--
-- Name: ptdoanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."ptdoanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "postgres";

--
-- Name: supabase_realtime chamdiem; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."chamdiem";


--
-- Name: supabase_realtime doanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."doanvien";


--
-- Name: supabase_realtime dotptdoanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."dotptdoanvien";


--
-- Name: supabase_realtime github_settings; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."github_settings";


--
-- Name: supabase_realtime namhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."namhoc";


--
-- Name: supabase_realtime phancong; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phancong";


--
-- Name: supabase_realtime phanquyen; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."phanquyen";


--
-- Name: supabase_realtime ptdoanvien; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."ptdoanvien";


--
-- Name: supabase_realtime qlchidoan; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."qlchidoan";


--
-- Name: supabase_realtime settings; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."settings";


--
-- Name: supabase_realtime taikhoan; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."taikhoan";


--
-- Name: supabase_realtime tieuchitd; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tieuchitd";


--
-- Name: supabase_realtime tuanhoc; Type: PUBLICATION TABLE; Schema: public; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime" ADD TABLE ONLY "public"."tuanhoc";


--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: postgres
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "storage" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT USAGE ON SCHEMA "vault" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "handle_chi_doan_deletion"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_chi_doan_deletion"() TO "service_role";


--
-- Name: FUNCTION "handle_post_like"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_post_like"() TO "service_role";


--
-- Name: FUNCTION "handle_update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."handle_update_likes_count"() TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: FUNCTION "rpc_get_user_by_username"("p_username" "text"); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."rpc_get_user_by_username"("p_username" "text") TO "service_role";


--
-- Name: FUNCTION "update_likes_count"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_likes_count"() TO "service_role";


--
-- Name: FUNCTION "update_modified_column"(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_modified_column"() TO "service_role";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "supabase_realtime_admin";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: supabase_admin
--

SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "dotptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."dotptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."dotptdoanvien" TO "service_role";


--
-- Name: TABLE "duytricsdl"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."duytricsdl" TO "anon";
GRANT ALL ON TABLE "public"."duytricsdl" TO "authenticated";
GRANT ALL ON TABLE "public"."duytricsdl" TO "service_role";


--
-- Name: TABLE "github_settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."github_settings" TO "anon";
GRANT ALL ON TABLE "public"."github_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."github_settings" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "ptdoanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."ptdoanvien" TO "anon";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."ptdoanvien" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_05_09"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_09" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_09" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_10"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_10" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_10" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_11"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_11" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_11" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_12"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_12" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_12" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_13"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_13" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_13" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_14"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_14" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_14" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_05_15"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_05_15" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_05_15" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "anon";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "service_role";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "supabase_realtime_admin";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";
GRANT ALL ON TABLE "realtime"."subscription" TO "supabase_realtime_admin";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "supabase_realtime_admin";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
RESET SESSION AUTHORIZATION;
SET SESSION AUTHORIZATION "postgres";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
SET SESSION AUTHORIZATION "postgres";
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";
RESET SESSION AUTHORIZATION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict wZoGDSbaXqXkLq8Xlgflk4ibGZBchhyfvTKeWobu2FDOAriCa5Uiyyaha4gXKZm

